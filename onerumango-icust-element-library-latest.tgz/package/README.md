# IcustLibrary

This library was generated with [Angular CLI](https://github.com/angular/angular-cli) version 16.0.0.

## Code scaffolding

Run `ng generate component component-name --project icust-library` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module --project icust-library`.

> Note: Don't forget to add `--project icust-library` or else it will be added to the default project in your `angular.json` file.

## Build

Run `ng build icust-library` to build the project. The build artifacts will be stored in the `dist/` directory.

## Publishing

After building your library with `ng build icust-library`, go to the dist folder `cd dist/icust-library` and run `npm publish`.

## Running unit tests

Run `ng test icust-library` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.

## Usage of the Components from elememt library

There are various kind of Customized UI Components as you can see the respecrtive file address[lib >> components].

## Button

> Here is the list of possible class names derived from your CSS for the .ic-button component. I've categorized them based on their purpose to make them more structured. You can use size

# Class Names for .ic-button

# [Size Variants]

> small
> medium
> large

# [Filled Buttons]

> filled
> filled-warning
> filled-danger
> filled-neutral
> filled-basic

# [Filled Rounded Buttons]

> filled-rounded
> filled-rounded-warning
> filled-rounded-danger
> filled-rounded-neutral
> filled-rounded-basic

# [Outlined Buttons]

> outlined
> outlined-warning
> outlined-danger
> outlined-neutral
> outlined-basic

# [Outlined Rounded Buttons]

> outlined-rounded
> outlined-rounded-warning
> outlined-rounded-danger
> outlined-rounded-neutral
> outlined-rounded-basic

# [Outlined Transparent Buttons]

> outlined-transparent
> outlined-transparent-warning
> outlined-transparent-danger
> outlined-transparent-neutral
> outlined-transparent-basic

# [Outlined Rounded Transparent Buttons]

> outlined-rounded-transparent
> outlined-rounded-transparent-warning
> outlined-rounded-transparent-danger
> outlined-rounded-transparent-neutral
> outlined-rounded-transparent-basic

# [Ghost Buttons]

> ghost
> ghost-warning
> ghost-danger
> ghost-neutral
> ghost-basic

# [Ghost Rounded Buttons]

> ghost-rounded
> ghost-rounded-warning
> ghost-rounded-danger
> ghost-rounded-neutral
> ghost-rounded-basic

## Input Directives

# Directive Descriptions

[icAlphaNumericWithSpace]
Allows only alphanumeric characters (letters and numbers) and spaces in the input field.

[icAlphanumeric]
Restricts input to alphanumeric characters (letters and numbers) without allowing spaces.

[icIsUpperCase]
Automatically converts the input value to uppercase. It can be enabled or disabled dynamically using a boolean input.

[icNoInitialSpace]
Prevents the user from entering spaces at the beginning of the input field.

[icNoSpace]
Disallows any spaces in the input field.

[icNumbersOnly]
Restricts input to numbers only.

[icSpecialAlphaNumeric]
Allows alphanumeric characters along with specific special characters like [ _ ] (underscore).

[icSpecialText]
Permits text input along with specific special characters (such as punctuation or symbols).

[icNoSpecialCharFirst]
Disallows special characters as the first character in the input field but allows them elsewhere.

[icAlphabetOnly]
Restricts input to alphabetic characters (letters) and optionally spaces, if enabled.

[icRestrictPercentage]
Ensure your input fields behave as expected: Accept only valid percentages (e.g., 0-100, 99.99).Remove invalid characters automatically.Truncate extra decimals.

[icRestrictDecimal]
Type numbers and dots (123.45 should be valid). Ensure multiple dots (e.g., 12.3.45) are not allowed. Paste invalid text (abc123) and verify only valid numbers are retained.
