import * as i0 from '@angular/core';
import { Directive, Input, HostBinding, HostListener, InjectionToken, PLATFORM_ID, Inject, Optional, Self, NgModule, forwardRef, Injectable, Component, EventEmitter, Output, ContentChild, ViewChild, ViewEncapsulation } from '@angular/core';
import * as i1$1 from '@angular/common';
import { isPlatformServer, CommonModule, DatePipe, isPlatformBrowser, NgOptimizedImage } from '@angular/common';
import _Inputmask from 'inputmask';
import * as i2 from '@angular/forms';
import { NG_VALUE_ACCESSOR, FormControl, Validators, NgControl, ReactiveFormsModule, FormsModule } from '@angular/forms';
import Cleave from 'cleave.js';
import { map, shareReplay, debounceTime, distinctUntilChanged, auditTime, takeUntil } from 'rxjs/operators';
import * as i1 from '@angular/platform-browser';
import * as i2$1 from '@angular/common/http';
import { TemplatePortal } from '@angular/cdk/portal';
import * as i1$2 from '@angular/cdk/overlay';
import { Subject, fromEvent, merge } from 'rxjs';
import PerfectScrollbar from 'perfect-scrollbar';
import { ResizeObserver } from '@juggle/resize-observer';

class FlexLayoutDirective {
    constructor() {
        /** Flexbox container direction */
        this.fxLayout = 'row';
        /** Alignment of children along the main axis */
        this.fxLayoutAlign = 'start stretch';
        /** Flex property for the element */
        this.fxFlex = '1 1 auto'; // Default flex value
        /** Host bindings for styles */
        this.display = 'flex';
    }
    get flexDirection() {
        return this.fxLayout;
    }
    get justifyContent() {
        return this.extractAlignment('justify');
    }
    get alignItems() {
        return this.extractAlignment('align');
    }
    get flex() {
        return this.fxFlex;
    }
    get gap() {
        return this.fxLayoutGap;
    }
    /**
     * Helper function to extract justify-content and align-items
     * from the fxLayoutAlign input.
     */
    extractAlignment(type) {
        if (!this.fxLayoutAlign)
            return type === 'justify' ? 'flex-start' : 'stretch';
        const [justify, align] = this.fxLayoutAlign.split(' ');
        if (type === 'justify') {
            return this.mapJustifyContent(justify);
        }
        else if (type === 'align') {
            return this.mapAlignItems(align);
        }
        return 'stretch';
    }
    /** Maps fxLayoutAlign's justify-content values */
    mapJustifyContent(value) {
        const justifyMap = {
            start: 'flex-start',
            center: 'center',
            end: 'flex-end',
            'space-between': 'space-between',
            'space-around': 'space-around',
            'space-evenly': 'space-evenly',
        };
        return justifyMap[value] || 'flex-start';
    }
    /** Maps fxLayoutAlign's align-items values */
    mapAlignItems(value) {
        const alignMap = {
            start: 'flex-start',
            center: 'center',
            end: 'flex-end',
            stretch: 'stretch',
            baseline: 'baseline',
        };
        return alignMap[value] || 'stretch';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FlexLayoutDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: FlexLayoutDirective, selector: "[icFlexLayout]", inputs: { fxLayout: "fxLayout", fxLayoutAlign: "fxLayoutAlign", fxFlex: "fxFlex", fxLayoutGap: "fxLayoutGap" }, host: { properties: { "style.display": "this.display", "style.flex-direction": "this.flexDirection", "style.justify-content": "this.justifyContent", "style.align-items": "this.alignItems", "style.flex": "this.flex", "style.gap": "this.gap" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FlexLayoutDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icFlexLayout]',
                }]
        }], propDecorators: { fxLayout: [{
                type: Input
            }], fxLayoutAlign: [{
                type: Input
            }], fxFlex: [{
                type: Input
            }], fxLayoutGap: [{
                type: Input
            }], display: [{
                type: HostBinding,
                args: ['style.display']
            }], flexDirection: [{
                type: HostBinding,
                args: ['style.flex-direction']
            }], justifyContent: [{
                type: HostBinding,
                args: ['style.justify-content']
            }], alignItems: [{
                type: HostBinding,
                args: ['style.align-items']
            }], flex: [{
                type: HostBinding,
                args: ['style.flex']
            }], gap: [{
                type: HostBinding,
                args: ['style.gap']
            }] } });

class IsUpperCaseDirective {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.isUpperCase = true; // Default to true
    }
    onInputChange(event) {
        if (!this.isUpperCase)
            return;
        const input = event.target;
        // Get the cursor position
        const start = input.selectionStart || 0;
        const end = input.selectionEnd || 0;
        // Transform the value to uppercase
        const transformedValue = input.value.toUpperCase();
        if (input.value !== transformedValue) {
            // Update the value while preserving the cursor position
            this.renderer.setProperty(input, 'value', transformedValue);
            input.setSelectionRange(start, end); // Restore the cursor position
            input.dispatchEvent(new Event('input')); // Trigger Angular's change detection
        }
    }
    onPaste(event) {
        if (!this.isUpperCase)
            return;
        event.preventDefault();
        const clipboardData = event.clipboardData || window['clipboardData'];
        const pastedText = clipboardData?.getData('text') ?? '';
        const transformedValue = pastedText.toUpperCase();
        const input = this.el.nativeElement;
        const start = input.selectionStart || 0;
        // Update the value while inserting the pasted text
        const newValue = input.value.slice(0, start) +
            transformedValue +
            input.value.slice(start + pastedText.length);
        this.renderer.setProperty(input, 'value', newValue);
        input.setSelectionRange(start + transformedValue.length, start + transformedValue.length); // Adjust cursor position
        input.dispatchEvent(new Event('input')); // Trigger Angular's change detection
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IsUpperCaseDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: IsUpperCaseDirective, selector: "[icIsUpperCase]", inputs: { isUpperCase: ["icIsUpperCase", "isUpperCase"] }, host: { listeners: { "input": "onInputChange($event)", "paste": "onPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IsUpperCaseDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icIsUpperCase]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.Renderer2 }]; }, propDecorators: { isUpperCase: [{
                type: Input,
                args: ['icIsUpperCase']
            }], onInputChange: [{
                type: HostListener,
                args: ['input', ['$event']]
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class AlphaNumericWithSpaceDirective {
    constructor() {
        // Regular expression to allow alphanumeric characters, underscores, hyphens, dots, and spaces
        this.regexStr = '^[a-zA-Z0-9_\\-. ]*$';
    }
    onKeyPress(event) {
        if (this.isAlphanumericspace !== false) {
            // Test if the pressed key matches the allowed characters
            if (!new RegExp(this.regexStr).test(event.key)) {
                event.preventDefault();
            }
        }
    }
    blockPaste(event) {
        if (this.isAlphanumericspace !== false) {
            event.preventDefault();
            const clipboardData = event.clipboardData || window.clipboardData;
            const pastedData = clipboardData.getData('text');
            const validPastedData = this.upperCaseOnly
                ? pastedData.toUpperCase().replace(/[^a-zA-Z0-9_.\- ]/g, '')
                : pastedData.replace(/[^a-zA-Z0-9_.\- ]/g, '');
            // Check for validity before inserting the cleaned data
            if (new RegExp(this.regexStr).test(validPastedData)) {
                document.execCommand('insertText', false, validPastedData);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AlphaNumericWithSpaceDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: AlphaNumericWithSpaceDirective, selector: "[icAlphaNumericWithSpace]", inputs: { isAlphanumericspace: ["icAlphaNumericWithSpace", "isAlphanumericspace"], isAlphaNumeric: "isAlphaNumeric", upperCaseOnly: "upperCaseOnly" }, host: { listeners: { "keypress": "onKeyPress($event)", "paste": "blockPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AlphaNumericWithSpaceDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icAlphaNumericWithSpace]',
                }]
        }], propDecorators: { isAlphanumericspace: [{
                type: Input,
                args: ['icAlphaNumericWithSpace']
            }], isAlphaNumeric: [{
                type: Input
            }], upperCaseOnly: [{
                type: Input
            }], onKeyPress: [{
                type: HostListener,
                args: ['keypress', ['$event']]
            }], blockPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class NoInitialSpaceDirective {
    constructor(el) {
        this.el = el;
    }
    onInput(_event) {
        const inputElement = this.el.nativeElement;
        let inputValue = inputElement.value;
        if (inputValue.startsWith(' ')) {
            inputElement.value = inputValue.trimStart();
            // Manually trigger input event for Angular to detect the change
            inputElement.dispatchEvent(new Event('input'));
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NoInitialSpaceDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: NoInitialSpaceDirective, selector: "input, textarea", host: { listeners: { "input": "onInput($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NoInitialSpaceDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input, textarea', // Apply to all input fields and textareas
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { onInput: [{
                type: HostListener,
                args: ['input', ['$event']]
            }] } });

class NumbersOnlyDirective {
    constructor(_el) {
        this._el = _el;
        this.regexStructure = '^[0-9]*$'; // numbers accpt dots
    }
    onInputChange(event) {
        const initalValue = this._el.nativeElement.value;
        this._el.nativeElement.value = initalValue
            .replace(/[^0-9]/g, '')
            // Replace extra dots
            .replace('.', '%FD%')
            .replace(/\./g, '')
            .replace('%FD%', '.');
        if (initalValue !== this._el.nativeElement.value) {
            event.stopPropagation();
        }
    }
    onKeyPress(event) {
        if (this.isNumbersOnly !== false)
            return new RegExp(this.regexStructure).test(event.key);
        return;
    }
    blockPaste(event) {
        if (this.isNumbersOnly !== false)
            this.validationFields(event);
    }
    validationFields(event) {
        event.preventDefault();
        if (event.clipboardData === null)
            return;
        const pasteData = event.clipboardData
            .getData('text/plain')
            .replace(/[^0-9.]/g, '')
            .replace(/\.(?=.*\.)/g, ''); // Remove extra dots
        const inputElement = this._el.nativeElement;
        const start = inputElement.selectionStart;
        const end = inputElement.selectionEnd;
        const value = inputElement.value;
        // Update input value while keeping focus
        inputElement.value =
            value.substring(0, start) + pasteData + value.substring(end);
        // Manually set the cursor position
        const newPosition = start + pasteData.length;
        setTimeout(() => inputElement.setSelectionRange(newPosition, newPosition), 0);
        inputElement.dispatchEvent(new Event('input', { bubbles: true }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NumbersOnlyDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: NumbersOnlyDirective, selector: "[icNumbersOnly]", inputs: { isNumbersOnly: ["icNumbersOnly", "isNumbersOnly"] }, host: { listeners: { "ion-input": "onInputChange($event)", "keypress": "onKeyPress($event)", "paste": "blockPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NumbersOnlyDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icNumbersOnly]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { isNumbersOnly: [{
                type: Input,
                args: ['icNumbersOnly']
            }], onInputChange: [{
                type: HostListener,
                args: ['ion-input', ['$event']]
            }], onKeyPress: [{
                type: HostListener,
                args: ['keypress', ['$event']]
            }], blockPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class SpecialAlphaNumericDirective {
    constructor(renderer) {
        this.renderer = renderer;
        this.regex = /^[a-zA-Z0-9_]*$/; // Allows letters, numbers, and underscores
        this.specialIsAlphaNumeric = true;
    }
    // Listen for the 'input' event for handling keypresses and changes in input
    onInputChange(event) {
        if (!this.specialIsAlphaNumeric) {
            return; // Allow all characters if `specialIsAlphaNumeric` is false
        }
        const inputElement = event.target;
        const newValue = inputElement.value.replace(/[^a-zA-Z0-9_]/g, ''); // Remove anything that doesn't match the regex
        if (inputElement.value !== newValue) {
            this.renderer.setProperty(inputElement, 'value', newValue); // Update input value
        }
    }
    // Handle the 'paste' event to block unwanted characters during pasting
    onPaste(event) {
        if (!this.specialIsAlphaNumeric) {
            return; // Allow all pasted content if `specialIsAlphaNumeric` is false
        }
        const clipboardData = event.clipboardData?.getData('text') || '';
        if (!this.regex.test(clipboardData)) {
            event.preventDefault(); // Block paste if content doesn't match regex
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SpecialAlphaNumericDirective, deps: [{ token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: SpecialAlphaNumericDirective, selector: "[icSpecialAlphaNumeric]", inputs: { specialIsAlphaNumeric: ["icSpecialAlphaNumeric", "specialIsAlphaNumeric"] }, host: { listeners: { "input": "onInputChange($event)", "paste": "onPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SpecialAlphaNumericDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icSpecialAlphaNumeric]',
                }]
        }], ctorParameters: function () { return [{ type: i0.Renderer2 }]; }, propDecorators: { specialIsAlphaNumeric: [{
                type: Input,
                args: ['icSpecialAlphaNumeric']
            }], onInputChange: [{
                type: HostListener,
                args: ['input', ['$event']]
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class SpecialAlphaNumericExtendedDirective {
    constructor(renderer) {
        this.renderer = renderer;
        this.regex = /^[a-zA-Z0-9._-]*$/; // Allows letters, numbers, ., -, and _
        this.specialIsAlphaNumeric = true;
    }
    onInputChange(event) {
        if (!this.specialIsAlphaNumeric) {
            return; // Allow all characters if `specialIsAlphaNumeric` is false
        }
        const inputElement = event.target;
        const cleanedValue = inputElement.value.replace(/[^a-zA-Z0-9._-]/g, ''); // Remove invalid characters
        if (inputElement.value !== cleanedValue) {
            this.renderer.setProperty(inputElement, 'value', cleanedValue); // Update input field
            event.preventDefault(); // Prevent unwanted changes
        }
    }
    blockPaste(event) {
        if (!this.specialIsAlphaNumeric) {
            return; // Allow all pasted content if `specialIsAlphaNumeric` is false
        }
        this.validateFields(event);
    }
    validateFields(event) {
        const clipboardData = event.clipboardData?.getData('text') || '';
        if (!this.regex.test(clipboardData)) {
            event.preventDefault(); // Block paste if content doesn't match regex
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SpecialAlphaNumericExtendedDirective, deps: [{ token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: SpecialAlphaNumericExtendedDirective, selector: "[icSpecialAlphaNumericExtended]", inputs: { specialIsAlphaNumeric: ["icSpecialAlphaNumericExtended", "specialIsAlphaNumeric"] }, host: { listeners: { "input": "onInputChange($event)", "paste": "blockPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SpecialAlphaNumericExtendedDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icSpecialAlphaNumericExtended]',
                }]
        }], ctorParameters: function () { return [{ type: i0.Renderer2 }]; }, propDecorators: { specialIsAlphaNumeric: [{
                type: Input,
                args: ['icSpecialAlphaNumericExtended']
            }], onInputChange: [{
                type: HostListener,
                args: ['input', ['$event']]
            }], blockPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class SpecialTextDirective {
    constructor() {
        this.regex = /^[a-zA-Z0-9_.-]*$/; // Allows alphanumeric, dot, underscore, and hyphen
        this.specialText = true; // Default to true
    }
    onKeyPress(event) {
        if (this.specialText && !this.regex.test(event.key)) {
            event.preventDefault(); // Block invalid characters
        }
    }
    blockPaste(event) {
        if (this.specialText) {
            this.validateFields(event);
        }
    }
    validateFields(event) {
        event.preventDefault(); // Prevent the default paste behavior
        const clipboardData = event.clipboardData?.getData('text/plain') || '';
        const sanitizedData = clipboardData.replace(/[^a-zA-Z0-9_.-]/g, ''); // Remove invalid characters
        const inputElement = event.target;
        // Insert sanitized data into the input
        const start = inputElement.selectionStart || 0;
        const end = inputElement.selectionEnd || 0;
        const currentValue = inputElement.value;
        inputElement.value =
            currentValue.substring(0, start) +
                sanitizedData +
                currentValue.substring(end);
        // Update the caret position
        const newCaretPosition = start + sanitizedData.length;
        inputElement.setSelectionRange(newCaretPosition, newCaretPosition);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SpecialTextDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: SpecialTextDirective, selector: "[icSpecialText]", inputs: { specialText: ["icSpecialText", "specialText"] }, host: { listeners: { "keypress": "onKeyPress($event)", "paste": "blockPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SpecialTextDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icSpecialText]',
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { specialText: [{
                type: Input,
                args: ['icSpecialText']
            }], onKeyPress: [{
                type: HostListener,
                args: ['keypress', ['$event']]
            }], blockPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class NoSpaceDirective {
    constructor(renderer) {
        this.renderer = renderer;
        this.noSpace = true;
    }
    onKeyDown(event) {
        if (this.noSpace && event.key === ' ') {
            event.preventDefault(); // Prevent space keypress
        }
    }
    onInputChange(event) {
        if (this.noSpace) {
            const inputElement = event.target;
            const newValue = inputElement.value.replace(/\s+/g, ''); // Remove any spaces
            if (inputElement.value !== newValue) {
                this.renderer.setProperty(inputElement, 'value', newValue); // Update input without spaces
            }
        }
    }
    onPaste(event) {
        if (this.noSpace) {
            const clipboardData = event.clipboardData?.getData('text') || '';
            if (/\s/.test(clipboardData)) {
                event.preventDefault(); // Prevent pasting if it contains spaces
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NoSpaceDirective, deps: [{ token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: NoSpaceDirective, selector: "[icNoSpace]", inputs: { noSpace: ["icNoSpace", "noSpace"] }, host: { listeners: { "keydown": "onKeyDown($event)", "input": "onInputChange($event)", "paste": "onPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NoSpaceDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icNoSpace]',
                }]
        }], ctorParameters: function () { return [{ type: i0.Renderer2 }]; }, propDecorators: { noSpace: [{
                type: Input,
                args: ['icNoSpace']
            }], onKeyDown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }], onInputChange: [{
                type: HostListener,
                args: ['input', ['$event']]
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class AlphanumericDirective {
    constructor(el) {
        this.el = el;
        this.isAlphanumeric = true;
        this.regexStr = '^[a-zA-Z0-9]*$';
    }
    onKeyPress(event) {
        if (this.isAlphanumeric)
            return new RegExp(this.regexStr).test(event.key);
        else
            return event.key;
    }
    blockPaste(event) {
        if (this.isAlphanumeric)
            this.validateFields(event);
    }
    validateFields(event) {
        setTimeout(() => {
            this.el.nativeElement.value = this.el.nativeElement.value.replace(/[^A-Za-z0-9 ]/g, '');
            event.preventDefault();
        }, 100);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AlphanumericDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: AlphanumericDirective, selector: "[icAlphanumeric]", inputs: { isAlphanumeric: ["icAlphanumeric", "isAlphanumeric"] }, host: { listeners: { "keypress": "onKeyPress($event)", "paste": "blockPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AlphanumericDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icAlphanumeric]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { isAlphanumeric: [{
                type: Input,
                args: ['icAlphanumeric']
            }], onKeyPress: [{
                type: HostListener,
                args: ['keypress', ['$event']]
            }], blockPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class NoSpecialCharFirstDirective {
    constructor(el) {
        this.el = el;
        this.NoSpecialCharFirst = true;
    }
    onInputChange() {
        const initialValue = this.el.nativeElement.value;
        if (typeof initialValue !== 'string' || !initialValue.length) {
            return;
        }
        const firstChar = initialValue.charAt(0);
        if (!this.isValidFirstChar(firstChar)) {
            // Remove special characters from the first position
            const newValue = initialValue.slice(1);
            this.el.nativeElement.value = newValue;
        }
    }
    isValidFirstChar(char) {
        // Define the allowed characters for the first position
        const allowedChars = /^[a-zA-Z0-9]+$/;
        return allowedChars.test(char);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NoSpecialCharFirstDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: NoSpecialCharFirstDirective, selector: "[icNoSpecialCharFirst]", inputs: { NoSpecialCharFirst: ["icNoSpecialCharFirst", "NoSpecialCharFirst"] }, host: { listeners: { "input": "onInputChange($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NoSpecialCharFirstDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icNoSpecialCharFirst]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { NoSpecialCharFirst: [{
                type: Input,
                args: ['icNoSpecialCharFirst']
            }], onInputChange: [{
                type: HostListener,
                args: ['input', ['$event']]
            }] } });

class AlphabetOnlyDirective {
    constructor() {
        this.appAlphabetOnly = true;
    }
    onKeydown(event) {
        if (this.appAlphabetOnly !== false) {
            const key = event.key;
            // Allow navigation keys and system keys
            if (key.length === 1 && // Single character keys
                !/^[a-zA-Z ]$/.test(key) // Allow alphabets and space only
            ) {
                event.preventDefault();
            }
        }
    }
    onPaste(event) {
        if (this.appAlphabetOnly !== false) {
            const clipboardData = event.clipboardData || window.clipboardData;
            const pastedText = clipboardData.getData('text');
            if (!this.isAlpha(pastedText)) {
                event.preventDefault();
            }
        }
    }
    isAlpha(text) {
        // Check if text contains only alphabets and spaces
        const alphabetRegex = /^[a-zA-Z ]*$/;
        return alphabetRegex.test(text);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AlphabetOnlyDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: AlphabetOnlyDirective, selector: "[icAlphabetOnly]", inputs: { appAlphabetOnly: ["icAlphabetOnly", "appAlphabetOnly"] }, host: { listeners: { "keydown": "onKeydown($event)", "paste": "onPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AlphabetOnlyDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icAlphabetOnly]',
                }]
        }], propDecorators: { appAlphabetOnly: [{
                type: Input,
                args: ['icAlphabetOnly']
            }], onKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class RestrictPercentageDirective {
    constructor(el) {
        this.el = el;
        this.enableRestrict = true; // Enable/Disable the directive
        this.maxNumber = 100; // Maximum allowed value
        this.maxDecimal = 2; // Maximum allowed decimal places
    }
    onInput(event) {
        if (!this.enableRestrict) {
            return; // Skip restriction if the directive is disabled
        }
        const inputValue = event.target.value;
        // Allow only valid numbers or decimals
        if (!this.isValidNumber(inputValue)) {
            const sanitizedValue = this.sanitizeValue(inputValue);
            this.updateInputValue(sanitizedValue);
        }
        else {
            const parsedValue = parseFloat(inputValue);
            // Ensure the value does not exceed the maximum allowed value
            if (!isNaN(parsedValue) && parsedValue > this.maxNumber) {
                this.updateInputValue(this.maxNumber.toString());
            }
            // Restrict to maximum decimal places
            const decimalIndex = inputValue.indexOf('.');
            if (decimalIndex !== -1 &&
                inputValue.length - decimalIndex - 1 > this.maxDecimal) {
                const trimmedValue = inputValue.substring(0, decimalIndex + this.maxDecimal + 1);
                this.updateInputValue(trimmedValue);
            }
        }
    }
    /**
     * Validates if the input value is a valid percentage (0-100 with up to 2 decimal places).
     */
    isValidNumber(value) {
        const regex = /^(100(\.0{1,2})?|[0-9]{1,2}(\.[0-9]{1,2})?)$/;
        return regex.test(value);
    }
    /**
     * Sanitizes the input value by removing invalid characters.
     */
    sanitizeValue(value) {
        const regex = /[^0-9.]/g; // Remove all non-numeric and non-decimal characters
        return value.replace(regex, '');
    }
    /**
     * Updates the input value programmatically and triggers the 'input' event.
     */
    updateInputValue(newValue) {
        this.el.nativeElement.value = newValue;
        this.el.nativeElement.dispatchEvent(new Event('input'));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RestrictPercentageDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: RestrictPercentageDirective, selector: "[icRestrictPercentage]", inputs: { enableRestrict: ["icRestrictPercentage", "enableRestrict"] }, host: { listeners: { "input": "onInput($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RestrictPercentageDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icRestrictPercentage]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { enableRestrict: [{
                type: Input,
                args: ['icRestrictPercentage']
            }], onInput: [{
                type: HostListener,
                args: ['input', ['$event']]
            }] } });

class RestrictDecimalDirective {
    constructor(_el) {
        this._el = _el;
        this.regexStructure = '^[0-9]*$'; // numbers accpt dots
    }
    onInputChange(event) {
        const initalValue = this._el.nativeElement.value;
        this._el.nativeElement.value = initalValue.replace(/[^0-9]/g, '');
        if (initalValue !== this._el.nativeElement.value) {
            event.stopPropagation();
        }
    }
    onKeyPress(event) {
        return new RegExp(this.regexStructure).test(event.key);
    }
    blockPaste(event) {
        event.preventDefault();
        const pasteData = event.clipboardData
            .getData('text/plain')
            .replace(/[^0-9]/g, '');
        document.execCommand('insertHTML', false, pasteData);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RestrictDecimalDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: RestrictDecimalDirective, selector: "ion-input[icRestrictDecimal],[icRestrictDecimal]", host: { listeners: { "ion-input": "onInputChange($event)", "keypress": "onKeyPress($event)", "paste": "blockPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RestrictDecimalDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ion-input[icRestrictDecimal],[icRestrictDecimal]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { onInputChange: [{
                type: HostListener,
                args: ['ion-input', ['$event']]
            }], onKeyPress: [{
                type: HostListener,
                args: ['keypress', ['$event']]
            }], blockPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class TwoDigitDecimalNumberDirective {
    constructor(el) {
        this.el = el;
        this.icTwoDigitDecimalNumber = true;
        this.decimalPlaces = 2;
        this.numLength = 10;
    }
    onInput() {
        if (!this.icTwoDigitDecimalNumber)
            return;
        const inputElement = this.el.nativeElement;
        const originalValue = inputElement.value || '';
        let inputValue = originalValue.replace(/[^0-9.]/g, '');
        const decimalIndex = inputValue.indexOf('.');
        if (decimalIndex !== -1) {
            inputValue =
                inputValue.substring(0, decimalIndex + 1) +
                    inputValue.substring(decimalIndex + 1).replace(/\./g, '');
        }
        if (inputValue.startsWith('0') &&
            !inputValue.startsWith('0.') &&
            inputValue.length > 1) {
            inputValue = inputValue.slice(1);
        }
        const [integerPart = '', decimalPart = ''] = inputValue.split('.');
        if (integerPart.length > this.numLength) {
            inputValue =
                integerPart.slice(0, this.numLength) +
                    (decimalPart !== undefined ? '.' + decimalPart : '');
        }
        if (decimalPart.length > this.decimalPlaces) {
            inputValue = integerPart + '.' + decimalPart.slice(0, this.decimalPlaces);
        }
        if (inputValue !== originalValue) {
            inputElement.value = inputValue;
            inputElement.dispatchEvent(new Event('input', { bubbles: true }));
        }
    }
    onPaste(event) {
        if (!this.icTwoDigitDecimalNumber)
            return;
        const clipboardData = event.clipboardData?.getData('text');
        if (!clipboardData)
            return;
        let pastedValue = clipboardData.replace(/[^0-9.]/g, '');
        const decimalIndex = pastedValue.indexOf('.');
        if (decimalIndex !== -1) {
            pastedValue =
                pastedValue.substring(0, decimalIndex + 1) +
                    pastedValue.substring(decimalIndex + 1).replace(/\./g, '');
        }
        if (pastedValue.startsWith('0') &&
            !pastedValue.startsWith('0.') &&
            pastedValue.length > 1) {
            pastedValue = pastedValue.slice(1);
        }
        const [integerPart = '', decimalPart = ''] = pastedValue.split('.');
        if (integerPart.length > this.numLength) {
            pastedValue =
                integerPart.slice(0, this.numLength) +
                    (decimalPart !== undefined ? '.' + decimalPart : '');
        }
        if (decimalPart.length > this.decimalPlaces) {
            pastedValue =
                integerPart + '.' + decimalPart.slice(0, this.decimalPlaces);
        }
        const inputElement = this.el.nativeElement;
        if (inputElement.value !== pastedValue) {
            inputElement.value = pastedValue;
            inputElement.dispatchEvent(new Event('input', { bubbles: true }));
        }
        event.preventDefault();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TwoDigitDecimalNumberDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: TwoDigitDecimalNumberDirective, selector: "[icTwoDigitDecimalNumber]", inputs: { icTwoDigitDecimalNumber: "icTwoDigitDecimalNumber", decimalPlaces: "decimalPlaces", numLength: "numLength" }, host: { listeners: { "input": "onInput()", "paste": "onPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TwoDigitDecimalNumberDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icTwoDigitDecimalNumber]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { icTwoDigitDecimalNumber: [{
                type: Input
            }], decimalPlaces: [{
                type: Input
            }], numLength: [{
                type: Input
            }], onInput: [{
                type: HostListener,
                args: ['input']
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class InputMaskConfig {
    constructor() {
        this.isAsync = false;
        this.inputSelector = 'input';
    }
}
const INPUT_MASK_CONFIG = new InjectionToken('InputMaskConfig');

const createMask = (options) => typeof options === 'string' ? { mask: options } : options;

const InputmaskConstructor = _Inputmask.default ||
    _Inputmask;
class InputMaskDirective {
    /**
     * Helps you to create input-mask based on https://github.com/RobinHerbots/Inputmask
     * Supports form-validation out-of-the box.
     * Visit https://github.com/ngneat/input-mask for more info.
     */
    set inputMask(inputMask) {
        if (inputMask) {
            this.inputMaskOptions = inputMask;
            this.updateInputMask();
        }
    }
    constructor(platformId, elementRef, renderer, ngControl, config, ngZone) {
        this.platformId = platformId;
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.ngControl = ngControl;
        this.ngZone = ngZone;
        this.inputMaskPlugin = null;
        this.nativeInputElement = null;
        this.defaultInputMaskConfig = new InputMaskConfig();
        this.inputMaskOptions = null;
        /* The original `onChange` function coming from the `setUpControl`. */
        this.onChange = () => {
            console.log();
        };
        this.mutationObserver = null;
        this.onInput = (_) => {
            console.log(_);
        };
        this.onTouched = (_) => {
            console.log(_);
        };
        this.validate = (control) => !control.value || !this.inputMaskPlugin || this.inputMaskPlugin.isValid()
            ? null
            : { inputMask: true };
        if (this.ngControl != null) {
            this.ngControl.valueAccessor = this;
        }
        this.setNativeInputElement(config);
    }
    ngOnInit() {
        // throw new Error('Method not implemented.');
    }
    ngOnDestroy() {
        this.removeInputMaskPlugin();
        this.mutationObserver?.disconnect();
    }
    writeValue(value) {
        const formatter = this.inputMaskOptions?.formatter;
        if (this.nativeInputElement) {
            this.renderer.setProperty(this.nativeInputElement, 'value', formatter && value ? formatter(value) : (value ?? ''));
        }
    }
    registerOnChange(onChange) {
        this.onChange = onChange;
        const parser = this.inputMaskOptions?.parser;
        this.onInput = (value) => {
            this.onChange(parser && value ? parser(value) : value);
        };
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(disabled) {
        if (this.nativeInputElement) {
            this.renderer.setProperty(this.nativeInputElement, 'disabled', disabled);
        }
    }
    updateInputMask() {
        this.removeInputMaskPlugin();
        this.createInputMaskPlugin();
        // This re-creates the `onInput` function since `inputMaskOptions` might be changed and the `parser`
        // property now differs.
        this.registerOnChange(this.onChange);
    }
    createInputMaskPlugin() {
        const { nativeInputElement, inputMaskOptions } = this;
        if (isPlatformServer(this.platformId) ||
            !nativeInputElement ||
            inputMaskOptions === null ||
            Object.keys(inputMaskOptions).length === 0) {
            return;
        }
        const { parser, formatter, ...options } = inputMaskOptions;
        this.inputMaskPlugin = this.ngZone.runOutsideAngular(() => new InputmaskConstructor(options).mask(nativeInputElement));
        if (this.control) {
            setTimeout(() => {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                this.control.updateValueAndValidity();
            });
        }
    }
    get control() {
        return this.ngControl?.control;
    }
    setNativeInputElement(config) {
        if (this.elementRef.nativeElement.tagName === 'INPUT') {
            this.nativeInputElement = this.elementRef.nativeElement;
        }
        else {
            this.defaultInputMaskConfig = {
                ...this.defaultInputMaskConfig,
                ...config,
            };
            if (this.defaultInputMaskConfig.isAsync) {
                // Create an observer instance linked to the callback function
                this.mutationObserver = new MutationObserver((mutationsList) => {
                    for (const mutation of mutationsList) {
                        if (mutation.type === 'childList') {
                            const nativeInputElement = this.elementRef.nativeElement.querySelector(this.defaultInputMaskConfig.inputSelector);
                            if (nativeInputElement) {
                                this.nativeInputElement = nativeInputElement;
                                this.mutationObserver?.disconnect();
                                this.createInputMaskPlugin();
                            }
                        }
                    }
                });
                // Start observing the target node for configured mutations
                this.mutationObserver.observe(this.elementRef.nativeElement, {
                    childList: true,
                    subtree: true,
                });
            }
            else {
                this.nativeInputElement = this.elementRef.nativeElement.querySelector(this.defaultInputMaskConfig.inputSelector);
            }
        }
    }
    removeInputMaskPlugin() {
        this.inputMaskPlugin?.remove();
        this.inputMaskPlugin = null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: InputMaskDirective, deps: [{ token: PLATFORM_ID }, { token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i2.NgControl, optional: true, self: true }, { token: INPUT_MASK_CONFIG }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: InputMaskDirective, selector: "[inputMask]", inputs: { inputMask: "inputMask" }, host: { listeners: { "input": "onInput($event.target.value)", "blur": "onTouched($event.target.value)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: InputMaskDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[inputMask]',
                }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }, { type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i2.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }, { type: InputMaskConfig, decorators: [{
                    type: Inject,
                    args: [INPUT_MASK_CONFIG]
                }] }, { type: i0.NgZone }]; }, propDecorators: { inputMask: [{
                type: Input
            }], onInput: [{
                type: HostListener,
                args: ['input', ['$event.target.value']]
            }], onTouched: [{
                type: HostListener,
                args: ['blur', ['$event.target.value']]
            }] } });

class InputMaskModule {
    static forRoot(config) {
        return {
            ngModule: InputMaskModule,
            providers: [{ provide: INPUT_MASK_CONFIG, useValue: config }],
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: InputMaskModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: InputMaskModule, declarations: [InputMaskDirective], exports: [InputMaskDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: InputMaskModule, providers: [
            {
                provide: INPUT_MASK_CONFIG,
                useClass: InputMaskConfig,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: InputMaskModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [InputMaskDirective],
                    exports: [InputMaskDirective],
                    providers: [
                        {
                            provide: INPUT_MASK_CONFIG,
                            useClass: InputMaskConfig,
                        },
                    ],
                }]
        }] });

class ImageLazyLoadDirective {
    constructor(el) {
        this.el = el;
        this.srcAttr = null;
    }
    ngOnChanges(changes) {
        if (changes['appLazyLoad']?.currentValue) {
            const imageElement = this.el.nativeElement;
            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        this.srcAttr = this.icLazyLoad;
                        observer.unobserve(imageElement);
                    }
                });
            });
            observer.observe(imageElement);
        }
    }
    // Handle error event and set the fallback image
    onError() {
        this.srcAttr = this.fallbackImage; // Set fallback image if image loading fails
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ImageLazyLoadDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: ImageLazyLoadDirective, selector: "[icLazyLoad]", inputs: { icLazyLoad: "icLazyLoad", fallbackImage: "fallbackImage" }, host: { listeners: { "error": "onError()" }, properties: { "attr.src": "this.srcAttr" } }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ImageLazyLoadDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icLazyLoad]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { icLazyLoad: [{
                type: Input,
                args: ['icLazyLoad']
            }], fallbackImage: [{
                type: Input,
                args: ['fallbackImage']
            }], srcAttr: [{
                type: HostBinding,
                args: ['attr.src']
            }], onError: [{
                type: HostListener,
                args: ['error']
            }] } });

class PreventInitialZeroDirective {
    constructor(el) {
        this.el = el;
        this.icPreventInitialZero = true;
    }
    onKeydown(event) {
        if (!this.icPreventInitialZero) {
            return;
        }
        const inputElement = this.el.nativeElement;
        const inputValue = inputElement.value;
        // Prevent '0' as the first character (unless followed by '.')
        if (inputValue.length === 0 && event.key === '0') {
            event.preventDefault();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PreventInitialZeroDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: PreventInitialZeroDirective, selector: "[icPreventInitialZero]", inputs: { icPreventInitialZero: "icPreventInitialZero" }, host: { listeners: { "keydown": "onKeydown($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PreventInitialZeroDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icPreventInitialZero]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { icPreventInitialZero: [{
                type: Input
            }], onKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

class DateFormatEnforcerDirective {
    constructor(el, control) {
        this.el = el;
        this.control = control;
    }
    ngOnInit() {
        this.el.nativeElement.placeholder = 'MM-DD-YYYY';
        this.el.nativeElement.maxLength = 10;
    }
    onKeyDown(event) {
        const input = this.el.nativeElement;
        const pos = input.selectionStart ?? 0;
        const isNavKey = [
            'ArrowLeft',
            'ArrowRight',
            'Tab',
            'Shift',
            'Home',
            'End',
        ].includes(event.key);
        const isControl = event.ctrlKey || event.metaKey;
        if (isNavKey || isControl)
            return;
        const isDigit = /^\d$/.test(event.key);
        const isBackspace = event.key === 'Backspace';
        const isDelete = event.key === 'Delete';
        if (!isDigit && !isBackspace && !isDelete) {
            event.preventDefault();
            return;
        }
        const val = input.value;
        // Prevent deletion of dashes
        if ((isBackspace && val[pos - 1] === '-') ||
            (isDelete && val[pos] === '-')) {
            event.preventDefault();
            return;
        }
        // Prevent inserting digits at dash positions
        if (isDigit && (pos === 2 || pos === 5)) {
            event.preventDefault();
            input.setSelectionRange(pos + 1, pos + 1);
        }
    }
    onInput() {
        const input = this.el.nativeElement;
        let digits = input.value.replace(/\D/g, '').slice(0, 8);
        let formatted = '';
        if (digits.length >= 2) {
            formatted += digits.slice(0, 2) + '-';
        }
        else {
            formatted += digits;
            this.setValue(formatted);
            return;
        }
        if (digits.length >= 4) {
            formatted += digits.slice(2, 4) + '-';
        }
        else {
            formatted += digits.slice(2);
            this.setValue(formatted);
            return;
        }
        if (digits.length > 4) {
            formatted += digits.slice(4);
        }
        input.value = formatted;
        this.setValue(formatted);
    }
    onBlur() {
        const input = this.el.nativeElement;
        const digits = input.value.replace(/\D/g, '');
        if (digits.length !== 8) {
            this.control.control?.setErrors({ invalidDate: true });
            return;
        }
        const formatted = this.formatToDate(digits);
        if (this.isValidDate(formatted)) {
            input.value = formatted;
            this.setValue(formatted);
            this.control.control?.setErrors(null);
        }
        else {
            this.control.control?.setErrors({ invalidDate: true });
        }
    }
    onPaste(event) {
        event.preventDefault();
        const pasted = event.clipboardData?.getData('text') ?? '';
        const digits = pasted.replace(/\D/g, '').slice(0, 8);
        const input = this.el.nativeElement;
        if (digits.length === 8) {
            const formatted = this.formatToDate(digits);
            input.value = formatted;
            this.setValue(formatted);
        }
    }
    formatToDate(digits) {
        return `${digits.slice(0, 2)}-${digits.slice(2, 4)}-${digits.slice(4, 8)}`;
    }
    isValidDate(value) {
        const parts = value.split('-');
        if (parts.length !== 3)
            return false;
        const mm = parseInt(parts[0], 10);
        const dd = parseInt(parts[1], 10);
        const yyyy = parseInt(parts[2], 10);
        if (isNaN(mm) || isNaN(dd) || isNaN(yyyy))
            return false;
        const date = new Date(yyyy, mm - 1, dd);
        return (date.getFullYear() === yyyy &&
            date.getMonth() === mm - 1 &&
            date.getDate() === dd);
    }
    setValue(value) {
        this.control.control?.setValue(value, { emitEvent: false });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DateFormatEnforcerDirective, deps: [{ token: i0.ElementRef }, { token: i2.NgControl }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: DateFormatEnforcerDirective, selector: "[icDateFormatEnforcer]", host: { listeners: { "keydown": "onKeyDown($event)", "input": "onInput()", "blur": "onBlur()", "paste": "onPaste($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DateFormatEnforcerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icDateFormatEnforcer]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i2.NgControl }]; }, propDecorators: { onKeyDown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }], onInput: [{
                type: HostListener,
                args: ['input']
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

const currencyList = {
    AED: {
        code: 'AED',
        symbol: 'د.إ.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    AFN: {
        code: 'AFN',
        symbol: '؋',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    ALL: {
        code: 'ALL',
        symbol: 'Lek',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    AMD: {
        code: 'AMD',
        symbol: '֏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    ANG: {
        code: 'ANG',
        symbol: 'ƒ',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    AOA: {
        code: 'AOA',
        symbol: 'Kz',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    ARS: {
        code: 'ARS',
        symbol: '$',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    AUD: {
        code: 'AUD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    AWG: {
        code: 'AWG',
        symbol: 'ƒ',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    AZN: {
        code: 'AZN',
        symbol: '₼',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    BAM: {
        code: 'BAM',
        symbol: 'КМ',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    BBD: {
        code: 'BBD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    BDT: {
        code: 'BDT',
        symbol: '৳',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 0,
    },
    BGN: {
        code: 'BGN',
        symbol: 'лв.',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    BHD: {
        code: 'BHD',
        symbol: 'د.ب.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 3,
    },
    BIF: {
        code: 'BIF',
        symbol: 'FBu',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    BMD: {
        code: 'BMD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    BND: {
        code: 'BND',
        symbol: '$',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    BOB: {
        code: 'BOB',
        symbol: 'Bs',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    BRL: {
        code: 'BRL',
        symbol: 'R$',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    BSD: {
        code: 'BSD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    BTC: {
        code: 'BTC',
        symbol: 'Ƀ',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 8,
    },
    BTN: {
        code: 'BTN',
        symbol: 'Nu.',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 1,
    },
    BWP: {
        code: 'BWP',
        symbol: 'P',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    BYR: {
        code: 'BYR',
        symbol: 'р.',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    BYN: {
        code: 'BYN',
        symbol: 'р.',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    BZD: {
        code: 'BZD',
        symbol: 'BZ$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    CAD: {
        code: 'CAD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    CDF: {
        code: 'CDF',
        symbol: 'FC',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    CHF: {
        code: 'CHF',
        symbol: 'CHF',
        thousandsSeparator: "'",
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    CLP: {
        code: 'CLP',
        symbol: '$',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 0,
    },
    CNY: {
        code: 'CNY',
        symbol: '¥',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    COP: {
        code: 'COP',
        symbol: '$',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    CRC: {
        code: 'CRC',
        symbol: '₡',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    CUC: {
        code: 'CUC',
        symbol: 'CUC',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    CUP: {
        code: 'CUP',
        symbol: '$MN',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    CVE: {
        code: 'CVE',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    CZK: {
        code: 'CZK',
        symbol: 'Kč',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    DJF: {
        code: 'DJF',
        symbol: 'Fdj',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    DKK: {
        code: 'DKK',
        symbol: 'kr.',
        thousandsSeparator: '',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    DOP: {
        code: 'DOP',
        symbol: 'RD$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    DZD: {
        code: 'DZD',
        symbol: 'د.ج.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    EGP: {
        code: 'EGP',
        symbol: 'ج.م.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    ERN: {
        code: 'ERN',
        symbol: 'Nfk',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    ETB: {
        code: 'ETB',
        symbol: 'ETB',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    EUR: {
        code: 'EUR',
        symbol: '€',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    FJD: {
        code: 'FJD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    FKP: {
        code: 'FKP',
        symbol: '£',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    GBP: {
        code: 'GBP',
        symbol: '£',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    GEL: {
        code: 'GEL',
        symbol: 'GEL',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    GHS: {
        code: 'GHS',
        symbol: '₵',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    GIP: {
        code: 'GIP',
        symbol: '£',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    GMD: {
        code: 'GMD',
        symbol: 'D',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    GNF: {
        code: 'GNF',
        symbol: 'FG',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    GTQ: {
        code: 'GTQ',
        symbol: 'Q',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    GYD: {
        code: 'GYD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    HKD: {
        code: 'HKD',
        symbol: 'HK$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    HNL: {
        code: 'HNL',
        symbol: 'L.',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    HRK: {
        code: 'HRK',
        symbol: 'kn',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    HTG: {
        code: 'HTG',
        symbol: 'G',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    HUF: {
        code: 'HUF',
        symbol: 'Ft',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    IDR: {
        code: 'IDR',
        symbol: 'Rp',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    ILS: {
        code: 'ILS',
        symbol: '₪',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    INR: {
        code: 'INR',
        symbol: '₹',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    IQD: {
        code: 'IQD',
        symbol: 'د.ع.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    IRR: {
        code: 'IRR',
        symbol: '﷼',
        thousandsSeparator: ',',
        decimalSeparator: '/',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    ISK: {
        code: 'ISK',
        symbol: 'kr.',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 0,
    },
    JMD: {
        code: 'JMD',
        symbol: 'J$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    JOD: {
        code: 'JOD',
        symbol: 'د.ا.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 3,
    },
    JPY: {
        code: 'JPY',
        symbol: '¥',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    KES: {
        code: 'KES',
        symbol: 'KSh',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    KGS: {
        code: 'KGS',
        symbol: 'сом',
        thousandsSeparator: ' ',
        decimalSeparator: '-',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    KHR: {
        code: 'KHR',
        symbol: '៛',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    KMF: {
        code: 'KMF',
        symbol: 'CF',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    KPW: {
        code: 'KPW',
        symbol: '₩',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    KRW: {
        code: 'KRW',
        symbol: '₩',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    KWD: {
        code: 'KWD',
        symbol: 'د.ك.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 3,
    },
    KYD: {
        code: 'KYD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    KZT: {
        code: 'KZT',
        symbol: '₸',
        thousandsSeparator: ' ',
        decimalSeparator: '-',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    LAK: {
        code: 'LAK',
        symbol: '₭',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    LBP: {
        code: 'LBP',
        symbol: 'ل.ل.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    LKR: {
        code: 'LKR',
        symbol: '₨',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 0,
    },
    LRD: {
        code: 'LRD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    LSL: {
        code: 'LSL',
        symbol: 'M',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    LYD: {
        code: 'LYD',
        symbol: 'د.ل.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 3,
    },
    MAD: {
        code: 'MAD',
        symbol: 'د.م.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    MDL: {
        code: 'MDL',
        symbol: 'lei',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    MGA: {
        code: 'MGA',
        symbol: 'Ar',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    MKD: {
        code: 'MKD',
        symbol: 'ден.',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    MMK: {
        code: 'MMK',
        symbol: 'K',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    MNT: {
        code: 'MNT',
        symbol: '₮',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    MOP: {
        code: 'MOP',
        symbol: 'MOP$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    MRO: {
        code: 'MRO',
        symbol: 'UM',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    MTL: {
        code: 'MTL',
        symbol: '₤',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    MUR: {
        code: 'MUR',
        symbol: '₨',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    MVR: {
        code: 'MVR',
        symbol: 'MVR',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 1,
    },
    MWK: {
        code: 'MWK',
        symbol: 'MK',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    MXN: {
        code: 'MXN',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    MYR: {
        code: 'MYR',
        symbol: 'RM',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    MZN: {
        code: 'MZN',
        symbol: 'MT',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    NAD: {
        code: 'NAD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    NGN: {
        code: 'NGN',
        symbol: '₦',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    NIO: {
        code: 'NIO',
        symbol: 'C$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    NOK: {
        code: 'NOK',
        symbol: 'kr',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    NPR: {
        code: 'NPR',
        symbol: '₨',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    NZD: {
        code: 'NZD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    OMR: {
        code: 'OMR',
        symbol: '﷼',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 3,
    },
    PAB: {
        code: 'PAB',
        symbol: 'B/.',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    PEN: {
        code: 'PEN',
        symbol: 'S/.',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    PGK: {
        code: 'PGK',
        symbol: 'K',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    PHP: {
        code: 'PHP',
        symbol: '₱',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    PKR: {
        code: 'PKR',
        symbol: '₨',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    PLN: {
        code: 'PLN',
        symbol: 'zł',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    PYG: {
        code: 'PYG',
        symbol: '₲',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    QAR: {
        code: 'QAR',
        symbol: '﷼',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    RON: {
        code: 'RON',
        symbol: 'L',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    RSD: {
        code: 'RSD',
        symbol: 'Дин.',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    RUB: {
        code: 'RUB',
        symbol: '₽',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    RWF: {
        code: 'RWF',
        symbol: 'RWF',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    SAR: {
        code: 'SAR',
        symbol: '﷼',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    SBD: {
        code: 'SBD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    SCR: {
        code: 'SCR',
        symbol: '₨',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    SDD: {
        code: 'SDD',
        symbol: 'LSd',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    SDG: {
        code: 'SDG',
        symbol: '£‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    SEK: {
        code: 'SEK',
        symbol: 'kr',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    SGD: {
        code: 'SGD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    SHP: {
        code: 'SHP',
        symbol: '£',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    SLL: {
        code: 'SLL',
        symbol: 'Le',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    SOS: {
        code: 'SOS',
        symbol: 'S',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    SRD: {
        code: 'SRD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    STD: {
        code: 'STD',
        symbol: 'Db',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    SVC: {
        code: 'SVC',
        symbol: '₡',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    SYP: {
        code: 'SYP',
        symbol: '£',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    SZL: {
        code: 'SZL',
        symbol: 'E',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    THB: {
        code: 'THB',
        symbol: '฿',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    TJS: {
        code: 'TJS',
        symbol: 'TJS',
        thousandsSeparator: ' ',
        decimalSeparator: ';',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    TMT: {
        code: 'TMT',
        symbol: 'm',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    TND: {
        code: 'TND',
        symbol: 'د.ت.‏',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 3,
    },
    TOP: {
        code: 'TOP',
        symbol: 'T$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    TRY: {
        code: 'TRY',
        symbol: '₺',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    TTD: {
        code: 'TTD',
        symbol: 'TT$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    TVD: {
        code: 'TVD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    TWD: {
        code: 'TWD',
        symbol: 'NT$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    TZS: {
        code: 'TZS',
        symbol: 'TSh',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    UAH: {
        code: 'UAH',
        symbol: '₴',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    UGX: {
        code: 'UGX',
        symbol: 'USh',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    USD: {
        code: 'USD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    UYU: {
        code: 'UYU',
        symbol: '$U',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    UZS: {
        code: 'UZS',
        symbol: 'сўм',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    VEB: {
        code: 'VEB',
        symbol: 'Bs.',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    VEF: {
        code: 'VEF',
        symbol: 'Bs. F.',
        thousandsSeparator: '.',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    VND: {
        code: 'VND',
        symbol: '₫',
        thousandsSeparator: '.',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 0,
    },
    VUV: {
        code: 'VUV',
        symbol: 'VT',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 0,
    },
    WST: {
        code: 'WST',
        symbol: 'WS$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    XAF: {
        code: 'XAF',
        symbol: 'F',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    XCD: {
        code: 'XCD',
        symbol: '$',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    XBT: {
        code: 'XBT',
        symbol: 'Ƀ',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    XOF: {
        code: 'XOF',
        symbol: 'F',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    XPF: {
        code: 'XPF',
        symbol: 'F',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: false,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    YER: {
        code: 'YER',
        symbol: '﷼',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: true,
        decimalDigits: 2,
    },
    ZAR: {
        code: 'ZAR',
        symbol: 'R',
        thousandsSeparator: ' ',
        decimalSeparator: ',',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    ZMW: {
        code: 'ZMW',
        symbol: 'ZK',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
    WON: {
        code: 'WON',
        symbol: '₩',
        thousandsSeparator: ',',
        decimalSeparator: '.',
        symbolOnLeft: true,
        spaceBetweenAmountAndSymbol: false,
        decimalDigits: 2,
    },
};

class CurrencyFormatterDirective {
    constructor(el) {
        this.el = el;
        this.onChange = (_value) => { };
        this.onTouched = () => { };
    }
    ngOnInit() {
        if (!this.currencyCode)
            return;
        this.config = currencyList[this.currencyCode] || this.config;
    }
    onInput(event) {
        if (!this.currencyCode || !this.config)
            return;
        const input = event.target;
        const oldValue = input.value;
        const selectionStart = input.selectionStart ?? oldValue.length;
        let raw = oldValue.replace(new RegExp(`\\${this.config.thousandsSeparator}`, 'g'), '')
            .replace(this.config.symbol, '')
            .replace(/\s/g, '');
        const normalized = raw.replace(this.config.decimalSeparator, '.');
        const num = parseFloat(normalized);
        const formatted = this.formatValue(num);
        input.value = formatted;
        const diff = formatted.length - oldValue.length;
        const newPos = selectionStart + diff;
        setTimeout(() => {
            input.setSelectionRange(newPos, newPos);
        });
        this.onChange(num);
    }
    onBlur() {
        if (!this.currencyCode || !this.config)
            return;
        this.onTouched();
    }
    writeValue(value) {
        if (value !== undefined && value !== null) {
            this.el.nativeElement.value = this.formatValue(value);
        }
        else {
            this.el.nativeElement.value = '';
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    formatValue(value) {
        if (isNaN(value) || !this.config)
            return '';
        const [intPart, decPart = ''] = value.toFixed(this.config.decimalDigits).split('.');
        const intWithSep = intPart?.replace(/\B(?=(\d{3})+(?!\d))/g, this.config.thousandsSeparator);
        const decimal = this.config.decimalDigits ? this.config.decimalSeparator + decPart : '';
        const space = this.config.spaceBetweenAmountAndSymbol ? ' ' : '';
        return this.config.symbolOnLeft
            ? `${this.config.symbol}${space}${intWithSep}${decimal}`
            : `${intWithSep}${decimal}${space}${this.config.symbol}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CurrencyFormatterDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: CurrencyFormatterDirective, selector: "[icCurrencyFormatter]", inputs: { currencyCode: ["icCurrencyFormatter", "currencyCode"] }, host: { listeners: { "input": "onInput($event)", "blur": "onBlur()" } }, providers: [{
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => CurrencyFormatterDirective),
                multi: true
            }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CurrencyFormatterDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icCurrencyFormatter]',
                    providers: [{
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => CurrencyFormatterDirective),
                            multi: true
                        }]
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { currencyCode: [{
                type: Input,
                args: ['icCurrencyFormatter']
            }], onInput: [{
                type: HostListener,
                args: ['input', ['$event']]
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }] } });

// cleave-currency.directive.ts
class CleaveCurrencyDirective {
    constructor(el) {
        this.el = el;
    }
    ngOnInit() {
        if (this.cleaveCurrency) {
            this.initCleave();
        }
    }
    ngOnChanges(changes) {
        if (changes['currencySymbol'] ||
            changes['decimalScale'] ||
            changes['groupStyle']) {
            if (!changes['currencySymbol']?.firstChange) {
                this.destroyCleave();
                this.initCleave();
            }
        }
    }
    initCleave() {
        this.cleaveInstance = new Cleave(this.el.nativeElement, {
            numeral: true,
            numeralDecimalScale: 3,
            numeralThousandsGroupStyle: 'lakh',
            rawValueTrimPrefix: true,
            numeralPositiveOnly: false,
        });
    }
    destroyCleave() {
        if (this.cleaveInstance) {
            this.cleaveInstance.destroy();
        }
    }
    ngOnDestroy() {
        this.destroyCleave();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CleaveCurrencyDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: CleaveCurrencyDirective, selector: "[icCleaveCurrency]", inputs: { cleaveCurrency: ["icCleaveCurrency", "cleaveCurrency"] }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CleaveCurrencyDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[icCleaveCurrency]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { cleaveCurrency: [{
                type: Input,
                args: ['icCleaveCurrency']
            }] } });

const directives = [
    FlexLayoutDirective,
    IsUpperCaseDirective,
    AlphaNumericWithSpaceDirective,
    NoInitialSpaceDirective,
    NumbersOnlyDirective,
    SpecialAlphaNumericDirective,
    SpecialTextDirective,
    NoSpaceDirective,
    AlphanumericDirective,
    NoSpecialCharFirstDirective,
    AlphabetOnlyDirective,
    RestrictPercentageDirective,
    RestrictDecimalDirective,
    TwoDigitDecimalNumberDirective,
    ImageLazyLoadDirective,
    PreventInitialZeroDirective,
    SpecialAlphaNumericExtendedDirective,
    NoSpaceDirective,
    AlphanumericDirective,
    RestrictDecimalDirective,
    DateFormatEnforcerDirective,
    CurrencyFormatterDirective,
    CleaveCurrencyDirective,
];
class LibDirectiveModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LibDirectiveModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: LibDirectiveModule, declarations: [FlexLayoutDirective,
            IsUpperCaseDirective,
            AlphaNumericWithSpaceDirective,
            NoInitialSpaceDirective,
            NumbersOnlyDirective,
            SpecialAlphaNumericDirective,
            SpecialTextDirective,
            NoSpaceDirective,
            AlphanumericDirective,
            NoSpecialCharFirstDirective,
            AlphabetOnlyDirective,
            RestrictPercentageDirective,
            RestrictDecimalDirective,
            TwoDigitDecimalNumberDirective,
            ImageLazyLoadDirective,
            PreventInitialZeroDirective,
            SpecialAlphaNumericExtendedDirective,
            NoSpaceDirective,
            AlphanumericDirective,
            RestrictDecimalDirective,
            DateFormatEnforcerDirective,
            CurrencyFormatterDirective,
            CleaveCurrencyDirective], imports: [CommonModule], exports: [FlexLayoutDirective,
            IsUpperCaseDirective,
            AlphaNumericWithSpaceDirective,
            NoInitialSpaceDirective,
            NumbersOnlyDirective,
            SpecialAlphaNumericDirective,
            SpecialTextDirective,
            NoSpaceDirective,
            AlphanumericDirective,
            NoSpecialCharFirstDirective,
            AlphabetOnlyDirective,
            RestrictPercentageDirective,
            RestrictDecimalDirective,
            TwoDigitDecimalNumberDirective,
            ImageLazyLoadDirective,
            PreventInitialZeroDirective,
            SpecialAlphaNumericExtendedDirective,
            NoSpaceDirective,
            AlphanumericDirective,
            RestrictDecimalDirective,
            DateFormatEnforcerDirective,
            CurrencyFormatterDirective,
            CleaveCurrencyDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LibDirectiveModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LibDirectiveModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: directives,
                    imports: [CommonModule],
                    exports: directives,
                }]
        }] });

class IcIconRegistryService {
    constructor(sanitizer, http) {
        this.sanitizer = sanitizer;
        this.http = http;
        this.iconCache = new Map();
        this.iconBasePath = 'assets/icons/';
    }
    getIcon(name) {
        if (this.iconCache.has(name)) {
            return this.iconCache.get(name);
        }
        const url = `${this.iconBasePath}${name}.svg`;
        const icon$ = this.http.get(url, { responseType: 'text' }).pipe(map(svgText => this.sanitizer.bypassSecurityTrustHtml(svgText)), shareReplay(1));
        this.iconCache.set(name, icon$);
        return icon$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IcIconRegistryService, deps: [{ token: i1.DomSanitizer }, { token: i2$1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IcIconRegistryService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IcIconRegistryService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1.DomSanitizer }, { type: i2$1.HttpClient }]; } });

class ThemeConfigService {
    constructor() {
        this._theme = 'light';
    }
    setTheme(theme) {
        document.body.classList.remove(`theme-${this._theme}`);
        this._theme = theme;
        document.body.classList.add(`theme-${theme}`);
    }
    get theme() {
        return this._theme;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ThemeConfigService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ThemeConfigService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ThemeConfigService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class IconComponent {
    constructor(iconRegistry, renderer, el) {
        this.iconRegistry = iconRegistry;
        this.renderer = renderer;
        this.el = el;
        this.size = '34px';
        this.svgIcon = '';
    }
    ngOnChanges(changes) {
        if (changes['name']) {
            if (this.name && this.name.trim() !== '') {
                this.loadIcon();
            }
            else {
                this.clearIcon();
            }
        }
        if ((changes['color'] || changes['size']) && this.svgIcon) {
            this.applyStyles();
        }
    }
    loadIcon() {
        this.iconRegistry.getIcon(this.name.trim()).subscribe({
            next: svg => {
                this.svgIcon = svg;
                this.applyStyles();
            },
            error: () => {
                this.clearIcon();
            },
        });
    }
    applyStyles() {
        const nativeEl = this.el.nativeElement.querySelector('.icon');
        if (nativeEl) {
            this.renderer.setStyle(this.el.nativeElement, '--icon-size', this.size);
            this.renderer.setStyle(this.el.nativeElement, '--icon-color', this.color || 'currentColor');
            setTimeout(() => {
                const svg = this.el.nativeElement.querySelector('.icon svg');
                if (svg) {
                    svg.style.width = '100%';
                    svg.style.height = '100%';
                    this.renderer.setStyle(nativeEl, 'fill', this.color || 'currentColor');
                    this.renderer.setStyle(nativeEl, 'display', 'inline-flex');
                    this.renderer.setStyle(nativeEl, 'justify-content', 'center');
                    this.renderer.setStyle(nativeEl, 'align-items', 'center');
                }
            });
        }
    }
    clearIcon() {
        this.svgIcon = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IconComponent, deps: [{ token: IcIconRegistryService }, { token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: IconComponent, selector: "ic-icon", inputs: { name: "name", color: "color", size: "size" }, usesOnChanges: true, ngImport: i0, template: ` <span class="icon" [innerHTML]="svgIcon"></span> `, isInline: true, styles: [":host{display:flex;justify-content:center;align-items:center;width:var(--ic-icon-size, 24px);height:var(--ic-icon-size, 24px);color:var(--ic-icon-color, currentColor);transition:color .3s ease-in-out,transform .3s ease-in-out}:host(:hover){color:var(--ic-icon-hover-color, var(--ic-icon-color, currentColor))}.icon{width:100%;height:100%;display:flex;justify-content:center;align-items:center}.icon svg{width:100%!important;height:100%!important;fill:currentColor!important}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-icon', template: ` <span class="icon" [innerHTML]="svgIcon"></span> `, styles: [":host{display:flex;justify-content:center;align-items:center;width:var(--ic-icon-size, 24px);height:var(--ic-icon-size, 24px);color:var(--ic-icon-color, currentColor);transition:color .3s ease-in-out,transform .3s ease-in-out}:host(:hover){color:var(--ic-icon-hover-color, var(--ic-icon-color, currentColor))}.icon{width:100%;height:100%;display:flex;justify-content:center;align-items:center}.icon svg{width:100%!important;height:100%!important;fill:currentColor!important}\n"] }]
        }], ctorParameters: function () { return [{ type: IcIconRegistryService }, { type: i0.Renderer2 }, { type: i0.ElementRef }]; }, propDecorators: { name: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }] } });

class ButtonComponent {
    constructor() {
        // Input properties for customization
        this.label = ''; // Button label text
        this.type = 'button'; // Button type
        this.size = 'medium'; // Button size
        this.disabled = false; // Disable state
        this.isLoading = false; // Show loading spinner
        this.isSkeleton = false; // Skeleton mode
        this.icButtonType = 'filled'; // Button type class
        this.icIcon = '';
        this.prefixIcon = '';
        this.suffixIcon = '';
        this.customButtonClass = '';
        this.OnClick = new EventEmitter();
    }
    // Lifecycle hook to detect and update input changes
    ngOnChanges(changes) {
        for (const propName in changes) {
            if (propName &&
                changes[propName]?.currentValue !== propName &&
                changes[propName]?.previousValue) {
            }
        }
    }
    // Unified click handler
    onButtonClick(event) {
        if (this.disabled || this.isLoading || this.isSkeleton) {
            // Ignore click events for disabled or loading state
            event.preventDefault();
            return;
        }
        this.handleClick(event);
    }
    // Handle click event and emit
    handleClick(event) {
        const btnEvent = {
            ...event,
            type: this.type,
            label: this.label,
            disabled: this.disabled,
            icButtonType: this.icButtonType,
        };
        this.OnClick.emit(btnEvent);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ButtonComponent, selector: "ic-button", inputs: { label: "label", type: "type", size: "size", disabled: "disabled", isLoading: "isLoading", isSkeleton: "isSkeleton", icButtonType: "icButtonType", icIcon: "icIcon", prefixIcon: "prefixIcon", suffixIcon: "suffixIcon", customButtonClass: "customButtonClass" }, outputs: { OnClick: "OnClick" }, usesOnChanges: true, ngImport: i0, template: "<!-- Button structure -->\r\n<button\r\n  [type]=\"type\"\r\n  class=\"ic-button {{ icButtonType }} {{ size }} {{ customButtonClass }}\"\r\n  [class.iconButtonClass]=\"type == 'icon'\"\r\n  [class.disabled]=\"disabled || isLoading\"\r\n  [class.loading]=\"isLoading\"\r\n  [class.skeleton]=\"isSkeleton\"\r\n  [disabled]=\"disabled || isLoading\"\r\n  (click)=\"onButtonClick($event)\"\r\n  [attr.aria-label]=\"label || 'Button'\"\r\n  [attr.aria-disabled]=\"disabled || isLoading\">\r\n  <ng-container *ngIf=\"isLoading\">\r\n    <div class=\"ic-loading-spinner\"></div>\r\n  </ng-container>\r\n  <ng-container *ngIf=\"!isLoading && !isSkeleton\">\r\n    <ng-container *ngIf=\"prefixIcon || icIcon\">\r\n      <ic-icon class=\"icon-div\" [name]=\"prefixIcon || icIcon\"> </ic-icon>\r\n    </ng-container>\r\n    <ng-container *ngIf=\"label\">\r\n      {{ label }}\r\n    </ng-container>\r\n    <ng-container *ngIf=\"suffixIcon\">\r\n      <ic-icon class=\"icon-div\" [name]=\"suffixIcon\"> </ic-icon>\r\n    </ng-container>\r\n  </ng-container>\r\n</button>\r\n", styles: [".ic-button{font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);border-radius:8px;border:none;cursor:pointer;display:flex;flex-direction:row;justify-content:center;align-items:center;gap:16px;position:relative;overflow:hidden;transition:background .3s,opacity .3s,box-shadow .3s;-webkit-user-select:none;user-select:none}.ic-button.small{height:32px;padding:8px 24px;font-size:12px}.ic-button.small.iconButtonClass{width:32px}.ic-button.medium{height:40px;padding:8px 32px;font-size:14px}.ic-button.medium.iconButtonClass{width:40px}.ic-button.large{height:48px;padding:8px 40px;font-size:16px}.ic-button.large.iconButtonClass{width:48px}.ic-button.filled{background:var(--ic-btn-filled-bg, linear-gradient(90deg, #0062e1 0%, #03a 100%));color:var(--ic-btn-filled-color, #fff)}.ic-button.filled-warning{background:var(--ic-btn-filled-warning-bg, #d68c00)}.ic-button.filled-danger{background:var(--ic-btn-filled-danger-bg, #b20000)}.ic-button.filled-neutral{background:var(--ic-btn-filled-neutral-bg, #0033a1)}.ic-button.filled-blue{background:var(--ic-btn-filled-blue-bg, #0062e1)}.ic-button.filled-basic{background:var(--ic-btn-filled-basic-bg, #000)}.ic-button.filled-success{background:var(--ic-btn-filled-success-bg, #008461)}.ic-button.filled-warning,.ic-button.filled-danger,.ic-button.filled-neutral,.ic-button.filled-basic,.ic-button.filled-success,.ic-button.filled-blue{color:var(--ic-btn-filled-color, #fff)}.ic-button.filled-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-success:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-blue:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.filled-warning.disabled,.ic-button.filled-danger.disabled,.ic-button.filled-neutral.disabled,.ic-button.filled-basic.disabled,.ic-button.filled-success.disabled,.ic-button.filled-blue.disabled{background:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.filled:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.filled.disabled{background:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.filled-rounded{border-radius:30px;background:var(--ic-btn-filled-bg, linear-gradient(90deg, #0062e1 0%, #03a 100%));color:var(--ic-btn-filled-color, #fff)}.ic-button.filled-rounded-warning{background:var(--ic-btn-filled-warning-bg, #d68c00)}.ic-button.filled-rounded-danger{background:var(--ic-btn-filled-danger-bg, #b20000)}.ic-button.filled-rounded-neutral{background:var(--ic-btn-filled-neutral-bg, #0033a1)}.ic-button.filled-rounded-blue{background:var(--ic-btn-filled-blue-bg, #0062e1)}.ic-button.filled-rounded-basic{background:var(--ic-btn-filled-basic-bg, #000)}.ic-button.filled-rounded-success{background:var(--ic-btn-filled-success-bg, #008461)}.ic-button.filled-rounded-warning,.ic-button.filled-rounded-danger,.ic-button.filled-rounded-neutral,.ic-button.filled-rounded-basic,.ic-button.filled-rounded-success,.ic-button.filled-rounded-blue{border-radius:30px;color:var(--ic-btn-filled-color, #fff)}.ic-button.filled-rounded-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-rounded-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-rounded-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-rounded-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-rounded-success:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-rounded-blue:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.filled-rounded-warning.disabled,.ic-button.filled-rounded-danger.disabled,.ic-button.filled-rounded-neutral.disabled,.ic-button.filled-rounded-basic.disabled,.ic-button.filled-rounded-success.disabled,.ic-button.filled-rounded-blue.disabled{background:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.filled-rounded:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.filled-rounded.disabled{background:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined{background:var(--ic-btn-outlined-bg, #fff);border:1px solid var(--ic-btn-outlined-border, #0033a1);color:var(--ic-btn-outlined-color, #0033a1)}.ic-button.outlined-warning{border:1px solid var(--ic-btn-outlined-warning, #d68c00);color:var(--ic-btn-outlined-warning, #d68c00)}.ic-button.outlined-danger{border:1px solid var(--ic-btn-outlined-danger, #b20000);color:var(--ic-btn-outlined-danger, #b20000)}.ic-button.outlined-neutral{border:1px solid var(--ic-btn-outlined-neutral, #0033a1);color:var(--ic-btn-outlined-neutral, #0033a1)}.ic-button.outlined-basic{border:1px solid var(--ic-btn-outlined-basic, #000);color:var(--ic-btn-outlined-basic, #000)}.ic-button.outlined-success{border:1px solid var(--ic-btn-outlined-success, #008461);color:var(--ic-btn-outlined-success, #008461)}.ic-button.outlined-warning,.ic-button.outlined-danger,.ic-button.outlined-neutral,.ic-button.outlined-basic,.ic-button.outlined-success{background:var(--ic-btn-outlined-bg, #fff)}.ic-button.outlined-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-success:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-outlined-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.outlined-warning.disabled,.ic-button.outlined-danger.disabled,.ic-button.outlined-neutral.disabled,.ic-button.outlined-basic.disabled,.ic-button.outlined-success.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);background:var(--ic-btn-outlined-bg, #fff)!important;pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-outlined-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.outlined.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-rounded{border:1px solid var(--ic-btn-outlined-border, #0033a1);color:var(--ic-btn-outlined-color, #0033a1);background:var(--ic-btn-outlined-bg, #fff);border-radius:30px}.ic-button.outlined-rounded-warning{border:1px solid var(--ic-btn-outlined-warning, #d68c00);color:var(--ic-btn-outlined-warning, #d68c00)}.ic-button.outlined-rounded-danger{border:1px solid var(--ic-btn-outlined-danger, #b20000);color:var(--ic-btn-outlined-danger, #b20000)}.ic-button.outlined-rounded-neutral{border:1px solid var(--ic-btn-outlined-neutral, #0033a1);color:var(--ic-btn-outlined-neutral, #0033a1)}.ic-button.outlined-rounded-basic{border:1px solid var(--ic-btn-outlined-basic, #000);color:var(--ic-btn-outlined-basic, #000)}.ic-button.outlined-rounded-success{border:1px solid var(--ic-btn-outlined-success, #008461);color:var(--ic-btn-outlined-success, #008461)}.ic-button.outlined-rounded-warning,.ic-button.outlined-rounded-danger,.ic-button.outlined-rounded-neutral,.ic-button.outlined-rounded-basic,.ic-button.outlined-rounded-success{background:var(--ic-btn-outlined-bg, #fff);border-radius:30px}.ic-button.outlined-rounded-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-success:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-outlined-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.outlined-rounded-warning.disabled,.ic-button.outlined-rounded-danger.disabled,.ic-button.outlined-rounded-neutral.disabled,.ic-button.outlined-rounded-basic.disabled,.ic-button.outlined-rounded-success.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);background:transparent!important;pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-rounded:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-outlined-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.outlined-rounded.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.status{border:1px solid var(--ic-btn-status-border, #0033a1);color:var(--ic-btn-status-color, #0033a1)}.ic-button.status-warning{border:1px solid var(--ic-btn-status-warning, #d68c00);color:var(--ic-btn-status-warning, #d68c00);background:var(--ic-btn-status-warning-bg, #fff7e6)!important}.ic-button.status-danger{border:1px solid var(--ic-btn-status-danger, #b20000);color:var(--ic-btn-status-danger, #b20000);background:var(--ic-btn-status-danger-bg, #ffe7e8)!important}.ic-button.status-neutral{border:1px solid var(--ic-btn-status-neutral, #0033a1);color:var(--ic-btn-status-neutral, #0033a1);background:var(--ic-btn-status-neutral-bg, #e3e9fe)!important}.ic-button.status-basic{border:1px solid var(--ic-btn-status-basic, #000);color:var(--ic-btn-status-basic, #000);background:var(--ic-btn-status-basic-bg, #fff)!important}.ic-button.status-success{border:1px solid var(--ic-btn-status-success, #008461);color:var(--ic-btn-status-success, #008461);background:var(--ic-btn-status-success-bg, #ddf8f1)!important}.ic-button.status-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-success:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-status-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.status-warning.disabled,.ic-button.status-danger.disabled,.ic-button.status-neutral.disabled,.ic-button.status-basic.disabled,.ic-button.status-success.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.status:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-status-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.status.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.status-rounded{border:1px solid var(--ic-btn-status-border, #0033a1);color:var(--ic-btn-status-color, #0033a1);border-radius:30px}.ic-button.status-rounded-warning{border:1px solid var(--ic-btn-status-warning, #d68c00);color:var(--ic-btn-status-warning, #d68c00);background:var(--ic-btn-status-warning-bg, #fff7e6)!important}.ic-button.status-rounded-danger{border:1px solid var(--ic-btn-status-danger, #b20000);color:var(--ic-btn-status-danger, #b20000);background:var(--ic-btn-status-danger-bg, #ffe7e8)!important}.ic-button.status-rounded-neutral{border:1px solid var(--ic-btn-status-neutral, #0033a1);color:var(--ic-btn-status-neutral, #0033a1);background:var(--ic-btn-status-neutral-bg, #e3e9fe)!important}.ic-button.status-rounded-basic{border:1px solid var(--ic-btn-status-basic, #000);color:var(--ic-btn-status-basic, #000);background:var(--ic-btn-status-basic-bg, #fff)!important}.ic-button.status-rounded-success{border:1px solid var(--ic-btn-status-success, #008461);color:var(--ic-btn-status-success, #008461);background:var(--ic-btn-status-success-bg, #ddf8f1)!important}.ic-button.status-rounded-warning,.ic-button.status-rounded-danger,.ic-button.status-rounded-neutral,.ic-button.status-rounded-basic,.ic-button.status-rounded-success{background:var(--ic-btn-status-bg, #fff);border-radius:30px}.ic-button.status-rounded-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-rounded-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-rounded-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-rounded-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-rounded-success:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-status-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.status-rounded-warning.disabled,.ic-button.status-rounded-danger.disabled,.ic-button.status-rounded-neutral.disabled,.ic-button.status-rounded-basic.disabled,.ic-button.status-rounded-success.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.status-rounded:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-status-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.status-rounded.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-transparent{background:transparent;border:1px solid var(--ic-btn-outlined-transparent-border, #fff);color:var(--ic-btn-outlined-transparent-color, #fff)}.ic-button.outlined-transparent-warning{border:1px solid var(--ic-btn-outlined-warning, #d68c00);color:var(--ic-btn-outlined-warning, #d68c00)}.ic-button.outlined-transparent-danger{border:1px solid var(--ic-btn-outlined-danger, #b20000);color:var(--ic-btn-outlined-danger, #b20000)}.ic-button.outlined-transparent-neutral{border:1px solid var(--ic-btn-outlined-neutral, #0033a1);color:var(--ic-btn-outlined-neutral, #0033a1)}.ic-button.outlined-transparent-basic{border:1px solid var(--ic-btn-outlined-basic, #000);color:var(--ic-btn-outlined-basic, #000)}.ic-button.outlined-transparent-success{border:1px solid var(--ic-btn-outlined-success, #008461);color:var(--ic-btn-outlined-success, #008461)}.ic-button.outlined-transparent-warning,.ic-button.outlined-transparent-danger,.ic-button.outlined-transparent-neutral,.ic-button.outlined-transparent-basic,.ic-button.outlined-transparent-success{background:transparent}.ic-button.outlined-transparent-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-transparent-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-transparent-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-transparent-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-transparent-success:hover:not(.disabled,.ic-button.skeleton){color:var(--ic-btn-outlined-transparent-hover-color, #212353);background:var(--ic-btn-outlined-transparent-hover-bg, #fff)}.ic-button.outlined-transparent-warning.disabled,.ic-button.outlined-transparent-danger.disabled,.ic-button.outlined-transparent-neutral.disabled,.ic-button.outlined-transparent-basic.disabled,.ic-button.outlined-transparent-success.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-transparent:hover:not(.disabled,.ic-button.skeleton){color:var(--ic-btn-outlined-transparent-hover-color, #212353);background:var(--ic-btn-outlined-transparent-hover-bg, #fff)}.ic-button.outlined-transparent.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-rounded-transparent{background:transparent;border-radius:30px;border:1px solid var(--ic-btn-outlined-transparent-border, #fff);color:var(--ic-btn-outlined-transparent-color, #fff)}.ic-button.outlined-rounded-transparent-warning{border:1px solid var(--ic-btn-outlined-warning, #d68c00);color:var(--ic-btn-outlined-warning, #d68c00)}.ic-button.outlined-rounded-transparent-danger{border:1px solid var(--ic-btn-outlined-danger, #b20000);color:var(--ic-btn-outlined-danger, #b20000)}.ic-button.outlined-rounded-transparent-neutral{border:1px solid var(--ic-btn-outlined-neutral, #0033a1);color:var(--ic-btn-outlined-neutral, #0033a1)}.ic-button.outlined-rounded-transparent-basic{border:1px solid var(--ic-btn-outlined-basic, #000);color:var(--ic-btn-outlined-basic, #000)}.ic-button.outlined-rounded-transparent-success{border:1px solid var(--ic-btn-outlined-success, #008461);color:var(--ic-btn-outlined-success, #008461)}.ic-button.outlined-rounded-transparent-warning,.ic-button.outlined-rounded-transparent-danger,.ic-button.outlined-rounded-transparent-neutral,.ic-button.outlined-rounded-transparent-basic,.ic-button.outlined-rounded-transparent-success{background:transparent;border-radius:30px}.ic-button.outlined-rounded-transparent-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-transparent-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-transparent-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-transparent-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-transparent-success:hover:not(.disabled,.ic-button.skeleton){color:var(--ic-btn-outlined-transparent-hover-color, #212353);background:var(--ic-btn-outlined-transparent-hover-bg, #fff)}.ic-button.outlined-rounded-transparent-warning.disabled,.ic-button.outlined-rounded-transparent-danger.disabled,.ic-button.outlined-rounded-transparent-neutral.disabled,.ic-button.outlined-rounded-transparent-basic.disabled,.ic-button.outlined-rounded-transparent-success.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-rounded-transparent:hover:not(.disabled,.ic-button.skeleton){color:var(--ic-btn-outlined-transparent-hover-color, #212353);background:var(--ic-btn-outlined-transparent-hover-bg, #fff)}.ic-button.outlined-rounded-transparent.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.ghost{color:var(--ic-btn-ghost-color, #0033a1);background:var(--ic-btn-ghost-bg, #fff);box-shadow:var(--ic-btn-ghost-shadow, 0px 3px 10px 0px rgba(0, 0, 0, .0901960784))}.ic-button.ghost-warning{color:var(--ic-btn-ghost-warning, #d68c00)}.ic-button.ghost-danger{color:var(--ic-btn-ghost-danger, #b20000)}.ic-button.ghost-neutral{color:var(--ic-btn-ghost-neutral, #0033a1)}.ic-button.ghost-basic{color:var(--ic-btn-ghost-basic, #000)}.ic-button.ghost-success{color:var(--ic-btn-ghost-success, #008461)}.ic-button.ghost-warning,.ic-button.ghost-danger,.ic-button.ghost-neutral,.ic-button.ghost-basic,.ic-button.ghost-success{background:var(--ic-btn-ghost-bg, #fff);box-shadow:var(--ic-btn-ghost-shadow, 0px 3px 10px 0px rgba(0, 0, 0, .0901960784))}.ic-button.ghost-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-success:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.ghost-warning.disabled,.ic-button.ghost-danger.disabled,.ic-button.ghost-neutral.disabled,.ic-button.ghost-basic.disabled,.ic-button.ghost-success.disabled{background:var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-ghost-disabled-color, #fff);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.ghost:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.ghost.disabled{background:var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-ghost-disabled-color, #fff);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.ghost-rounded{border-radius:30px;background:var(--ic-btn-ghost-bg, #fff);color:var(--ic-btn-ghost-color, #0033a1);box-shadow:var(--ic-btn-ghost-shadow, 0px 3px 10px 0px rgba(0, 0, 0, .0901960784))}.ic-button.ghost-rounded-warning{color:var(--ic-btn-ghost-warning, #d68c00)}.ic-button.ghost-rounded-danger{color:var(--ic-btn-ghost-danger, #b20000)}.ic-button.ghost-rounded-neutral{color:var(--ic-btn-ghost-neutral, #0033a1)}.ic-button.ghost-rounded-basic{color:var(--ic-btn-ghost-basic, #000)}.ic-button.ghost-rounded-success{color:var(--ic-btn-ghost-success, #008461)}.ic-button.ghost-rounded-warning,.ic-button.ghost-rounded-danger,.ic-button.ghost-rounded-neutral,.ic-button.ghost-rounded-basic,.ic-button.ghost-rounded-success{border-radius:30px;background:var(--ic-btn-ghost-bg, #fff);box-shadow:var(--ic-btn-ghost-shadow, 0px 3px 10px 0px rgba(0, 0, 0, .0901960784))}.ic-button.ghost-rounded-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-rounded-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-rounded-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-rounded-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-rounded-success:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.ghost-rounded-warning.disabled,.ic-button.ghost-rounded-danger.disabled,.ic-button.ghost-rounded-neutral.disabled,.ic-button.ghost-rounded-basic.disabled,.ic-button.ghost-rounded-success.disabled{background:var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-ghost-disabled-color, #fff);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.ghost-rounded:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.ghost-rounded.disabled{background:var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-ghost-disabled-color, #fff);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button .ic-loading-spinner{border:2px solid transparent;border-top:2px solid var(--ic-btn-spinner-color, #fff);border-radius:50%;width:16px;height:16px;animation:spin 1s linear infinite;margin:auto}@keyframes spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}.ic-button.skeleton{background:linear-gradient(90deg,#f0f0f0 25%,#e0e0e0,#f0f0f0 75%);background-size:200% 100%;animation:skeleton-animation 1.5s infinite;box-shadow:none}@keyframes skeleton-animation{0%{background-position:200% 0}to{background-position:-200% 0}}.ic-button.disabled{background:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;cursor:not-allowed!important}.ic-button.iconButtonClass{padding:8px;display:flex;justify-content:center}.ic-button .icon-div{width:16px;height:100%;align-items:center;display:flex}\n"], dependencies: [{ kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "ic-icon", inputs: ["name", "color", "size"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-button', template: "<!-- Button structure -->\r\n<button\r\n  [type]=\"type\"\r\n  class=\"ic-button {{ icButtonType }} {{ size }} {{ customButtonClass }}\"\r\n  [class.iconButtonClass]=\"type == 'icon'\"\r\n  [class.disabled]=\"disabled || isLoading\"\r\n  [class.loading]=\"isLoading\"\r\n  [class.skeleton]=\"isSkeleton\"\r\n  [disabled]=\"disabled || isLoading\"\r\n  (click)=\"onButtonClick($event)\"\r\n  [attr.aria-label]=\"label || 'Button'\"\r\n  [attr.aria-disabled]=\"disabled || isLoading\">\r\n  <ng-container *ngIf=\"isLoading\">\r\n    <div class=\"ic-loading-spinner\"></div>\r\n  </ng-container>\r\n  <ng-container *ngIf=\"!isLoading && !isSkeleton\">\r\n    <ng-container *ngIf=\"prefixIcon || icIcon\">\r\n      <ic-icon class=\"icon-div\" [name]=\"prefixIcon || icIcon\"> </ic-icon>\r\n    </ng-container>\r\n    <ng-container *ngIf=\"label\">\r\n      {{ label }}\r\n    </ng-container>\r\n    <ng-container *ngIf=\"suffixIcon\">\r\n      <ic-icon class=\"icon-div\" [name]=\"suffixIcon\"> </ic-icon>\r\n    </ng-container>\r\n  </ng-container>\r\n</button>\r\n", styles: [".ic-button{font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);border-radius:8px;border:none;cursor:pointer;display:flex;flex-direction:row;justify-content:center;align-items:center;gap:16px;position:relative;overflow:hidden;transition:background .3s,opacity .3s,box-shadow .3s;-webkit-user-select:none;user-select:none}.ic-button.small{height:32px;padding:8px 24px;font-size:12px}.ic-button.small.iconButtonClass{width:32px}.ic-button.medium{height:40px;padding:8px 32px;font-size:14px}.ic-button.medium.iconButtonClass{width:40px}.ic-button.large{height:48px;padding:8px 40px;font-size:16px}.ic-button.large.iconButtonClass{width:48px}.ic-button.filled{background:var(--ic-btn-filled-bg, linear-gradient(90deg, #0062e1 0%, #03a 100%));color:var(--ic-btn-filled-color, #fff)}.ic-button.filled-warning{background:var(--ic-btn-filled-warning-bg, #d68c00)}.ic-button.filled-danger{background:var(--ic-btn-filled-danger-bg, #b20000)}.ic-button.filled-neutral{background:var(--ic-btn-filled-neutral-bg, #0033a1)}.ic-button.filled-blue{background:var(--ic-btn-filled-blue-bg, #0062e1)}.ic-button.filled-basic{background:var(--ic-btn-filled-basic-bg, #000)}.ic-button.filled-success{background:var(--ic-btn-filled-success-bg, #008461)}.ic-button.filled-warning,.ic-button.filled-danger,.ic-button.filled-neutral,.ic-button.filled-basic,.ic-button.filled-success,.ic-button.filled-blue{color:var(--ic-btn-filled-color, #fff)}.ic-button.filled-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-success:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-blue:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.filled-warning.disabled,.ic-button.filled-danger.disabled,.ic-button.filled-neutral.disabled,.ic-button.filled-basic.disabled,.ic-button.filled-success.disabled,.ic-button.filled-blue.disabled{background:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.filled:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.filled.disabled{background:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.filled-rounded{border-radius:30px;background:var(--ic-btn-filled-bg, linear-gradient(90deg, #0062e1 0%, #03a 100%));color:var(--ic-btn-filled-color, #fff)}.ic-button.filled-rounded-warning{background:var(--ic-btn-filled-warning-bg, #d68c00)}.ic-button.filled-rounded-danger{background:var(--ic-btn-filled-danger-bg, #b20000)}.ic-button.filled-rounded-neutral{background:var(--ic-btn-filled-neutral-bg, #0033a1)}.ic-button.filled-rounded-blue{background:var(--ic-btn-filled-blue-bg, #0062e1)}.ic-button.filled-rounded-basic{background:var(--ic-btn-filled-basic-bg, #000)}.ic-button.filled-rounded-success{background:var(--ic-btn-filled-success-bg, #008461)}.ic-button.filled-rounded-warning,.ic-button.filled-rounded-danger,.ic-button.filled-rounded-neutral,.ic-button.filled-rounded-basic,.ic-button.filled-rounded-success,.ic-button.filled-rounded-blue{border-radius:30px;color:var(--ic-btn-filled-color, #fff)}.ic-button.filled-rounded-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-rounded-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-rounded-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-rounded-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-rounded-success:hover:not(.disabled,.ic-button.skeleton),.ic-button.filled-rounded-blue:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.filled-rounded-warning.disabled,.ic-button.filled-rounded-danger.disabled,.ic-button.filled-rounded-neutral.disabled,.ic-button.filled-rounded-basic.disabled,.ic-button.filled-rounded-success.disabled,.ic-button.filled-rounded-blue.disabled{background:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.filled-rounded:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.filled-rounded.disabled{background:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined{background:var(--ic-btn-outlined-bg, #fff);border:1px solid var(--ic-btn-outlined-border, #0033a1);color:var(--ic-btn-outlined-color, #0033a1)}.ic-button.outlined-warning{border:1px solid var(--ic-btn-outlined-warning, #d68c00);color:var(--ic-btn-outlined-warning, #d68c00)}.ic-button.outlined-danger{border:1px solid var(--ic-btn-outlined-danger, #b20000);color:var(--ic-btn-outlined-danger, #b20000)}.ic-button.outlined-neutral{border:1px solid var(--ic-btn-outlined-neutral, #0033a1);color:var(--ic-btn-outlined-neutral, #0033a1)}.ic-button.outlined-basic{border:1px solid var(--ic-btn-outlined-basic, #000);color:var(--ic-btn-outlined-basic, #000)}.ic-button.outlined-success{border:1px solid var(--ic-btn-outlined-success, #008461);color:var(--ic-btn-outlined-success, #008461)}.ic-button.outlined-warning,.ic-button.outlined-danger,.ic-button.outlined-neutral,.ic-button.outlined-basic,.ic-button.outlined-success{background:var(--ic-btn-outlined-bg, #fff)}.ic-button.outlined-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-success:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-outlined-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.outlined-warning.disabled,.ic-button.outlined-danger.disabled,.ic-button.outlined-neutral.disabled,.ic-button.outlined-basic.disabled,.ic-button.outlined-success.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);background:var(--ic-btn-outlined-bg, #fff)!important;pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-outlined-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.outlined.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-rounded{border:1px solid var(--ic-btn-outlined-border, #0033a1);color:var(--ic-btn-outlined-color, #0033a1);background:var(--ic-btn-outlined-bg, #fff);border-radius:30px}.ic-button.outlined-rounded-warning{border:1px solid var(--ic-btn-outlined-warning, #d68c00);color:var(--ic-btn-outlined-warning, #d68c00)}.ic-button.outlined-rounded-danger{border:1px solid var(--ic-btn-outlined-danger, #b20000);color:var(--ic-btn-outlined-danger, #b20000)}.ic-button.outlined-rounded-neutral{border:1px solid var(--ic-btn-outlined-neutral, #0033a1);color:var(--ic-btn-outlined-neutral, #0033a1)}.ic-button.outlined-rounded-basic{border:1px solid var(--ic-btn-outlined-basic, #000);color:var(--ic-btn-outlined-basic, #000)}.ic-button.outlined-rounded-success{border:1px solid var(--ic-btn-outlined-success, #008461);color:var(--ic-btn-outlined-success, #008461)}.ic-button.outlined-rounded-warning,.ic-button.outlined-rounded-danger,.ic-button.outlined-rounded-neutral,.ic-button.outlined-rounded-basic,.ic-button.outlined-rounded-success{background:var(--ic-btn-outlined-bg, #fff);border-radius:30px}.ic-button.outlined-rounded-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-success:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-outlined-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.outlined-rounded-warning.disabled,.ic-button.outlined-rounded-danger.disabled,.ic-button.outlined-rounded-neutral.disabled,.ic-button.outlined-rounded-basic.disabled,.ic-button.outlined-rounded-success.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);background:transparent!important;pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-rounded:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-outlined-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.outlined-rounded.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.status{border:1px solid var(--ic-btn-status-border, #0033a1);color:var(--ic-btn-status-color, #0033a1)}.ic-button.status-warning{border:1px solid var(--ic-btn-status-warning, #d68c00);color:var(--ic-btn-status-warning, #d68c00);background:var(--ic-btn-status-warning-bg, #fff7e6)!important}.ic-button.status-danger{border:1px solid var(--ic-btn-status-danger, #b20000);color:var(--ic-btn-status-danger, #b20000);background:var(--ic-btn-status-danger-bg, #ffe7e8)!important}.ic-button.status-neutral{border:1px solid var(--ic-btn-status-neutral, #0033a1);color:var(--ic-btn-status-neutral, #0033a1);background:var(--ic-btn-status-neutral-bg, #e3e9fe)!important}.ic-button.status-basic{border:1px solid var(--ic-btn-status-basic, #000);color:var(--ic-btn-status-basic, #000);background:var(--ic-btn-status-basic-bg, #fff)!important}.ic-button.status-success{border:1px solid var(--ic-btn-status-success, #008461);color:var(--ic-btn-status-success, #008461);background:var(--ic-btn-status-success-bg, #ddf8f1)!important}.ic-button.status-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-success:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-status-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.status-warning.disabled,.ic-button.status-danger.disabled,.ic-button.status-neutral.disabled,.ic-button.status-basic.disabled,.ic-button.status-success.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.status:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-status-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.status.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.status-rounded{border:1px solid var(--ic-btn-status-border, #0033a1);color:var(--ic-btn-status-color, #0033a1);border-radius:30px}.ic-button.status-rounded-warning{border:1px solid var(--ic-btn-status-warning, #d68c00);color:var(--ic-btn-status-warning, #d68c00);background:var(--ic-btn-status-warning-bg, #fff7e6)!important}.ic-button.status-rounded-danger{border:1px solid var(--ic-btn-status-danger, #b20000);color:var(--ic-btn-status-danger, #b20000);background:var(--ic-btn-status-danger-bg, #ffe7e8)!important}.ic-button.status-rounded-neutral{border:1px solid var(--ic-btn-status-neutral, #0033a1);color:var(--ic-btn-status-neutral, #0033a1);background:var(--ic-btn-status-neutral-bg, #e3e9fe)!important}.ic-button.status-rounded-basic{border:1px solid var(--ic-btn-status-basic, #000);color:var(--ic-btn-status-basic, #000);background:var(--ic-btn-status-basic-bg, #fff)!important}.ic-button.status-rounded-success{border:1px solid var(--ic-btn-status-success, #008461);color:var(--ic-btn-status-success, #008461);background:var(--ic-btn-status-success-bg, #ddf8f1)!important}.ic-button.status-rounded-warning,.ic-button.status-rounded-danger,.ic-button.status-rounded-neutral,.ic-button.status-rounded-basic,.ic-button.status-rounded-success{background:var(--ic-btn-status-bg, #fff);border-radius:30px}.ic-button.status-rounded-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-rounded-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-rounded-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-rounded-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.status-rounded-success:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-status-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.status-rounded-warning.disabled,.ic-button.status-rounded-danger.disabled,.ic-button.status-rounded-neutral.disabled,.ic-button.status-rounded-basic.disabled,.ic-button.status-rounded-success.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.status-rounded:hover:not(.disabled,.ic-button.skeleton){background:var(--ic-btn-status-hover-bg, rgba(0, 127, 255, .0784313725))}.ic-button.status-rounded.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-transparent{background:transparent;border:1px solid var(--ic-btn-outlined-transparent-border, #fff);color:var(--ic-btn-outlined-transparent-color, #fff)}.ic-button.outlined-transparent-warning{border:1px solid var(--ic-btn-outlined-warning, #d68c00);color:var(--ic-btn-outlined-warning, #d68c00)}.ic-button.outlined-transparent-danger{border:1px solid var(--ic-btn-outlined-danger, #b20000);color:var(--ic-btn-outlined-danger, #b20000)}.ic-button.outlined-transparent-neutral{border:1px solid var(--ic-btn-outlined-neutral, #0033a1);color:var(--ic-btn-outlined-neutral, #0033a1)}.ic-button.outlined-transparent-basic{border:1px solid var(--ic-btn-outlined-basic, #000);color:var(--ic-btn-outlined-basic, #000)}.ic-button.outlined-transparent-success{border:1px solid var(--ic-btn-outlined-success, #008461);color:var(--ic-btn-outlined-success, #008461)}.ic-button.outlined-transparent-warning,.ic-button.outlined-transparent-danger,.ic-button.outlined-transparent-neutral,.ic-button.outlined-transparent-basic,.ic-button.outlined-transparent-success{background:transparent}.ic-button.outlined-transparent-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-transparent-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-transparent-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-transparent-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-transparent-success:hover:not(.disabled,.ic-button.skeleton){color:var(--ic-btn-outlined-transparent-hover-color, #212353);background:var(--ic-btn-outlined-transparent-hover-bg, #fff)}.ic-button.outlined-transparent-warning.disabled,.ic-button.outlined-transparent-danger.disabled,.ic-button.outlined-transparent-neutral.disabled,.ic-button.outlined-transparent-basic.disabled,.ic-button.outlined-transparent-success.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-transparent:hover:not(.disabled,.ic-button.skeleton){color:var(--ic-btn-outlined-transparent-hover-color, #212353);background:var(--ic-btn-outlined-transparent-hover-bg, #fff)}.ic-button.outlined-transparent.disabled{border:1px solid var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-rounded-transparent{background:transparent;border-radius:30px;border:1px solid var(--ic-btn-outlined-transparent-border, #fff);color:var(--ic-btn-outlined-transparent-color, #fff)}.ic-button.outlined-rounded-transparent-warning{border:1px solid var(--ic-btn-outlined-warning, #d68c00);color:var(--ic-btn-outlined-warning, #d68c00)}.ic-button.outlined-rounded-transparent-danger{border:1px solid var(--ic-btn-outlined-danger, #b20000);color:var(--ic-btn-outlined-danger, #b20000)}.ic-button.outlined-rounded-transparent-neutral{border:1px solid var(--ic-btn-outlined-neutral, #0033a1);color:var(--ic-btn-outlined-neutral, #0033a1)}.ic-button.outlined-rounded-transparent-basic{border:1px solid var(--ic-btn-outlined-basic, #000);color:var(--ic-btn-outlined-basic, #000)}.ic-button.outlined-rounded-transparent-success{border:1px solid var(--ic-btn-outlined-success, #008461);color:var(--ic-btn-outlined-success, #008461)}.ic-button.outlined-rounded-transparent-warning,.ic-button.outlined-rounded-transparent-danger,.ic-button.outlined-rounded-transparent-neutral,.ic-button.outlined-rounded-transparent-basic,.ic-button.outlined-rounded-transparent-success{background:transparent;border-radius:30px}.ic-button.outlined-rounded-transparent-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-transparent-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-transparent-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-transparent-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.outlined-rounded-transparent-success:hover:not(.disabled,.ic-button.skeleton){color:var(--ic-btn-outlined-transparent-hover-color, #212353);background:var(--ic-btn-outlined-transparent-hover-bg, #fff)}.ic-button.outlined-rounded-transparent-warning.disabled,.ic-button.outlined-rounded-transparent-danger.disabled,.ic-button.outlined-rounded-transparent-neutral.disabled,.ic-button.outlined-rounded-transparent-basic.disabled,.ic-button.outlined-rounded-transparent-success.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.outlined-rounded-transparent:hover:not(.disabled,.ic-button.skeleton){color:var(--ic-btn-outlined-transparent-hover-color, #212353);background:var(--ic-btn-outlined-transparent-hover-bg, #fff)}.ic-button.outlined-rounded-transparent.disabled{color:var(--ic-btn-disabled-bg, #cecece);border:1px solid var(--ic-btn-disabled-bg, #cecece);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.ghost{color:var(--ic-btn-ghost-color, #0033a1);background:var(--ic-btn-ghost-bg, #fff);box-shadow:var(--ic-btn-ghost-shadow, 0px 3px 10px 0px rgba(0, 0, 0, .0901960784))}.ic-button.ghost-warning{color:var(--ic-btn-ghost-warning, #d68c00)}.ic-button.ghost-danger{color:var(--ic-btn-ghost-danger, #b20000)}.ic-button.ghost-neutral{color:var(--ic-btn-ghost-neutral, #0033a1)}.ic-button.ghost-basic{color:var(--ic-btn-ghost-basic, #000)}.ic-button.ghost-success{color:var(--ic-btn-ghost-success, #008461)}.ic-button.ghost-warning,.ic-button.ghost-danger,.ic-button.ghost-neutral,.ic-button.ghost-basic,.ic-button.ghost-success{background:var(--ic-btn-ghost-bg, #fff);box-shadow:var(--ic-btn-ghost-shadow, 0px 3px 10px 0px rgba(0, 0, 0, .0901960784))}.ic-button.ghost-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-success:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.ghost-warning.disabled,.ic-button.ghost-danger.disabled,.ic-button.ghost-neutral.disabled,.ic-button.ghost-basic.disabled,.ic-button.ghost-success.disabled{background:var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-ghost-disabled-color, #fff);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.ghost:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.ghost.disabled{background:var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-ghost-disabled-color, #fff);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.ghost-rounded{border-radius:30px;background:var(--ic-btn-ghost-bg, #fff);color:var(--ic-btn-ghost-color, #0033a1);box-shadow:var(--ic-btn-ghost-shadow, 0px 3px 10px 0px rgba(0, 0, 0, .0901960784))}.ic-button.ghost-rounded-warning{color:var(--ic-btn-ghost-warning, #d68c00)}.ic-button.ghost-rounded-danger{color:var(--ic-btn-ghost-danger, #b20000)}.ic-button.ghost-rounded-neutral{color:var(--ic-btn-ghost-neutral, #0033a1)}.ic-button.ghost-rounded-basic{color:var(--ic-btn-ghost-basic, #000)}.ic-button.ghost-rounded-success{color:var(--ic-btn-ghost-success, #008461)}.ic-button.ghost-rounded-warning,.ic-button.ghost-rounded-danger,.ic-button.ghost-rounded-neutral,.ic-button.ghost-rounded-basic,.ic-button.ghost-rounded-success{border-radius:30px;background:var(--ic-btn-ghost-bg, #fff);box-shadow:var(--ic-btn-ghost-shadow, 0px 3px 10px 0px rgba(0, 0, 0, .0901960784))}.ic-button.ghost-rounded-warning:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-rounded-danger:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-rounded-neutral:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-rounded-basic:hover:not(.disabled,.ic-button.skeleton),.ic-button.ghost-rounded-success:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.ghost-rounded-warning.disabled,.ic-button.ghost-rounded-danger.disabled,.ic-button.ghost-rounded-neutral.disabled,.ic-button.ghost-rounded-basic.disabled,.ic-button.ghost-rounded-success.disabled{background:var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-ghost-disabled-color, #fff);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button.ghost-rounded:hover:not(.disabled,.ic-button.skeleton){box-shadow:none;filter:brightness(.97) saturate(2)}.ic-button.ghost-rounded.disabled{background:var(--ic-btn-disabled-bg, #cecece);color:var(--ic-btn-ghost-disabled-color, #fff);pointer-events:none;box-shadow:none;cursor:not-allowed!important}.ic-button .ic-loading-spinner{border:2px solid transparent;border-top:2px solid var(--ic-btn-spinner-color, #fff);border-radius:50%;width:16px;height:16px;animation:spin 1s linear infinite;margin:auto}@keyframes spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}.ic-button.skeleton{background:linear-gradient(90deg,#f0f0f0 25%,#e0e0e0,#f0f0f0 75%);background-size:200% 100%;animation:skeleton-animation 1.5s infinite;box-shadow:none}@keyframes skeleton-animation{0%{background-position:200% 0}to{background-position:-200% 0}}.ic-button.disabled{background:var(--ic-btn-disabled-bg, #cecece);pointer-events:none;cursor:not-allowed!important}.ic-button.iconButtonClass{padding:8px;display:flex;justify-content:center}.ic-button .icon-div{width:16px;height:100%;align-items:center;display:flex}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], type: [{
                type: Input
            }], size: [{
                type: Input
            }], disabled: [{
                type: Input
            }], isLoading: [{
                type: Input
            }], isSkeleton: [{
                type: Input
            }], icButtonType: [{
                type: Input
            }], icIcon: [{
                type: Input
            }], prefixIcon: [{
                type: Input
            }], suffixIcon: [{
                type: Input
            }], customButtonClass: [{
                type: Input
            }], OnClick: [{
                type: Output
            }] } });

class HeaderComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: HeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: HeaderComponent, selector: "ic-header", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true, styles: [":host{display:block;font-size:1.25rem;font-weight:500;padding:16px;background:#f5f5f5;border-bottom:1px solid #e0e0e0}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: HeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-header', template: `<ng-content></ng-content>`, styles: [":host{display:block;font-size:1.25rem;font-weight:500;padding:16px;background:#f5f5f5;border-bottom:1px solid #e0e0e0}\n"] }]
        }] });

class FooterComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FooterComponent, selector: "ic-footer", ngImport: i0, template: `<ng-content></ng-content>`, isInline: true, styles: [":host{display:block;padding:16px;background:#f5f5f5;border-top:1px solid #e0e0e0;text-align:right}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FooterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-footer', template: `<ng-content></ng-content>`, styles: [":host{display:block;padding:16px;background:#f5f5f5;border-top:1px solid #e0e0e0;text-align:right}\n"] }]
        }] });

class CardComponent {
    constructor() {
        this.header = null;
        this.footer = null;
        this.hasHeader = false;
        this.hasFooter = false;
    }
    ngAfterContentInit() {
        // Dynamically check if header and footer content exist
        this.hasHeader = !!this.header;
        this.hasFooter = !!this.footer;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: CardComponent, selector: "ic-card", queries: [{ propertyName: "header", first: true, predicate: HeaderComponent, descendants: true }, { propertyName: "footer", first: true, predicate: FooterComponent, descendants: true }], ngImport: i0, template: "<div class=\"ic-card\">\r\n  <!-- Render Header -->\r\n  <div class=\"ic-card__header\" *ngIf=\"hasHeader\">\r\n    <ng-content select=\"ic-header\"></ng-content>\r\n  </div>\r\n\r\n  <!-- Render Body -->\r\n  <div class=\"ic-card__body\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n\r\n  <!-- Render Footer -->\r\n  <div class=\"ic-card__footer\" *ngIf=\"hasFooter\">\r\n    <ng-content select=\"ic-footer\"></ng-content>\r\n  </div>\r\n</div>\r\n", styles: [".ic-card{display:flex;flex-direction:column;background:var(--ic-card-bg, #ffffff);border-radius:8px;box-shadow:var(--ic-card-shadow, 0px 3px 9px 0px rgba(0, 0, 0, .11));overflow:hidden}.ic-card__body{padding:16px}\n"], dependencies: [{ kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-card', template: "<div class=\"ic-card\">\r\n  <!-- Render Header -->\r\n  <div class=\"ic-card__header\" *ngIf=\"hasHeader\">\r\n    <ng-content select=\"ic-header\"></ng-content>\r\n  </div>\r\n\r\n  <!-- Render Body -->\r\n  <div class=\"ic-card__body\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n\r\n  <!-- Render Footer -->\r\n  <div class=\"ic-card__footer\" *ngIf=\"hasFooter\">\r\n    <ng-content select=\"ic-footer\"></ng-content>\r\n  </div>\r\n</div>\r\n", styles: [".ic-card{display:flex;flex-direction:column;background:var(--ic-card-bg, #ffffff);border-radius:8px;box-shadow:var(--ic-card-shadow, 0px 3px 9px 0px rgba(0, 0, 0, .11));overflow:hidden}.ic-card__body{padding:16px}\n"] }]
        }], propDecorators: { header: [{
                type: ContentChild,
                args: [HeaderComponent]
            }], footer: [{
                type: ContentChild,
                args: [FooterComponent]
            }] } });

class FormFieldComponent {
    constructor() {
        this.label = ''; // Label for the form field
        this.type = 'text'; // Input type
        this.placeholder = ''; // Placeholder
        this.id = ''; // Input ID
        this.control = new FormControl();
        this.disabled = false;
        this.customClass = '';
        this.prefixIcon = '';
        this.numLength = 2;
        this.decimalPlaces = 10;
        this.suffixButton = '';
        this.readonly = false;
        this.skipLabel = false;
        this.customError = '';
        this.addDiv = '';
        // Attribute Directives Input
        this.icNumbersOnly = false;
        this.icAlphaNumericWithSpace = false;
        this.icSpecialAlphaNumeric = false;
        this.icSpecialAlphaNumericExtended = false;
        this.icAlphanumeric = false;
        this.icNoSpace = false;
        this.icSpecialText = false;
        this.icIsUpperCase = false;
        this.icNoSpecialCharFirst = false;
        this.icAlphabetOnly = false;
        this.icRestrictPercentage = false;
        this.icRestrictDecimal = false;
        this.icTwoDigitDecimalNumber = false;
        this.alphabetspace = false;
        this.appNoInitialDot = false;
        this.specialIsAlphaNumeric = false;
        this.someSpecialIsAlphaNumeric = false;
        this.icPreventInitialZero = false;
        this.icCurrencyFormatter = '';
        this.icCleaveCurrency = false;
        this.isRequired = false;
        this.isFocused = false;
        this.showPopover = false;
        this.onSuffixClick = new EventEmitter();
        this.onInputChange = new EventEmitter();
        this.onKeyUp = new EventEmitter();
        this.onKeyDown = new EventEmitter();
        this.onChange = (_) => { }; // ControlValueAccessor callback
        this.onTouched = () => { }; // ControlValueAccessor callback
        this.valueChangesSubscription = null; // Store the subscription
        this.lastRequiredCheck = null;
    }
    ngOnInit() {
        if (!this.control) {
            this.control = new FormControl();
        }
        this.updateIsRequired();
        if (this.control.value || this.control.value === 0) {
            this.isFocused = true;
        }
        if (this.disabled) {
            this.control.disable();
        }
        this.valueChangesSubscription = this.control.valueChanges.subscribe((value) => {
            if (this.maxLength && value && value.length > this.maxLength) {
                this.control.setValue(value.substring(0, this.maxLength), {
                    emitEvent: false,
                });
            }
            this.onChange(value);
            this.onInputChange.emit(value);
        });
    }
    ngOnChanges(changes) {
        if (changes['disabled']) {
            this.setDisabledState(changes['disabled'].currentValue);
        }
        if (changes['maxLength'] &&
            this.maxLength !== undefined &&
            this.control?.value?.length > this.maxLength) {
            this.control.setValue(this.control.value.substring(0, this.maxLength), {
                emitEvent: false,
            });
        }
    }
    ngDoCheck() {
        this.updateIsRequired();
    }
    updateIsRequired() {
        const required = this.control?.validator?.({})?.['required'] ?? false;
        if (required !== this.lastRequiredCheck) {
            this.isRequired = required;
            this.lastRequiredCheck = required;
        }
    }
    ngOnDestroy() {
        // Unsubscribe to avoid memory leaks
        if (this.valueChangesSubscription) {
            this.valueChangesSubscription.unsubscribe();
        }
    }
    setDisabledState(isDisabled) {
        if (isDisabled) {
            this.control?.disable();
        }
        else {
            this.control?.enable();
        }
    }
    onFocus() {
        this.isFocused = true;
    }
    onBlur() {
        // Ensure the label stays floated if the control has a value
        if (this.control.value || this.control.value === 0) {
            this.isFocused = true;
        }
        else {
            this.isFocused = false;
        }
        this.onTouched();
    }
    writeValue(value) {
        if (this.control) {
            // Enforce maxLength when setting value
            if (this.maxLength && value?.length > this.maxLength) {
                value = value.substring(0, this.maxLength);
            }
            this.control.setValue(value, { emitEvent: false });
            // Float the label if value is not empty
            if (value || value === 0) {
                this.isFocused = true;
            }
            else {
                this.isFocused = false;
            }
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    validate(control) {
        return this.control?.valid
            ? null
            : { invalidForm: { value: control.value } };
    }
    checkIfRequired(control) {
        if (!control || !control.validator) {
            return false;
        }
        const validator = control.validator({});
        return !!(validator && validator['required']);
    }
    get errorMessages() {
        let errors = [];
        if (this.control?.errors && (this.control.dirty || this.control.touched)) {
            if (this.control.errors['required']) {
                errors.push(`${this.label} is Required!`);
            }
            if (this.control.errors['minlength']) {
                errors.push(`Minimum length is ${this.control.errors['minlength'].requiredLength} characters.`);
            }
            if (this.control.errors['maxlength']) {
                errors.push(`Maximum length is ${this.control.errors['maxlength'].requiredLength} characters.`);
            }
        }
        // Always show custom errors if provided
        if (this.customError) {
            if (Array.isArray(this.customError)) {
                errors.push(...this.customError);
            }
            else {
                errors.push(this.customError);
            }
        }
        return errors;
    }
    get firstErrorMessage() {
        return this.errorMessages.length ? (this.errorMessages[0] ?? '') : '';
    }
    get remainingErrorCount() {
        return this.errorMessages.length > 1 ? this.errorMessages.length - 1 : 0;
    }
    get isLabelFloated() {
        return (this.isFocused || !!this.control?.getRawValue() || this.type === 'date');
    }
    handleInputChange(event) {
        const inputElement = event.target;
        this.onInputChange.emit(inputElement.value);
    }
    suffixClick(event) {
        this.onSuffixClick.emit(event);
    }
    handleKeyUp(event) {
        this.onKeyUp.emit(event);
    }
    handleKeyDown(event) {
        this.onKeyDown.emit(event);
    }
    get inputControl() {
        return this.control;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FormFieldComponent, selector: "ic-form-field", inputs: { label: "label", type: "type", placeholder: "placeholder", id: "id", control: "control", disabled: "disabled", customClass: "customClass", prefixIcon: "prefixIcon", minLength: "minLength", maxLength: "maxLength", numLength: "numLength", decimalPlaces: "decimalPlaces", suffixIcon: "suffixIcon", suffixButton: "suffixButton", readonly: "readonly", skipLabel: "skipLabel", maskedInput: "maskedInput", customError: "customError", addDiv: "addDiv", icNumbersOnly: "icNumbersOnly", icAlphaNumericWithSpace: "icAlphaNumericWithSpace", icSpecialAlphaNumeric: "icSpecialAlphaNumeric", icSpecialAlphaNumericExtended: "icSpecialAlphaNumericExtended", icAlphanumeric: "icAlphanumeric", icNoSpace: "icNoSpace", icSpecialText: "icSpecialText", icIsUpperCase: "icIsUpperCase", icNoSpecialCharFirst: "icNoSpecialCharFirst", icAlphabetOnly: "icAlphabetOnly", icRestrictPercentage: "icRestrictPercentage", icRestrictDecimal: "icRestrictDecimal", icTwoDigitDecimalNumber: "icTwoDigitDecimalNumber", alphabetspace: "alphabetspace", appNoInitialDot: "appNoInitialDot", specialIsAlphaNumeric: "specialIsAlphaNumeric", someSpecialIsAlphaNumeric: "someSpecialIsAlphaNumeric", icPreventInitialZero: "icPreventInitialZero", icCurrencyFormatter: "icCurrencyFormatter", icCleaveCurrency: "icCleaveCurrency" }, outputs: { onSuffixClick: "onSuffixClick", onInputChange: "onInputChange", onKeyUp: "onKeyUp", onKeyDown: "onKeyDown" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"ic-form-field {{ customClass }}\">\r\n  <label\r\n    *ngIf=\"label && !skipLabel\"\r\n    [for]=\"id\"\r\n    [class.floated]=\"isLabelFloated\"\r\n    [attr.aria-label]=\"label\"\r\n    [attr.aria-invalid]=\"control.invalid && (control.dirty || control.touched)\"\r\n    [attr.aria-describedby]=\"control.invalid ? 'error-message' : null\">\r\n    {{ label }}\r\n    <span *ngIf=\"isRequired\" class=\"required_star\" style=\"color: red\">*</span>\r\n  </label>\r\n\r\n  <div\r\n    class=\"input-wrapper\"\r\n    [class.disabled]=\"this.disabled\"\r\n    [ngStyle]=\"{ width: addDiv ? 'calc(100% - 30px)' : '100%' }\">\r\n    <ng-container *ngIf=\"isLabelFloated && prefixIcon\">\r\n      <div class=\"prefix-div\">{{ prefixIcon }}</div>\r\n    </ng-container>\r\n    <!-- Input field with dynamic directive -->\r\n    <input\r\n      [id]=\"id\"\r\n      [type]=\"type\"\r\n      [formControl]=\"inputControl\"\r\n      [placeholder]=\"isFocused && !control.value ? placeholder : ''\"\r\n      [class.invalid]=\"control.invalid && (control.dirty || control.touched)\"\r\n      [disabled]=\"disabled\"\r\n      (focus)=\"onFocus()\"\r\n      (blur)=\"onBlur()\"\r\n      (input)=\"handleInputChange($event)\"\r\n      (keyup)=\"handleKeyUp($event)\"\r\n      (keydown)=\"handleKeyDown($event)\"\r\n      [attr.icAlphaNumericWithSpace]=\"icAlphaNumericWithSpace ? '' : null\"\r\n      [attr.icAlphanumeric]=\"icAlphanumeric ? '' : null\"\r\n      [icIsUpperCase]=\"icIsUpperCase\"\r\n      [icNoSpace]=\"icNoSpace ? icNoSpace : false\"\r\n      [icNumbersOnly]=\"icNumbersOnly ? icNumbersOnly : false\"\r\n      [icSpecialAlphaNumeric]=\"\r\n        icSpecialAlphaNumeric ? icSpecialAlphaNumeric : false\r\n      \"\r\n      [icPreventInitialZero]=\"\r\n        icPreventInitialZero ? icPreventInitialZero : false\r\n      \"\r\n      [icSpecialAlphaNumericExtended]=\"\r\n        icSpecialAlphaNumericExtended ? icSpecialAlphaNumericExtended : false\r\n      \"\r\n      [icCurrencyFormatter]=\"icCurrencyFormatter\"\r\n      [attr.icSpecialText]=\"icSpecialText ? '' : null\"\r\n      [attr.icAlphabetOnly]=\"icAlphabetOnly ? '' : null\"\r\n      [attr.icNoSpecialCharFirst]=\"icNoSpecialCharFirst ? '' : null\"\r\n      [attr.icRestrictPercentage]=\"icRestrictPercentage ? '' : null\"\r\n      [attr.icRestrictDecimal]=\"icRestrictDecimal ? '' : null\"\r\n      [icTwoDigitDecimalNumber]=\"\r\n        icTwoDigitDecimalNumber ? icTwoDigitDecimalNumber : false\r\n      \"\r\n      [decimalPlaces]=\"decimalPlaces\"\r\n      [numLength]=\"numLength\"\r\n      [attr.alphabetspace]=\"alphabetspace ? '' : null\"\r\n      [attr.appNoInitialDot]=\"appNoInitialDot ? '' : null\"\r\n      [attr.specialIsAlphaNumeric]=\"specialIsAlphaNumeric ? '' : null\"\r\n      [attr.someSpecialIsAlphaNumeric]=\"someSpecialIsAlphaNumeric ? '' : null\"\r\n      [inputMask]=\"maskedInput ? maskedInput : null\"\r\n      maxlength=\"{{ maxLength }}\"\r\n      minlength=\"{{ minLength }}\"\r\n      [readonly]=\"readonly\"\r\n      [icCleaveCurrency]=\"icCleaveCurrency ? icCleaveCurrency : false\" />\r\n    <ng-container *ngIf=\"suffixIcon\">\r\n      <ic-icon\r\n        class=\"suffix-div\"\r\n        [name]=\"suffixIcon\"\r\n        (click)=\"suffixClick($event)\"\r\n        [class.disabled]=\"disabled\">\r\n      </ic-icon>\r\n    </ng-container>\r\n    <ng-container *ngIf=\"suffixButton\">\r\n      <ic-button\r\n        label=\"{{ suffixButton }}\"\r\n        type=\"submit\"\r\n        size=\"small\"\r\n        [disabled]=\"disabled\"\r\n        icButtonType=\"filled\"\r\n        (OnClick)=\"suffixClick($event)\">\r\n      </ic-button>\r\n    </ng-container>\r\n  </div>\r\n  <ng-container *ngIf=\"addDiv\">\r\n    <div\r\n      class=\"add_div\"\r\n      (click)=\"suffixClick($event)\"\r\n      [class.disabled]=\"disabled\">\r\n      {{ addDiv }}\r\n    </div>\r\n  </ng-container>\r\n\r\n  <div\r\n    *ngIf=\"\r\n      (control?.invalid && (control?.dirty || control?.touched)) || customError\r\n    \"\r\n    class=\"error-message\">\r\n    <div>{{ firstErrorMessage }}</div>\r\n\r\n    <div\r\n      *ngIf=\"remainingErrorCount\"\r\n      class=\"error-counter\"\r\n      (mouseover)=\"showPopover = true\"\r\n      (mouseleave)=\"showPopover = false\">\r\n      +{{ remainingErrorCount }}\r\n\r\n      <!-- Popover for multiple errors -->\r\n      <div class=\"popover\" *ngIf=\"showPopover\">\r\n        <ul>\r\n          <li *ngFor=\"let err of errorMessages.slice(1)\">\r\n            {{ err }}\r\n          </li>\r\n        </ul>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n", styles: [".ic-form-field{position:relative;margin:8px 0;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif),serif;display:flex;flex-direction:column;transition:margin-bottom .3s ease}.ic-form-field .input-wrapper{position:relative;display:flex;flex-direction:row;align-items:center;padding:8px 8px 8px 16px;height:40px;font-size:14px!important;border:2px solid var(--ic-form-field-border, #dcdcdc);border-radius:8px;background:var(--ic-form-field-bg, #fff);outline:none;box-shadow:var(--ic-form-field-box-shadow, none);transition:border-color .3s ease,box-shadow .3s ease;z-index:2}.ic-form-field .input-wrapper:has(input:focus){border-color:var(--ic-form-field-border-focus, #0033a1)}.ic-form-field .input-wrapper:has(input.invalid){border-color:var(--ic-form-field-border-error, red)}.ic-form-field .input-wrapper:has(input:disabled){background-color:var(--ic-form-field-disabled-bg, #f3f3f3)!important;border-color:var(--ic-form-field-disabled-border, #dcdcdc)!important;box-shadow:none!important;cursor:not-allowed!important}.ic-form-field .input-wrapper.disabled{background-color:var(--ic-form-field-disabled-bg, #f3f3f3)!important;border-color:var(--ic-form-field-disabled-border, #dcdcdc)!important;box-shadow:none!important;color:var(--ic-form-field-disabled-color, gray)!important;pointer-events:none;cursor:not-allowed!important}.ic-form-field .input-wrapper .prefix-div{font-size:16px;color:var(--ic-form-field-prefix-color, #0033a1);display:flex;align-items:center}.ic-form-field .input-wrapper .suffix-div{width:24px;height:24px;align-items:center;display:flex;cursor:pointer}.ic-form-field .input-wrapper .suffix-div.disabled{cursor:not-allowed;pointer-events:none}.ic-form-field .add_div{height:40px;width:45px;border-radius:7px;background:var(--ic-form-field-add-bg, #e9ecf5);position:absolute;right:0;font-size:24px;color:var(--ic-form-field-add-color, #0033a1);cursor:pointer;display:flex;justify-content:flex-end;align-items:center;padding-right:8px}.ic-form-field .add_div:hover{background:var(--ic-form-field-add-hover-bg, #d7e3fb)}.ic-form-field .add_div.disabled{background:var(--ic-form-field-add-disabled-bg, #dcdcdc);color:var(--ic-form-field-add-disabled-color, #b1b1b1);pointer-events:none}.ic-form-field label{position:absolute;top:20px;left:12px;transform:translateY(-50%);font-size:14px;color:var(--ic-form-field-label-color, #666);padding:0 4px;transition:all .2s ease-in-out;pointer-events:none;z-index:3;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif),serif}.ic-form-field label.disabled{color:var(--ic-form-field-label-disabled-color, #999)}.ic-form-field label.floated{font-size:12px;top:0;background:var(--ic-form-field-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0) 30%, #ffffff 53%, rgba(0, 128, 0, 0) 80%))}.ic-form-field:has(input:not(:placeholder-shown)) label{color:var(--ic-form-field-label-active-color, #0033a1)}.ic-form-field input{font-size:14px!important;font-weight:500;background:transparent;outline:none;width:100%;border:none;transition:color .3s ease;color:var(--ic-form-field-input-color, inherit)}.ic-form-field input:disabled{background-color:transparent;color:var(--ic-form-field-input-disabled-color, #999)}.ic-form-field .error-message{color:var(--ic-form-field-error-color, red);font-size:12px;margin:0 16px;display:flex;align-items:center;gap:5px;z-index:4}.ic-form-field .error-counter{background-color:var(--ic-form-field-error-counter-bg, rgba(255, 0, 0, .1));color:var(--ic-form-field-error-counter-color, red);font-size:10px;padding:2px 5px;border-radius:10px;cursor:pointer;position:relative}.ic-form-field .popover{position:absolute;bottom:100%;left:0;background:var(--ic-form-field-popover-bg, #fff);border-radius:5px;padding:5px;box-shadow:var(--ic-form-field-popover-shadow, 0px 0px 10px rgba(255, 0, 0, .3));min-width:200px;z-index:10}.ic-form-field .popover div{padding:3px 5px;font-size:12px;color:var(--ic-form-field-popover-color, red)}.ic-form-field input[type=date]{appearance:none;-webkit-appearance:none;-moz-appearance:none;position:relative;padding-right:10px}.ic-form-field input[type=date]::-webkit-calendar-picker-indicator{background:var(--ic-icon-calendar) no-repeat center;background-size:contain;cursor:pointer;opacity:1}\n"], dependencies: [{ kind: "directive", type: i1$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.MinLengthValidator, selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]", inputs: ["minlength"] }, { kind: "directive", type: i2.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: InputMaskDirective, selector: "[inputMask]", inputs: ["inputMask"] }, { kind: "directive", type: IsUpperCaseDirective, selector: "[icIsUpperCase]", inputs: ["icIsUpperCase"] }, { kind: "directive", type: NoInitialSpaceDirective, selector: "input, textarea" }, { kind: "directive", type: NumbersOnlyDirective, selector: "[icNumbersOnly]", inputs: ["icNumbersOnly"] }, { kind: "directive", type: SpecialAlphaNumericDirective, selector: "[icSpecialAlphaNumeric]", inputs: ["icSpecialAlphaNumeric"] }, { kind: "directive", type: NoSpaceDirective, selector: "[icNoSpace]", inputs: ["icNoSpace"] }, { kind: "directive", type: TwoDigitDecimalNumberDirective, selector: "[icTwoDigitDecimalNumber]", inputs: ["icTwoDigitDecimalNumber", "decimalPlaces", "numLength"] }, { kind: "directive", type: PreventInitialZeroDirective, selector: "[icPreventInitialZero]", inputs: ["icPreventInitialZero"] }, { kind: "directive", type: SpecialAlphaNumericExtendedDirective, selector: "[icSpecialAlphaNumericExtended]", inputs: ["icSpecialAlphaNumericExtended"] }, { kind: "directive", type: CurrencyFormatterDirective, selector: "[icCurrencyFormatter]", inputs: ["icCurrencyFormatter"] }, { kind: "directive", type: CleaveCurrencyDirective, selector: "[icCleaveCurrency]", inputs: ["icCleaveCurrency"] }, { kind: "component", type: ButtonComponent, selector: "ic-button", inputs: ["label", "type", "size", "disabled", "isLoading", "isSkeleton", "icButtonType", "icIcon", "prefixIcon", "suffixIcon", "customButtonClass"], outputs: ["OnClick"] }, { kind: "component", type: IconComponent, selector: "ic-icon", inputs: ["name", "color", "size"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-form-field', template: "<div class=\"ic-form-field {{ customClass }}\">\r\n  <label\r\n    *ngIf=\"label && !skipLabel\"\r\n    [for]=\"id\"\r\n    [class.floated]=\"isLabelFloated\"\r\n    [attr.aria-label]=\"label\"\r\n    [attr.aria-invalid]=\"control.invalid && (control.dirty || control.touched)\"\r\n    [attr.aria-describedby]=\"control.invalid ? 'error-message' : null\">\r\n    {{ label }}\r\n    <span *ngIf=\"isRequired\" class=\"required_star\" style=\"color: red\">*</span>\r\n  </label>\r\n\r\n  <div\r\n    class=\"input-wrapper\"\r\n    [class.disabled]=\"this.disabled\"\r\n    [ngStyle]=\"{ width: addDiv ? 'calc(100% - 30px)' : '100%' }\">\r\n    <ng-container *ngIf=\"isLabelFloated && prefixIcon\">\r\n      <div class=\"prefix-div\">{{ prefixIcon }}</div>\r\n    </ng-container>\r\n    <!-- Input field with dynamic directive -->\r\n    <input\r\n      [id]=\"id\"\r\n      [type]=\"type\"\r\n      [formControl]=\"inputControl\"\r\n      [placeholder]=\"isFocused && !control.value ? placeholder : ''\"\r\n      [class.invalid]=\"control.invalid && (control.dirty || control.touched)\"\r\n      [disabled]=\"disabled\"\r\n      (focus)=\"onFocus()\"\r\n      (blur)=\"onBlur()\"\r\n      (input)=\"handleInputChange($event)\"\r\n      (keyup)=\"handleKeyUp($event)\"\r\n      (keydown)=\"handleKeyDown($event)\"\r\n      [attr.icAlphaNumericWithSpace]=\"icAlphaNumericWithSpace ? '' : null\"\r\n      [attr.icAlphanumeric]=\"icAlphanumeric ? '' : null\"\r\n      [icIsUpperCase]=\"icIsUpperCase\"\r\n      [icNoSpace]=\"icNoSpace ? icNoSpace : false\"\r\n      [icNumbersOnly]=\"icNumbersOnly ? icNumbersOnly : false\"\r\n      [icSpecialAlphaNumeric]=\"\r\n        icSpecialAlphaNumeric ? icSpecialAlphaNumeric : false\r\n      \"\r\n      [icPreventInitialZero]=\"\r\n        icPreventInitialZero ? icPreventInitialZero : false\r\n      \"\r\n      [icSpecialAlphaNumericExtended]=\"\r\n        icSpecialAlphaNumericExtended ? icSpecialAlphaNumericExtended : false\r\n      \"\r\n      [icCurrencyFormatter]=\"icCurrencyFormatter\"\r\n      [attr.icSpecialText]=\"icSpecialText ? '' : null\"\r\n      [attr.icAlphabetOnly]=\"icAlphabetOnly ? '' : null\"\r\n      [attr.icNoSpecialCharFirst]=\"icNoSpecialCharFirst ? '' : null\"\r\n      [attr.icRestrictPercentage]=\"icRestrictPercentage ? '' : null\"\r\n      [attr.icRestrictDecimal]=\"icRestrictDecimal ? '' : null\"\r\n      [icTwoDigitDecimalNumber]=\"\r\n        icTwoDigitDecimalNumber ? icTwoDigitDecimalNumber : false\r\n      \"\r\n      [decimalPlaces]=\"decimalPlaces\"\r\n      [numLength]=\"numLength\"\r\n      [attr.alphabetspace]=\"alphabetspace ? '' : null\"\r\n      [attr.appNoInitialDot]=\"appNoInitialDot ? '' : null\"\r\n      [attr.specialIsAlphaNumeric]=\"specialIsAlphaNumeric ? '' : null\"\r\n      [attr.someSpecialIsAlphaNumeric]=\"someSpecialIsAlphaNumeric ? '' : null\"\r\n      [inputMask]=\"maskedInput ? maskedInput : null\"\r\n      maxlength=\"{{ maxLength }}\"\r\n      minlength=\"{{ minLength }}\"\r\n      [readonly]=\"readonly\"\r\n      [icCleaveCurrency]=\"icCleaveCurrency ? icCleaveCurrency : false\" />\r\n    <ng-container *ngIf=\"suffixIcon\">\r\n      <ic-icon\r\n        class=\"suffix-div\"\r\n        [name]=\"suffixIcon\"\r\n        (click)=\"suffixClick($event)\"\r\n        [class.disabled]=\"disabled\">\r\n      </ic-icon>\r\n    </ng-container>\r\n    <ng-container *ngIf=\"suffixButton\">\r\n      <ic-button\r\n        label=\"{{ suffixButton }}\"\r\n        type=\"submit\"\r\n        size=\"small\"\r\n        [disabled]=\"disabled\"\r\n        icButtonType=\"filled\"\r\n        (OnClick)=\"suffixClick($event)\">\r\n      </ic-button>\r\n    </ng-container>\r\n  </div>\r\n  <ng-container *ngIf=\"addDiv\">\r\n    <div\r\n      class=\"add_div\"\r\n      (click)=\"suffixClick($event)\"\r\n      [class.disabled]=\"disabled\">\r\n      {{ addDiv }}\r\n    </div>\r\n  </ng-container>\r\n\r\n  <div\r\n    *ngIf=\"\r\n      (control?.invalid && (control?.dirty || control?.touched)) || customError\r\n    \"\r\n    class=\"error-message\">\r\n    <div>{{ firstErrorMessage }}</div>\r\n\r\n    <div\r\n      *ngIf=\"remainingErrorCount\"\r\n      class=\"error-counter\"\r\n      (mouseover)=\"showPopover = true\"\r\n      (mouseleave)=\"showPopover = false\">\r\n      +{{ remainingErrorCount }}\r\n\r\n      <!-- Popover for multiple errors -->\r\n      <div class=\"popover\" *ngIf=\"showPopover\">\r\n        <ul>\r\n          <li *ngFor=\"let err of errorMessages.slice(1)\">\r\n            {{ err }}\r\n          </li>\r\n        </ul>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n", styles: [".ic-form-field{position:relative;margin:8px 0;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif),serif;display:flex;flex-direction:column;transition:margin-bottom .3s ease}.ic-form-field .input-wrapper{position:relative;display:flex;flex-direction:row;align-items:center;padding:8px 8px 8px 16px;height:40px;font-size:14px!important;border:2px solid var(--ic-form-field-border, #dcdcdc);border-radius:8px;background:var(--ic-form-field-bg, #fff);outline:none;box-shadow:var(--ic-form-field-box-shadow, none);transition:border-color .3s ease,box-shadow .3s ease;z-index:2}.ic-form-field .input-wrapper:has(input:focus){border-color:var(--ic-form-field-border-focus, #0033a1)}.ic-form-field .input-wrapper:has(input.invalid){border-color:var(--ic-form-field-border-error, red)}.ic-form-field .input-wrapper:has(input:disabled){background-color:var(--ic-form-field-disabled-bg, #f3f3f3)!important;border-color:var(--ic-form-field-disabled-border, #dcdcdc)!important;box-shadow:none!important;cursor:not-allowed!important}.ic-form-field .input-wrapper.disabled{background-color:var(--ic-form-field-disabled-bg, #f3f3f3)!important;border-color:var(--ic-form-field-disabled-border, #dcdcdc)!important;box-shadow:none!important;color:var(--ic-form-field-disabled-color, gray)!important;pointer-events:none;cursor:not-allowed!important}.ic-form-field .input-wrapper .prefix-div{font-size:16px;color:var(--ic-form-field-prefix-color, #0033a1);display:flex;align-items:center}.ic-form-field .input-wrapper .suffix-div{width:24px;height:24px;align-items:center;display:flex;cursor:pointer}.ic-form-field .input-wrapper .suffix-div.disabled{cursor:not-allowed;pointer-events:none}.ic-form-field .add_div{height:40px;width:45px;border-radius:7px;background:var(--ic-form-field-add-bg, #e9ecf5);position:absolute;right:0;font-size:24px;color:var(--ic-form-field-add-color, #0033a1);cursor:pointer;display:flex;justify-content:flex-end;align-items:center;padding-right:8px}.ic-form-field .add_div:hover{background:var(--ic-form-field-add-hover-bg, #d7e3fb)}.ic-form-field .add_div.disabled{background:var(--ic-form-field-add-disabled-bg, #dcdcdc);color:var(--ic-form-field-add-disabled-color, #b1b1b1);pointer-events:none}.ic-form-field label{position:absolute;top:20px;left:12px;transform:translateY(-50%);font-size:14px;color:var(--ic-form-field-label-color, #666);padding:0 4px;transition:all .2s ease-in-out;pointer-events:none;z-index:3;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif),serif}.ic-form-field label.disabled{color:var(--ic-form-field-label-disabled-color, #999)}.ic-form-field label.floated{font-size:12px;top:0;background:var(--ic-form-field-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0) 30%, #ffffff 53%, rgba(0, 128, 0, 0) 80%))}.ic-form-field:has(input:not(:placeholder-shown)) label{color:var(--ic-form-field-label-active-color, #0033a1)}.ic-form-field input{font-size:14px!important;font-weight:500;background:transparent;outline:none;width:100%;border:none;transition:color .3s ease;color:var(--ic-form-field-input-color, inherit)}.ic-form-field input:disabled{background-color:transparent;color:var(--ic-form-field-input-disabled-color, #999)}.ic-form-field .error-message{color:var(--ic-form-field-error-color, red);font-size:12px;margin:0 16px;display:flex;align-items:center;gap:5px;z-index:4}.ic-form-field .error-counter{background-color:var(--ic-form-field-error-counter-bg, rgba(255, 0, 0, .1));color:var(--ic-form-field-error-counter-color, red);font-size:10px;padding:2px 5px;border-radius:10px;cursor:pointer;position:relative}.ic-form-field .popover{position:absolute;bottom:100%;left:0;background:var(--ic-form-field-popover-bg, #fff);border-radius:5px;padding:5px;box-shadow:var(--ic-form-field-popover-shadow, 0px 0px 10px rgba(255, 0, 0, .3));min-width:200px;z-index:10}.ic-form-field .popover div{padding:3px 5px;font-size:12px;color:var(--ic-form-field-popover-color, red)}.ic-form-field input[type=date]{appearance:none;-webkit-appearance:none;-moz-appearance:none;position:relative;padding-right:10px}.ic-form-field input[type=date]::-webkit-calendar-picker-indicator{background:var(--ic-icon-calendar) no-repeat center;background-size:contain;cursor:pointer;opacity:1}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { label: [{
                type: Input
            }], type: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], id: [{
                type: Input
            }], control: [{
                type: Input
            }], disabled: [{
                type: Input
            }], customClass: [{
                type: Input
            }], prefixIcon: [{
                type: Input
            }], minLength: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], numLength: [{
                type: Input
            }], decimalPlaces: [{
                type: Input
            }], suffixIcon: [{
                type: Input
            }], suffixButton: [{
                type: Input
            }], readonly: [{
                type: Input
            }], skipLabel: [{
                type: Input
            }], maskedInput: [{
                type: Input
            }], customError: [{
                type: Input
            }], addDiv: [{
                type: Input
            }], icNumbersOnly: [{
                type: Input,
                args: ['icNumbersOnly']
            }], icAlphaNumericWithSpace: [{
                type: Input,
                args: ['icAlphaNumericWithSpace']
            }], icSpecialAlphaNumeric: [{
                type: Input,
                args: ['icSpecialAlphaNumeric']
            }], icSpecialAlphaNumericExtended: [{
                type: Input,
                args: ['icSpecialAlphaNumericExtended']
            }], icAlphanumeric: [{
                type: Input,
                args: ['icAlphanumeric']
            }], icNoSpace: [{
                type: Input,
                args: ['icNoSpace']
            }], icSpecialText: [{
                type: Input,
                args: ['icSpecialText']
            }], icIsUpperCase: [{
                type: Input,
                args: ['icIsUpperCase']
            }], icNoSpecialCharFirst: [{
                type: Input,
                args: ['icNoSpecialCharFirst']
            }], icAlphabetOnly: [{
                type: Input,
                args: ['icAlphabetOnly']
            }], icRestrictPercentage: [{
                type: Input,
                args: ['icRestrictPercentage']
            }], icRestrictDecimal: [{
                type: Input,
                args: ['icRestrictDecimal']
            }], icTwoDigitDecimalNumber: [{
                type: Input,
                args: ['icTwoDigitDecimalNumber']
            }], alphabetspace: [{
                type: Input,
                args: ['alphabetspace']
            }], appNoInitialDot: [{
                type: Input,
                args: ['appNoInitialDot']
            }], specialIsAlphaNumeric: [{
                type: Input,
                args: ['specialIsAlphaNumeric']
            }], someSpecialIsAlphaNumeric: [{
                type: Input,
                args: ['someSpecialIsAlphaNumeric']
            }], icPreventInitialZero: [{
                type: Input,
                args: ['icPreventInitialZero']
            }], icCurrencyFormatter: [{
                type: Input,
                args: ['icCurrencyFormatter']
            }], icCleaveCurrency: [{
                type: Input,
                args: ['icCleaveCurrency']
            }], onSuffixClick: [{
                type: Output
            }], onInputChange: [{
                type: Output
            }], onKeyUp: [{
                type: Output
            }], onKeyDown: [{
                type: Output
            }] } });

class SelectComponent {
    static { this.lastInstance = null; }
    closeDropdownOnClickOutside(event) {
        const target = event.target;
        const clickedInside = target.closest('.ic-select-field');
        const clickedInsideDropdown = target.closest('.dropdown-menu-overlay');
        const clickedInsideDropdownSearch = target.closest('.search-input');
        if (!clickedInside &&
            !clickedInsideDropdownSearch &&
            !clickedInsideDropdown) {
            this.dropdownOpen = false;
            this.detachOverlay();
            this.openedChange.emit(false);
        }
    }
    constructor(overlay, viewContainerRef, scrollStrategyOptions) {
        this.overlay = overlay;
        this.viewContainerRef = viewContainerRef;
        this.scrollStrategyOptions = scrollStrategyOptions;
        this.label = '';
        this.control = new FormControl();
        this.options = []; // Can be key-value pairs or single values
        this.bindLabelKey = 'key';
        this.bindValueKey = 'value';
        this.specificDisplayAttribute = null;
        this.specificBracketAttribute = null;
        this.selectionType = 'single';
        this.customError = '';
        this.displayLabel = false;
        this.showProfile = false;
        this.skipLabel = false;
        this.showFlag = false;
        this.readonly = false;
        this.disabled = false;
        this.customClass = '';
        this.hideSearch = false;
        this.searchInField = false;
        this.selectionChange = new EventEmitter();
        this.openedChange = new EventEmitter();
        this.isRequired = false;
        this.filterFormControl = new FormControl('');
        this.filteredOptions = [];
        this.selectedValues = [];
        this.dropdownOpen = false;
        this.selectedLabel = null;
        this.multiSelectedLabel = [];
        this.overlayRef = null;
    }
    ngOnChanges(changes) {
        if (changes['options'] && this.options) {
            this.filteredOptions = [...this.options];
            this.syncSelectedValues();
        }
        if (changes['control'] && changes['control'].currentValue) {
            this.syncSelectedValues();
        }
    }
    ngOnInit() {
        this.isRequired = this.control?.validator
            ? this.control.validator({})?.['required']
            : false;
        this.filteredOptions = [...this.options];
        this.syncSelectedValues();
        this.control.valueChanges.subscribe(() => this.syncSelectedValues());
        this.filterFormControl.valueChanges
            .pipe(debounceTime(300))
            .subscribe((search) => {
            this.filterOptions(search);
        });
    }
    toggleDropdown() {
        if (!this.readonly) {
            if (SelectComponent.lastInstance &&
                SelectComponent.lastInstance !== this) {
                SelectComponent.lastInstance.dropdownOpen = false;
                SelectComponent.lastInstance.detachOverlay();
                SelectComponent.lastInstance.openedChange.emit(false);
            }
            SelectComponent.lastInstance = this;
            if (this.selectionType === 'multi') {
                this.dropdownOpen = true;
            }
            else {
                this.dropdownOpen = !this.dropdownOpen;
            }
            if (this.dropdownOpen) {
                this.control.markAsTouched();
                this.filterFormControl.setValue('');
                setTimeout(() => {
                    this.filteredOptions = [...this.options];
                });
                this.attachOverlay();
            }
            else {
                this.detachOverlay();
            }
            this.openedChange.emit(this.dropdownOpen);
        }
    }
    attachOverlay() {
        if (!this.overlayRef) {
            const fieldRect = this.dropdownHeader.nativeElement.getBoundingClientRect();
            const positionStrategy = this.overlay
                .position()
                .flexibleConnectedTo(this.dropdownHeader.nativeElement)
                .withPositions([
                {
                    originX: 'start',
                    originY: 'bottom',
                    overlayX: 'start',
                    overlayY: 'top',
                },
                {
                    originX: 'start',
                    originY: 'top',
                    overlayX: 'start',
                    overlayY: 'bottom',
                },
            ]);
            this.overlayRef = this.overlay.create({
                positionStrategy,
                hasBackdrop: true,
                backdropClass: 'cdk-overlay-transparent-backdrop',
                scrollStrategy: this.scrollStrategyOptions.block(),
                width: `${fieldRect.width}px`,
            });
            const portal = new TemplatePortal(this.dropdownMenuTemplate, this.viewContainerRef);
            this.overlayRef.attach(portal);
        }
    }
    detachOverlay() {
        if (this.overlayRef) {
            this.overlayRef.detach();
            this.overlayRef = null;
        }
    }
    syncSelectedValues() {
        if (this.selectionType === 'multi') {
            const currentValues = Array.isArray(this.control.value)
                ? [...this.control.value]
                : [];
            this.selectedValues = currentValues.filter(value => this.options.some(option => this.getOptionValue(option) === value));
            this.multiSelectedLabel = this.selectedValues.map(value => this.getOptionLabel(this.getOptionByValue(value)));
            if (this.selectedValues.length === 0) {
                this.selectedLabel = null;
            }
        }
        else {
            const value = this.control.value;
            const selectedOption = this.getOptionByValue(value);
            if (selectedOption) {
                this.selectedLabel = this.specificDisplayAttribute
                    ? selectedOption?.[this.specificDisplayAttribute] || ''
                    : this.getOptionLabel(selectedOption);
            }
            else
                this.selectedLabel = '';
        }
    }
    filterOptions(search) {
        const searchLower = search.trim().toLowerCase();
        this.filteredOptions = this.options.filter(option => {
            if (!option)
                return false;
            const label = this.getOptionLabel(option)?.toString().toLowerCase() || '';
            const value = option[this.bindValueKey]?.toString().toLowerCase() || '';
            const specific = this.specificBracketAttribute && option[this.specificBracketAttribute]
                ? option[this.specificBracketAttribute].toString().toLowerCase()
                : '';
            let searchText = label;
            if (this.displayLabel) {
                if (this.specificBracketAttribute) {
                    searchText = `${label} (${specific})`;
                }
                else {
                    searchText = `${label} (${value})`;
                }
            }
            return (searchText.includes(searchLower) ||
                label.includes(searchLower) ||
                value.includes(searchLower) ||
                specific.includes(searchLower));
        });
    }
    selectOption(option) {
        const value = this.getOptionValue(option);
        if (this.selectionType === 'single') {
            this.control.setValue(value);
            this.selectedLabel = this.specificDisplayAttribute
                ? option?.[this.specificDisplayAttribute] || ''
                : this.getOptionLabel(option);
            this.selectionChange.emit(value);
            this.dropdownOpen = false;
            this.detachOverlay();
            this.openedChange.emit(false);
        }
        else {
            const index = this.selectedValues.indexOf(value);
            if (index > -1) {
                this.selectedValues.splice(index, 1);
                this.multiSelectedLabel.splice(index, 1);
            }
            else {
                this.selectedValues.push(value);
                this.multiSelectedLabel.push(this.getOptionLabel(option));
            }
            this.control.setValue(this.selectedValues);
            this.selectionChange.emit(this.selectedValues);
        }
    }
    toggleAllSelections() {
        if (this.selectedValues.length === this.options.length) {
            this.selectedValues = [];
            this.multiSelectedLabel = [];
        }
        else {
            this.selectedValues = this.options.map(option => this.getOptionValue(option));
            this.multiSelectedLabel = this.options.map(option => this.getOptionLabel(option));
        }
        this.control.setValue(this.selectedValues.length > 0 ? this.selectedValues : null);
        this.selectionChange.emit(this.selectedValues);
        this.syncSelectedValues();
    }
    isSelected(value) {
        return this.selectionType === 'multi'
            ? this.selectedValues.includes(value)
            : this.control.value === value;
    }
    deselectOption(value) {
        const deselectedValue = this.getOptionValue(value);
        this.selectedValues = this.selectedValues.filter(selected => selected !== deselectedValue);
        this.multiSelectedLabel = this.multiSelectedLabel.filter(label => label !== this.getOptionLabel(value));
        this.control.setValue(this.selectedValues.length > 0 ? this.selectedValues : null);
        this.selectionChange.emit(this.selectedValues);
        this.syncSelectedValues();
    }
    shouldFloatLabel() {
        if (this.selectionType === 'multi') {
            return this.selectedValues.length > 0;
        }
        else {
            return !!this.control.value || this.selectedLabel === 'Both';
        }
    }
    getOptionLabel(option) {
        if (typeof option === 'object') {
            return option?.[this.bindLabelKey] || '';
        }
        return option ? String(option) : ''; // For single values
    }
    getOptionValue(option) {
        if (typeof option === 'object') {
            return option?.[this.bindValueKey] ?? '';
        }
        return option; // For single values
    }
    getOptionByLabel(label) {
        return this.options?.find(option => this.getOptionLabel(option) === label);
    }
    getOptionByValue(value) {
        return this.options?.find(option => this.getOptionValue(option) === value);
    }
    clearSelection() {
        this.control.setValue(null);
        this.selectedLabel = null;
        this.selectionChange.emit(null);
    }
    ngOnDestroy() {
        if (SelectComponent.lastInstance === this) {
            SelectComponent.lastInstance = null;
        }
        this.detachOverlay();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SelectComponent, deps: [{ token: i1$2.Overlay }, { token: i0.ViewContainerRef }, { token: i1$2.ScrollStrategyOptions }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SelectComponent, selector: "ic-select", inputs: { label: "label", control: "control", options: "options", bindLabelKey: "bindLabelKey", bindValueKey: "bindValueKey", specificDisplayAttribute: "specificDisplayAttribute", specificBracketAttribute: "specificBracketAttribute", selectionType: "selectionType", customError: "customError", displayLabel: "displayLabel", showProfile: "showProfile", skipLabel: "skipLabel", showFlag: "showFlag", readonly: "readonly", disabled: "disabled", customClass: "customClass", hideSearch: "hideSearch", searchInField: "searchInField" }, outputs: { selectionChange: "selectionChange", openedChange: "openedChange" }, host: { listeners: { "document:click": "closeDropdownOnClickOutside($event)" } }, viewQueries: [{ propertyName: "dropdownMenu", first: true, predicate: ["dropdownMenu"], descendants: true }, { propertyName: "dropdownHeader", first: true, predicate: ["dropdownHeader"], descendants: true }, { propertyName: "dropdownMenuTemplate", first: true, predicate: ["dropdownMenuTemplate"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div\r\n  class=\"ic-select-field {{ customClass }}\"\r\n  (click)=\"toggleDropdown()\"\r\n  [class.disabled]=\"disabled\">\r\n  <label *ngIf=\"!skipLabel\" [class.floated]=\"shouldFloatLabel()\">\r\n    {{ label }}\r\n    <span *ngIf=\"isRequired\" class=\"required_star\" style=\"color: red\">*</span>\r\n  </label>\r\n  <div class=\"dropdown\">\r\n    <div\r\n      #dropdownHeader\r\n      class=\"dropdown-header-div\"\r\n      [class.dropdown-open]=\"dropdownOpen\"\r\n      [class.dropdown-disabled]=\"disabled\"\r\n      [class.dropdown-error]=\"\r\n        control.invalid && (control.dirty || control.touched)\r\n      \">\r\n      <div\r\n        *ngIf=\"selectionType === 'multi' && selectedValues.length > 0\"\r\n        class=\"chip-container\">\r\n        <div *ngFor=\"let value of multiSelectedLabel.slice(0, 2)\" class=\"chip\">\r\n          {{ value }}\r\n          <span\r\n            class=\"remove-chip\"\r\n            (click)=\"deselectOption(getOptionByLabel(value))\">\r\n            \u00D7\r\n          </span>\r\n        </div>\r\n        <div *ngIf=\"selectedValues.length > 2\" class=\"chip\">\r\n          +{{ selectedValues.length - 2 }}\r\n        </div>\r\n      </div>\r\n      <span\r\n        *ngIf=\"selectionType === 'single' || !selectedValues.length\"\r\n        class=\"label-display-container\">\r\n        <ng-container *ngIf=\"selectedLabel\">\r\n          <ng-container *ngIf=\"!displayLabel\">\r\n            {{ selectedLabel }}\r\n          </ng-container>\r\n          <ng-container *ngIf=\"displayLabel && !specificBracketAttribute\">\r\n            {{\r\n              selectedLabel\r\n                ? selectedLabel +\r\n                  ' (' +\r\n                  getOptionByLabel(selectedLabel)[bindValueKey] +\r\n                  ')'\r\n                : ''\r\n            }}\r\n          </ng-container>\r\n          <ng-container *ngIf=\"displayLabel && specificBracketAttribute\">\r\n            {{\r\n              selectedLabel\r\n                ? selectedLabel +\r\n                  ' (' +\r\n                  getOptionByLabel(selectedLabel)[specificBracketAttribute] +\r\n                  ')'\r\n                : ''\r\n            }}\r\n          </ng-container>\r\n        </ng-container>\r\n      </span>\r\n      <ic-icon\r\n        name=\"sort-down\"\r\n        style=\"--ic-icon-color: #b3bac8; height: 12px; width: 12px\">\r\n      </ic-icon>\r\n      <ng-container *ngIf=\"searchInField == true\">\r\n        <div class=\"vl\"></div>\r\n        <ic-icon\r\n          name=\"search\"\r\n          style=\"--ic-icon-color: #b3bac8; height: 12px; width: 12px\"></ic-icon>\r\n      </ng-container>\r\n    </div>\r\n    <ng-template #dropdownMenuTemplate>\r\n      <div class=\"dropdown-menu-overlay\">\r\n        <ng-container *ngIf=\"!hideSearch\">\r\n          <input\r\n            [formControl]=\"filterFormControl\"\r\n            class=\"search-input\"\r\n            type=\"search\"\r\n            placeholder=\"Search...\"\r\n            autofocus />\r\n        </ng-container>\r\n        <ul class=\"dropdown-list\">\r\n          <ng-container *ngIf=\"filteredOptions.length > 0; else noContent\">\r\n            <li\r\n              *ngIf=\"selectionType === 'multi'\"\r\n              class=\"dropdown-item\"\r\n              (click)=\"toggleAllSelections()\">\r\n              <input\r\n                type=\"checkbox\"\r\n                [checked]=\"selectedValues.length === options.length\" />\r\n              Select All\r\n            </li>\r\n            <li\r\n              *ngIf=\"selectionType === 'single' && !hideSearch\"\r\n              class=\"dropdown-item\"\r\n              (click)=\"clearSelection()\">\r\n              Select\r\n            </li>\r\n            <li\r\n              *ngFor=\"let option of filteredOptions; let i = index\"\r\n              class=\"dropdown-item\"\r\n              [class.selected]=\"\r\n                isSelected(option[bindValueKey] ?? option) ||\r\n                (option[bindValueKey] === '' && isSelected(''))\r\n              \"\r\n              (click)=\"selectOption(option)\">\r\n              <ng-container *ngIf=\"selectionType === 'multi'\">\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [checked]=\"isSelected(option[bindValueKey] || option)\" />\r\n              </ng-container>\r\n              <ng-container *ngIf=\"showProfile\">\r\n                <ng-container\r\n                  *ngIf=\"\r\n                    option?.profileUrl && option?.profileUrl !== 'NOT_EXIST';\r\n                    else showInitialAvatar\r\n                  \">\r\n                  <img\r\n                    [src]=\"option.profileUrl\"\r\n                    alt=\"image\"\r\n                    class=\"avatar-2x\" />\r\n                </ng-container>\r\n                <ng-template #showInitialAvatar>\r\n                  <div class=\"circle\">\r\n                    {{ option.username?.[0][0]?.toUpperCase()\r\n                    }}{{ option.username?.[1][0]?.toUpperCase() }}\r\n                  </div>\r\n                </ng-template>\r\n              </ng-container>\r\n              <div>\r\n                <div>\r\n                  {{ getOptionLabel(option) }}\r\n                  <span *ngIf=\"displayLabel && !specificBracketAttribute\">\r\n                    ({{ option[bindValueKey] }})\r\n                  </span>\r\n                  <span *ngIf=\"displayLabel && specificBracketAttribute\">\r\n                    ({{ option[specificBracketAttribute] }})\r\n                  </span>\r\n                </div>\r\n                <div>\r\n                  <h6\r\n                    *ngIf=\"showProfile && option.empId !== null\"\r\n                    class=\"text-gray\">\r\n                    EMP #{{ option.empId }}\r\n                  </h6>\r\n                </div>\r\n              </div>\r\n            </li>\r\n          </ng-container>\r\n          <ng-template #noContent>\r\n            <li class=\"dropdown-item\">No Data Present</li>\r\n          </ng-template>\r\n        </ul>\r\n      </div>\r\n    </ng-template>\r\n  </div>\r\n  <div\r\n    *ngIf=\"control?.invalid && (control?.dirty || control?.touched)\"\r\n    class=\"error-message\">\r\n    <div *ngIf=\"control?.errors?.['required']\">{{ label }} is Required!</div>\r\n    <div *ngIf=\"customError\">{{ customError }}</div>\r\n  </div>\r\n</div>\r\n", styles: [":root{--ic-clr-default: #ffffff;--ic-clr-inverted: #000000;--ic-clr-primary-a0: #0051ff;--ic-clr-primary-a10: #0033a1;--ic-clr-primary-a20: #00008c;--ic-clr-primary-a30: #00164e;--ic-clr-tonal-a0: #0062e1;--ic-clr-tonal-a10: #004aa0;--ic-clr-tonal-a20: #004991;--ic-clr-tonal-a30: #0033aa;--ic-clr-tonal-a40: #06113c;--ic-clr-green-a0: #008461;--ic-clr-red-a0: #ff3d3d;--ic-clr-red-a10: #ff0000;--ic-clr-red-a20: #b20000;--ic-clr-gray-a0: #8e8e8e;--ic-clr-gray-a10: #9c9c9c;--ic-clr-gray-a20: #858585;--ic-clr-gray-a30: #707070;--ic-clr-yellow-a0: #d68c00;--ic-surface-primary-a0: #ffffff;--ic-surface-primary-a10: #f0f4ff;--ic-surface-primary-a20: #f3f3f3;--ic-surface-primary-a30: #e8e8e8;--ic-surface-primary-a40: #dcdcdc;--ic-surface-tonal-a0: #eff7ff;--ic-surface-tonal-a10: #e1f1ff;--ic-surface-tonal-a20: #d8e3f0;--ic-surface-tonal-a30: #c4d0e0;--ic-surface-tonal-a40: #b0bec5;--ic-surface-tonal-a50: #9ea7b6;background:var(--ic-app-bg);--ic-app-bg: var(--ic-surface-primary-a0);--ic-card-bg: var(--ic-surface-primary-a0);--ic-card-bg-accent: var(--ic-surface-tonal-a0);--ic-text-white: var(--ic-clr-default);--ic-text-black: var(--ic-clr-inverted);--ic-text-theme: var(--ic-clr-primary-a10);--ic-gray-accent: var(--ic-surface-primary-a20);--ic-text-gray: var(--ic-clr-gray-a0);--ic-text-gray-dark: var(--ic-clr-gray-a20);--ic-text-gray-light: var(--ic-clr-gray-a10);--ic-text-red: var(--ic-clr-red-a0);--ic-text-green: var(--ic-clr-green-a0);--ic-primary-font-family: \"Benton Sans\", sans-serif;--ic-secondary-font-family: \"Inter\", sans-serif;--ic-btn-filled-bg: linear-gradient(90deg, var(--ic-clr-tonal-a0) 0%, var(--ic-clr-tonal-a30) 100%);--ic-btn-filled-color: var(--ic-clr-default);--ic-btn-filled-warning-bg: var(--ic-clr-yellow-a0);--ic-btn-filled-danger-bg: var(--ic-clr-red-a20);--ic-btn-filled-neutral-bg: var(--ic-clr-primary-a10);--ic-btn-filled-blue-bg: var(--ic-clr-tonal-a0);--ic-btn-filled-basic-bg: var(--ic-clr-inverted);--ic-btn-filled-success-bg: var(--ic-clr-green-a0);--ic-btn-outlined-bg: var(--ic-surface-primary-a0);--ic-btn-outlined-color: var(--ic-clr-primary-a10);--ic-btn-outlined-border: var(--ic-clr-primary-a10);--ic-btn-outlined-hover-bg: #007fff14;--ic-btn-outlined-warning: var(--ic-clr-yellow-a0);--ic-btn-outlined-danger: var(--ic-clr-red-a20);--ic-btn-outlined-neutral: var(--ic-clr-primary-a10);--ic-btn-outlined-basic: var(--ic-clr-inverted);--ic-btn-outlined-success: var(--ic-clr-green-a0);--ic-btn-outlined-transparent-bg: transparent;--ic-btn-outlined-transparent-color: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-border: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-hover-bg: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-hover-color: #212353;--ic-btn-status-border: var(--ic-clr-primary-a10);--ic-btn-status-color: var(--ic-clr-primary-a10);--ic-btn-status-warning: var(--ic-clr-yellow-a0);--ic-btn-status-warning-bg: #fff7e6;--ic-btn-status-danger: var(--ic-clr-red-a20);--ic-btn-status-danger-bg: #ffe7e8;--ic-btn-status-neutral: var(--ic-clr-primary-a10);--ic-btn-status-neutral-bg: #e3e9fe;--ic-btn-status-basic: var(--ic-clr-inverted);--ic-btn-status-basic-bg: var(--ic-surface-primary-a0);--ic-btn-status-success: var(--ic-clr-green-a0);--ic-btn-status-success-bg: #ddf8f1;--ic-btn-status-hover-bg: #007fff14;--ic-btn-ghost-bg: var(--ic-surface-primary-a0);--ic-btn-ghost-color: var(--ic-clr-primary-a10);--ic-btn-ghost-shadow: 0px 3px 10px 0px #00000017;--ic-btn-ghost-warning: var(--ic-clr-yellow-a0);--ic-btn-ghost-danger: var(--ic-clr-red-a20);--ic-btn-ghost-neutral: var(--ic-clr-primary-a10);--ic-btn-ghost-basic: var(--ic-clr-inverted);--ic-btn-ghost-success: var(--ic-clr-green-a0);--ic-btn-ghost-disabled-color: var(--ic-clr-default);--ic-btn-disabled-bg: #cecece;--ic-btn-spinner-color: var(--ic-surface-primary-a0);--ic-btn-toggle-group-bg: var(--ic-surface-primary-a0);--ic-btn-toggle-group-border: #e0e0e0;--ic-btn-toggle-group-shadow: 0 3px 10px #00000017;--ic-card-shadow: 0px 3px 9px 0px rgba(0, 0, 0, .11);--ic-checkbox-filled-bg: var(--ic-clr-tonal-a20);--ic-checkbox-filled-border: var(--ic-clr-tonal-a20);--ic-checkbox-checkmark-color: var(--ic-clr-default);--ic-checkbox-outlined-bg: var(--ic-surface-primary-a0);--ic-checkbox-outlined-border: var(--ic-clr-tonal-a20);--ic-checkbox-checkmark-outlined-color: var(--ic-clr-tonal-a20);--ic-checkbox-border: #70707057;--ic-checkbox-bg: var(--ic-surface-primary-a0);--ic-checkbox-primary-bg: var(--ic-clr-tonal-a20);--ic-checkbox-primary-border: var(--ic-clr-tonal-a20);--ic-checkbox-accent-bg: #ff4081;--ic-checkbox-accent-border: #ff4081;--ic-checkbox-warn-bg: #f44336;--ic-checkbox-warn-border: #f44336;--ic-checkbox-label-color: #212353;--ic-date-picker-bg: var(--ic-surface-primary-a0);--ic-date-picker-border: #dcdcdc;--ic-date-picker-border-focus: var(--ic-clr-primary-a10);--ic-date-picker-border-error: var(--ic-clr-red-a10);--ic-date-picker-label-color: #666;--ic-date-picker-label-active-color: var(--ic-clr-primary-a10);--ic-date-picker-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-date-picker-required-star: var(--ic-clr-red-a10);--ic-date-picker-disabled-bg: var(--ic-surface-primary-a20);--ic-date-picker-disabled-border: #dcdcdc;--ic-date-picker-disabled-color: gray;--ic-date-picker-input-color: inherit;--ic-date-picker-calendar-toggle-color: inherit;--ic-date-picker-calendar-bg: var(--ic-surface-primary-a0);--ic-date-picker-calendar-shadow: 0 3px 15px rgba(0, 0, 0, .15);--ic-date-picker-calendar-header-bg: #e6efff;--ic-date-picker-calendar-header-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-header-hover-bg: #ededed;--ic-date-picker-calendar-nav-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-nav-hover-bg: #f0f0f0;--ic-date-picker-calendar-date-color: inherit;--ic-date-picker-calendar-date-disabled-color: #aaa;--ic-date-picker-calendar-date-selected-bg: #007bff;--ic-date-picker-calendar-date-selected-color: var(--ic-clr-default);--ic-date-picker-calendar-date-hover-bg: #f0f0f0;--ic-date-picker-calendar-selector-border: #ccc;--ic-date-picker-calendar-selector-hover-bg: #f0f0f0;--ic-date-picker-error-color: var(--ic-clr-red-a10);--ic-form-field-bg: var(--ic-surface-primary-a0);--ic-form-field-border: #dcdcdc;--ic-form-field-border-focus: var(--ic-clr-primary-a10);--ic-form-field-border-error: var(--ic-clr-red-a10);--ic-form-field-disabled-bg: var(--ic-surface-primary-a20);--ic-form-field-disabled-border: #dcdcdc;--ic-form-field-disabled-color: gray;--ic-form-field-label-color: #666;--ic-form-field-label-active-color: var(--ic-clr-primary-a10);--ic-form-field-label-disabled-color: #999;--ic-form-field-label-bg: linear-gradient(180deg, #0000ff00 30%, var(--ic-surface-primary-a0) 53%, #00800000 80%);--ic-form-field-input-color: inherit;--ic-form-field-input-disabled-color: #999;--ic-form-field-prefix-color: var(--ic-clr-primary-a10);--ic-form-field-add-bg: #e9ecf5;--ic-form-field-add-color: var(--ic-clr-primary-a10);--ic-form-field-add-hover-bg: #d7e3fb;--ic-form-field-add-disabled-bg: #dcdcdc;--ic-form-field-add-disabled-color: #b1b1b1;--ic-form-field-error-color: var(--ic-clr-red-a10);--ic-form-field-error-counter-bg: rgba(255, 0, 0, .1);--ic-form-field-error-counter-color: var(--ic-clr-red-a10);--ic-form-field-popover-bg: var(--ic-surface-primary-a0);--ic-form-field-popover-shadow: 0px 0px 10px rgba(255, 0, 0, .3);--ic-form-field-popover-color: var(--ic-clr-red-a10);--ic-mobile-field-bg: var(--ic-surface-primary-a0);--ic-mobile-field-border: #dcdcdc;--ic-mobile-field-border-focus: var(--ic-clr-primary-a10);--ic-mobile-field-border-error: var(--ic-clr-red-a10);--ic-mobile-field-disabled-bg: var(--ic-surface-primary-a20);--ic-mobile-field-disabled-border: #dcdcdc;--ic-mobile-field-label-color: #666;--ic-mobile-field-label-active-color: var(--ic-clr-primary-a10);--ic-mobile-field-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-mobile-field-required-star: var(--ic-clr-red-a10);--ic-mobile-field-input-disabled-color: #999;--ic-mobile-field-prefix-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-arrow-color: #b3bac8;--ic-mobile-field-dropdown-bg: var(--ic-surface-primary-a0);--ic-mobile-field-dropdown-option-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-option-hover-bg: #f5f5f5;--ic-mobile-field-dropdown-no-results-color: #999;--ic-mobile-field-separator: var(--ic-surface-primary-a30);--ic-mobile-field-error-color: var(--ic-clr-red-a10);--ic-radio-label-color: var(--ic-clr-gray-a30);--ic-radio-label-checked-color: var(--ic-clr-primary-a10);--ic-radio-label-disabled-color: #b1b1b1;--ic-radio-border: var(--ic-clr-default);--ic-radio-bg: var(--ic-surface-primary-a0);--ic-radio-border-checked: var(--ic-clr-default);--ic-radio-bg-checked: var(--ic-clr-primary-a10);--ic-radio-outline-checked: var(--ic-clr-primary-a10);--ic-radio-border-hover: var(--ic-clr-primary-a10);--ic-radio-bg-disabled: var(--ic-surface-primary-a20);--ic-radio-border-disabled: #dcdcdc;--ic-select-label-color: #666;--ic-select-label-active-color: var(--ic-clr-primary-a10);--ic-select-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-select-bg: var(--ic-surface-primary-a0);--ic-select-border: #dcdcdc;--ic-select-border-focus: var(--ic-clr-primary-a10);--ic-select-border-error: var(--ic-clr-red-a10);--ic-select-disabled-bg: var(--ic-surface-primary-a20);--ic-select-disabled-border: #dcdcdc;--ic-select-disabled-color: gray;--ic-select-input-color: inherit;--ic-select-chip-bg: #e1f1ff;--ic-select-chip-color: cornflowerblue;--ic-select-error-color: var(--ic-clr-red-a10);--ic-select-dropdown-bg: var(--ic-surface-primary-a0);--ic-select-dropdown-shadow: 0px 3px 10px 0px rgba(0, 0, 0, .09);--ic-select-search-border: #ccc;--ic-select-item-color: var(--ic-clr-primary-a10);--ic-select-item-hover-bg: linear-gradient(90deg, #06113c 0%, #004aa0 100%);--ic-select-item-hover-color: var(--ic-clr-default);--ic-select-item-hover-text-gray: #95ceff;--ic-select-item-selected-color: var(--ic-clr-primary-a10);--ic-select-item-selected-bg: #d8e3f0;--ic-select-item-circle-color: #059eab;--ic-select-item-circle-bg: var(--ic-surface-primary-a20);--ic-slide-toggle-bg: #ccc;--ic-slide-toggle-active-bg: var(--ic-clr-tonal-a20);--ic-slide-toggle-knob-bg: var(--ic-surface-primary-a0);--ic-tenure-field-label-color: var(--ic-clr-primary-a10);--ic-tenure-field-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-tenure-field-required-star: var(--ic-clr-red-a10);--ic-tenure-field-border: #dcdcdc;--ic-tenure-field-border-focus: #2196f3;--ic-tenure-field-border-error: var(--ic-clr-red-a10);--ic-tenure-field-bg: var(--ic-surface-primary-a0);--ic-tenure-field-disabled-bg: var(--ic-surface-primary-a20);--ic-tenure-field-disabled-border: #dcdcdc;--ic-tenure-field-input-color: inherit;--ic-tenure-field-unit-label-color: #010101;--ic-tenure-field-separator-color: var(--ic-clr-gray-a30);--ic-tenure-field-error-color: var(--ic-clr-red-a10);--ic-textarea-label-color: #666;--ic-textarea-label-active-color: var(--ic-clr-primary-a10);--ic-textarea-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-textarea-required-star: var(--ic-clr-red-a10);--ic-textarea-border: #dcdcdc;--ic-textarea-border-focus: var(--ic-clr-primary-a10);--ic-textarea-border-error: var(--ic-clr-red-a10);--ic-textarea-bg: var(--ic-surface-primary-a0);--ic-textarea-disabled-bg: var(--ic-surface-primary-a20);--ic-textarea-disabled-border: #dcdcdc;--ic-textarea-disabled-color: gray;--ic-textarea-input-color: inherit;--ic-textarea-error-color: var(--ic-clr-red-a10);--ic-footer-bg: var(--ic-surface-primary-a0);--ic-footer-logo-color: var(--ic-clr-primary-a10);--ic-footer-desc-color: var(--ic-clr-primary-a10);--ic-footer-heading-color: #212353;--ic-footer-link-color: var(--ic-clr-primary-a10);--ic-footer-link-hover-color: var(--ic-clr-tonal-a0);--ic-footer-divider-color: #52515187;--ic-accordion-panel-bg: var(--ic-surface-primary-a0);--ic-accordion-panel-shadow: 0px 6.12px 30.62px 0px rgba(0, 0, 0, .11);--ic-accordion-header-color: var(--ic-clr-primary-a10);--ic-accordion-header-accent: var(--ic-clr-tonal-a0);--ic-accordion-list-color: #909090;--ic-accordion-list-hover: var(--ic-clr-inverted)}.theme-dark{--ic-clr-default: #000000;--ic-clr-inverted: #ffffff;--ic-clr-primary-a0: #91baff;--ic-clr-primary-a10: #5d9bff;--ic-clr-primary-a20: #367ee6;--ic-clr-primary-a30: #204f9c;--ic-clr-tonal-a0: #3a7dff;--ic-clr-tonal-a10: #2a5fd6;--ic-clr-tonal-a20: #183a6a;--ic-clr-tonal-a30: #121a2a;--ic-clr-tonal-a40: #0d1320;--ic-clr-green-a0: #3ad29f;--ic-clr-red-a0: #ff6b7d;--ic-clr-red-a10: #ff3d3d;--ic-clr-red-a20: #b20000;--ic-clr-gray-a0: #c7d1dd;--ic-clr-gray-a10: #8a95a5;--ic-clr-gray-a20: #67758a;--ic-clr-gray-a30: #525151;--ic-clr-yellow-a0: #ffb83a;--ic-surface-primary-a0: #121a2a;--ic-surface-primary-a10: #1d2433;--ic-surface-primary-a20: #2a3446;--ic-surface-primary-a30: #232b3a;--ic-surface-primary-a40: #1a202c;--ic-surface-tonal-a0: #1a2333;--ic-surface-tonal-a10: #232b3a;--ic-surface-tonal-a20: #2a3446;--ic-surface-tonal-a30: #183a6a;--ic-surface-tonal-a40: #0d1320;--ic-surface-tonal-a50: #06080e;background:var(--ic-app-bg);--ic-app-bg: var(--ic-surface-primary-a0);--ic-card-bg: var(--ic-surface-primary-a10);--ic-card-bg-accent: #252d40;--ic-text-white: var(--ic-clr-default);--ic-text-black: var(--ic-clr-inverted);--ic-text-theme: var(--ic-clr-primary-a10);--ic-gray-accent: var(--ic-surface-primary-a20);--ic-text-gray: var(--ic-clr-gray-a0);--ic-text-gray-dark: var(--ic-clr-gray-a10);--ic-text-gray-light: var(--ic-clr-gray-a20);--ic-text-red: var(--ic-clr-red-a0);--ic-text-green: var(--ic-clr-green-a0);--ic-primary-font-family: \"Benton Sans\", sans-serif;--ic-secondary-font-family: \"Poppins\", sans-serif;--ic-btn-filled-bg: linear-gradient(90deg, var(--ic-clr-tonal-a0) 0%, var(--ic-clr-tonal-a10) 100%);--ic-btn-filled-color: #ffffff;--ic-btn-filled-warning-bg: var(--ic-clr-yellow-a0);--ic-btn-filled-danger-bg: var(--ic-clr-red-a0);--ic-btn-filled-neutral-bg: var(--ic-surface-primary-a20);--ic-btn-filled-blue-bg: var(--ic-clr-tonal-a0);--ic-btn-filled-basic-bg: var(--ic-surface-primary-a10);--ic-btn-filled-success-bg: var(--ic-clr-green-a0);--ic-btn-outlined-bg: transparent;--ic-btn-outlined-color: var(--ic-clr-primary-a10);--ic-btn-outlined-border: var(--ic-clr-primary-a10);--ic-btn-outlined-hover-bg: rgba(93, 155, 255, .08);--ic-btn-outlined-warning: var(--ic-clr-yellow-a0);--ic-btn-outlined-danger: var(--ic-clr-red-a0);--ic-btn-outlined-neutral: var(--ic-clr-gray-a0);--ic-btn-outlined-basic: #f5f7fa;--ic-btn-outlined-success: var(--ic-clr-green-a0);--ic-btn-outlined-transparent-bg: transparent;--ic-btn-outlined-transparent-color: var(--ic-clr-primary-a10);--ic-btn-outlined-transparent-border: var(--ic-clr-primary-a10);--ic-btn-outlined-transparent-hover-bg: rgba(93, 155, 255, .1);--ic-btn-outlined-transparent-hover-color: var(--ic-clr-primary-a10);--ic-btn-status-border: var(--ic-surface-primary-a20);--ic-btn-status-color: var(--ic-clr-primary-a10);--ic-btn-status-warning: var(--ic-clr-yellow-a0);--ic-btn-status-warning-bg: rgba(255, 184, 58, .1);--ic-btn-status-danger: var(--ic-clr-red-a0);--ic-btn-status-danger-bg: rgba(255, 107, 125, .1);--ic-btn-status-neutral: var(--ic-clr-gray-a0);--ic-btn-status-neutral-bg: rgba(199, 209, 221, .1);--ic-btn-status-basic: #f5f7fa;--ic-btn-status-basic-bg: rgba(245, 247, 250, .1);--ic-btn-status-success: var(--ic-clr-green-a0);--ic-btn-status-success-bg: rgba(58, 210, 159, .1);--ic-btn-status-hover-bg: rgba(93, 155, 255, .1);--ic-btn-ghost-bg: var(--ic-surface-primary-a20);--ic-btn-ghost-color: var(--ic-clr-primary-a10);--ic-btn-ghost-shadow: 0px 3px 10px rgba(0, 0, 0, .15);--ic-btn-ghost-warning: var(--ic-clr-yellow-a0);--ic-btn-ghost-danger: var(--ic-clr-red-a0);--ic-btn-ghost-neutral: var(--ic-clr-gray-a0);--ic-btn-ghost-basic: #f5f7fa;--ic-btn-ghost-success: var(--ic-clr-green-a0);--ic-btn-ghost-disabled-color: var(--ic-clr-gray-a20);--ic-btn-disabled-bg: var(--ic-surface-primary-a20);--ic-btn-disabled-color: var(--ic-clr-gray-a20);--ic-btn-toggle-group-bg: var(--ic-surface-primary-a10);--ic-btn-toggle-group-border: var(--ic-surface-primary-a20);--ic-btn-toggle-group-shadow: 0 3px 10px rgba(0, 0, 0, .2);--ic-card-shadow: 0px 3px 9px rgba(0, 0, 0, .2);--ic-checkbox-filled-bg: var(--ic-clr-primary-a10);--ic-checkbox-filled-border: var(--ic-clr-primary-a10);--ic-checkbox-checkmark-color: #ffffff;--ic-checkbox-outlined-bg: transparent;--ic-checkbox-outlined-border: var(--ic-clr-primary-a10);--ic-checkbox-checkmark-outlined-color: var(--ic-clr-primary-a10);--ic-checkbox-border: var(--ic-surface-primary-a20);--ic-checkbox-bg: var(--ic-surface-primary-a10);--ic-checkbox-primary-bg: var(--ic-clr-primary-a10);--ic-checkbox-primary-border: var(--ic-clr-primary-a10);--ic-checkbox-accent-bg: var(--ic-clr-red-a0);--ic-checkbox-accent-border: var(--ic-clr-red-a0);--ic-checkbox-warn-bg: var(--ic-clr-red-a0);--ic-checkbox-warn-border: var(--ic-clr-red-a0);--ic-checkbox-label-color: #f5f7fa;--ic-date-picker-bg: var(--ic-surface-primary-a10);--ic-date-picker-border: var(--ic-surface-primary-a20);--ic-date-picker-border-focus: var(--ic-clr-primary-a10);--ic-date-picker-border-error: var(--ic-clr-red-a0);--ic-date-picker-label-color: var(--ic-clr-gray-a0);--ic-date-picker-label-active-color: var(--ic-clr-primary-a10);--ic-date-picker-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 53%, #000000 );--ic-date-picker-required-star: var(--ic-clr-red-a0);--ic-date-picker-disabled-bg: var(--ic-surface-primary-a20);--ic-date-picker-disabled-border: var(--ic-surface-primary-a20);--ic-date-picker-disabled-color: var(--ic-clr-gray-a20);--ic-date-picker-input-color: #f5f7fa;--ic-date-picker-calendar-toggle-color: #f5f7fa;--ic-date-picker-calendar-bg: var(--ic-surface-primary-a10);--ic-date-picker-calendar-shadow: 0 3px 15px rgba(0, 0, 0, .2);--ic-date-picker-calendar-header-bg: var(--ic-surface-primary-a0);--ic-date-picker-calendar-header-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-header-hover-bg: var(--ic-surface-primary-a10);--ic-date-picker-calendar-nav-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-nav-hover-bg: var(--ic-surface-primary-a10);--ic-date-picker-calendar-date-color: #f5f7fa;--ic-date-picker-calendar-date-disabled-color: var(--ic-clr-gray-a20);--ic-date-picker-calendar-date-selected-bg: var(--ic-clr-primary-a10);--ic-date-picker-calendar-date-selected-color: #ffffff;--ic-date-picker-calendar-date-hover-bg: var(--ic-surface-primary-a20);--ic-date-picker-calendar-selector-border: var(--ic-surface-primary-a20);--ic-date-picker-calendar-selector-hover-bg: var(--ic-surface-primary-a10);--ic-date-picker-error-color: var(--ic-clr-red-a0);--ic-form-field-bg: var(--ic-surface-primary-a10);--ic-form-field-border: var(--ic-surface-primary-a20);--ic-form-field-border-focus: var(--ic-clr-primary-a10);--ic-form-field-border-error: var(--ic-clr-red-a0);--ic-form-field-disabled-bg: var(--ic-surface-primary-a20);--ic-form-field-disabled-border: var(--ic-surface-primary-a20);--ic-form-field-disabled-color: var(--ic-clr-gray-a20);--ic-form-field-label-color: var(--ic-clr-gray-a0);--ic-form-field-label-active-color: var(--ic-clr-primary-a10);--ic-form-field-label-disabled-color: var(--ic-clr-gray-a20);--ic-form-field-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 53%, #000000 );--ic-form-field-input-color: #f5f7fa;--ic-form-field-input-disabled-color: var(--ic-clr-gray-a20);--ic-form-field-prefix-color: var(--ic-clr-primary-a10);--ic-form-field-add-bg: var(--ic-surface-primary-a20);--ic-form-field-add-color: var(--ic-clr-primary-a10);--ic-form-field-add-hover-bg: var(--ic-surface-primary-a10);--ic-form-field-add-disabled-bg: var(--ic-surface-primary-a20);--ic-form-field-add-disabled-color: var(--ic-clr-gray-a20);--ic-form-field-error-color: var(--ic-clr-red-a0);--ic-form-field-error-counter-bg: rgba(255, 107, 125, .1);--ic-form-field-error-counter-color: var(--ic-clr-red-a0);--ic-form-field-popover-bg: var(--ic-surface-primary-a10);--ic-form-field-popover-shadow: 0px 0px 10px rgba(255, 107, 125, .3);--ic-form-field-popover-color: var(--ic-clr-red-a0);--ic-mobile-field-bg: var(--ic-surface-primary-a10);--ic-mobile-field-border: var(--ic-surface-primary-a20);--ic-mobile-field-border-focus: var(--ic-clr-primary-a10);--ic-mobile-field-border-error: var(--ic-clr-red-a0);--ic-mobile-field-disabled-bg: var(--ic-surface-primary-a20);--ic-mobile-field-disabled-border: var(--ic-surface-primary-a20);--ic-mobile-field-label-color: var(--ic-clr-gray-a0);--ic-mobile-field-label-active-color: var(--ic-clr-primary-a10);--ic-mobile-field-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 57%, #000000 );--ic-mobile-field-required-star: var(--ic-clr-red-a0);--ic-mobile-field-input-disabled-color: var(--ic-clr-gray-a20);--ic-mobile-field-prefix-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-arrow-color: var(--ic-clr-gray-a20);--ic-mobile-field-dropdown-bg: var(--ic-surface-primary-a10);--ic-mobile-field-dropdown-option-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-option-hover-bg: var(--ic-surface-primary-a20);--ic-mobile-field-dropdown-no-results-color: var(--ic-clr-gray-a20);--ic-mobile-field-separator: var(--ic-surface-primary-a20);--ic-mobile-field-error-color: var(--ic-clr-red-a0);--ic-radio-label-color: var(--ic-clr-gray-a0);--ic-radio-label-checked-color: var(--ic-clr-primary-a10);--ic-radio-label-disabled-color: var(--ic-clr-gray-a20);--ic-radio-border: var(--ic-surface-primary-a20);--ic-radio-bg: var(--ic-surface-primary-a10);--ic-radio-border-checked: var(--ic-clr-primary-a10);--ic-radio-bg-checked: var(--ic-clr-primary-a10);--ic-radio-outline-checked: var(--ic-clr-primary-a10);--ic-radio-border-hover: var(--ic-clr-primary-a10);--ic-radio-bg-disabled: var(--ic-surface-primary-a20);--ic-radio-border-disabled: var(--ic-surface-primary-a20);--ic-select-label-color: var(--ic-clr-gray-a0);--ic-select-label-active-color: var(--ic-clr-primary-a10);--ic-select-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 57%, #000000 );--ic-select-bg: var(--ic-surface-primary-a10);--ic-select-border: var(--ic-surface-primary-a20);--ic-select-border-focus: var(--ic-clr-primary-a10);--ic-select-border-error: var(--ic-clr-red-a0);--ic-select-disabled-bg: var(--ic-surface-primary-a20);--ic-select-disabled-border: var(--ic-surface-primary-a20);--ic-select-disabled-color: var(--ic-clr-gray-a20);--ic-select-input-color: #f5f7fa;--ic-select-chip-bg: var(--ic-surface-primary-a20);--ic-select-chip-color: var(--ic-clr-primary-a10);--ic-select-error-color: var(--ic-clr-red-a0);--ic-select-dropdown-bg: var(--ic-surface-primary-a10);--ic-select-dropdown-shadow: 0px 3px 10px rgba(0, 0, 0, .2);--ic-select-search-border: var(--ic-surface-primary-a20);--ic-select-item-color: var(--ic-clr-primary-a10);--ic-select-item-hover-bg: var(--ic-surface-primary-a20);--ic-select-item-hover-color: #ffffff;--ic-select-item-hover-text-gray: var(--ic-clr-gray-a0);--ic-select-item-selected-color: var(--ic-clr-primary-a10);--ic-select-item-selected-bg: var(--ic-surface-primary-a0);--ic-select-item-circle-color: var(--ic-clr-primary-a10);--ic-select-item-circle-bg: var(--ic-surface-primary-a10);--ic-slide-toggle-bg: var(--ic-surface-primary-a20);--ic-slide-toggle-active-bg: var(--ic-clr-primary-a10);--ic-slide-toggle-knob-bg: #ffffff;--ic-tenure-field-label-color: var(--ic-clr-primary-a10);--ic-tenure-field-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 57%, #000000 );--ic-tenure-field-required-star: var(--ic-clr-red-a0);--ic-tenure-field-border: var(--ic-surface-primary-a20);--ic-tenure-field-border-focus: var(--ic-clr-primary-a10);--ic-tenure-field-border-error: var(--ic-clr-red-a0);--ic-tenure-field-bg: var(--ic-surface-primary-a10);--ic-tenure-field-disabled-bg: var(--ic-surface-primary-a20);--ic-tenure-field-disabled-border: var(--ic-surface-primary-a20);--ic-tenure-field-input-color: #f5f7fa;--ic-tenure-field-unit-label-color: var(--ic-clr-gray-a0);--ic-tenure-field-separator-color: var(--ic-clr-gray-a20);--ic-tenure-field-error-color: var(--ic-clr-red-a0);--ic-textarea-label-color: var(--ic-clr-gray-a0);--ic-textarea-label-active-color: var(--ic-clr-primary-a10);--ic-textarea-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 57%, #000000 );--ic-textarea-required-star: var(--ic-clr-red-a0);--ic-textarea-border: var(--ic-surface-primary-a20);--ic-textarea-border-focus: var(--ic-clr-primary-a10);--ic-textarea-border-error: var(--ic-clr-red-a0);--ic-textarea-bg: var(--ic-surface-primary-a10);--ic-textarea-disabled-bg: var(--ic-surface-primary-a20);--ic-textarea-disabled-border: var(--ic-surface-primary-a20);--ic-textarea-disabled-color: var(--ic-clr-gray-a20);--ic-textarea-input-color: #f5f7fa;--ic-textarea-error-color: var(--ic-clr-red-a0);--ic-footer-bg: var(--ic-surface-primary-a10);--ic-footer-logo-color: #ffffff;--ic-footer-desc-color: var(--ic-clr-gray-a0);--ic-footer-heading-color: #ffffff;--ic-footer-link-color: var(--ic-clr-primary-a10);--ic-footer-link-hover-color: #8ab8ff;--ic-footer-divider-color: var(--ic-surface-primary-a20);--ic-accordion-panel-bg: var(--ic-surface-primary-a10);--ic-accordion-panel-shadow: 0px 6.12px 30.62px rgba(0, 0, 0, .2);--ic-accordion-header-color: var(--ic-clr-primary-a10);--ic-accordion-header-accent: var(--ic-clr-gray-a0);--ic-accordion-list-color: var(--ic-clr-gray-a0);--ic-accordion-list-hover: #f5f7fa}.theme-ruby{--ic-clr-default: #ffffff;--ic-clr-inverted: #000000;--ic-clr-primary-a0: #e71b3c;--ic-clr-primary-a10: #b1142f;--ic-clr-primary-a20: #8a1025;--ic-clr-primary-a30: #540a17;--ic-clr-tonal-a0: #ffb3c2;--ic-clr-tonal-a10: #ff809a;--ic-clr-tonal-a20: #ff4d73;--ic-clr-tonal-a30: #e71b3c;--ic-clr-tonal-a40: #b1142f;--ic-clr-green-a0: #17b26a;--ic-clr-red-a0: #ff3d3d;--ic-clr-red-a10: #f04438;--ic-clr-red-a20: #b20000;--ic-clr-gray-a0: #8e8e8e;--ic-clr-gray-a10: #9c9c9c;--ic-clr-gray-a20: #858585;--ic-clr-gray-a30: #707070;--ic-clr-yellow-a0: #f79009;--ic-surface-primary-a0: #ffffff;--ic-surface-primary-a10: #f0f4ff;--ic-surface-primary-a20: #f3f3f3;--ic-surface-primary-a30: #ffe7e8;--ic-surface-primary-a40: #fef3f2;--ic-surface-primary-a50: #999;--ic-surface-tonal-a0: #fff0f3;--ic-surface-tonal-a10: #ffd6de;--ic-surface-tonal-a20: #ffb3c2;--ic-surface-tonal-a30: #ff809a;--ic-surface-tonal-a40: #ff4d73;--ic-surface-tonal-a50: #e71b3c;background:var(--ic-app-bg);--ic-app-bg: var(--ic-surface-primary-a0);--ic-card-bg: var(--ic-surface-primary-a0);--ic-card-bg-accent: #fef3f2;--ic-text-white: var(--ic-clr-default);--ic-text-black: var(--ic-clr-inverted);--ic-text-theme: var(--ic-clr-primary-a0);--ic-gray-accent: var(--ic-surface-primary-a20);--ic-text-gray: var(--ic-clr-gray-a0);--ic-text-gray-dark: var(--ic-clr-gray-a20);--ic-text-gray-light: var(--ic-clr-gray-a10);--ic-text-red: var(--ic-clr-tonal-a0);--ic-text-green: var(--ic-clr-green-a0);--ic-primary-font-family: \"Bliss Pro\", sans-serif;--ic-secondary-font-family: \"Inter\", sans-serif;--ic-btn-filled-bg: var(--ic-clr-primary-a0);--ic-btn-filled-color: var(--ic-clr-default);--ic-btn-filled-warning-bg: var(--ic-clr-yellow-a0);--ic-btn-filled-danger-bg: var(--ic-clr-red-a10);--ic-btn-filled-neutral-bg: var(--ic-clr-primary-a10);--ic-btn-filled-blue-bg: var(--ic-clr-primary-a0);--ic-btn-filled-basic-bg: #000000;--ic-btn-filled-success-bg: var(--ic-clr-green-a0);--ic-btn-outlined-bg: var(--ic-surface-primary-a0);--ic-btn-outlined-color: var(--ic-clr-primary-a10);--ic-btn-outlined-border: var(--ic-clr-primary-a10);--ic-btn-outlined-hover-bg: #007fff14;--ic-btn-outlined-warning: var(--ic-clr-yellow-a0);--ic-btn-outlined-danger: var(--ic-clr-red-a10);--ic-btn-outlined-neutral: var(--ic-clr-primary-a10);--ic-btn-outlined-basic: #000000;--ic-btn-outlined-success: var(--ic-clr-green-a0);--ic-btn-outlined-transparent-bg: transparent;--ic-btn-outlined-transparent-color: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-border: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-hover-bg: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-hover-color: var(--ic-clr-primary-a0);--ic-btn-status-border: var(--ic-clr-primary-a10);--ic-btn-status-color: var(--ic-clr-primary-a10);--ic-btn-status-warning: var(--ic-clr-yellow-a0);--ic-btn-status-warning-bg: #fff7e6;--ic-btn-status-danger: var(--ic-clr-red-a10);--ic-btn-status-danger-bg: #ffe7e8;--ic-btn-status-neutral: var(--ic-clr-primary-a10);--ic-btn-status-neutral-bg: #e3e9fe;--ic-btn-status-basic: #000000;--ic-btn-status-basic-bg: var(--ic-surface-primary-a0);--ic-btn-status-success: var(--ic-clr-green-a0);--ic-btn-status-success-bg: #ddf8f1;--ic-btn-status-hover-bg: #007fff14;--ic-btn-ghost-bg: var(--ic-surface-primary-a0);--ic-btn-ghost-color: var(--ic-clr-primary-a10);--ic-btn-ghost-shadow: 0px 3px 10px 0px #00000017;--ic-btn-ghost-warning: var(--ic-clr-yellow-a0);--ic-btn-ghost-danger: var(--ic-clr-red-a10);--ic-btn-ghost-neutral: var(--ic-clr-primary-a10);--ic-btn-ghost-basic: #000000;--ic-btn-ghost-success: var(--ic-clr-green-a0);--ic-btn-ghost-disabled-color: var(--ic-clr-default);--ic-btn-disabled-bg: #cecece;--ic-btn-spinner-color: var(--ic-surface-primary-a0);--ic-btn-toggle-group-bg: var(--ic-surface-primary-a0);--ic-btn-toggle-group-border: #e0e0e0;--ic-btn-toggle-group-shadow: 0 3px 10px #00000017;--ic-card-shadow: 0px 3px 9px 0px rgba(0, 0, 0, .11);--ic-checkbox-filled-bg: var(--ic-clr-primary-a0);--ic-checkbox-filled-border: var(--ic-clr-primary-a0);--ic-checkbox-checkmark-color: var(--ic-clr-default);--ic-checkbox-outlined-bg: var(--ic-surface-primary-a0);--ic-checkbox-outlined-border: var(--ic-clr-primary-a0);--ic-checkbox-checkmark-outlined-color: var(--ic-clr-primary-a0);--ic-checkbox-border: #70707057;--ic-checkbox-bg: var(--ic-surface-primary-a0);--ic-checkbox-primary-bg: var(--ic-clr-primary-a0);--ic-checkbox-primary-border: var(--ic-clr-primary-a0);--ic-checkbox-accent-bg: #ff4081;--ic-checkbox-accent-border: #ff4081;--ic-checkbox-warn-bg: #f44336;--ic-checkbox-warn-border: #f44336;--ic-checkbox-label-color: var(--ic-clr-primary-a0);--ic-date-picker-bg: var(--ic-surface-primary-a0);--ic-date-picker-border: #dcdcdc;--ic-date-picker-border-focus: var(--ic-clr-primary-a10);--ic-date-picker-border-error: var(--ic-clr-red-a10);--ic-date-picker-label-color: #666;--ic-date-picker-label-active-color: var(--ic-clr-primary-a10);--ic-date-picker-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-date-picker-required-star: #ff0000;--ic-date-picker-disabled-bg: var(--ic-surface-primary-a20);--ic-date-picker-disabled-border: #dcdcdc;--ic-date-picker-disabled-color: gray;--ic-date-picker-input-color: inherit;--ic-date-picker-calendar-toggle-color: inherit;--ic-date-picker-calendar-bg: var(--ic-surface-primary-a0);--ic-date-picker-calendar-shadow: 0 3px 15px rgba(0, 0, 0, .15);--ic-date-picker-calendar-header-bg: #e6efff;--ic-date-picker-calendar-header-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-header-hover-bg: #ededed;--ic-date-picker-calendar-nav-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-nav-hover-bg: #f0f0f0;--ic-date-picker-calendar-date-color: inherit;--ic-date-picker-calendar-date-disabled-color: #aaa;--ic-date-picker-calendar-date-selected-bg: #fef3f2;--ic-date-picker-calendar-date-selected-color: var(--ic-clr-default);--ic-date-picker-calendar-date-hover-bg: #f0f0f0;--ic-date-picker-calendar-selector-border: #ccc;--ic-date-picker-calendar-selector-hover-bg: #f0f0f0;--ic-date-picker-error-color: var(--ic-clr-red-a10);--ic-form-field-bg: var(--ic-surface-primary-a0);--ic-form-field-border: #dcdcdc;--ic-form-field-border-focus: var(--ic-clr-primary-a10);--ic-form-field-border-error: var(--ic-clr-red-a10);--ic-form-field-disabled-bg: var(--ic-surface-primary-a20);--ic-form-field-disabled-border: #dcdcdc;--ic-form-field-disabled-color: gray;--ic-form-field-label-color: #666;--ic-form-field-label-active-color: var(--ic-clr-primary-a10);--ic-form-field-label-disabled-color: #999;--ic-form-field-label-bg: linear-gradient(180deg, #0000ff00 30%, var(--ic-surface-primary-a0) 53%, #00800000 80%);--ic-form-field-input-color: inherit;--ic-form-field-input-disabled-color: #999;--ic-form-field-prefix-color: var(--ic-clr-primary-a10);--ic-form-field-add-bg: #e9ecf5;--ic-form-field-add-color: var(--ic-clr-primary-a10);--ic-form-field-add-hover-bg: #d7e3fb;--ic-form-field-add-disabled-bg: #dcdcdc;--ic-form-field-add-disabled-color: #b1b1b1;--ic-form-field-error-color: var(--ic-clr-red-a10);--ic-form-field-error-counter-bg: rgba(255, 0, 0, .1);--ic-form-field-error-counter-color: var(--ic-clr-red-a10);--ic-form-field-popover-bg: var(--ic-surface-primary-a0);--ic-form-field-popover-shadow: 0px 0px 10px rgba(255, 0, 0, .3);--ic-form-field-popover-color: var(--ic-clr-red-a10);--ic-mobile-field-bg: var(--ic-surface-primary-a0);--ic-mobile-field-border: #dcdcdc;--ic-mobile-field-border-focus: var(--ic-clr-primary-a10);--ic-mobile-field-border-error: var(--ic-clr-red-a10);--ic-mobile-field-disabled-bg: var(--ic-surface-primary-a20);--ic-mobile-field-disabled-border: #dcdcdc;--ic-mobile-field-label-color: #666;--ic-mobile-field-label-active-color: var(--ic-clr-primary-a10);--ic-mobile-field-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-mobile-field-required-star: #ff0000;--ic-mobile-field-input-disabled-color: #999;--ic-mobile-field-prefix-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-arrow-color: #b3bac8;--ic-mobile-field-dropdown-bg: var(--ic-surface-primary-a0);--ic-mobile-field-dropdown-option-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-option-hover-bg: #f5f5f5;--ic-mobile-field-dropdown-no-results-color: #999;--ic-mobile-field-separator: #e8e8e8;--ic-mobile-field-error-color: var(--ic-clr-red-a10);--ic-radio-label-color: var(--ic-clr-gray-a30);--ic-radio-label-checked-color: var(--ic-clr-primary-a10);--ic-radio-label-disabled-color: #b1b1b1;--ic-radio-border: var(--ic-clr-default);--ic-radio-bg: var(--ic-surface-primary-a0);--ic-radio-border-checked: var(--ic-clr-default);--ic-radio-bg-checked: var(--ic-clr-primary-a10);--ic-radio-outline-checked: var(--ic-clr-primary-a10);--ic-radio-border-hover: var(--ic-clr-primary-a10);--ic-radio-bg-disabled: var(--ic-surface-primary-a20);--ic-radio-border-disabled: #dcdcdc;--ic-select-label-color: #666;--ic-select-label-active-color: var(--ic-clr-primary-a10);--ic-select-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-select-bg: var(--ic-surface-primary-a0);--ic-select-border: #dcdcdc;--ic-select-border-focus: var(--ic-clr-primary-a10);--ic-select-border-error: var(--ic-clr-red-a10);--ic-select-disabled-bg: var(--ic-surface-primary-a20);--ic-select-disabled-border: #dcdcdc;--ic-select-disabled-color: gray;--ic-select-input-color: inherit;--ic-select-chip-bg: #e1f1ff;--ic-select-chip-color: var(--ic-clr-primary-a0);--ic-select-error-color: var(--ic-clr-red-a10);--ic-select-dropdown-bg: var(--ic-surface-primary-a0);--ic-select-dropdown-shadow: 0px 3px 10px 0px rgba(0, 0, 0, .09);--ic-select-search-border: #ccc;--ic-select-item-color: var(--ic-clr-primary-a10);--ic-select-item-hover-bg: var(--ic-clr-primary-a0);--ic-select-item-hover-color: var(--ic-clr-default);--ic-select-item-hover-text-gray: #95ceff;--ic-select-item-selected-color: var(--ic-clr-default);--ic-select-item-selected-bg: var(--ic-clr-primary-a0);--ic-select-item-circle-color: var(--ic-clr-primary-a0);--ic-select-item-circle-bg: var(--ic-surface-primary-a20);--ic-slide-toggle-bg: #ccc;--ic-slide-toggle-active-bg: var(--ic-clr-primary-a0);--ic-slide-toggle-knob-bg: var(--ic-surface-primary-a0);--ic-tenure-field-label-color: var(--ic-clr-primary-a10);--ic-tenure-field-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-tenure-field-required-star: #ff0000;--ic-tenure-field-border: #dcdcdc;--ic-tenure-field-border-focus: #fef3f2;--ic-tenure-field-border-error: var(--ic-clr-red-a10);--ic-tenure-field-bg: var(--ic-surface-primary-a0);--ic-tenure-field-disabled-bg: var(--ic-surface-primary-a20);--ic-tenure-field-disabled-border: #dcdcdc;--ic-tenure-field-input-color: inherit;--ic-tenure-field-unit-label-color: #010101;--ic-tenure-field-separator-color: var(--ic-clr-gray-a30);--ic-tenure-field-error-color: var(--ic-clr-red-a10);--ic-textarea-label-color: #666;--ic-textarea-label-active-color: var(--ic-clr-primary-a10);--ic-textarea-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-textarea-required-star: #ff0000;--ic-textarea-border: #dcdcdc;--ic-textarea-border-focus: var(--ic-clr-primary-a10);--ic-textarea-border-error: var(--ic-clr-red-a10);--ic-textarea-bg: var(--ic-surface-primary-a0);--ic-textarea-disabled-bg: var(--ic-surface-primary-a20);--ic-textarea-disabled-border: #dcdcdc;--ic-textarea-disabled-color: gray;--ic-textarea-input-color: inherit;--ic-textarea-error-color: var(--ic-clr-red-a10);--ic-footer-bg: var(--ic-surface-primary-a0);--ic-footer-logo-color: var(--ic-clr-primary-a10);--ic-footer-desc-color: var(--ic-clr-primary-a10);--ic-footer-heading-color: #212353;--ic-footer-link-color: var(--ic-clr-primary-a10);--ic-footer-link-hover-color: var(--ic-clr-primary-a0);--ic-footer-divider-color: #52515187;--ic-accordion-panel-bg: var(--ic-surface-primary-a0);--ic-accordion-panel-shadow: 0px 6.12px 30.62px 0px rgba(0, 0, 0, .11);--ic-accordion-header-color: var(--ic-clr-primary-a10);--ic-accordion-header-accent: var(--ic-clr-primary-a0);--ic-accordion-list-color: #909090;--ic-accordion-list-hover: #000000}.ic-select-field{position:relative;width:100%;margin:8px 0}.ic-select-field.disabled{pointer-events:none}.ic-select-field label{position:absolute;left:16px;font-size:14px;transition:.3s;color:var(--ic-select-label-color, #666);font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);transform:translateY(9px)!important;z-index:2}.ic-select-field label.floated{left:12px;transform:translateY(-8px)!important;font-size:12px;color:var(--ic-select-label-active-color, #0033a1);background:var(--ic-select-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0), #fff 57%, rgba(0, 128, 0, 0)));padding:0 4px;z-index:1}.ic-select-field .dropdown{position:relative}.ic-select-field .dropdown .dropdown-header-div{height:40px;display:flex;justify-content:space-between;align-items:center;padding:8px 16px;font-size:14px!important;font-weight:500;font-family:var(--ic-primary-font-family),sans-serif;outline:none;border:2px solid var(--ic-select-border, #dcdcdc);border-radius:8px;background:var(--ic-select-bg, #ffffff);box-shadow:var(--ic-select-box-shadow, none);transition:border-color .3s ease,box-shadow .3s ease;color:var(--ic-select-input-color, inherit);cursor:pointer}.ic-select-field .dropdown .dropdown-header-div.dropdown-open{border-color:var(--ic-select-border-focus, #0033a1)}.ic-select-field .dropdown .dropdown-header-div.dropdown-error{border-color:var(--ic-select-border-error, red)}.ic-select-field .dropdown .dropdown-header-div.dropdown-disabled{background-color:var(--ic-select-disabled-bg, #f3f3f3)!important;border-color:var(--ic-select-disabled-border, #dcdcdc)!important;box-shadow:none!important;color:var(--ic-select-disabled-color, gray)!important;pointer-events:none;cursor:not-allowed!important}.ic-select-field .dropdown .dropdown-header-div .chip-container{display:flex;gap:2px}.ic-select-field .dropdown .dropdown-header-div .chip-container .chip{background:var(--ic-select-chip-bg, #e1f1ff);padding:1px 8px;color:var(--ic-select-chip-color, cornflowerblue);border-radius:8px}.ic-select-field .dropdown .dropdown-header-div .label-display-container{text-overflow:ellipsis;white-space:nowrap;overflow:hidden;width:80%}.ic-select-field .dropdown .dropdown-header-div .vl{height:90%;width:2px;background-color:#dcdcdc;margin:0 3px;border-radius:2px}.ic-select-field .error-message{color:var(--ic-select-error-color, red);font-size:12px;margin:0 16px}.dropdown-menu-overlay{background:var(--ic-select-dropdown-bg, #fff);border-bottom-left-radius:8px;border-bottom-right-radius:8px;box-shadow:var(--ic-select-dropdown-shadow, 0px 3px 10px 0px rgba(0, 0, 0, .09));width:100%}.dropdown-menu-overlay .search-input{padding:8px;border:1px solid var(--ic-select-search-border, #ccc);border-radius:8px;width:calc(100% - 5px);display:flex;margin:2px auto;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.dropdown-menu-overlay .dropdown-list{list-style:none;padding:0;margin:1%;max-height:200px;overflow:auto}.dropdown-menu-overlay .dropdown-list .dropdown-item{display:flex;align-items:center;gap:2px;padding:8px;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);color:var(--ic-select-item-color, #0033a1);text-overflow:ellipsis;white-space:nowrap;overflow:auto;scrollbar-width:none;cursor:pointer;transition:color .12s linear}.dropdown-menu-overlay .dropdown-list .dropdown-item .profileImage{border-radius:50%;box-shadow:0 3px 15px #0000000a;border:2px solid #ffffff;opacity:1;text-align:center;width:40px;height:40px;margin-right:10px;object-fit:cover}.dropdown-menu-overlay .dropdown-list .dropdown-item .circle{color:var(--ic-select-item-circle-color, #059eab);background:var(--ic-select-item-circle-bg, #f3f3f3);font-size:14px;border-radius:50%;box-shadow:0 3px 15px #0000000a;border:2px solid #ffffff;opacity:1;text-align:center;width:35px;height:35px;margin-right:10px;display:flex;justify-content:center;align-items:center}.dropdown-menu-overlay .dropdown-list .dropdown-item:hover{background:var(--ic-select-item-hover-bg, linear-gradient(90deg, #06113c 0%, #004aa0 100%));color:var(--ic-select-item-hover-color, #fff);border-radius:4px}.dropdown-menu-overlay .dropdown-list .dropdown-item:hover .text-gray{color:var(--ic-select-item-hover-text-gray, #95ceff)!important;font-weight:300!important}.dropdown-menu-overlay .dropdown-list .dropdown-item.selected{color:var(--ic-select-item-selected-color, #0033a1);background:var(--ic-select-item-selected-bg, #d8e3f0);min-width:100%;font-size:inherit;font-weight:inherit;border-radius:4px;margin:2px 0;height:auto}.cdk-overlay-transparent-backdrop{background-color:transparent!important}\n"], dependencies: [{ kind: "directive", type: i1$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: NoInitialSpaceDirective, selector: "input, textarea" }, { kind: "component", type: IconComponent, selector: "ic-icon", inputs: ["name", "color", "size"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-select', template: "<div\r\n  class=\"ic-select-field {{ customClass }}\"\r\n  (click)=\"toggleDropdown()\"\r\n  [class.disabled]=\"disabled\">\r\n  <label *ngIf=\"!skipLabel\" [class.floated]=\"shouldFloatLabel()\">\r\n    {{ label }}\r\n    <span *ngIf=\"isRequired\" class=\"required_star\" style=\"color: red\">*</span>\r\n  </label>\r\n  <div class=\"dropdown\">\r\n    <div\r\n      #dropdownHeader\r\n      class=\"dropdown-header-div\"\r\n      [class.dropdown-open]=\"dropdownOpen\"\r\n      [class.dropdown-disabled]=\"disabled\"\r\n      [class.dropdown-error]=\"\r\n        control.invalid && (control.dirty || control.touched)\r\n      \">\r\n      <div\r\n        *ngIf=\"selectionType === 'multi' && selectedValues.length > 0\"\r\n        class=\"chip-container\">\r\n        <div *ngFor=\"let value of multiSelectedLabel.slice(0, 2)\" class=\"chip\">\r\n          {{ value }}\r\n          <span\r\n            class=\"remove-chip\"\r\n            (click)=\"deselectOption(getOptionByLabel(value))\">\r\n            \u00D7\r\n          </span>\r\n        </div>\r\n        <div *ngIf=\"selectedValues.length > 2\" class=\"chip\">\r\n          +{{ selectedValues.length - 2 }}\r\n        </div>\r\n      </div>\r\n      <span\r\n        *ngIf=\"selectionType === 'single' || !selectedValues.length\"\r\n        class=\"label-display-container\">\r\n        <ng-container *ngIf=\"selectedLabel\">\r\n          <ng-container *ngIf=\"!displayLabel\">\r\n            {{ selectedLabel }}\r\n          </ng-container>\r\n          <ng-container *ngIf=\"displayLabel && !specificBracketAttribute\">\r\n            {{\r\n              selectedLabel\r\n                ? selectedLabel +\r\n                  ' (' +\r\n                  getOptionByLabel(selectedLabel)[bindValueKey] +\r\n                  ')'\r\n                : ''\r\n            }}\r\n          </ng-container>\r\n          <ng-container *ngIf=\"displayLabel && specificBracketAttribute\">\r\n            {{\r\n              selectedLabel\r\n                ? selectedLabel +\r\n                  ' (' +\r\n                  getOptionByLabel(selectedLabel)[specificBracketAttribute] +\r\n                  ')'\r\n                : ''\r\n            }}\r\n          </ng-container>\r\n        </ng-container>\r\n      </span>\r\n      <ic-icon\r\n        name=\"sort-down\"\r\n        style=\"--ic-icon-color: #b3bac8; height: 12px; width: 12px\">\r\n      </ic-icon>\r\n      <ng-container *ngIf=\"searchInField == true\">\r\n        <div class=\"vl\"></div>\r\n        <ic-icon\r\n          name=\"search\"\r\n          style=\"--ic-icon-color: #b3bac8; height: 12px; width: 12px\"></ic-icon>\r\n      </ng-container>\r\n    </div>\r\n    <ng-template #dropdownMenuTemplate>\r\n      <div class=\"dropdown-menu-overlay\">\r\n        <ng-container *ngIf=\"!hideSearch\">\r\n          <input\r\n            [formControl]=\"filterFormControl\"\r\n            class=\"search-input\"\r\n            type=\"search\"\r\n            placeholder=\"Search...\"\r\n            autofocus />\r\n        </ng-container>\r\n        <ul class=\"dropdown-list\">\r\n          <ng-container *ngIf=\"filteredOptions.length > 0; else noContent\">\r\n            <li\r\n              *ngIf=\"selectionType === 'multi'\"\r\n              class=\"dropdown-item\"\r\n              (click)=\"toggleAllSelections()\">\r\n              <input\r\n                type=\"checkbox\"\r\n                [checked]=\"selectedValues.length === options.length\" />\r\n              Select All\r\n            </li>\r\n            <li\r\n              *ngIf=\"selectionType === 'single' && !hideSearch\"\r\n              class=\"dropdown-item\"\r\n              (click)=\"clearSelection()\">\r\n              Select\r\n            </li>\r\n            <li\r\n              *ngFor=\"let option of filteredOptions; let i = index\"\r\n              class=\"dropdown-item\"\r\n              [class.selected]=\"\r\n                isSelected(option[bindValueKey] ?? option) ||\r\n                (option[bindValueKey] === '' && isSelected(''))\r\n              \"\r\n              (click)=\"selectOption(option)\">\r\n              <ng-container *ngIf=\"selectionType === 'multi'\">\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [checked]=\"isSelected(option[bindValueKey] || option)\" />\r\n              </ng-container>\r\n              <ng-container *ngIf=\"showProfile\">\r\n                <ng-container\r\n                  *ngIf=\"\r\n                    option?.profileUrl && option?.profileUrl !== 'NOT_EXIST';\r\n                    else showInitialAvatar\r\n                  \">\r\n                  <img\r\n                    [src]=\"option.profileUrl\"\r\n                    alt=\"image\"\r\n                    class=\"avatar-2x\" />\r\n                </ng-container>\r\n                <ng-template #showInitialAvatar>\r\n                  <div class=\"circle\">\r\n                    {{ option.username?.[0][0]?.toUpperCase()\r\n                    }}{{ option.username?.[1][0]?.toUpperCase() }}\r\n                  </div>\r\n                </ng-template>\r\n              </ng-container>\r\n              <div>\r\n                <div>\r\n                  {{ getOptionLabel(option) }}\r\n                  <span *ngIf=\"displayLabel && !specificBracketAttribute\">\r\n                    ({{ option[bindValueKey] }})\r\n                  </span>\r\n                  <span *ngIf=\"displayLabel && specificBracketAttribute\">\r\n                    ({{ option[specificBracketAttribute] }})\r\n                  </span>\r\n                </div>\r\n                <div>\r\n                  <h6\r\n                    *ngIf=\"showProfile && option.empId !== null\"\r\n                    class=\"text-gray\">\r\n                    EMP #{{ option.empId }}\r\n                  </h6>\r\n                </div>\r\n              </div>\r\n            </li>\r\n          </ng-container>\r\n          <ng-template #noContent>\r\n            <li class=\"dropdown-item\">No Data Present</li>\r\n          </ng-template>\r\n        </ul>\r\n      </div>\r\n    </ng-template>\r\n  </div>\r\n  <div\r\n    *ngIf=\"control?.invalid && (control?.dirty || control?.touched)\"\r\n    class=\"error-message\">\r\n    <div *ngIf=\"control?.errors?.['required']\">{{ label }} is Required!</div>\r\n    <div *ngIf=\"customError\">{{ customError }}</div>\r\n  </div>\r\n</div>\r\n", styles: [":root{--ic-clr-default: #ffffff;--ic-clr-inverted: #000000;--ic-clr-primary-a0: #0051ff;--ic-clr-primary-a10: #0033a1;--ic-clr-primary-a20: #00008c;--ic-clr-primary-a30: #00164e;--ic-clr-tonal-a0: #0062e1;--ic-clr-tonal-a10: #004aa0;--ic-clr-tonal-a20: #004991;--ic-clr-tonal-a30: #0033aa;--ic-clr-tonal-a40: #06113c;--ic-clr-green-a0: #008461;--ic-clr-red-a0: #ff3d3d;--ic-clr-red-a10: #ff0000;--ic-clr-red-a20: #b20000;--ic-clr-gray-a0: #8e8e8e;--ic-clr-gray-a10: #9c9c9c;--ic-clr-gray-a20: #858585;--ic-clr-gray-a30: #707070;--ic-clr-yellow-a0: #d68c00;--ic-surface-primary-a0: #ffffff;--ic-surface-primary-a10: #f0f4ff;--ic-surface-primary-a20: #f3f3f3;--ic-surface-primary-a30: #e8e8e8;--ic-surface-primary-a40: #dcdcdc;--ic-surface-tonal-a0: #eff7ff;--ic-surface-tonal-a10: #e1f1ff;--ic-surface-tonal-a20: #d8e3f0;--ic-surface-tonal-a30: #c4d0e0;--ic-surface-tonal-a40: #b0bec5;--ic-surface-tonal-a50: #9ea7b6;background:var(--ic-app-bg);--ic-app-bg: var(--ic-surface-primary-a0);--ic-card-bg: var(--ic-surface-primary-a0);--ic-card-bg-accent: var(--ic-surface-tonal-a0);--ic-text-white: var(--ic-clr-default);--ic-text-black: var(--ic-clr-inverted);--ic-text-theme: var(--ic-clr-primary-a10);--ic-gray-accent: var(--ic-surface-primary-a20);--ic-text-gray: var(--ic-clr-gray-a0);--ic-text-gray-dark: var(--ic-clr-gray-a20);--ic-text-gray-light: var(--ic-clr-gray-a10);--ic-text-red: var(--ic-clr-red-a0);--ic-text-green: var(--ic-clr-green-a0);--ic-primary-font-family: \"Benton Sans\", sans-serif;--ic-secondary-font-family: \"Inter\", sans-serif;--ic-btn-filled-bg: linear-gradient(90deg, var(--ic-clr-tonal-a0) 0%, var(--ic-clr-tonal-a30) 100%);--ic-btn-filled-color: var(--ic-clr-default);--ic-btn-filled-warning-bg: var(--ic-clr-yellow-a0);--ic-btn-filled-danger-bg: var(--ic-clr-red-a20);--ic-btn-filled-neutral-bg: var(--ic-clr-primary-a10);--ic-btn-filled-blue-bg: var(--ic-clr-tonal-a0);--ic-btn-filled-basic-bg: var(--ic-clr-inverted);--ic-btn-filled-success-bg: var(--ic-clr-green-a0);--ic-btn-outlined-bg: var(--ic-surface-primary-a0);--ic-btn-outlined-color: var(--ic-clr-primary-a10);--ic-btn-outlined-border: var(--ic-clr-primary-a10);--ic-btn-outlined-hover-bg: #007fff14;--ic-btn-outlined-warning: var(--ic-clr-yellow-a0);--ic-btn-outlined-danger: var(--ic-clr-red-a20);--ic-btn-outlined-neutral: var(--ic-clr-primary-a10);--ic-btn-outlined-basic: var(--ic-clr-inverted);--ic-btn-outlined-success: var(--ic-clr-green-a0);--ic-btn-outlined-transparent-bg: transparent;--ic-btn-outlined-transparent-color: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-border: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-hover-bg: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-hover-color: #212353;--ic-btn-status-border: var(--ic-clr-primary-a10);--ic-btn-status-color: var(--ic-clr-primary-a10);--ic-btn-status-warning: var(--ic-clr-yellow-a0);--ic-btn-status-warning-bg: #fff7e6;--ic-btn-status-danger: var(--ic-clr-red-a20);--ic-btn-status-danger-bg: #ffe7e8;--ic-btn-status-neutral: var(--ic-clr-primary-a10);--ic-btn-status-neutral-bg: #e3e9fe;--ic-btn-status-basic: var(--ic-clr-inverted);--ic-btn-status-basic-bg: var(--ic-surface-primary-a0);--ic-btn-status-success: var(--ic-clr-green-a0);--ic-btn-status-success-bg: #ddf8f1;--ic-btn-status-hover-bg: #007fff14;--ic-btn-ghost-bg: var(--ic-surface-primary-a0);--ic-btn-ghost-color: var(--ic-clr-primary-a10);--ic-btn-ghost-shadow: 0px 3px 10px 0px #00000017;--ic-btn-ghost-warning: var(--ic-clr-yellow-a0);--ic-btn-ghost-danger: var(--ic-clr-red-a20);--ic-btn-ghost-neutral: var(--ic-clr-primary-a10);--ic-btn-ghost-basic: var(--ic-clr-inverted);--ic-btn-ghost-success: var(--ic-clr-green-a0);--ic-btn-ghost-disabled-color: var(--ic-clr-default);--ic-btn-disabled-bg: #cecece;--ic-btn-spinner-color: var(--ic-surface-primary-a0);--ic-btn-toggle-group-bg: var(--ic-surface-primary-a0);--ic-btn-toggle-group-border: #e0e0e0;--ic-btn-toggle-group-shadow: 0 3px 10px #00000017;--ic-card-shadow: 0px 3px 9px 0px rgba(0, 0, 0, .11);--ic-checkbox-filled-bg: var(--ic-clr-tonal-a20);--ic-checkbox-filled-border: var(--ic-clr-tonal-a20);--ic-checkbox-checkmark-color: var(--ic-clr-default);--ic-checkbox-outlined-bg: var(--ic-surface-primary-a0);--ic-checkbox-outlined-border: var(--ic-clr-tonal-a20);--ic-checkbox-checkmark-outlined-color: var(--ic-clr-tonal-a20);--ic-checkbox-border: #70707057;--ic-checkbox-bg: var(--ic-surface-primary-a0);--ic-checkbox-primary-bg: var(--ic-clr-tonal-a20);--ic-checkbox-primary-border: var(--ic-clr-tonal-a20);--ic-checkbox-accent-bg: #ff4081;--ic-checkbox-accent-border: #ff4081;--ic-checkbox-warn-bg: #f44336;--ic-checkbox-warn-border: #f44336;--ic-checkbox-label-color: #212353;--ic-date-picker-bg: var(--ic-surface-primary-a0);--ic-date-picker-border: #dcdcdc;--ic-date-picker-border-focus: var(--ic-clr-primary-a10);--ic-date-picker-border-error: var(--ic-clr-red-a10);--ic-date-picker-label-color: #666;--ic-date-picker-label-active-color: var(--ic-clr-primary-a10);--ic-date-picker-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-date-picker-required-star: var(--ic-clr-red-a10);--ic-date-picker-disabled-bg: var(--ic-surface-primary-a20);--ic-date-picker-disabled-border: #dcdcdc;--ic-date-picker-disabled-color: gray;--ic-date-picker-input-color: inherit;--ic-date-picker-calendar-toggle-color: inherit;--ic-date-picker-calendar-bg: var(--ic-surface-primary-a0);--ic-date-picker-calendar-shadow: 0 3px 15px rgba(0, 0, 0, .15);--ic-date-picker-calendar-header-bg: #e6efff;--ic-date-picker-calendar-header-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-header-hover-bg: #ededed;--ic-date-picker-calendar-nav-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-nav-hover-bg: #f0f0f0;--ic-date-picker-calendar-date-color: inherit;--ic-date-picker-calendar-date-disabled-color: #aaa;--ic-date-picker-calendar-date-selected-bg: #007bff;--ic-date-picker-calendar-date-selected-color: var(--ic-clr-default);--ic-date-picker-calendar-date-hover-bg: #f0f0f0;--ic-date-picker-calendar-selector-border: #ccc;--ic-date-picker-calendar-selector-hover-bg: #f0f0f0;--ic-date-picker-error-color: var(--ic-clr-red-a10);--ic-form-field-bg: var(--ic-surface-primary-a0);--ic-form-field-border: #dcdcdc;--ic-form-field-border-focus: var(--ic-clr-primary-a10);--ic-form-field-border-error: var(--ic-clr-red-a10);--ic-form-field-disabled-bg: var(--ic-surface-primary-a20);--ic-form-field-disabled-border: #dcdcdc;--ic-form-field-disabled-color: gray;--ic-form-field-label-color: #666;--ic-form-field-label-active-color: var(--ic-clr-primary-a10);--ic-form-field-label-disabled-color: #999;--ic-form-field-label-bg: linear-gradient(180deg, #0000ff00 30%, var(--ic-surface-primary-a0) 53%, #00800000 80%);--ic-form-field-input-color: inherit;--ic-form-field-input-disabled-color: #999;--ic-form-field-prefix-color: var(--ic-clr-primary-a10);--ic-form-field-add-bg: #e9ecf5;--ic-form-field-add-color: var(--ic-clr-primary-a10);--ic-form-field-add-hover-bg: #d7e3fb;--ic-form-field-add-disabled-bg: #dcdcdc;--ic-form-field-add-disabled-color: #b1b1b1;--ic-form-field-error-color: var(--ic-clr-red-a10);--ic-form-field-error-counter-bg: rgba(255, 0, 0, .1);--ic-form-field-error-counter-color: var(--ic-clr-red-a10);--ic-form-field-popover-bg: var(--ic-surface-primary-a0);--ic-form-field-popover-shadow: 0px 0px 10px rgba(255, 0, 0, .3);--ic-form-field-popover-color: var(--ic-clr-red-a10);--ic-mobile-field-bg: var(--ic-surface-primary-a0);--ic-mobile-field-border: #dcdcdc;--ic-mobile-field-border-focus: var(--ic-clr-primary-a10);--ic-mobile-field-border-error: var(--ic-clr-red-a10);--ic-mobile-field-disabled-bg: var(--ic-surface-primary-a20);--ic-mobile-field-disabled-border: #dcdcdc;--ic-mobile-field-label-color: #666;--ic-mobile-field-label-active-color: var(--ic-clr-primary-a10);--ic-mobile-field-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-mobile-field-required-star: var(--ic-clr-red-a10);--ic-mobile-field-input-disabled-color: #999;--ic-mobile-field-prefix-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-arrow-color: #b3bac8;--ic-mobile-field-dropdown-bg: var(--ic-surface-primary-a0);--ic-mobile-field-dropdown-option-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-option-hover-bg: #f5f5f5;--ic-mobile-field-dropdown-no-results-color: #999;--ic-mobile-field-separator: var(--ic-surface-primary-a30);--ic-mobile-field-error-color: var(--ic-clr-red-a10);--ic-radio-label-color: var(--ic-clr-gray-a30);--ic-radio-label-checked-color: var(--ic-clr-primary-a10);--ic-radio-label-disabled-color: #b1b1b1;--ic-radio-border: var(--ic-clr-default);--ic-radio-bg: var(--ic-surface-primary-a0);--ic-radio-border-checked: var(--ic-clr-default);--ic-radio-bg-checked: var(--ic-clr-primary-a10);--ic-radio-outline-checked: var(--ic-clr-primary-a10);--ic-radio-border-hover: var(--ic-clr-primary-a10);--ic-radio-bg-disabled: var(--ic-surface-primary-a20);--ic-radio-border-disabled: #dcdcdc;--ic-select-label-color: #666;--ic-select-label-active-color: var(--ic-clr-primary-a10);--ic-select-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-select-bg: var(--ic-surface-primary-a0);--ic-select-border: #dcdcdc;--ic-select-border-focus: var(--ic-clr-primary-a10);--ic-select-border-error: var(--ic-clr-red-a10);--ic-select-disabled-bg: var(--ic-surface-primary-a20);--ic-select-disabled-border: #dcdcdc;--ic-select-disabled-color: gray;--ic-select-input-color: inherit;--ic-select-chip-bg: #e1f1ff;--ic-select-chip-color: cornflowerblue;--ic-select-error-color: var(--ic-clr-red-a10);--ic-select-dropdown-bg: var(--ic-surface-primary-a0);--ic-select-dropdown-shadow: 0px 3px 10px 0px rgba(0, 0, 0, .09);--ic-select-search-border: #ccc;--ic-select-item-color: var(--ic-clr-primary-a10);--ic-select-item-hover-bg: linear-gradient(90deg, #06113c 0%, #004aa0 100%);--ic-select-item-hover-color: var(--ic-clr-default);--ic-select-item-hover-text-gray: #95ceff;--ic-select-item-selected-color: var(--ic-clr-primary-a10);--ic-select-item-selected-bg: #d8e3f0;--ic-select-item-circle-color: #059eab;--ic-select-item-circle-bg: var(--ic-surface-primary-a20);--ic-slide-toggle-bg: #ccc;--ic-slide-toggle-active-bg: var(--ic-clr-tonal-a20);--ic-slide-toggle-knob-bg: var(--ic-surface-primary-a0);--ic-tenure-field-label-color: var(--ic-clr-primary-a10);--ic-tenure-field-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-tenure-field-required-star: var(--ic-clr-red-a10);--ic-tenure-field-border: #dcdcdc;--ic-tenure-field-border-focus: #2196f3;--ic-tenure-field-border-error: var(--ic-clr-red-a10);--ic-tenure-field-bg: var(--ic-surface-primary-a0);--ic-tenure-field-disabled-bg: var(--ic-surface-primary-a20);--ic-tenure-field-disabled-border: #dcdcdc;--ic-tenure-field-input-color: inherit;--ic-tenure-field-unit-label-color: #010101;--ic-tenure-field-separator-color: var(--ic-clr-gray-a30);--ic-tenure-field-error-color: var(--ic-clr-red-a10);--ic-textarea-label-color: #666;--ic-textarea-label-active-color: var(--ic-clr-primary-a10);--ic-textarea-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-textarea-required-star: var(--ic-clr-red-a10);--ic-textarea-border: #dcdcdc;--ic-textarea-border-focus: var(--ic-clr-primary-a10);--ic-textarea-border-error: var(--ic-clr-red-a10);--ic-textarea-bg: var(--ic-surface-primary-a0);--ic-textarea-disabled-bg: var(--ic-surface-primary-a20);--ic-textarea-disabled-border: #dcdcdc;--ic-textarea-disabled-color: gray;--ic-textarea-input-color: inherit;--ic-textarea-error-color: var(--ic-clr-red-a10);--ic-footer-bg: var(--ic-surface-primary-a0);--ic-footer-logo-color: var(--ic-clr-primary-a10);--ic-footer-desc-color: var(--ic-clr-primary-a10);--ic-footer-heading-color: #212353;--ic-footer-link-color: var(--ic-clr-primary-a10);--ic-footer-link-hover-color: var(--ic-clr-tonal-a0);--ic-footer-divider-color: #52515187;--ic-accordion-panel-bg: var(--ic-surface-primary-a0);--ic-accordion-panel-shadow: 0px 6.12px 30.62px 0px rgba(0, 0, 0, .11);--ic-accordion-header-color: var(--ic-clr-primary-a10);--ic-accordion-header-accent: var(--ic-clr-tonal-a0);--ic-accordion-list-color: #909090;--ic-accordion-list-hover: var(--ic-clr-inverted)}.theme-dark{--ic-clr-default: #000000;--ic-clr-inverted: #ffffff;--ic-clr-primary-a0: #91baff;--ic-clr-primary-a10: #5d9bff;--ic-clr-primary-a20: #367ee6;--ic-clr-primary-a30: #204f9c;--ic-clr-tonal-a0: #3a7dff;--ic-clr-tonal-a10: #2a5fd6;--ic-clr-tonal-a20: #183a6a;--ic-clr-tonal-a30: #121a2a;--ic-clr-tonal-a40: #0d1320;--ic-clr-green-a0: #3ad29f;--ic-clr-red-a0: #ff6b7d;--ic-clr-red-a10: #ff3d3d;--ic-clr-red-a20: #b20000;--ic-clr-gray-a0: #c7d1dd;--ic-clr-gray-a10: #8a95a5;--ic-clr-gray-a20: #67758a;--ic-clr-gray-a30: #525151;--ic-clr-yellow-a0: #ffb83a;--ic-surface-primary-a0: #121a2a;--ic-surface-primary-a10: #1d2433;--ic-surface-primary-a20: #2a3446;--ic-surface-primary-a30: #232b3a;--ic-surface-primary-a40: #1a202c;--ic-surface-tonal-a0: #1a2333;--ic-surface-tonal-a10: #232b3a;--ic-surface-tonal-a20: #2a3446;--ic-surface-tonal-a30: #183a6a;--ic-surface-tonal-a40: #0d1320;--ic-surface-tonal-a50: #06080e;background:var(--ic-app-bg);--ic-app-bg: var(--ic-surface-primary-a0);--ic-card-bg: var(--ic-surface-primary-a10);--ic-card-bg-accent: #252d40;--ic-text-white: var(--ic-clr-default);--ic-text-black: var(--ic-clr-inverted);--ic-text-theme: var(--ic-clr-primary-a10);--ic-gray-accent: var(--ic-surface-primary-a20);--ic-text-gray: var(--ic-clr-gray-a0);--ic-text-gray-dark: var(--ic-clr-gray-a10);--ic-text-gray-light: var(--ic-clr-gray-a20);--ic-text-red: var(--ic-clr-red-a0);--ic-text-green: var(--ic-clr-green-a0);--ic-primary-font-family: \"Benton Sans\", sans-serif;--ic-secondary-font-family: \"Poppins\", sans-serif;--ic-btn-filled-bg: linear-gradient(90deg, var(--ic-clr-tonal-a0) 0%, var(--ic-clr-tonal-a10) 100%);--ic-btn-filled-color: #ffffff;--ic-btn-filled-warning-bg: var(--ic-clr-yellow-a0);--ic-btn-filled-danger-bg: var(--ic-clr-red-a0);--ic-btn-filled-neutral-bg: var(--ic-surface-primary-a20);--ic-btn-filled-blue-bg: var(--ic-clr-tonal-a0);--ic-btn-filled-basic-bg: var(--ic-surface-primary-a10);--ic-btn-filled-success-bg: var(--ic-clr-green-a0);--ic-btn-outlined-bg: transparent;--ic-btn-outlined-color: var(--ic-clr-primary-a10);--ic-btn-outlined-border: var(--ic-clr-primary-a10);--ic-btn-outlined-hover-bg: rgba(93, 155, 255, .08);--ic-btn-outlined-warning: var(--ic-clr-yellow-a0);--ic-btn-outlined-danger: var(--ic-clr-red-a0);--ic-btn-outlined-neutral: var(--ic-clr-gray-a0);--ic-btn-outlined-basic: #f5f7fa;--ic-btn-outlined-success: var(--ic-clr-green-a0);--ic-btn-outlined-transparent-bg: transparent;--ic-btn-outlined-transparent-color: var(--ic-clr-primary-a10);--ic-btn-outlined-transparent-border: var(--ic-clr-primary-a10);--ic-btn-outlined-transparent-hover-bg: rgba(93, 155, 255, .1);--ic-btn-outlined-transparent-hover-color: var(--ic-clr-primary-a10);--ic-btn-status-border: var(--ic-surface-primary-a20);--ic-btn-status-color: var(--ic-clr-primary-a10);--ic-btn-status-warning: var(--ic-clr-yellow-a0);--ic-btn-status-warning-bg: rgba(255, 184, 58, .1);--ic-btn-status-danger: var(--ic-clr-red-a0);--ic-btn-status-danger-bg: rgba(255, 107, 125, .1);--ic-btn-status-neutral: var(--ic-clr-gray-a0);--ic-btn-status-neutral-bg: rgba(199, 209, 221, .1);--ic-btn-status-basic: #f5f7fa;--ic-btn-status-basic-bg: rgba(245, 247, 250, .1);--ic-btn-status-success: var(--ic-clr-green-a0);--ic-btn-status-success-bg: rgba(58, 210, 159, .1);--ic-btn-status-hover-bg: rgba(93, 155, 255, .1);--ic-btn-ghost-bg: var(--ic-surface-primary-a20);--ic-btn-ghost-color: var(--ic-clr-primary-a10);--ic-btn-ghost-shadow: 0px 3px 10px rgba(0, 0, 0, .15);--ic-btn-ghost-warning: var(--ic-clr-yellow-a0);--ic-btn-ghost-danger: var(--ic-clr-red-a0);--ic-btn-ghost-neutral: var(--ic-clr-gray-a0);--ic-btn-ghost-basic: #f5f7fa;--ic-btn-ghost-success: var(--ic-clr-green-a0);--ic-btn-ghost-disabled-color: var(--ic-clr-gray-a20);--ic-btn-disabled-bg: var(--ic-surface-primary-a20);--ic-btn-disabled-color: var(--ic-clr-gray-a20);--ic-btn-toggle-group-bg: var(--ic-surface-primary-a10);--ic-btn-toggle-group-border: var(--ic-surface-primary-a20);--ic-btn-toggle-group-shadow: 0 3px 10px rgba(0, 0, 0, .2);--ic-card-shadow: 0px 3px 9px rgba(0, 0, 0, .2);--ic-checkbox-filled-bg: var(--ic-clr-primary-a10);--ic-checkbox-filled-border: var(--ic-clr-primary-a10);--ic-checkbox-checkmark-color: #ffffff;--ic-checkbox-outlined-bg: transparent;--ic-checkbox-outlined-border: var(--ic-clr-primary-a10);--ic-checkbox-checkmark-outlined-color: var(--ic-clr-primary-a10);--ic-checkbox-border: var(--ic-surface-primary-a20);--ic-checkbox-bg: var(--ic-surface-primary-a10);--ic-checkbox-primary-bg: var(--ic-clr-primary-a10);--ic-checkbox-primary-border: var(--ic-clr-primary-a10);--ic-checkbox-accent-bg: var(--ic-clr-red-a0);--ic-checkbox-accent-border: var(--ic-clr-red-a0);--ic-checkbox-warn-bg: var(--ic-clr-red-a0);--ic-checkbox-warn-border: var(--ic-clr-red-a0);--ic-checkbox-label-color: #f5f7fa;--ic-date-picker-bg: var(--ic-surface-primary-a10);--ic-date-picker-border: var(--ic-surface-primary-a20);--ic-date-picker-border-focus: var(--ic-clr-primary-a10);--ic-date-picker-border-error: var(--ic-clr-red-a0);--ic-date-picker-label-color: var(--ic-clr-gray-a0);--ic-date-picker-label-active-color: var(--ic-clr-primary-a10);--ic-date-picker-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 53%, #000000 );--ic-date-picker-required-star: var(--ic-clr-red-a0);--ic-date-picker-disabled-bg: var(--ic-surface-primary-a20);--ic-date-picker-disabled-border: var(--ic-surface-primary-a20);--ic-date-picker-disabled-color: var(--ic-clr-gray-a20);--ic-date-picker-input-color: #f5f7fa;--ic-date-picker-calendar-toggle-color: #f5f7fa;--ic-date-picker-calendar-bg: var(--ic-surface-primary-a10);--ic-date-picker-calendar-shadow: 0 3px 15px rgba(0, 0, 0, .2);--ic-date-picker-calendar-header-bg: var(--ic-surface-primary-a0);--ic-date-picker-calendar-header-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-header-hover-bg: var(--ic-surface-primary-a10);--ic-date-picker-calendar-nav-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-nav-hover-bg: var(--ic-surface-primary-a10);--ic-date-picker-calendar-date-color: #f5f7fa;--ic-date-picker-calendar-date-disabled-color: var(--ic-clr-gray-a20);--ic-date-picker-calendar-date-selected-bg: var(--ic-clr-primary-a10);--ic-date-picker-calendar-date-selected-color: #ffffff;--ic-date-picker-calendar-date-hover-bg: var(--ic-surface-primary-a20);--ic-date-picker-calendar-selector-border: var(--ic-surface-primary-a20);--ic-date-picker-calendar-selector-hover-bg: var(--ic-surface-primary-a10);--ic-date-picker-error-color: var(--ic-clr-red-a0);--ic-form-field-bg: var(--ic-surface-primary-a10);--ic-form-field-border: var(--ic-surface-primary-a20);--ic-form-field-border-focus: var(--ic-clr-primary-a10);--ic-form-field-border-error: var(--ic-clr-red-a0);--ic-form-field-disabled-bg: var(--ic-surface-primary-a20);--ic-form-field-disabled-border: var(--ic-surface-primary-a20);--ic-form-field-disabled-color: var(--ic-clr-gray-a20);--ic-form-field-label-color: var(--ic-clr-gray-a0);--ic-form-field-label-active-color: var(--ic-clr-primary-a10);--ic-form-field-label-disabled-color: var(--ic-clr-gray-a20);--ic-form-field-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 53%, #000000 );--ic-form-field-input-color: #f5f7fa;--ic-form-field-input-disabled-color: var(--ic-clr-gray-a20);--ic-form-field-prefix-color: var(--ic-clr-primary-a10);--ic-form-field-add-bg: var(--ic-surface-primary-a20);--ic-form-field-add-color: var(--ic-clr-primary-a10);--ic-form-field-add-hover-bg: var(--ic-surface-primary-a10);--ic-form-field-add-disabled-bg: var(--ic-surface-primary-a20);--ic-form-field-add-disabled-color: var(--ic-clr-gray-a20);--ic-form-field-error-color: var(--ic-clr-red-a0);--ic-form-field-error-counter-bg: rgba(255, 107, 125, .1);--ic-form-field-error-counter-color: var(--ic-clr-red-a0);--ic-form-field-popover-bg: var(--ic-surface-primary-a10);--ic-form-field-popover-shadow: 0px 0px 10px rgba(255, 107, 125, .3);--ic-form-field-popover-color: var(--ic-clr-red-a0);--ic-mobile-field-bg: var(--ic-surface-primary-a10);--ic-mobile-field-border: var(--ic-surface-primary-a20);--ic-mobile-field-border-focus: var(--ic-clr-primary-a10);--ic-mobile-field-border-error: var(--ic-clr-red-a0);--ic-mobile-field-disabled-bg: var(--ic-surface-primary-a20);--ic-mobile-field-disabled-border: var(--ic-surface-primary-a20);--ic-mobile-field-label-color: var(--ic-clr-gray-a0);--ic-mobile-field-label-active-color: var(--ic-clr-primary-a10);--ic-mobile-field-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 57%, #000000 );--ic-mobile-field-required-star: var(--ic-clr-red-a0);--ic-mobile-field-input-disabled-color: var(--ic-clr-gray-a20);--ic-mobile-field-prefix-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-arrow-color: var(--ic-clr-gray-a20);--ic-mobile-field-dropdown-bg: var(--ic-surface-primary-a10);--ic-mobile-field-dropdown-option-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-option-hover-bg: var(--ic-surface-primary-a20);--ic-mobile-field-dropdown-no-results-color: var(--ic-clr-gray-a20);--ic-mobile-field-separator: var(--ic-surface-primary-a20);--ic-mobile-field-error-color: var(--ic-clr-red-a0);--ic-radio-label-color: var(--ic-clr-gray-a0);--ic-radio-label-checked-color: var(--ic-clr-primary-a10);--ic-radio-label-disabled-color: var(--ic-clr-gray-a20);--ic-radio-border: var(--ic-surface-primary-a20);--ic-radio-bg: var(--ic-surface-primary-a10);--ic-radio-border-checked: var(--ic-clr-primary-a10);--ic-radio-bg-checked: var(--ic-clr-primary-a10);--ic-radio-outline-checked: var(--ic-clr-primary-a10);--ic-radio-border-hover: var(--ic-clr-primary-a10);--ic-radio-bg-disabled: var(--ic-surface-primary-a20);--ic-radio-border-disabled: var(--ic-surface-primary-a20);--ic-select-label-color: var(--ic-clr-gray-a0);--ic-select-label-active-color: var(--ic-clr-primary-a10);--ic-select-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 57%, #000000 );--ic-select-bg: var(--ic-surface-primary-a10);--ic-select-border: var(--ic-surface-primary-a20);--ic-select-border-focus: var(--ic-clr-primary-a10);--ic-select-border-error: var(--ic-clr-red-a0);--ic-select-disabled-bg: var(--ic-surface-primary-a20);--ic-select-disabled-border: var(--ic-surface-primary-a20);--ic-select-disabled-color: var(--ic-clr-gray-a20);--ic-select-input-color: #f5f7fa;--ic-select-chip-bg: var(--ic-surface-primary-a20);--ic-select-chip-color: var(--ic-clr-primary-a10);--ic-select-error-color: var(--ic-clr-red-a0);--ic-select-dropdown-bg: var(--ic-surface-primary-a10);--ic-select-dropdown-shadow: 0px 3px 10px rgba(0, 0, 0, .2);--ic-select-search-border: var(--ic-surface-primary-a20);--ic-select-item-color: var(--ic-clr-primary-a10);--ic-select-item-hover-bg: var(--ic-surface-primary-a20);--ic-select-item-hover-color: #ffffff;--ic-select-item-hover-text-gray: var(--ic-clr-gray-a0);--ic-select-item-selected-color: var(--ic-clr-primary-a10);--ic-select-item-selected-bg: var(--ic-surface-primary-a0);--ic-select-item-circle-color: var(--ic-clr-primary-a10);--ic-select-item-circle-bg: var(--ic-surface-primary-a10);--ic-slide-toggle-bg: var(--ic-surface-primary-a20);--ic-slide-toggle-active-bg: var(--ic-clr-primary-a10);--ic-slide-toggle-knob-bg: #ffffff;--ic-tenure-field-label-color: var(--ic-clr-primary-a10);--ic-tenure-field-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 57%, #000000 );--ic-tenure-field-required-star: var(--ic-clr-red-a0);--ic-tenure-field-border: var(--ic-surface-primary-a20);--ic-tenure-field-border-focus: var(--ic-clr-primary-a10);--ic-tenure-field-border-error: var(--ic-clr-red-a0);--ic-tenure-field-bg: var(--ic-surface-primary-a10);--ic-tenure-field-disabled-bg: var(--ic-surface-primary-a20);--ic-tenure-field-disabled-border: var(--ic-surface-primary-a20);--ic-tenure-field-input-color: #f5f7fa;--ic-tenure-field-unit-label-color: var(--ic-clr-gray-a0);--ic-tenure-field-separator-color: var(--ic-clr-gray-a20);--ic-tenure-field-error-color: var(--ic-clr-red-a0);--ic-textarea-label-color: var(--ic-clr-gray-a0);--ic-textarea-label-active-color: var(--ic-clr-primary-a10);--ic-textarea-label-bg: linear-gradient( 180deg, #000000, var(--ic-surface-primary-a10) 57%, #000000 );--ic-textarea-required-star: var(--ic-clr-red-a0);--ic-textarea-border: var(--ic-surface-primary-a20);--ic-textarea-border-focus: var(--ic-clr-primary-a10);--ic-textarea-border-error: var(--ic-clr-red-a0);--ic-textarea-bg: var(--ic-surface-primary-a10);--ic-textarea-disabled-bg: var(--ic-surface-primary-a20);--ic-textarea-disabled-border: var(--ic-surface-primary-a20);--ic-textarea-disabled-color: var(--ic-clr-gray-a20);--ic-textarea-input-color: #f5f7fa;--ic-textarea-error-color: var(--ic-clr-red-a0);--ic-footer-bg: var(--ic-surface-primary-a10);--ic-footer-logo-color: #ffffff;--ic-footer-desc-color: var(--ic-clr-gray-a0);--ic-footer-heading-color: #ffffff;--ic-footer-link-color: var(--ic-clr-primary-a10);--ic-footer-link-hover-color: #8ab8ff;--ic-footer-divider-color: var(--ic-surface-primary-a20);--ic-accordion-panel-bg: var(--ic-surface-primary-a10);--ic-accordion-panel-shadow: 0px 6.12px 30.62px rgba(0, 0, 0, .2);--ic-accordion-header-color: var(--ic-clr-primary-a10);--ic-accordion-header-accent: var(--ic-clr-gray-a0);--ic-accordion-list-color: var(--ic-clr-gray-a0);--ic-accordion-list-hover: #f5f7fa}.theme-ruby{--ic-clr-default: #ffffff;--ic-clr-inverted: #000000;--ic-clr-primary-a0: #e71b3c;--ic-clr-primary-a10: #b1142f;--ic-clr-primary-a20: #8a1025;--ic-clr-primary-a30: #540a17;--ic-clr-tonal-a0: #ffb3c2;--ic-clr-tonal-a10: #ff809a;--ic-clr-tonal-a20: #ff4d73;--ic-clr-tonal-a30: #e71b3c;--ic-clr-tonal-a40: #b1142f;--ic-clr-green-a0: #17b26a;--ic-clr-red-a0: #ff3d3d;--ic-clr-red-a10: #f04438;--ic-clr-red-a20: #b20000;--ic-clr-gray-a0: #8e8e8e;--ic-clr-gray-a10: #9c9c9c;--ic-clr-gray-a20: #858585;--ic-clr-gray-a30: #707070;--ic-clr-yellow-a0: #f79009;--ic-surface-primary-a0: #ffffff;--ic-surface-primary-a10: #f0f4ff;--ic-surface-primary-a20: #f3f3f3;--ic-surface-primary-a30: #ffe7e8;--ic-surface-primary-a40: #fef3f2;--ic-surface-primary-a50: #999;--ic-surface-tonal-a0: #fff0f3;--ic-surface-tonal-a10: #ffd6de;--ic-surface-tonal-a20: #ffb3c2;--ic-surface-tonal-a30: #ff809a;--ic-surface-tonal-a40: #ff4d73;--ic-surface-tonal-a50: #e71b3c;background:var(--ic-app-bg);--ic-app-bg: var(--ic-surface-primary-a0);--ic-card-bg: var(--ic-surface-primary-a0);--ic-card-bg-accent: #fef3f2;--ic-text-white: var(--ic-clr-default);--ic-text-black: var(--ic-clr-inverted);--ic-text-theme: var(--ic-clr-primary-a0);--ic-gray-accent: var(--ic-surface-primary-a20);--ic-text-gray: var(--ic-clr-gray-a0);--ic-text-gray-dark: var(--ic-clr-gray-a20);--ic-text-gray-light: var(--ic-clr-gray-a10);--ic-text-red: var(--ic-clr-tonal-a0);--ic-text-green: var(--ic-clr-green-a0);--ic-primary-font-family: \"Bliss Pro\", sans-serif;--ic-secondary-font-family: \"Inter\", sans-serif;--ic-btn-filled-bg: var(--ic-clr-primary-a0);--ic-btn-filled-color: var(--ic-clr-default);--ic-btn-filled-warning-bg: var(--ic-clr-yellow-a0);--ic-btn-filled-danger-bg: var(--ic-clr-red-a10);--ic-btn-filled-neutral-bg: var(--ic-clr-primary-a10);--ic-btn-filled-blue-bg: var(--ic-clr-primary-a0);--ic-btn-filled-basic-bg: #000000;--ic-btn-filled-success-bg: var(--ic-clr-green-a0);--ic-btn-outlined-bg: var(--ic-surface-primary-a0);--ic-btn-outlined-color: var(--ic-clr-primary-a10);--ic-btn-outlined-border: var(--ic-clr-primary-a10);--ic-btn-outlined-hover-bg: #007fff14;--ic-btn-outlined-warning: var(--ic-clr-yellow-a0);--ic-btn-outlined-danger: var(--ic-clr-red-a10);--ic-btn-outlined-neutral: var(--ic-clr-primary-a10);--ic-btn-outlined-basic: #000000;--ic-btn-outlined-success: var(--ic-clr-green-a0);--ic-btn-outlined-transparent-bg: transparent;--ic-btn-outlined-transparent-color: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-border: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-hover-bg: var(--ic-surface-primary-a0);--ic-btn-outlined-transparent-hover-color: var(--ic-clr-primary-a0);--ic-btn-status-border: var(--ic-clr-primary-a10);--ic-btn-status-color: var(--ic-clr-primary-a10);--ic-btn-status-warning: var(--ic-clr-yellow-a0);--ic-btn-status-warning-bg: #fff7e6;--ic-btn-status-danger: var(--ic-clr-red-a10);--ic-btn-status-danger-bg: #ffe7e8;--ic-btn-status-neutral: var(--ic-clr-primary-a10);--ic-btn-status-neutral-bg: #e3e9fe;--ic-btn-status-basic: #000000;--ic-btn-status-basic-bg: var(--ic-surface-primary-a0);--ic-btn-status-success: var(--ic-clr-green-a0);--ic-btn-status-success-bg: #ddf8f1;--ic-btn-status-hover-bg: #007fff14;--ic-btn-ghost-bg: var(--ic-surface-primary-a0);--ic-btn-ghost-color: var(--ic-clr-primary-a10);--ic-btn-ghost-shadow: 0px 3px 10px 0px #00000017;--ic-btn-ghost-warning: var(--ic-clr-yellow-a0);--ic-btn-ghost-danger: var(--ic-clr-red-a10);--ic-btn-ghost-neutral: var(--ic-clr-primary-a10);--ic-btn-ghost-basic: #000000;--ic-btn-ghost-success: var(--ic-clr-green-a0);--ic-btn-ghost-disabled-color: var(--ic-clr-default);--ic-btn-disabled-bg: #cecece;--ic-btn-spinner-color: var(--ic-surface-primary-a0);--ic-btn-toggle-group-bg: var(--ic-surface-primary-a0);--ic-btn-toggle-group-border: #e0e0e0;--ic-btn-toggle-group-shadow: 0 3px 10px #00000017;--ic-card-shadow: 0px 3px 9px 0px rgba(0, 0, 0, .11);--ic-checkbox-filled-bg: var(--ic-clr-primary-a0);--ic-checkbox-filled-border: var(--ic-clr-primary-a0);--ic-checkbox-checkmark-color: var(--ic-clr-default);--ic-checkbox-outlined-bg: var(--ic-surface-primary-a0);--ic-checkbox-outlined-border: var(--ic-clr-primary-a0);--ic-checkbox-checkmark-outlined-color: var(--ic-clr-primary-a0);--ic-checkbox-border: #70707057;--ic-checkbox-bg: var(--ic-surface-primary-a0);--ic-checkbox-primary-bg: var(--ic-clr-primary-a0);--ic-checkbox-primary-border: var(--ic-clr-primary-a0);--ic-checkbox-accent-bg: #ff4081;--ic-checkbox-accent-border: #ff4081;--ic-checkbox-warn-bg: #f44336;--ic-checkbox-warn-border: #f44336;--ic-checkbox-label-color: var(--ic-clr-primary-a0);--ic-date-picker-bg: var(--ic-surface-primary-a0);--ic-date-picker-border: #dcdcdc;--ic-date-picker-border-focus: var(--ic-clr-primary-a10);--ic-date-picker-border-error: var(--ic-clr-red-a10);--ic-date-picker-label-color: #666;--ic-date-picker-label-active-color: var(--ic-clr-primary-a10);--ic-date-picker-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-date-picker-required-star: #ff0000;--ic-date-picker-disabled-bg: var(--ic-surface-primary-a20);--ic-date-picker-disabled-border: #dcdcdc;--ic-date-picker-disabled-color: gray;--ic-date-picker-input-color: inherit;--ic-date-picker-calendar-toggle-color: inherit;--ic-date-picker-calendar-bg: var(--ic-surface-primary-a0);--ic-date-picker-calendar-shadow: 0 3px 15px rgba(0, 0, 0, .15);--ic-date-picker-calendar-header-bg: #e6efff;--ic-date-picker-calendar-header-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-header-hover-bg: #ededed;--ic-date-picker-calendar-nav-color: var(--ic-clr-primary-a10);--ic-date-picker-calendar-nav-hover-bg: #f0f0f0;--ic-date-picker-calendar-date-color: inherit;--ic-date-picker-calendar-date-disabled-color: #aaa;--ic-date-picker-calendar-date-selected-bg: #fef3f2;--ic-date-picker-calendar-date-selected-color: var(--ic-clr-default);--ic-date-picker-calendar-date-hover-bg: #f0f0f0;--ic-date-picker-calendar-selector-border: #ccc;--ic-date-picker-calendar-selector-hover-bg: #f0f0f0;--ic-date-picker-error-color: var(--ic-clr-red-a10);--ic-form-field-bg: var(--ic-surface-primary-a0);--ic-form-field-border: #dcdcdc;--ic-form-field-border-focus: var(--ic-clr-primary-a10);--ic-form-field-border-error: var(--ic-clr-red-a10);--ic-form-field-disabled-bg: var(--ic-surface-primary-a20);--ic-form-field-disabled-border: #dcdcdc;--ic-form-field-disabled-color: gray;--ic-form-field-label-color: #666;--ic-form-field-label-active-color: var(--ic-clr-primary-a10);--ic-form-field-label-disabled-color: #999;--ic-form-field-label-bg: linear-gradient(180deg, #0000ff00 30%, var(--ic-surface-primary-a0) 53%, #00800000 80%);--ic-form-field-input-color: inherit;--ic-form-field-input-disabled-color: #999;--ic-form-field-prefix-color: var(--ic-clr-primary-a10);--ic-form-field-add-bg: #e9ecf5;--ic-form-field-add-color: var(--ic-clr-primary-a10);--ic-form-field-add-hover-bg: #d7e3fb;--ic-form-field-add-disabled-bg: #dcdcdc;--ic-form-field-add-disabled-color: #b1b1b1;--ic-form-field-error-color: var(--ic-clr-red-a10);--ic-form-field-error-counter-bg: rgba(255, 0, 0, .1);--ic-form-field-error-counter-color: var(--ic-clr-red-a10);--ic-form-field-popover-bg: var(--ic-surface-primary-a0);--ic-form-field-popover-shadow: 0px 0px 10px rgba(255, 0, 0, .3);--ic-form-field-popover-color: var(--ic-clr-red-a10);--ic-mobile-field-bg: var(--ic-surface-primary-a0);--ic-mobile-field-border: #dcdcdc;--ic-mobile-field-border-focus: var(--ic-clr-primary-a10);--ic-mobile-field-border-error: var(--ic-clr-red-a10);--ic-mobile-field-disabled-bg: var(--ic-surface-primary-a20);--ic-mobile-field-disabled-border: #dcdcdc;--ic-mobile-field-label-color: #666;--ic-mobile-field-label-active-color: var(--ic-clr-primary-a10);--ic-mobile-field-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-mobile-field-required-star: #ff0000;--ic-mobile-field-input-disabled-color: #999;--ic-mobile-field-prefix-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-arrow-color: #b3bac8;--ic-mobile-field-dropdown-bg: var(--ic-surface-primary-a0);--ic-mobile-field-dropdown-option-color: var(--ic-clr-primary-a10);--ic-mobile-field-dropdown-option-hover-bg: #f5f5f5;--ic-mobile-field-dropdown-no-results-color: #999;--ic-mobile-field-separator: #e8e8e8;--ic-mobile-field-error-color: var(--ic-clr-red-a10);--ic-radio-label-color: var(--ic-clr-gray-a30);--ic-radio-label-checked-color: var(--ic-clr-primary-a10);--ic-radio-label-disabled-color: #b1b1b1;--ic-radio-border: var(--ic-clr-default);--ic-radio-bg: var(--ic-surface-primary-a0);--ic-radio-border-checked: var(--ic-clr-default);--ic-radio-bg-checked: var(--ic-clr-primary-a10);--ic-radio-outline-checked: var(--ic-clr-primary-a10);--ic-radio-border-hover: var(--ic-clr-primary-a10);--ic-radio-bg-disabled: var(--ic-surface-primary-a20);--ic-radio-border-disabled: #dcdcdc;--ic-select-label-color: #666;--ic-select-label-active-color: var(--ic-clr-primary-a10);--ic-select-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-select-bg: var(--ic-surface-primary-a0);--ic-select-border: #dcdcdc;--ic-select-border-focus: var(--ic-clr-primary-a10);--ic-select-border-error: var(--ic-clr-red-a10);--ic-select-disabled-bg: var(--ic-surface-primary-a20);--ic-select-disabled-border: #dcdcdc;--ic-select-disabled-color: gray;--ic-select-input-color: inherit;--ic-select-chip-bg: #e1f1ff;--ic-select-chip-color: var(--ic-clr-primary-a0);--ic-select-error-color: var(--ic-clr-red-a10);--ic-select-dropdown-bg: var(--ic-surface-primary-a0);--ic-select-dropdown-shadow: 0px 3px 10px 0px rgba(0, 0, 0, .09);--ic-select-search-border: #ccc;--ic-select-item-color: var(--ic-clr-primary-a10);--ic-select-item-hover-bg: var(--ic-clr-primary-a0);--ic-select-item-hover-color: var(--ic-clr-default);--ic-select-item-hover-text-gray: #95ceff;--ic-select-item-selected-color: var(--ic-clr-default);--ic-select-item-selected-bg: var(--ic-clr-primary-a0);--ic-select-item-circle-color: var(--ic-clr-primary-a0);--ic-select-item-circle-bg: var(--ic-surface-primary-a20);--ic-slide-toggle-bg: #ccc;--ic-slide-toggle-active-bg: var(--ic-clr-primary-a0);--ic-slide-toggle-knob-bg: var(--ic-surface-primary-a0);--ic-tenure-field-label-color: var(--ic-clr-primary-a10);--ic-tenure-field-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-tenure-field-required-star: #ff0000;--ic-tenure-field-border: #dcdcdc;--ic-tenure-field-border-focus: #fef3f2;--ic-tenure-field-border-error: var(--ic-clr-red-a10);--ic-tenure-field-bg: var(--ic-surface-primary-a0);--ic-tenure-field-disabled-bg: var(--ic-surface-primary-a20);--ic-tenure-field-disabled-border: #dcdcdc;--ic-tenure-field-input-color: inherit;--ic-tenure-field-unit-label-color: #010101;--ic-tenure-field-separator-color: var(--ic-clr-gray-a30);--ic-tenure-field-error-color: var(--ic-clr-red-a10);--ic-textarea-label-color: #666;--ic-textarea-label-active-color: var(--ic-clr-primary-a10);--ic-textarea-label-bg: linear-gradient(180deg, #00f0, var(--ic-surface-primary-a0) 57%, #00800000);--ic-textarea-required-star: #ff0000;--ic-textarea-border: #dcdcdc;--ic-textarea-border-focus: var(--ic-clr-primary-a10);--ic-textarea-border-error: var(--ic-clr-red-a10);--ic-textarea-bg: var(--ic-surface-primary-a0);--ic-textarea-disabled-bg: var(--ic-surface-primary-a20);--ic-textarea-disabled-border: #dcdcdc;--ic-textarea-disabled-color: gray;--ic-textarea-input-color: inherit;--ic-textarea-error-color: var(--ic-clr-red-a10);--ic-footer-bg: var(--ic-surface-primary-a0);--ic-footer-logo-color: var(--ic-clr-primary-a10);--ic-footer-desc-color: var(--ic-clr-primary-a10);--ic-footer-heading-color: #212353;--ic-footer-link-color: var(--ic-clr-primary-a10);--ic-footer-link-hover-color: var(--ic-clr-primary-a0);--ic-footer-divider-color: #52515187;--ic-accordion-panel-bg: var(--ic-surface-primary-a0);--ic-accordion-panel-shadow: 0px 6.12px 30.62px 0px rgba(0, 0, 0, .11);--ic-accordion-header-color: var(--ic-clr-primary-a10);--ic-accordion-header-accent: var(--ic-clr-primary-a0);--ic-accordion-list-color: #909090;--ic-accordion-list-hover: #000000}.ic-select-field{position:relative;width:100%;margin:8px 0}.ic-select-field.disabled{pointer-events:none}.ic-select-field label{position:absolute;left:16px;font-size:14px;transition:.3s;color:var(--ic-select-label-color, #666);font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);transform:translateY(9px)!important;z-index:2}.ic-select-field label.floated{left:12px;transform:translateY(-8px)!important;font-size:12px;color:var(--ic-select-label-active-color, #0033a1);background:var(--ic-select-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0), #fff 57%, rgba(0, 128, 0, 0)));padding:0 4px;z-index:1}.ic-select-field .dropdown{position:relative}.ic-select-field .dropdown .dropdown-header-div{height:40px;display:flex;justify-content:space-between;align-items:center;padding:8px 16px;font-size:14px!important;font-weight:500;font-family:var(--ic-primary-font-family),sans-serif;outline:none;border:2px solid var(--ic-select-border, #dcdcdc);border-radius:8px;background:var(--ic-select-bg, #ffffff);box-shadow:var(--ic-select-box-shadow, none);transition:border-color .3s ease,box-shadow .3s ease;color:var(--ic-select-input-color, inherit);cursor:pointer}.ic-select-field .dropdown .dropdown-header-div.dropdown-open{border-color:var(--ic-select-border-focus, #0033a1)}.ic-select-field .dropdown .dropdown-header-div.dropdown-error{border-color:var(--ic-select-border-error, red)}.ic-select-field .dropdown .dropdown-header-div.dropdown-disabled{background-color:var(--ic-select-disabled-bg, #f3f3f3)!important;border-color:var(--ic-select-disabled-border, #dcdcdc)!important;box-shadow:none!important;color:var(--ic-select-disabled-color, gray)!important;pointer-events:none;cursor:not-allowed!important}.ic-select-field .dropdown .dropdown-header-div .chip-container{display:flex;gap:2px}.ic-select-field .dropdown .dropdown-header-div .chip-container .chip{background:var(--ic-select-chip-bg, #e1f1ff);padding:1px 8px;color:var(--ic-select-chip-color, cornflowerblue);border-radius:8px}.ic-select-field .dropdown .dropdown-header-div .label-display-container{text-overflow:ellipsis;white-space:nowrap;overflow:hidden;width:80%}.ic-select-field .dropdown .dropdown-header-div .vl{height:90%;width:2px;background-color:#dcdcdc;margin:0 3px;border-radius:2px}.ic-select-field .error-message{color:var(--ic-select-error-color, red);font-size:12px;margin:0 16px}.dropdown-menu-overlay{background:var(--ic-select-dropdown-bg, #fff);border-bottom-left-radius:8px;border-bottom-right-radius:8px;box-shadow:var(--ic-select-dropdown-shadow, 0px 3px 10px 0px rgba(0, 0, 0, .09));width:100%}.dropdown-menu-overlay .search-input{padding:8px;border:1px solid var(--ic-select-search-border, #ccc);border-radius:8px;width:calc(100% - 5px);display:flex;margin:2px auto;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.dropdown-menu-overlay .dropdown-list{list-style:none;padding:0;margin:1%;max-height:200px;overflow:auto}.dropdown-menu-overlay .dropdown-list .dropdown-item{display:flex;align-items:center;gap:2px;padding:8px;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);color:var(--ic-select-item-color, #0033a1);text-overflow:ellipsis;white-space:nowrap;overflow:auto;scrollbar-width:none;cursor:pointer;transition:color .12s linear}.dropdown-menu-overlay .dropdown-list .dropdown-item .profileImage{border-radius:50%;box-shadow:0 3px 15px #0000000a;border:2px solid #ffffff;opacity:1;text-align:center;width:40px;height:40px;margin-right:10px;object-fit:cover}.dropdown-menu-overlay .dropdown-list .dropdown-item .circle{color:var(--ic-select-item-circle-color, #059eab);background:var(--ic-select-item-circle-bg, #f3f3f3);font-size:14px;border-radius:50%;box-shadow:0 3px 15px #0000000a;border:2px solid #ffffff;opacity:1;text-align:center;width:35px;height:35px;margin-right:10px;display:flex;justify-content:center;align-items:center}.dropdown-menu-overlay .dropdown-list .dropdown-item:hover{background:var(--ic-select-item-hover-bg, linear-gradient(90deg, #06113c 0%, #004aa0 100%));color:var(--ic-select-item-hover-color, #fff);border-radius:4px}.dropdown-menu-overlay .dropdown-list .dropdown-item:hover .text-gray{color:var(--ic-select-item-hover-text-gray, #95ceff)!important;font-weight:300!important}.dropdown-menu-overlay .dropdown-list .dropdown-item.selected{color:var(--ic-select-item-selected-color, #0033a1);background:var(--ic-select-item-selected-bg, #d8e3f0);min-width:100%;font-size:inherit;font-weight:inherit;border-radius:4px;margin:2px 0;height:auto}.cdk-overlay-transparent-backdrop{background-color:transparent!important}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.Overlay }, { type: i0.ViewContainerRef }, { type: i1$2.ScrollStrategyOptions }]; }, propDecorators: { label: [{
                type: Input
            }], control: [{
                type: Input
            }], options: [{
                type: Input
            }], bindLabelKey: [{
                type: Input
            }], bindValueKey: [{
                type: Input
            }], specificDisplayAttribute: [{
                type: Input
            }], specificBracketAttribute: [{
                type: Input
            }], selectionType: [{
                type: Input
            }], customError: [{
                type: Input
            }], displayLabel: [{
                type: Input
            }], showProfile: [{
                type: Input
            }], skipLabel: [{
                type: Input
            }], showFlag: [{
                type: Input
            }], readonly: [{
                type: Input
            }], disabled: [{
                type: Input
            }], customClass: [{
                type: Input
            }], hideSearch: [{
                type: Input
            }], searchInField: [{
                type: Input
            }], selectionChange: [{
                type: Output
            }], openedChange: [{
                type: Output
            }], dropdownMenu: [{
                type: ViewChild,
                args: ['dropdownMenu']
            }], dropdownHeader: [{
                type: ViewChild,
                args: ['dropdownHeader']
            }], dropdownMenuTemplate: [{
                type: ViewChild,
                args: ['dropdownMenuTemplate']
            }], closeDropdownOnClickOutside: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class MobileFieldComponent {
    constructor(injector) {
        this.injector = injector;
        this.label = '';
        this.placeholder = '';
        this.id = '';
        this.disabled = false;
        this.prefixIcon = '';
        this.isdCode = [];
        this.isdControl = new FormControl('');
        this.minLength = 10; // Default to 10 digits
        this.maxLength = 10; // Default to 10 digits
        this.readonly = false;
        this.suffixButton = '';
        this.customError = '';
        this.onInputChangeOutput = new EventEmitter();
        this.onSelectionChangeOutput = new EventEmitter();
        this.onSuffixClick = new EventEmitter();
        this.innerValue = '';
        this.isRequiredValidator = Validators.required;
        this.isIsdDropdownOpen = false;
        this.isdSearchTerm = '';
        this.filteredIsdCodes = [];
        this.selectedIsd = null;
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    ngOnInit() {
        this.ngControl = this.injector.get(NgControl, null);
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
            setTimeout(() => {
                const initial = this.isdControl.value;
                if (initial) {
                    this.selectedIsd =
                        this.isdCode.find(item => item.countryTelIsdCode === initial) ||
                            null;
                }
                this.validateIsdPresence(); // Initial validation
            });
        }
        this.filteredIsdCodes = [...this.isdCode];
        this.isdControl.valueChanges.subscribe(val => {
            this.selectedIsd =
                this.isdCode.find(item => item.countryTelIsdCode === val) || null;
            if (this.selectedIsd && this.selectedIsd.mobileLength) {
                this.minLength = this.selectedIsd.mobileLength;
                this.maxLength = this.selectedIsd.mobileLength;
                this.control.setValidators([
                    Validators.required,
                    Validators.minLength(this.minLength),
                    Validators.maxLength(this.maxLength)
                ]);
                this.control.updateValueAndValidity();
            }
            this.validateIsdPresence();
        });
        this.control?.valueChanges.subscribe(() => {
            this.validateIsdPresence();
        });
    }
    ngOnChanges(changes) {
        if (changes['isdCode'] || changes['isdControl']) {
            const val = this.isdControl.value;
            if (val) {
                this.selectedIsd =
                    this.isdCode.find(item => item.countryTelIsdCode === val) || null;
                // Dynamically set minLength and maxLength if selectedIsd is present
                if (this.selectedIsd && this.selectedIsd.mobileLength) {
                    this.minLength = this.selectedIsd.mobileLength;
                    this.maxLength = this.selectedIsd.mobileLength;
                    // Update validators on the mobile number control
                    this.control.setValidators([
                        Validators.required,
                        Validators.minLength(this.minLength),
                        Validators.maxLength(this.maxLength)
                    ]);
                    this.control.updateValueAndValidity();
                }
            }
        }
    }
    isFieldRequired() {
        try {
            if (!this.control || !this.control.validator)
                return false;
            const validator = this.control.validator({});
            return validator ? validator['required'] : false;
        }
        catch {
            return false;
        }
    }
    validateIsdPresence() {
        if (!this.control)
            return;
        const isRequired = this.control.hasValidator(Validators.required);
        const isdEmpty = !this.isdControl.value;
        const errors = { ...(this.control.errors || {}) };
        if (isRequired && isdEmpty) {
            errors['isdMissing'] = true;
        }
        else {
            delete errors['isdMissing'];
        }
        const hasErrors = Object.keys(errors).length > 0;
        this.control.setErrors(hasErrors ? errors : null);
    }
    toggleIsdDropdown() {
        if (this.disabled)
            return;
        this.isIsdDropdownOpen = !this.isIsdDropdownOpen;
        if (this.isIsdDropdownOpen) {
            this.isdSearchTerm = '';
            this.filterIsdCodes();
        }
    }
    filterIsdCodes() {
        if (!this.isdSearchTerm) {
            this.filteredIsdCodes = [...this.isdCode];
        }
        else {
            const searchTerm = this.isdSearchTerm.toString().toLowerCase();
            this.filteredIsdCodes = this.isdCode.filter(item => {
                const isdCodeStr = item.countryTelIsdCode.toString();
                return isdCodeStr.includes(searchTerm);
            });
        }
    }
    selectIsdCode(isdCode) {
        const matched = this.isdCode.find(item => item.countryTelIsdCode === isdCode);
        if (matched) {
            this.selectedIsd = matched;
            this.isdControl.setValue(matched.countryTelIsdCode);
            this.onSelectionChangeOutput.emit(matched.countryTelIsdCode);
            // Dynamically set minLength and maxLength
            this.minLength = matched.mobileLength;
            this.maxLength = matched.mobileLength;
            // Update validators on the mobile number control
            this.control.setValidators([
                Validators.required,
                Validators.minLength(this.minLength),
                Validators.maxLength(this.maxLength)
            ]);
            this.control?.updateValueAndValidity();
        }
        this.isIsdDropdownOpen = false;
        this.onBlur();
    }
    onClickOutside(event) {
        if (!this.isIsdDropdownOpen)
            return;
        const target = event.target;
        if (!target.closest('.custom-dropdown')) {
            this.isIsdDropdownOpen = false;
        }
    }
    get control() {
        return this.ngControl?.control;
    }
    suffixClick() {
        this.onSuffixClick.emit();
    }
    onKeyPress(event) {
        if (!/^\d*$/.test(event.key)) {
            event.preventDefault();
            return false;
        }
        return true;
    }
    onBlur() {
        this.onTouched();
        if (this.control) {
            this.control?.updateValueAndValidity();
            this.isdControl?.updateValueAndValidity();
        }
    }
    onInputChange(event) {
        const value = event.target.value;
        this.innerValue = value;
        this.onInputChangeOutput.emit(value);
        this.onChange(value);
    }
    onPaste(event) {
        event.preventDefault(); // Stop the default paste behavior
        const pastedText = event.clipboardData?.getData('text') ?? '';
        const numericOnly = pastedText.replace(/\D/g, '');
        // Apply maxlength if defined
        const maxLength = this.maxLength ?? Infinity;
        const trimmedValue = numericOnly.substring(0, maxLength);
        const input = event.target;
        input.value = trimmedValue;
        this.innerValue = trimmedValue;
        this.onInputChangeOutput.emit(trimmedValue);
        this.onChange(trimmedValue);
        this.control?.setValue(trimmedValue);
        this.control?.markAsTouched();
        this.control?.updateValueAndValidity();
    }
    writeValue(value) {
        this.innerValue = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: MobileFieldComponent, deps: [{ token: i0.Injector }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: MobileFieldComponent, selector: "ic-mobile-field", inputs: { label: "label", placeholder: "placeholder", id: "id", disabled: "disabled", prefixIcon: "prefixIcon", isdCode: "isdCode", isdControl: "isdControl", minLength: "minLength", maxLength: "maxLength", readonly: "readonly", suffixIcon: "suffixIcon", suffixButton: "suffixButton", customError: "customError" }, outputs: { onInputChangeOutput: "onInputChangeOutput", onSelectionChangeOutput: "onSelectionChangeOutput", onSuffixClick: "onSuffixClick" }, host: { listeners: { "document:click": "onClickOutside($event)", "paste": "onPaste($event)" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => MobileFieldComponent),
                multi: true,
            },
        ], usesOnChanges: true, ngImport: i0, template: "<div class=\"ic-mobile-field\" [class.disabled]=\"disabled\">\r\n  <label *ngIf=\"label\" class=\"floated\" [attr.for]=\"id\">\r\n    {{ label }}\r\n    <span\r\n      *ngIf=\"control.hasValidator(isRequiredValidator)\"\r\n      class=\"required-star\"\r\n      style=\"color: red\"\r\n      >*</span\r\n    >\r\n  </label>\r\n\r\n  <div\r\n    class=\"input-wrapper\"\r\n    [class.error]=\"\r\n      (control.touched && control.invalid) ||\r\n      (isFieldRequired() && isdControl.touched && isdControl.invalid)\r\n    \">\r\n    <!-- ISD Code Dropdown -->\r\n    <div class=\"isd-select-container\" *ngIf=\"isdCode?.length\">\r\n      <div class=\"custom-dropdown\">\r\n        <div class=\"dropdown-header\" (click)=\"toggleIsdDropdown()\">\r\n          <span *ngIf=\"!selectedIsd\">Select</span>\r\n          <span *ngIf=\"selectedIsd\">+{{ selectedIsd.countryTelIsdCode }}</span>\r\n          <span class=\"dropdown-arrow\">\r\n            <ic-icon\r\n              name=\"sort-down\"\r\n              style=\"--ic-icon-color: #b3bac8\"></ic-icon>\r\n          </span>\r\n        </div>\r\n        <div class=\"dropdown-content\" *ngIf=\"isIsdDropdownOpen\">\r\n          <div class=\"search-container\">\r\n            <input\r\n              type=\"search\"\r\n              placeholder=\"Search\"\r\n              [(ngModel)]=\"isdSearchTerm\"\r\n              (ngModelChange)=\"filterIsdCodes()\"\r\n              class=\"search-input\" />\r\n          </div>\r\n          <div class=\"dropdown-options\">\r\n            <div\r\n              *ngFor=\"let item of filteredIsdCodes\"\r\n              class=\"dropdown-option\"\r\n              (click)=\"selectIsdCode(item.countryTelIsdCode)\">\r\n              +{{ item.countryTelIsdCode }}\r\n            </div>\r\n            <div *ngIf=\"filteredIsdCodes.length === 0\" class=\"no-results\">\r\n              Not found!\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"separator\"></div>\r\n    </div>\r\n\r\n    <!-- Prefix Icon -->\r\n    <span *ngIf=\"prefixIcon\" class=\"prefix-icon\" aria-hidden=\"true\">\r\n      {{ prefixIcon }}\r\n    </span>\r\n    <div class=\"input-container\">\r\n      <!-- Input Field -->\r\n      <input\r\n        [id]=\"id\"\r\n        type=\"tel\"\r\n        class=\"mobile-input\"\r\n        [formControl]=\"control\"\r\n        [placeholder]=\"placeholder\"\r\n        [readonly]=\"readonly\"\r\n        [disabled]=\"disabled\"\r\n        [minlength]=\"minLength\"\r\n        [maxlength]=\"maxLength\"\r\n        (keypress)=\"onKeyPress($event)\"\r\n        (blur)=\"onBlur()\"\r\n        (input)=\"onInputChange($event)\" />\r\n\r\n      <!-- Suffix Icon -->\r\n      <span\r\n        *ngIf=\"suffixIcon\"\r\n        class=\"suffix-icon\"\r\n        [style.backgroundImage]=\"'url(/assets/images/' + suffixIcon + '.svg)'\"\r\n        (click)=\"suffixClick()\"\r\n        [class.disabled]=\"disabled\"\r\n        aria-hidden=\"true\"></span>\r\n\r\n      <!-- Suffix Button -->\r\n      <ic-button\r\n        *ngIf=\"suffixButton\"\r\n        [label]=\"suffixButton\"\r\n        [disabled]=\"!control.valid || disabled\"\r\n        size=\"small\"\r\n        customButtonClass=\"w-100\"\r\n        (OnClick)=\"suffixClick()\">\r\n      </ic-button>\r\n    </div>\r\n  </div>\r\n\r\n  <!-- Error Messages (remain the same) -->\r\n  <div class=\"error-message\">\r\n    <div *ngIf=\"control?.hasError('isdMissing') && control?.touched\">\r\n      Please select a country code.\r\n    </div>\r\n\r\n    <ng-container *ngIf=\"control.invalid && control.touched\">\r\n      <div *ngIf=\"control.hasError('required')\">\r\n        {{ label || 'Mobile number' }} is required!\r\n      </div>\r\n\r\n      <div *ngIf=\"control.hasError('minlength')\">\r\n        Please enter at least\r\n        {{ control.errors?.['minlength']?.requiredLength }} digits.\r\n      </div>\r\n\r\n      <div *ngIf=\"control.hasError('maxlength')\">\r\n        Maximum {{ control.errors?.['maxlength']?.requiredLength }} digits\r\n        allowed.\r\n      </div>\r\n    </ng-container>\r\n\r\n    <div *ngIf=\"customError && control.invalid && control.touched\">\r\n      {{ customError }}\r\n    </div>\r\n  </div>\r\n</div>\r\n", styles: [".ic-mobile-field{position:relative;margin:8px 0;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.ic-mobile-field label{position:absolute;left:16px;font-size:14px;transition:.3s;color:var(--ic-mobile-field-label-color, #666);font-family:var(--ic-primary-font-family),sans-serif;transform:translateY(9px)!important;z-index:2}.ic-mobile-field label.floated{left:12px;transform:translateY(-8px)!important;font-size:12px;color:var(--ic-mobile-field-label-active-color, #0033a1);background:var(--ic-mobile-field-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0), #fff 57%, rgba(0, 128, 0, 0)));padding:0 4px;z-index:1}.ic-mobile-field label.floated .required-star{color:var(--ic-mobile-field-required-star, red)}.ic-mobile-field .input-wrapper{position:relative;display:flex;justify-content:space-between;flex-direction:row;align-items:center;padding:8px 4px 8px 16px;height:40px;font-size:14px!important;border:2px solid var(--ic-mobile-field-border, #dcdcdc);border-radius:8px;background:var(--ic-mobile-field-bg, #fff);outline:none;box-shadow:var(--ic-mobile-field-box-shadow, none);transition:border-color .3s ease,box-shadow .3s ease}.ic-mobile-field .input-wrapper:has(input:focus){border-color:var(--ic-mobile-field-border-focus, #0033a1)}.ic-mobile-field .input-wrapper.error{border-color:var(--ic-mobile-field-border-error, red)}.ic-mobile-field .input-wrapper:has(input:disabled){background-color:var(--ic-mobile-field-disabled-bg, #f3f3f3);border-color:var(--ic-mobile-field-disabled-border, #dcdcdc);box-shadow:none;cursor:not-allowed}.ic-mobile-field .input-wrapper .isd-select-container{display:flex;align-items:center}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown{position:relative;display:inline-block;color:var(--ic-text-black);cursor:pointer}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-header{border-radius:4px;font-weight:500;display:flex;justify-content:space-between;align-items:center}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-header .dropdown-arrow{margin:0 4px;color:var(--ic-mobile-field-dropdown-arrow-color, #b3bac8)}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-header .dropdown-arrow ic-icon{width:10px}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content{position:absolute;top:100%;left:0;background-color:var(--ic-mobile-field-dropdown-bg, #fff);border-radius:4px;box-shadow:0 2px 5px #0003;z-index:1000}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .search-container{padding:4px;border-bottom:1px solid #eee;display:flex}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .search-container .search-input{width:100%;padding:4px;border:1px solid #ddd;border-radius:4px;font-size:10px!important}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .dropdown-options{max-height:300px;overflow-y:auto}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .dropdown-options .dropdown-option{padding:8px 12px;color:var(--ic-mobile-field-dropdown-option-color, #0033a1);cursor:pointer}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .dropdown-options .dropdown-option:hover{background-color:var(--ic-mobile-field-dropdown-option-hover-bg, #f5f5f5)}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .dropdown-options .no-results{padding:8px 12px;color:var(--ic-mobile-field-dropdown-no-results-color, #999);font-style:italic;word-break:break-word;text-align:center;font-size:10px}.ic-mobile-field .input-wrapper .isd-select-container .separator{width:2px;height:25px;margin:0 5px;border-right:2px solid var(--ic-mobile-field-separator, #e8e8e8)}.ic-mobile-field .input-wrapper .input-container{display:flex;flex-direction:row;justify-content:space-between;width:100%}.ic-mobile-field .input-wrapper .prefix-div{font-size:16px;color:var(--ic-mobile-field-prefix-color, #0033a1);display:flex;align-items:center}.ic-mobile-field .input-wrapper .suffix-div{width:24px;height:24px;align-items:center;display:flex;cursor:pointer}.ic-mobile-field .input-wrapper .suffix-div.disabled{cursor:not-allowed;pointer-events:none}.ic-mobile-field input{font-size:14px!important;font-weight:500;background:transparent;color:var(--ic-text-black, #000);outline:none;border:none;transition:color .3s ease}.ic-mobile-field input:disabled{background-color:transparent;color:var(--ic-mobile-field-input-disabled-color, #999)}.ic-mobile-field.disabled .input-wrapper{background-color:var(--ic-mobile-field-disabled-bg, #f3f3f3);border-color:var(--ic-mobile-field-disabled-border, #dcdcdc);box-shadow:none;cursor:not-allowed}.ic-mobile-field.disabled .input-wrapper .isd-select-container .custom-dropdown,.ic-mobile-field.disabled .input-wrapper input{cursor:not-allowed;pointer-events:none}.ic-mobile-field input[type=number]::-webkit-inner-spin-button,.ic-mobile-field input[type=number]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.ic-mobile-field input[type=number]{-moz-appearance:textfield}.ic-mobile-field .error-message{color:var(--ic-mobile-field-error-color, red);font-size:12px;margin:0 16px}\n"], dependencies: [{ kind: "directive", type: i1$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.MinLengthValidator, selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]", inputs: ["minlength"] }, { kind: "directive", type: i2.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NoInitialSpaceDirective, selector: "input, textarea" }, { kind: "component", type: ButtonComponent, selector: "ic-button", inputs: ["label", "type", "size", "disabled", "isLoading", "isSkeleton", "icButtonType", "icIcon", "prefixIcon", "suffixIcon", "customButtonClass"], outputs: ["OnClick"] }, { kind: "component", type: IconComponent, selector: "ic-icon", inputs: ["name", "color", "size"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: MobileFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-mobile-field', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => MobileFieldComponent),
                            multi: true,
                        },
                    ], template: "<div class=\"ic-mobile-field\" [class.disabled]=\"disabled\">\r\n  <label *ngIf=\"label\" class=\"floated\" [attr.for]=\"id\">\r\n    {{ label }}\r\n    <span\r\n      *ngIf=\"control.hasValidator(isRequiredValidator)\"\r\n      class=\"required-star\"\r\n      style=\"color: red\"\r\n      >*</span\r\n    >\r\n  </label>\r\n\r\n  <div\r\n    class=\"input-wrapper\"\r\n    [class.error]=\"\r\n      (control.touched && control.invalid) ||\r\n      (isFieldRequired() && isdControl.touched && isdControl.invalid)\r\n    \">\r\n    <!-- ISD Code Dropdown -->\r\n    <div class=\"isd-select-container\" *ngIf=\"isdCode?.length\">\r\n      <div class=\"custom-dropdown\">\r\n        <div class=\"dropdown-header\" (click)=\"toggleIsdDropdown()\">\r\n          <span *ngIf=\"!selectedIsd\">Select</span>\r\n          <span *ngIf=\"selectedIsd\">+{{ selectedIsd.countryTelIsdCode }}</span>\r\n          <span class=\"dropdown-arrow\">\r\n            <ic-icon\r\n              name=\"sort-down\"\r\n              style=\"--ic-icon-color: #b3bac8\"></ic-icon>\r\n          </span>\r\n        </div>\r\n        <div class=\"dropdown-content\" *ngIf=\"isIsdDropdownOpen\">\r\n          <div class=\"search-container\">\r\n            <input\r\n              type=\"search\"\r\n              placeholder=\"Search\"\r\n              [(ngModel)]=\"isdSearchTerm\"\r\n              (ngModelChange)=\"filterIsdCodes()\"\r\n              class=\"search-input\" />\r\n          </div>\r\n          <div class=\"dropdown-options\">\r\n            <div\r\n              *ngFor=\"let item of filteredIsdCodes\"\r\n              class=\"dropdown-option\"\r\n              (click)=\"selectIsdCode(item.countryTelIsdCode)\">\r\n              +{{ item.countryTelIsdCode }}\r\n            </div>\r\n            <div *ngIf=\"filteredIsdCodes.length === 0\" class=\"no-results\">\r\n              Not found!\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"separator\"></div>\r\n    </div>\r\n\r\n    <!-- Prefix Icon -->\r\n    <span *ngIf=\"prefixIcon\" class=\"prefix-icon\" aria-hidden=\"true\">\r\n      {{ prefixIcon }}\r\n    </span>\r\n    <div class=\"input-container\">\r\n      <!-- Input Field -->\r\n      <input\r\n        [id]=\"id\"\r\n        type=\"tel\"\r\n        class=\"mobile-input\"\r\n        [formControl]=\"control\"\r\n        [placeholder]=\"placeholder\"\r\n        [readonly]=\"readonly\"\r\n        [disabled]=\"disabled\"\r\n        [minlength]=\"minLength\"\r\n        [maxlength]=\"maxLength\"\r\n        (keypress)=\"onKeyPress($event)\"\r\n        (blur)=\"onBlur()\"\r\n        (input)=\"onInputChange($event)\" />\r\n\r\n      <!-- Suffix Icon -->\r\n      <span\r\n        *ngIf=\"suffixIcon\"\r\n        class=\"suffix-icon\"\r\n        [style.backgroundImage]=\"'url(/assets/images/' + suffixIcon + '.svg)'\"\r\n        (click)=\"suffixClick()\"\r\n        [class.disabled]=\"disabled\"\r\n        aria-hidden=\"true\"></span>\r\n\r\n      <!-- Suffix Button -->\r\n      <ic-button\r\n        *ngIf=\"suffixButton\"\r\n        [label]=\"suffixButton\"\r\n        [disabled]=\"!control.valid || disabled\"\r\n        size=\"small\"\r\n        customButtonClass=\"w-100\"\r\n        (OnClick)=\"suffixClick()\">\r\n      </ic-button>\r\n    </div>\r\n  </div>\r\n\r\n  <!-- Error Messages (remain the same) -->\r\n  <div class=\"error-message\">\r\n    <div *ngIf=\"control?.hasError('isdMissing') && control?.touched\">\r\n      Please select a country code.\r\n    </div>\r\n\r\n    <ng-container *ngIf=\"control.invalid && control.touched\">\r\n      <div *ngIf=\"control.hasError('required')\">\r\n        {{ label || 'Mobile number' }} is required!\r\n      </div>\r\n\r\n      <div *ngIf=\"control.hasError('minlength')\">\r\n        Please enter at least\r\n        {{ control.errors?.['minlength']?.requiredLength }} digits.\r\n      </div>\r\n\r\n      <div *ngIf=\"control.hasError('maxlength')\">\r\n        Maximum {{ control.errors?.['maxlength']?.requiredLength }} digits\r\n        allowed.\r\n      </div>\r\n    </ng-container>\r\n\r\n    <div *ngIf=\"customError && control.invalid && control.touched\">\r\n      {{ customError }}\r\n    </div>\r\n  </div>\r\n</div>\r\n", styles: [".ic-mobile-field{position:relative;margin:8px 0;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.ic-mobile-field label{position:absolute;left:16px;font-size:14px;transition:.3s;color:var(--ic-mobile-field-label-color, #666);font-family:var(--ic-primary-font-family),sans-serif;transform:translateY(9px)!important;z-index:2}.ic-mobile-field label.floated{left:12px;transform:translateY(-8px)!important;font-size:12px;color:var(--ic-mobile-field-label-active-color, #0033a1);background:var(--ic-mobile-field-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0), #fff 57%, rgba(0, 128, 0, 0)));padding:0 4px;z-index:1}.ic-mobile-field label.floated .required-star{color:var(--ic-mobile-field-required-star, red)}.ic-mobile-field .input-wrapper{position:relative;display:flex;justify-content:space-between;flex-direction:row;align-items:center;padding:8px 4px 8px 16px;height:40px;font-size:14px!important;border:2px solid var(--ic-mobile-field-border, #dcdcdc);border-radius:8px;background:var(--ic-mobile-field-bg, #fff);outline:none;box-shadow:var(--ic-mobile-field-box-shadow, none);transition:border-color .3s ease,box-shadow .3s ease}.ic-mobile-field .input-wrapper:has(input:focus){border-color:var(--ic-mobile-field-border-focus, #0033a1)}.ic-mobile-field .input-wrapper.error{border-color:var(--ic-mobile-field-border-error, red)}.ic-mobile-field .input-wrapper:has(input:disabled){background-color:var(--ic-mobile-field-disabled-bg, #f3f3f3);border-color:var(--ic-mobile-field-disabled-border, #dcdcdc);box-shadow:none;cursor:not-allowed}.ic-mobile-field .input-wrapper .isd-select-container{display:flex;align-items:center}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown{position:relative;display:inline-block;color:var(--ic-text-black);cursor:pointer}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-header{border-radius:4px;font-weight:500;display:flex;justify-content:space-between;align-items:center}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-header .dropdown-arrow{margin:0 4px;color:var(--ic-mobile-field-dropdown-arrow-color, #b3bac8)}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-header .dropdown-arrow ic-icon{width:10px}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content{position:absolute;top:100%;left:0;background-color:var(--ic-mobile-field-dropdown-bg, #fff);border-radius:4px;box-shadow:0 2px 5px #0003;z-index:1000}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .search-container{padding:4px;border-bottom:1px solid #eee;display:flex}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .search-container .search-input{width:100%;padding:4px;border:1px solid #ddd;border-radius:4px;font-size:10px!important}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .dropdown-options{max-height:300px;overflow-y:auto}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .dropdown-options .dropdown-option{padding:8px 12px;color:var(--ic-mobile-field-dropdown-option-color, #0033a1);cursor:pointer}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .dropdown-options .dropdown-option:hover{background-color:var(--ic-mobile-field-dropdown-option-hover-bg, #f5f5f5)}.ic-mobile-field .input-wrapper .isd-select-container .custom-dropdown .dropdown-content .dropdown-options .no-results{padding:8px 12px;color:var(--ic-mobile-field-dropdown-no-results-color, #999);font-style:italic;word-break:break-word;text-align:center;font-size:10px}.ic-mobile-field .input-wrapper .isd-select-container .separator{width:2px;height:25px;margin:0 5px;border-right:2px solid var(--ic-mobile-field-separator, #e8e8e8)}.ic-mobile-field .input-wrapper .input-container{display:flex;flex-direction:row;justify-content:space-between;width:100%}.ic-mobile-field .input-wrapper .prefix-div{font-size:16px;color:var(--ic-mobile-field-prefix-color, #0033a1);display:flex;align-items:center}.ic-mobile-field .input-wrapper .suffix-div{width:24px;height:24px;align-items:center;display:flex;cursor:pointer}.ic-mobile-field .input-wrapper .suffix-div.disabled{cursor:not-allowed;pointer-events:none}.ic-mobile-field input{font-size:14px!important;font-weight:500;background:transparent;color:var(--ic-text-black, #000);outline:none;border:none;transition:color .3s ease}.ic-mobile-field input:disabled{background-color:transparent;color:var(--ic-mobile-field-input-disabled-color, #999)}.ic-mobile-field.disabled .input-wrapper{background-color:var(--ic-mobile-field-disabled-bg, #f3f3f3);border-color:var(--ic-mobile-field-disabled-border, #dcdcdc);box-shadow:none;cursor:not-allowed}.ic-mobile-field.disabled .input-wrapper .isd-select-container .custom-dropdown,.ic-mobile-field.disabled .input-wrapper input{cursor:not-allowed;pointer-events:none}.ic-mobile-field input[type=number]::-webkit-inner-spin-button,.ic-mobile-field input[type=number]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.ic-mobile-field input[type=number]{-moz-appearance:textfield}.ic-mobile-field .error-message{color:var(--ic-mobile-field-error-color, red);font-size:12px;margin:0 16px}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.Injector }]; }, propDecorators: { label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], id: [{
                type: Input
            }], disabled: [{
                type: Input
            }], prefixIcon: [{
                type: Input
            }], isdCode: [{
                type: Input
            }], isdControl: [{
                type: Input
            }], minLength: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], readonly: [{
                type: Input
            }], suffixIcon: [{
                type: Input
            }], suffixButton: [{
                type: Input
            }], customError: [{
                type: Input
            }], onInputChangeOutput: [{
                type: Output
            }], onSelectionChangeOutput: [{
                type: Output
            }], onSuffixClick: [{
                type: Output
            }], onClickOutside: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class TenureFieldComponent {
    constructor(fb) {
        this.fb = fb;
        this.label = '';
        this.fields = [];
        this.fieldLabels = {};
        this.customError = '';
        this.isRequired = false;
        this.disabled = false;
        this.skipLabel = false;
        this.readonly = false;
        this.inputValuesChange = new EventEmitter();
        this.showError = false;
        this.errorMessage = '';
    }
    ngOnInit() {
        if (!this.parentForm) {
            console.error('Parent form is required for TenureFieldComponent.');
            return;
        }
        // Add controls to the parent form
        this.fields.forEach(field => {
            if (!this.parentForm?.contains(field)) {
                this.parentForm.addControl(field, this.fb.control('', [Validators.min(0)]));
            }
        });
        // Subscribe to value changes
        this.parentForm.valueChanges
            .pipe(debounceTime(500), distinctUntilChanged())
            .subscribe(() => {
            const normalizedValues = this.normalizeValues(this.parentForm?.value || {});
            this.inputValuesChange.emit(normalizedValues);
            this.validateForm();
        });
        // Subscribe to status changes for validation
        this.parentForm.statusChanges.subscribe(() => this.validateForm());
    }
    ngDoCheck() {
        if (!this.parentForm)
            return;
        const anyTouched = this.fields.some(field => this.parentForm.get(field)?.touched);
        if (anyTouched) {
            this.validateForm();
        }
    }
    normalizeValues(values) {
        const result = {};
        Object.keys(values).forEach(key => {
            const value = values[key];
            result[key] = !value || isNaN(Number(value)) ? 0 : Number(value);
        });
        return result;
    }
    getFieldLabel(field) {
        const baseLabel = this.fieldLabels[field] || field;
        const value = this.parentForm?.get(field)?.value;
        if (value && !isNaN(value)) {
            return Number(value) > 1 ? baseLabel + 's' : baseLabel;
        }
        return baseLabel;
    }
    isNumeric(value) {
        return (value !== null && value !== undefined && value !== '' && !isNaN(+value));
    }
    onBlur(field) {
        const control = this.parentForm?.get(field);
        if (control && !control.value) {
            control.markAsTouched();
        }
        const currentValues = this.parentForm?.value || {};
        const normalizedValues = this.normalizeValues(currentValues);
        this.inputValuesChange.emit(normalizedValues);
        this.validateForm();
    }
    onPaste(event, field) {
        const pastedValue = event.clipboardData?.getData('text') || '';
        const control = this.parentForm.get(field);
        if (control) {
            const truncatedValue = pastedValue.slice(0, 2);
            control.setValue(truncatedValue);
        }
        event.preventDefault();
    }
    validateForm() {
        if (!this.parentForm) {
            return;
        }
        const controls = this.parentForm.controls;
        // Check if any control is touched
        const anyFieldTouched = Object.keys(controls)
            .filter(key => this.fields.includes(key))
            .some(key => controls[key]?.touched);
        // Check if all fields are empty
        const allFieldsEmpty = Object.keys(controls)
            .filter(key => this.fields.includes(key))
            .every(key => !controls[key]?.value || controls[key]?.value === 0);
        if (anyFieldTouched && allFieldsEmpty && this.isRequired) {
            this.showError = true;
            this.errorMessage = `${this.label} is required!`;
            return;
        }
        // Check for custom error logic
        if (this.customError) {
            this.showError = true;
            this.errorMessage = this.customError;
            return;
        }
        // Clear errors
        this.showError = false;
        this.errorMessage = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TenureFieldComponent, deps: [{ token: i2.FormBuilder }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: TenureFieldComponent, selector: "ic-tenure-field", inputs: { label: "label", fields: "fields", fieldLabels: "fieldLabels", customError: "customError", parentForm: "parentForm", isRequired: "isRequired", disabled: "disabled", skipLabel: "skipLabel", readonly: "readonly" }, outputs: { inputValuesChange: "inputValuesChange" }, ngImport: i0, template: "<div class=\"tenure-field-container\">\r\n  <label class=\"field-label\" *ngIf=\"label && !skipLabel\">\r\n    {{ label }} <span *ngIf=\"isRequired\" class=\"required-star\">*</span>\r\n  </label>\r\n\r\n  <div\r\n    class=\"input-group\"\r\n    [class.disabled]=\"disabled\"\r\n    [class.error]=\"showError\"\r\n    [formGroup]=\"parentForm\">\r\n    <ng-container *ngFor=\"let field of fields; let findx = index\">\r\n      <div class=\"input-field\">\r\n        <input\r\n          type=\"text\"\r\n          [formControlName]=\"field\"\r\n          [placeholder]=\"getFieldLabel(field)\"\r\n          [readOnly]=\"readonly\"\r\n          min=\"0\"\r\n          [maxlength]=\"2\"\r\n          [icNumbersOnly]=\"true\"\r\n          (blur)=\"onBlur(field)\"\r\n          (input)=\"parentForm.get(field)?.updateValueAndValidity()\"\r\n          (paste)=\"onPaste($event, field)\" />\r\n        <label\r\n          class=\"unit-label\"\r\n          *ngIf=\"isNumeric(parentForm.get(field)?.value)\">\r\n          {{ getFieldLabel(field) }}\r\n        </label>\r\n      </div>\r\n      <div class=\"separator\" *ngIf=\"findx < fields.length - 1\">|</div>\r\n    </ng-container>\r\n  </div>\r\n\r\n  <div class=\"error-message\" *ngIf=\"showError\">\r\n    <span>{{ errorMessage }}</span>\r\n  </div>\r\n</div>\r\n", styles: [".tenure-field-container{position:relative;display:flex;margin:8px 0;flex-direction:column;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.tenure-field-container .field-label{position:absolute;transform:translateY(-8px) translate(12px)!important;font-size:12px;color:var(--ic-tenure-field-label-color, #0033a1);background:var(--ic-tenure-field-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0), #fff 57%, rgba(0, 128, 0, 0)));padding:0 4px;z-index:1}.tenure-field-container .field-label .required-star{color:var(--ic-tenure-field-required-star, red)}.tenure-field-container .input-group{display:flex;flex-wrap:nowrap;flex-direction:row;align-items:center;justify-content:space-between;height:40px;padding:8px 16px;font-size:14px!important;border:2px solid var(--ic-tenure-field-border, #dcdcdc);border-radius:8px;background:var(--ic-tenure-field-bg, #fff);box-shadow:var(--ic-tenure-field-box-shadow, none);transition:border-color .3s ease,box-shadow .3s ease}.tenure-field-container .input-group.disabled{background-color:var(--ic-tenure-field-disabled-bg, #f3f3f3)!important;border-color:var(--ic-tenure-field-disabled-border, #dcdcdc)!important;box-shadow:none!important;cursor:not-allowed!important;pointer-events:none!important}.tenure-field-container .input-group.error{border-color:var(--ic-tenure-field-border-error, red)}.tenure-field-container .input-group .input-field{display:flex;flex-direction:row;gap:4px;width:100%;align-items:center;justify-content:center}.tenure-field-container .input-group .input-field input{border:none;outline:none;background:transparent;text-align:center;border-radius:4px;width:100%;min-width:23px;color:var(--ic-tenure-field-input-color, inherit)}.tenure-field-container .input-group .input-field input:focus{outline:none;border-color:var(--ic-tenure-field-border-focus, #2196f3)}.tenure-field-container .input-group .input-field .unit-label{color:var(--ic-tenure-field-unit-label-color, #010101);font-size:11px;font-style:normal;font-weight:500;line-height:normal}.tenure-field-container .input-group .separator{margin:0 8px!important;font-size:14px;opacity:.174;color:var(--ic-tenure-field-separator-color, #707070)}.tenure-field-container .error-message{color:var(--ic-tenure-field-error-color, red);font-size:12px;margin:0 16px}input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}input[type=number]{-moz-appearance:textfield}\n"], dependencies: [{ kind: "directive", type: i1$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: NoInitialSpaceDirective, selector: "input, textarea" }, { kind: "directive", type: NumbersOnlyDirective, selector: "[icNumbersOnly]", inputs: ["icNumbersOnly"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TenureFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-tenure-field', template: "<div class=\"tenure-field-container\">\r\n  <label class=\"field-label\" *ngIf=\"label && !skipLabel\">\r\n    {{ label }} <span *ngIf=\"isRequired\" class=\"required-star\">*</span>\r\n  </label>\r\n\r\n  <div\r\n    class=\"input-group\"\r\n    [class.disabled]=\"disabled\"\r\n    [class.error]=\"showError\"\r\n    [formGroup]=\"parentForm\">\r\n    <ng-container *ngFor=\"let field of fields; let findx = index\">\r\n      <div class=\"input-field\">\r\n        <input\r\n          type=\"text\"\r\n          [formControlName]=\"field\"\r\n          [placeholder]=\"getFieldLabel(field)\"\r\n          [readOnly]=\"readonly\"\r\n          min=\"0\"\r\n          [maxlength]=\"2\"\r\n          [icNumbersOnly]=\"true\"\r\n          (blur)=\"onBlur(field)\"\r\n          (input)=\"parentForm.get(field)?.updateValueAndValidity()\"\r\n          (paste)=\"onPaste($event, field)\" />\r\n        <label\r\n          class=\"unit-label\"\r\n          *ngIf=\"isNumeric(parentForm.get(field)?.value)\">\r\n          {{ getFieldLabel(field) }}\r\n        </label>\r\n      </div>\r\n      <div class=\"separator\" *ngIf=\"findx < fields.length - 1\">|</div>\r\n    </ng-container>\r\n  </div>\r\n\r\n  <div class=\"error-message\" *ngIf=\"showError\">\r\n    <span>{{ errorMessage }}</span>\r\n  </div>\r\n</div>\r\n", styles: [".tenure-field-container{position:relative;display:flex;margin:8px 0;flex-direction:column;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.tenure-field-container .field-label{position:absolute;transform:translateY(-8px) translate(12px)!important;font-size:12px;color:var(--ic-tenure-field-label-color, #0033a1);background:var(--ic-tenure-field-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0), #fff 57%, rgba(0, 128, 0, 0)));padding:0 4px;z-index:1}.tenure-field-container .field-label .required-star{color:var(--ic-tenure-field-required-star, red)}.tenure-field-container .input-group{display:flex;flex-wrap:nowrap;flex-direction:row;align-items:center;justify-content:space-between;height:40px;padding:8px 16px;font-size:14px!important;border:2px solid var(--ic-tenure-field-border, #dcdcdc);border-radius:8px;background:var(--ic-tenure-field-bg, #fff);box-shadow:var(--ic-tenure-field-box-shadow, none);transition:border-color .3s ease,box-shadow .3s ease}.tenure-field-container .input-group.disabled{background-color:var(--ic-tenure-field-disabled-bg, #f3f3f3)!important;border-color:var(--ic-tenure-field-disabled-border, #dcdcdc)!important;box-shadow:none!important;cursor:not-allowed!important;pointer-events:none!important}.tenure-field-container .input-group.error{border-color:var(--ic-tenure-field-border-error, red)}.tenure-field-container .input-group .input-field{display:flex;flex-direction:row;gap:4px;width:100%;align-items:center;justify-content:center}.tenure-field-container .input-group .input-field input{border:none;outline:none;background:transparent;text-align:center;border-radius:4px;width:100%;min-width:23px;color:var(--ic-tenure-field-input-color, inherit)}.tenure-field-container .input-group .input-field input:focus{outline:none;border-color:var(--ic-tenure-field-border-focus, #2196f3)}.tenure-field-container .input-group .input-field .unit-label{color:var(--ic-tenure-field-unit-label-color, #010101);font-size:11px;font-style:normal;font-weight:500;line-height:normal}.tenure-field-container .input-group .separator{margin:0 8px!important;font-size:14px;opacity:.174;color:var(--ic-tenure-field-separator-color, #707070)}.tenure-field-container .error-message{color:var(--ic-tenure-field-error-color, red);font-size:12px;margin:0 16px}input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}input[type=number]{-moz-appearance:textfield}\n"] }]
        }], ctorParameters: function () { return [{ type: i2.FormBuilder }]; }, propDecorators: { label: [{
                type: Input
            }], fields: [{
                type: Input
            }], fieldLabels: [{
                type: Input
            }], customError: [{
                type: Input
            }], parentForm: [{
                type: Input
            }], isRequired: [{
                type: Input
            }], disabled: [{
                type: Input
            }], skipLabel: [{
                type: Input
            }], readonly: [{
                type: Input
            }], inputValuesChange: [{
                type: Output
            }] } });

class SlideToggleComponent {
    constructor() {
        this.formControl = new FormControl(false);
        this.checked = false;
        this.disabled = false;
        this.required = false;
        this.color = 'primary';
        this.labelPosition = 'after';
        this.id = '';
        this.ariaLabel = '';
        this.ariaLabelledBy = '';
        this.sliderChange = new EventEmitter();
    }
    ngOnInit() {
        this.checked = this.formControl.value ?? false;
        // Listen for formControl value changes
        this.formControl.valueChanges.subscribe(value => {
            if (value !== this.checked) {
                this.checked = value;
            }
        });
    }
    ngOnChanges(changes) {
        if (changes['checked'] && changes['checked'].currentValue !== undefined) {
            this.formControl.setValue(this.checked, { emitEvent: false });
        }
    }
    onToggleChange(event) {
        if (this.disabled || !event.isTrusted) {
            return;
        }
        const target = event.target;
        this.checked = target.checked;
        // Ensure proper formControl update
        if (this.formControl) {
            this.formControl.setValue(this.checked, { emitEvent: true });
        }
        this.sliderChange.emit(this.checked);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SlideToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SlideToggleComponent, selector: "ic-slide-toggle", inputs: { formControl: "formControl", checked: "checked", disabled: "disabled", required: "required", color: "color", labelPosition: "labelPosition", id: "id", ariaLabel: "ariaLabel", ariaLabelledBy: "ariaLabelledBy" }, outputs: { sliderChange: "sliderChange" }, usesOnChanges: true, ngImport: i0, template: "<label\r\n  class=\"ic-slide-toggle-container\"\r\n  [class.ic-slide-toggle-disabled]=\"disabled\"\r\n  [attr.aria-label]=\"ariaLabel\"\r\n  [attr.aria-labelledby]=\"ariaLabelledBy\">\r\n  <input\r\n    type=\"checkbox\"\r\n    class=\"ic-slide-toggle-input\"\r\n    [checked]=\"checked\"\r\n    [disabled]=\"disabled\"\r\n    [required]=\"required\"\r\n    (change)=\"onToggleChange($event)\" />\r\n  <span\r\n    class=\"ic-slide-toggle-slider\"\r\n    [ngClass]=\"{\r\n      primary: color === 'primary',\r\n      accent: color === 'accent',\r\n      warn: color === 'warn',\r\n    }\">\r\n  </span>\r\n  <span\r\n    class=\"ic-slide-toggle-label\"\r\n    [ngClass]=\"{\r\n      before: labelPosition === 'before',\r\n      after: labelPosition === 'after',\r\n    }\">\r\n    <ng-content></ng-content>\r\n  </span>\r\n</label>\r\n", styles: [".ic-slide-toggle-container{display:flex;align-items:center;cursor:pointer}.ic-slide-toggle-input{display:none}.ic-slide-toggle-slider{width:40px;height:20px;background-color:var(--ic-slide-toggle-bg, #ccc);border-radius:10px;position:relative;transition:background-color .3s ease}.ic-slide-toggle-slider:before{content:\"\";position:absolute;width:12px;height:12px;background-color:var(--ic-slide-toggle-knob-bg, #fff);border-radius:50%;top:4px;left:4px;transition:transform .3s ease}.ic-slide-toggle-input:checked+.ic-slide-toggle-slider{background-color:var(--ic-slide-toggle-active-bg, var(--ic-primary-color, #004991))}.ic-slide-toggle-input:checked+.ic-slide-toggle-slider:before{transform:translate(20px)}.ic-slide-toggle-label{margin-left:8px;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.ic-slide-toggle-label.before{order:-1;margin-right:8px;margin-left:0}.primary{--ic-primary-color: #004991}.accent{--ic-primary-color: #ff4081}.warn{--ic-primary-color: #f44336}\n"], dependencies: [{ kind: "directive", type: i1$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NoInitialSpaceDirective, selector: "input, textarea" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SlideToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-slide-toggle', template: "<label\r\n  class=\"ic-slide-toggle-container\"\r\n  [class.ic-slide-toggle-disabled]=\"disabled\"\r\n  [attr.aria-label]=\"ariaLabel\"\r\n  [attr.aria-labelledby]=\"ariaLabelledBy\">\r\n  <input\r\n    type=\"checkbox\"\r\n    class=\"ic-slide-toggle-input\"\r\n    [checked]=\"checked\"\r\n    [disabled]=\"disabled\"\r\n    [required]=\"required\"\r\n    (change)=\"onToggleChange($event)\" />\r\n  <span\r\n    class=\"ic-slide-toggle-slider\"\r\n    [ngClass]=\"{\r\n      primary: color === 'primary',\r\n      accent: color === 'accent',\r\n      warn: color === 'warn',\r\n    }\">\r\n  </span>\r\n  <span\r\n    class=\"ic-slide-toggle-label\"\r\n    [ngClass]=\"{\r\n      before: labelPosition === 'before',\r\n      after: labelPosition === 'after',\r\n    }\">\r\n    <ng-content></ng-content>\r\n  </span>\r\n</label>\r\n", styles: [".ic-slide-toggle-container{display:flex;align-items:center;cursor:pointer}.ic-slide-toggle-input{display:none}.ic-slide-toggle-slider{width:40px;height:20px;background-color:var(--ic-slide-toggle-bg, #ccc);border-radius:10px;position:relative;transition:background-color .3s ease}.ic-slide-toggle-slider:before{content:\"\";position:absolute;width:12px;height:12px;background-color:var(--ic-slide-toggle-knob-bg, #fff);border-radius:50%;top:4px;left:4px;transition:transform .3s ease}.ic-slide-toggle-input:checked+.ic-slide-toggle-slider{background-color:var(--ic-slide-toggle-active-bg, var(--ic-primary-color, #004991))}.ic-slide-toggle-input:checked+.ic-slide-toggle-slider:before{transform:translate(20px)}.ic-slide-toggle-label{margin-left:8px;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.ic-slide-toggle-label.before{order:-1;margin-right:8px;margin-left:0}.primary{--ic-primary-color: #004991}.accent{--ic-primary-color: #ff4081}.warn{--ic-primary-color: #f44336}\n"] }]
        }], propDecorators: { formControl: [{
                type: Input
            }], checked: [{
                type: Input
            }], disabled: [{
                type: Input
            }], required: [{
                type: Input
            }], color: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], id: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], ariaLabelledBy: [{
                type: Input
            }], sliderChange: [{
                type: Output
            }] } });

class CheckboxComponent {
    constructor() {
        this.formControl = new FormControl(false);
        this.checked = false;
        this.disabled = false;
        this.required = false;
        this.indeterminate = false;
        this.labelPosition = 'after';
        this.icCheckBoxType = 'filled';
        this.name = '';
        this.id = '';
        this.ariaLabel = '';
        this.ariaLabelledBy = '';
        /** Outputs */
        this.checkboxChange = new EventEmitter();
        this.indeterminateChange = new EventEmitter();
    }
    ngOnInit() {
        this.checked = this.formControl.value ?? false;
        // Subscribe to formControl changes to update checkbox state
        this.formControl.valueChanges.subscribe(value => {
            this.checked = value;
        });
    }
    ngOnChanges(changes) {
        if (changes['checked'] && changes['checked'].currentValue !== undefined) {
            this.formControl.setValue(this.checked, { emitEvent: false });
        }
    }
    onCheckboxChange(event) {
        if (this.disabled || !event.isTrusted) {
            return;
        }
        const target = event.target;
        this.indeterminate = false;
        this.checked = target.checked;
        this.formControl.setValue(this.checked);
        this.checkboxChange.emit(this.checked);
    }
    /** Handle indeterminate state change */
    onIndeterminateChange() {
        this.indeterminateChange.emit(this.indeterminate);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: CheckboxComponent, selector: "ic-checkbox", inputs: { formControl: "formControl", checked: "checked", disabled: "disabled", required: "required", indeterminate: "indeterminate", labelPosition: "labelPosition", color: "color", icCheckBoxType: "icCheckBoxType", name: "name", id: "id", ariaLabel: "ariaLabel", ariaLabelledBy: "ariaLabelledBy" }, outputs: { checkboxChange: "checkboxChange", indeterminateChange: "indeterminateChange" }, usesOnChanges: true, ngImport: i0, template: "<label\r\n  class=\"ic-checkbox-container\"\r\n  [class.ic-checkbox-disabled]=\"disabled\"\r\n  [attr.aria-label]=\"ariaLabel\"\r\n  [attr.aria-labelledby]=\"ariaLabelledBy\">\r\n  <input\r\n    type=\"checkbox\"\r\n    class=\"ic-checkbox-input {{ icCheckBoxType }}\"\r\n    [checked]=\"checked\"\r\n    [disabled]=\"disabled\"\r\n    [indeterminate]=\"indeterminate\"\r\n    [required]=\"required\"\r\n    [name]=\"name\"\r\n    [id]=\"id\"\r\n    (change)=\"onCheckboxChange($event)\"\r\n    [formControl]=\"formControl\"\r\n  />\r\n  <span\r\n    class=\"ic-checkbox-box\"\r\n    [ngClass]=\"{\r\n      primary: color === 'primary',\r\n      accent: color === 'accent',\r\n      warn: color === 'warn',\r\n    }\">\r\n    <span class=\"ic-checkbox-indeterminate\" *ngIf=\"indeterminate\"></span>\r\n  </span>\r\n  <span\r\n    class=\"ic-checkbox-label\"\r\n    [ngClass]=\"{\r\n      before: labelPosition === 'before',\r\n      after: labelPosition === 'after',\r\n    }\">\r\n    <ng-content></ng-content>\r\n  </span>\r\n</label>\r\n", styles: [".ic-checkbox-container{display:flex;align-items:center;cursor:pointer}.ic-checkbox-container.ic-checkbox-disabled{cursor:not-allowed;opacity:.6;pointer-events:none}.ic-checkbox-container .ic-checkbox-input{position:absolute;opacity:0;cursor:pointer}.ic-checkbox-container .ic-checkbox-input.filled:checked+.ic-checkbox-box{background-color:var(--ic-checkbox-filled-bg, #004991);border-color:var(--ic-checkbox-filled-border, #004991)}.ic-checkbox-container .ic-checkbox-input.filled:checked+.ic-checkbox-box:after{content:\"\";position:absolute;top:-50%;left:50%;width:5px;height:10px;border:solid var(--ic-checkbox-checkmark-color, #fff);border-width:0 2px 2px 0;transform:rotate(45deg) translate(4px,8px)}.ic-checkbox-container .ic-checkbox-input.outlined:checked+.ic-checkbox-box{background-color:var(--ic-checkbox-outlined-bg, #ffffff);border-color:var(--ic-checkbox-outlined-border, #004991)}.ic-checkbox-container .ic-checkbox-input.outlined:checked+.ic-checkbox-box:after{content:\"\";position:absolute;top:-50%;left:50%;width:5px;height:11px;border:solid var(--ic-checkbox-checkmark-outlined-color, #004991);border-width:0 2px 2px 0;transform:rotate(45deg) translate(4px,7px)}.ic-checkbox-container .ic-checkbox-box{position:relative;height:18px;width:18px;border:1px solid var(--ic-checkbox-border, rgba(112, 112, 112, .3411764706));border-radius:2px;background:var(--ic-checkbox-bg, #ffffff)}.ic-checkbox-container .ic-checkbox-box.primary{background-color:var(--ic-checkbox-primary-bg, #004991);border-color:var(--ic-checkbox-primary-border, #004991)}.ic-checkbox-container .ic-checkbox-box.accent{background-color:var(--ic-checkbox-accent-bg, #ff4081);border-color:var(--ic-checkbox-accent-border, #ff4081)}.ic-checkbox-container .ic-checkbox-box.warn{background-color:var(--ic-checkbox-warn-bg, #f44336);border-color:var(--ic-checkbox-warn-border, #f44336)}.ic-checkbox-container .ic-checkbox-label{margin-left:8px;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);font-weight:500;color:var(--ic-checkbox-label-color, unset)}.ic-checkbox-container .ic-checkbox-label.before{order:-1;margin-left:0;margin-right:8px}.ic-checkbox-container .ic-checkbox-label.after{order:1;margin-left:8px;margin-right:0}\n"], dependencies: [{ kind: "directive", type: i1$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.CheckboxRequiredValidator, selector: "input[type=checkbox][required][formControlName],input[type=checkbox][required][formControl],input[type=checkbox][required][ngModel]" }, { kind: "directive", type: i2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: NoInitialSpaceDirective, selector: "input, textarea" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-checkbox', template: "<label\r\n  class=\"ic-checkbox-container\"\r\n  [class.ic-checkbox-disabled]=\"disabled\"\r\n  [attr.aria-label]=\"ariaLabel\"\r\n  [attr.aria-labelledby]=\"ariaLabelledBy\">\r\n  <input\r\n    type=\"checkbox\"\r\n    class=\"ic-checkbox-input {{ icCheckBoxType }}\"\r\n    [checked]=\"checked\"\r\n    [disabled]=\"disabled\"\r\n    [indeterminate]=\"indeterminate\"\r\n    [required]=\"required\"\r\n    [name]=\"name\"\r\n    [id]=\"id\"\r\n    (change)=\"onCheckboxChange($event)\"\r\n    [formControl]=\"formControl\"\r\n  />\r\n  <span\r\n    class=\"ic-checkbox-box\"\r\n    [ngClass]=\"{\r\n      primary: color === 'primary',\r\n      accent: color === 'accent',\r\n      warn: color === 'warn',\r\n    }\">\r\n    <span class=\"ic-checkbox-indeterminate\" *ngIf=\"indeterminate\"></span>\r\n  </span>\r\n  <span\r\n    class=\"ic-checkbox-label\"\r\n    [ngClass]=\"{\r\n      before: labelPosition === 'before',\r\n      after: labelPosition === 'after',\r\n    }\">\r\n    <ng-content></ng-content>\r\n  </span>\r\n</label>\r\n", styles: [".ic-checkbox-container{display:flex;align-items:center;cursor:pointer}.ic-checkbox-container.ic-checkbox-disabled{cursor:not-allowed;opacity:.6;pointer-events:none}.ic-checkbox-container .ic-checkbox-input{position:absolute;opacity:0;cursor:pointer}.ic-checkbox-container .ic-checkbox-input.filled:checked+.ic-checkbox-box{background-color:var(--ic-checkbox-filled-bg, #004991);border-color:var(--ic-checkbox-filled-border, #004991)}.ic-checkbox-container .ic-checkbox-input.filled:checked+.ic-checkbox-box:after{content:\"\";position:absolute;top:-50%;left:50%;width:5px;height:10px;border:solid var(--ic-checkbox-checkmark-color, #fff);border-width:0 2px 2px 0;transform:rotate(45deg) translate(4px,8px)}.ic-checkbox-container .ic-checkbox-input.outlined:checked+.ic-checkbox-box{background-color:var(--ic-checkbox-outlined-bg, #ffffff);border-color:var(--ic-checkbox-outlined-border, #004991)}.ic-checkbox-container .ic-checkbox-input.outlined:checked+.ic-checkbox-box:after{content:\"\";position:absolute;top:-50%;left:50%;width:5px;height:11px;border:solid var(--ic-checkbox-checkmark-outlined-color, #004991);border-width:0 2px 2px 0;transform:rotate(45deg) translate(4px,7px)}.ic-checkbox-container .ic-checkbox-box{position:relative;height:18px;width:18px;border:1px solid var(--ic-checkbox-border, rgba(112, 112, 112, .3411764706));border-radius:2px;background:var(--ic-checkbox-bg, #ffffff)}.ic-checkbox-container .ic-checkbox-box.primary{background-color:var(--ic-checkbox-primary-bg, #004991);border-color:var(--ic-checkbox-primary-border, #004991)}.ic-checkbox-container .ic-checkbox-box.accent{background-color:var(--ic-checkbox-accent-bg, #ff4081);border-color:var(--ic-checkbox-accent-border, #ff4081)}.ic-checkbox-container .ic-checkbox-box.warn{background-color:var(--ic-checkbox-warn-bg, #f44336);border-color:var(--ic-checkbox-warn-border, #f44336)}.ic-checkbox-container .ic-checkbox-label{margin-left:8px;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);font-weight:500;color:var(--ic-checkbox-label-color, unset)}.ic-checkbox-container .ic-checkbox-label.before{order:-1;margin-left:0;margin-right:8px}.ic-checkbox-container .ic-checkbox-label.after{order:1;margin-left:8px;margin-right:0}\n"] }]
        }], propDecorators: { formControl: [{
                type: Input
            }], checked: [{
                type: Input
            }], disabled: [{
                type: Input
            }], required: [{
                type: Input
            }], indeterminate: [{
                type: Input
            }], labelPosition: [{
                type: Input
            }], color: [{
                type: Input
            }], icCheckBoxType: [{
                type: Input
            }], name: [{
                type: Input
            }], id: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], ariaLabelledBy: [{
                type: Input
            }], checkboxChange: [{
                type: Output
            }], indeterminateChange: [{
                type: Output
            }] } });

class ImageComponent {
    constructor() {
        /** Fallback image source when `src` fails */
        this.srcFallback = '';
        /** Placeholder image shown while loading */
        this.placeholder = '';
        /** Custom CSS classes for styling */
        this.customClass = '';
        /** Alt text for the image */
        this.alt = 'Image';
        /** Tracks the current source being displayed */
        this.imageSrc = '';
        /** Tracks loading state */
        this.isLoading = true;
    }
    ngOnInit() {
        this.imageSrc = this.placeholder || this.src;
    }
    /**
     * Handle successful image loading
     */
    onLoad() {
        this.isLoading = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ImageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ImageComponent, selector: "ic-image", inputs: { src: "src", srcFallback: "srcFallback", placeholder: "placeholder", customClass: "customClass", alt: "alt", width: "width", height: "height" }, ngImport: i0, template: "<div class=\"ic-image-container\" [ngClass]=\"customClass\">\r\n  <!-- Placeholder -->\r\n  <div\r\n    *ngIf=\"isLoading && placeholder\"\r\n    class=\"ic-image-placeholder\"\r\n    [style.backgroundImage]=\"'url(' + placeholder + ')'\"></div>\r\n\r\n  <!-- Image -->\r\n  <img\r\n    *ngIf=\"!isLoading || !placeholder\"\r\n    [alt]=\"alt\"\r\n    class=\"ic-image\"\r\n    (load)=\"onLoad()\"\r\n    [icLazyLoad]=\"imageSrc\"\r\n    [fallbackImage]=\"srcFallback\"\r\n    [height]=\"height\"\r\n    [width]=\"width\"\r\n     />\r\n</div>\r\n", styles: [".ic-image-container{display:inline-block;position:relative;overflow:hidden;height:100%;width:100%}.ic-image-container .ic-image-placeholder{width:100%;height:100%;background-size:cover;background-position:center;background-repeat:no-repeat;animation:shimmer 1.5s infinite linear}.ic-image-container img.ic-image{display:block;width:100%;height:auto;object-fit:cover}@keyframes shimmer{0%{background-color:#f6f7f8}50%{background-color:#e0e0e0}to{background-color:#f6f7f8}}\n"], dependencies: [{ kind: "directive", type: i1$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: ImageLazyLoadDirective, selector: "[icLazyLoad]", inputs: ["icLazyLoad", "fallbackImage"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ImageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-image', template: "<div class=\"ic-image-container\" [ngClass]=\"customClass\">\r\n  <!-- Placeholder -->\r\n  <div\r\n    *ngIf=\"isLoading && placeholder\"\r\n    class=\"ic-image-placeholder\"\r\n    [style.backgroundImage]=\"'url(' + placeholder + ')'\"></div>\r\n\r\n  <!-- Image -->\r\n  <img\r\n    *ngIf=\"!isLoading || !placeholder\"\r\n    [alt]=\"alt\"\r\n    class=\"ic-image\"\r\n    (load)=\"onLoad()\"\r\n    [icLazyLoad]=\"imageSrc\"\r\n    [fallbackImage]=\"srcFallback\"\r\n    [height]=\"height\"\r\n    [width]=\"width\"\r\n     />\r\n</div>\r\n", styles: [".ic-image-container{display:inline-block;position:relative;overflow:hidden;height:100%;width:100%}.ic-image-container .ic-image-placeholder{width:100%;height:100%;background-size:cover;background-position:center;background-repeat:no-repeat;animation:shimmer 1.5s infinite linear}.ic-image-container img.ic-image{display:block;width:100%;height:auto;object-fit:cover}@keyframes shimmer{0%{background-color:#f6f7f8}50%{background-color:#e0e0e0}to{background-color:#f6f7f8}}\n"] }]
        }], propDecorators: { src: [{
                type: Input
            }], srcFallback: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], customClass: [{
                type: Input
            }], alt: [{
                type: Input
            }], width: [{
                type: Input
            }], height: [{
                type: Input
            }] } });

class SpinnerComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SpinnerComponent, selector: "ic-spinner", ngImport: i0, template: "<div id=\"pause\" class=\"d-flex align-items-center justify-content-center\">\r\n  <svg\r\n    xmlns=\"http://www.w3.org/2000/svg\"\r\n    xmlns:xlink=\"http://www.w3.org/1999/xlink\"\r\n    width=\"100\"\r\n    height=\"100\"\r\n    viewBox=\"0 -30 1 90\">\r\n    <defs>\r\n      <path\r\n        id=\"s\"\r\n        d=\"M22.169 52.51C9.873 48.435 2.129 39.706.936 28.535c-.504-4.73.338-15.402.9-21.322a5.905 5.905 0 0 1 4.566-5.346A83 83 0 0 1 23.294.054a83 83 0 0 1 16.874 1.812 5.905 5.905 0 0 1 4.584 5.346l.036.39c.738 7.985 1.413 16.733.832 21.032-1.8 13.164-12.106 20.96-21.16 23.863l-1.161.38z\"\r\n        fill=\"transparent\"\r\n        stroke=\"var(--ic-clr-primary-a0)\" />\r\n    </defs>\r\n\r\n    <g transform=\"translate(0, 0)\">\r\n      <!-- Shields Animation -->\r\n      <use\r\n        xlink:href=\"#s\"\r\n        transform=\"scale(-1,1) translate(-23 -26) scale(1.4, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use\r\n        xlink:href=\"#s\"\r\n        transform=\"scale(-1,1) translate(-23 -26) scale(1.3, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.15s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use\r\n        xlink:href=\"#s\"\r\n        transform=\"scale(-1,1) translate(-23 -26) scale(1.2, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.3s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use\r\n        xlink:href=\"#s\"\r\n        transform=\"scale(-1,1) translate(-23 -26) scale(1.1, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.45s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use\r\n        xlink:href=\"#s\"\r\n        transform=\"translate(-23 -26) scale(1.0, 1)\"\r\n        stroke-width=\"2\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.6s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use xlink:href=\"#s\" transform=\"translate(-23 -26) scale(1.1, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.75s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use xlink:href=\"#s\" transform=\"translate(-23 -26) scale(1.2, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.9s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use xlink:href=\"#s\" transform=\"translate(-23 -26) scale(1.3, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"1.05s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use xlink:href=\"#s\" transform=\"translate(-23 -26) scale(1.4, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"1.2s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n    </g>\r\n\r\n    <!-- Loading text and animated dots -->\r\n    <g\r\n      transform=\"translate(-50, 35)\"\r\n      font-size=\"6\"\r\n      fill=\"var(--ic-clr-primary-a0)\"\r\n      font-family=\"Arial, sans-serif\">\r\n      <text x=\"50\" y=\"5\" text-anchor=\"middle\" font-size=\"8\">Loading</text>\r\n      <circle cx=\"67\" cy=\"3\" r=\"1.2\" fill=\"var(--ic-clr-primary-a0)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"1.5s\"\r\n          begin=\"0s\"\r\n          repeatCount=\"indefinite\" />\r\n      </circle>\r\n      <circle cx=\"71\" cy=\"3\" r=\"1.2\" fill=\"var(--ic-clr-primary-a0)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"1.5s\"\r\n          begin=\"0.2s\"\r\n          repeatCount=\"indefinite\" />\r\n      </circle>\r\n      <circle cx=\"75\" cy=\"3\" r=\"1.2\" fill=\"var(--ic-clr-primary-a0)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"1.5s\"\r\n          begin=\"0.4s\"\r\n          repeatCount=\"indefinite\" />\r\n      </circle>\r\n    </g>\r\n  </svg>\r\n</div>\r\n", styles: ["@keyframes rotate{0%{transform:rotate(0)}to{transform:rotate(359deg)}}#pause{position:fixed;top:0;left:0;width:100%;height:100%;background-color:#00000080;z-index:1000;display:flex;align-items:center;justify-content:center}.custom-spinner{width:50px;height:50px;border:5px solid #f3f3f3;border-top:5px solid #3498db;border-radius:50%;animation:rotate 1s linear infinite}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-spinner', template: "<div id=\"pause\" class=\"d-flex align-items-center justify-content-center\">\r\n  <svg\r\n    xmlns=\"http://www.w3.org/2000/svg\"\r\n    xmlns:xlink=\"http://www.w3.org/1999/xlink\"\r\n    width=\"100\"\r\n    height=\"100\"\r\n    viewBox=\"0 -30 1 90\">\r\n    <defs>\r\n      <path\r\n        id=\"s\"\r\n        d=\"M22.169 52.51C9.873 48.435 2.129 39.706.936 28.535c-.504-4.73.338-15.402.9-21.322a5.905 5.905 0 0 1 4.566-5.346A83 83 0 0 1 23.294.054a83 83 0 0 1 16.874 1.812 5.905 5.905 0 0 1 4.584 5.346l.036.39c.738 7.985 1.413 16.733.832 21.032-1.8 13.164-12.106 20.96-21.16 23.863l-1.161.38z\"\r\n        fill=\"transparent\"\r\n        stroke=\"var(--ic-clr-primary-a0)\" />\r\n    </defs>\r\n\r\n    <g transform=\"translate(0, 0)\">\r\n      <!-- Shields Animation -->\r\n      <use\r\n        xlink:href=\"#s\"\r\n        transform=\"scale(-1,1) translate(-23 -26) scale(1.4, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use\r\n        xlink:href=\"#s\"\r\n        transform=\"scale(-1,1) translate(-23 -26) scale(1.3, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.15s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use\r\n        xlink:href=\"#s\"\r\n        transform=\"scale(-1,1) translate(-23 -26) scale(1.2, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.3s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use\r\n        xlink:href=\"#s\"\r\n        transform=\"scale(-1,1) translate(-23 -26) scale(1.1, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.45s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use\r\n        xlink:href=\"#s\"\r\n        transform=\"translate(-23 -26) scale(1.0, 1)\"\r\n        stroke-width=\"2\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.6s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use xlink:href=\"#s\" transform=\"translate(-23 -26) scale(1.1, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.75s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use xlink:href=\"#s\" transform=\"translate(-23 -26) scale(1.2, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"0.9s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use xlink:href=\"#s\" transform=\"translate(-23 -26) scale(1.3, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"1.05s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n      <use xlink:href=\"#s\" transform=\"translate(-23 -26) scale(1.4, 1)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"2s\"\r\n          begin=\"1.2s\"\r\n          repeatCount=\"indefinite\" />\r\n      </use>\r\n    </g>\r\n\r\n    <!-- Loading text and animated dots -->\r\n    <g\r\n      transform=\"translate(-50, 35)\"\r\n      font-size=\"6\"\r\n      fill=\"var(--ic-clr-primary-a0)\"\r\n      font-family=\"Arial, sans-serif\">\r\n      <text x=\"50\" y=\"5\" text-anchor=\"middle\" font-size=\"8\">Loading</text>\r\n      <circle cx=\"67\" cy=\"3\" r=\"1.2\" fill=\"var(--ic-clr-primary-a0)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"1.5s\"\r\n          begin=\"0s\"\r\n          repeatCount=\"indefinite\" />\r\n      </circle>\r\n      <circle cx=\"71\" cy=\"3\" r=\"1.2\" fill=\"var(--ic-clr-primary-a0)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"1.5s\"\r\n          begin=\"0.2s\"\r\n          repeatCount=\"indefinite\" />\r\n      </circle>\r\n      <circle cx=\"75\" cy=\"3\" r=\"1.2\" fill=\"var(--ic-clr-primary-a0)\">\r\n        <animate\r\n          attributeName=\"opacity\"\r\n          values=\"0.2;1;0.2\"\r\n          dur=\"1.5s\"\r\n          begin=\"0.4s\"\r\n          repeatCount=\"indefinite\" />\r\n      </circle>\r\n    </g>\r\n  </svg>\r\n</div>\r\n", styles: ["@keyframes rotate{0%{transform:rotate(0)}to{transform:rotate(359deg)}}#pause{position:fixed;top:0;left:0;width:100%;height:100%;background-color:#00000080;z-index:1000;display:flex;align-items:center;justify-content:center}.custom-spinner{width:50px;height:50px;border:5px solid #f3f3f3;border-top:5px solid #3498db;border-radius:50%;animation:rotate 1s linear infinite}\n"] }]
        }] });

class DatePickerComponent {
    constructor(datePipe) {
        this.datePipe = datePipe;
        this.control = new FormControl();
        this.placeholder = '';
        this.mandatory = false;
        this.disabled = false;
        this.readonly = false;
        this.dateFormat = 'MM-dd-yyyy';
        this.valueChange = new EventEmitter();
        this.isRequiredValidator = Validators.required;
        this.isCalendarVisible = false;
        this.isMonthSelectorVisible = false;
        this.isYearSelectorVisible = false;
        this.weekdays = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
        this.months = [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December',
        ];
        this.years = [];
        this.dates = [];
        this.currentDate = new Date();
    }
    ngOnInit() {
        this.minDate = this.minDate ? this.stripTime(this.minDate) : this.minDate;
        this.maxDate = this.maxDate ? this.stripTime(this.maxDate) : this.maxDate;
        this.initializeControl();
        this.updateCalendar(new Date());
        this.initializeYears();
    }
    ngAfterViewInit() {
        if (this.dateInput && this.dateInput.nativeElement) {
            const im = new Inputmask('99-99-9999');
            im.mask(this.dateInput.nativeElement);
        }
        else {
            console.error('dateInput is not available in AfterViewInit');
        }
    }
    ngOnChanges() {
        // Add or remove customError dynamically
        if (this.customError) {
            const currentErrors = this.control.errors || {};
            this.control.setErrors({ ...currentErrors, customError: true });
        }
        else {
            const currentErrors = this.control.errors || {};
            const { customError, ...rest } = currentErrors;
            this.control.setErrors(Object.keys(rest).length ? rest : null);
        }
    }
    initializeControl() {
        const originalValidator = this.control.validator;
        const validators = [];
        // 1. Append required validator only if not already present
        if (this.mandatory && !this.hasRequiredValidator(originalValidator)) {
            validators.push(Validators.required);
        }
        // 2. Append date range validator if minDate/maxDate is present
        if (this.minDate || this.maxDate) {
            validators.push(this.dateRangeValidator.bind(this));
        }
        // 3. Add any existing validator passed from parent
        if (originalValidator) {
            validators.push(originalValidator);
        }
        // Compose all validators together
        this.control.setValidators(Validators.compose(validators));
        this.control.updateValueAndValidity();
    }
    isRequired() {
        return this.mandatory || this.hasRequiredValidator(this.control.validator);
    }
    hasRequiredValidator(validator) {
        if (!validator)
            return false;
        const testControl = new FormControl('');
        const result = validator(testControl);
        return !!result?.['required'];
    }
    dateRangeValidator(control) {
        const rawValue = control.value;
        if (!rawValue)
            return null;
        const parsedDate = new Date(rawValue);
        if (isNaN(parsedDate.getTime()))
            return null;
        const stripped = this.stripTime(parsedDate);
        if (this.minDate && stripped < this.stripTime(this.minDate)) {
            return { minDate: true };
        }
        if (this.maxDate && stripped > this.stripTime(this.maxDate)) {
            return { maxDate: true };
        }
        return null;
    }
    stripTime(date) {
        return new Date(date.getFullYear(), date.getMonth(), date.getDate());
    }
    onInput(event) {
        this.control.markAsTouched();
        const raw = event.target.value.trim();
        if (raw) {
            const parsed = this.parseDate(raw);
            if (!parsed) {
                this.control.setErrors({ ...this.control.errors, invalidDate: true });
            }
            else {
                const errors = { ...this.control.errors };
                delete errors['invalidDate'];
                this.control.setErrors(Object.keys(errors).length ? errors : null);
            }
        }
    }
    onBlur() {
        const raw = this.dateInput.nativeElement.value.trim();
        // Handle empty value differently
        if (!raw) {
            if (this.isRequired()) {
                this.control.setErrors({ ...this.control.errors, required: true });
            }
            return;
        }
        const parsed = this.parseDate(raw);
        if (!parsed) {
            const currentErrors = this.control.errors || {};
            this.control.setErrors({ ...currentErrors, invalidDate: true });
        }
        else {
            const formatted = this.datePipe.transform(parsed, this.dateFormat);
            this.control.setValue(formatted, { emitEvent: false });
            // Clear invalidDate error if it exists
            const errors = { ...this.control.errors };
            delete errors['invalidDate'];
            this.control.setErrors(Object.keys(errors).length ? errors : null);
            // Check date range
            if (this.minDate || this.maxDate) {
                const rangeError = this.dateRangeValidator(this.control);
                if (rangeError) {
                    this.control.setErrors({ ...this.control.errors, ...rangeError });
                }
            }
        }
    }
    onToggleCalendar() {
        if (!this.readonly) {
            this.isCalendarVisible = !this.isCalendarVisible;
            if (this.isCalendarVisible) {
                if (this.control.value) {
                    const selectedDate = this.parseDate(this.control.value);
                    if (selectedDate) {
                        this.updateCalendar(selectedDate);
                    }
                    else {
                        this.updateCalendar(new Date());
                    }
                }
                else {
                    this.updateCalendar(new Date());
                }
            }
        }
    }
    closeDropdownOnClickOutside(event) {
        const target = event.target;
        const clickedInsideCalendar = target.closest('.ic-date-picker');
        const clickedInsideSelectors = target.closest('.month-selector') || target.closest('.year-selector');
        if (!clickedInsideCalendar && !clickedInsideSelectors) {
            this.isCalendarVisible = false;
        }
    }
    // private parseDate(value: string): Date | null {
    //   if (!value || typeof value !== 'string') return null;
    //   // First validate the format strictly (MM-DD-YYYY)
    //   const dateRegex = /^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])-(19|20)\d{2}$/;
    //   if (!dateRegex.test(value)) {
    //     return null;
    //   }
    //   const parts = value.split('-');
    //   if (parts.length !== 3) return null;
    //   const monthStr = parts[0];
    //   const dayStr = parts[1];
    //   const yearStr = parts[2];
    //   // Explicit type checking
    //   if (!monthStr || !dayStr || !yearStr) return null;
    //   const month = parseInt(monthStr, 10) - 1; // months are 0-based
    //   const day = parseInt(dayStr, 10);
    //   const year = parseInt(yearStr, 10);
    //   // Create the date in UTC to avoid timezone issues
    //   const date = new Date(Date.UTC(year, month, day));
    //   // Validate the date components match exactly
    //   if (
    //     date.getUTCFullYear() !== year ||
    //     date.getUTCMonth() !== month ||
    //     date.getUTCDate() !== day
    //   ) {
    //     return null; // Invalid date (like February 30)
    //   }
    //   return date;
    // }
    parseDate(value) {
        if (!value || typeof value !== 'string')
            return null;
        // Validate the format strictly (MM-DD-YYYY)
        const dateRegex = /^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])-(19|20)\d{2}$/;
        if (!dateRegex.test(value)) {
            return null;
        }
        const parts = value.split('-');
        if (parts.length !== 3)
            return null;
        const monthStr = parts[0];
        const dayStr = parts[1];
        const yearStr = parts[2];
        // Explicit type checking
        if (!monthStr || !dayStr || !yearStr)
            return null;
        const month = parseInt(monthStr, 10) - 1;
        const day = parseInt(dayStr, 10);
        const year = parseInt(yearStr, 10);
        // Create date in local timezone (or UTC if preferred)
        const date = new Date(year, month, day);
        // Check if the date components match the input (handles invalid dates like Feb 30)
        if (date.getFullYear() !== year ||
            date.getMonth() !== month ||
            date.getDate() !== day) {
            return null;
        }
        return date;
    }
    updateCalendar(date) {
        this.displayMonth = date.toLocaleString('default', { month: 'long' });
        this.displayYear = date.getFullYear();
        const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
        const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
        this.dates = [];
        for (let i = 0; i < firstDay.getDay(); i++) {
            this.dates.push({ display: '', value: null, disabled: true });
        }
        for (let d = 1; d <= lastDay.getDate(); d++) {
            const current = new Date(date.getFullYear(), date.getMonth(), d);
            const isDisabled = (this.minDate && current < this.minDate) ||
                (this.maxDate && current > this.maxDate);
            this.dates.push({ display: d, value: current, disabled: isDisabled });
        }
        this.currentDate = date;
    }
    navigateMonth(direction) {
        const newDate = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth() + direction);
        this.currentDate = newDate;
        this.updateCalendar(newDate);
    }
    selectDate(date) {
        if (!date)
            return;
        const formatted = this.formatDate(date);
        this.control.setValue(formatted);
        this.control.markAsTouched();
        this.valueChange.emit(formatted);
        this.updateCalendar(date);
        this.isCalendarVisible = false;
    }
    isSelectedDate(date) {
        return (date &&
            this.control.value &&
            new Date(this.control.value).toDateString() === date.toDateString());
    }
    toggleMonthSelector() {
        this.isMonthSelectorVisible = !this.isMonthSelectorVisible;
        this.isYearSelectorVisible = false;
    }
    toggleYearSelector() {
        this.isYearSelectorVisible = !this.isYearSelectorVisible;
        this.isMonthSelectorVisible = false;
    }
    selectMonth(monthIndex) {
        const newDate = new Date(this.currentDate.getFullYear(), monthIndex);
        this.currentDate = newDate;
        this.updateCalendar(newDate);
        this.isMonthSelectorVisible = false;
    }
    selectYear(year) {
        const newDate = new Date(year, this.currentDate.getMonth());
        this.currentDate = newDate;
        this.updateCalendar(newDate);
        this.isYearSelectorVisible = false;
        this.isMonthSelectorVisible = true;
    }
    initializeYears() {
        const currentYear = this.currentDate.getFullYear();
        const startYear = currentYear - 100;
        const endYear = currentYear + 500;
        for (let year = startYear; year <= endYear; year++) {
            this.years.push(year);
        }
    }
    formatDate(date) {
        if (!date || !(date instanceof Date) || isNaN(date.getTime())) {
            return '';
        }
        const month = date.getMonth() + 1; // Months are 0-based
        const day = date.getDate();
        const year = date.getFullYear();
        // Pad with leading zeros if needed
        const pad = (num) => (num < 10 ? `0${num}` : num);
        return `${pad(month)}-${pad(day)}-${year}`;
    }
    isValidDate(date) {
        if (!date)
            return true;
        const parsed = new Date(date);
        return !isNaN(parsed.getTime());
    }
    dateDispatchEvent(_e) {
        this.valueChange.emit(this.control.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DatePickerComponent, deps: [{ token: i1$1.DatePipe }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: DatePickerComponent, selector: "ic-date-picker", inputs: { control: "control", label: "label", placeholder: "placeholder", minDate: "minDate", maxDate: "maxDate", mandatory: "mandatory", disabled: "disabled", readonly: "readonly", dateFormat: "dateFormat", customError: "customError" }, outputs: { valueChange: "valueChange" }, host: { listeners: { "document:click": "closeDropdownOnClickOutside($event)" } }, providers: [DatePipe], viewQueries: [{ propertyName: "dateInput", first: true, predicate: ["dateInput"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"ic-date-picker\" [class.disabled]=\"disabled || readonly\">\r\n  <label *ngIf=\"label\" class=\"floated\">\r\n    {{ label }}\r\n    <span *ngIf=\"isRequired()\" class=\"required-star\" style=\"color: red\">*</span>\r\n  </label>\r\n\r\n  <div\r\n    class=\"input-container\"\r\n    [class.has-error]=\"control.invalid && (control.dirty || control.touched)\"\r\n    #calendarHeader>\r\n    <input\r\n      #dateInput\r\n      id=\"dateInput\"\r\n      type=\"text\"\r\n      [formControl]=\"control\"\r\n      [placeholder]=\"placeholder || dateFormat\"\r\n      [readonly]=\"readonly\"\r\n      (input)=\"onInput($event)\"\r\n      (blur)=\"onBlur()\"\r\n      (change)=\"dateDispatchEvent($event)\" />\r\n    <ic-icon\r\n      name=\"calendar\"\r\n      style=\"--ic-icon-color: var(--ic-text-black, #000000)\"\r\n      tabindex=\"0\"\r\n      role=\"button\"\r\n      (keydown.enter)=\"onToggleCalendar()\"\r\n      (click)=\"onToggleCalendar()\"></ic-icon>\r\n  </div>\r\n\r\n  <div class=\"calendar-container\" [class.show]=\"isCalendarVisible\" #calendar>\r\n    <div class=\"custom-calendar\">\r\n      <div class=\"calendar-header\">\r\n        <div>\r\n          <span class=\"dp_nav_header_text\" (click)=\"toggleMonthSelector()\">\r\n            {{ displayMonth }}\r\n          </span>\r\n          &nbsp;\r\n          <span class=\"dp_nav_header_text\" (click)=\"toggleYearSelector()\">\r\n            {{ displayYear }}\r\n          </span>\r\n        </div>\r\n        <div class=\"navigation_btn_div\">\r\n          <ic-icon\r\n            name=\"keyboard-arrow-left\"\r\n            class=\"dp_nav_btn\"\r\n            (click)=\"navigateMonth(-1)\"></ic-icon>\r\n          <ic-icon\r\n            name=\"keyboard-arrow-right\"\r\n            class=\"dp_nav_btn\"\r\n            (click)=\"navigateMonth(1)\"></ic-icon>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"calendar-body\">\r\n        <div\r\n          class=\"calendar-weekdays\"\r\n          *ngIf=\"!isMonthSelectorVisible && !isYearSelectorVisible\">\r\n          <span *ngFor=\"let day of weekdays\">{{ day }}</span>\r\n        </div>\r\n        <hr class=\"my-2\" />\r\n        <div\r\n          class=\"calendar-dates\"\r\n          *ngIf=\"!isMonthSelectorVisible && !isYearSelectorVisible\">\r\n          <span\r\n            *ngFor=\"let date of dates\"\r\n            [class.disabledCell]=\"date.disabled\"\r\n            [class.selectedCell]=\"isSelectedDate(date.value)\"\r\n            (click)=\"selectDate(date.value)\">\r\n            {{ date.display }}\r\n          </span>\r\n        </div>\r\n\r\n        <div class=\"month-selector\" *ngIf=\"isMonthSelectorVisible\">\r\n          <span\r\n            *ngFor=\"let month of months; let i = index\"\r\n            (click)=\"selectMonth(i)\">\r\n            {{ month }}\r\n          </span>\r\n        </div>\r\n\r\n        <div class=\"year-selector\" *ngIf=\"isYearSelectorVisible\">\r\n          <span *ngFor=\"let year of years\" (click)=\"selectYear(year)\">\r\n            {{ year }}\r\n          </span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"error-message\">\r\n    <ng-container *ngIf=\"control.hasError('required') && control.touched\">\r\n      {{ label }} is required!\r\n    </ng-container>\r\n    <ng-container\r\n      *ngIf=\"\r\n        control.hasError('invalidDate') && (control.dirty || control.touched)\r\n      \">\r\n      Invalid date format!\r\n    </ng-container>\r\n    <ng-container *ngIf=\"control.hasError('minDate')\">\r\n      Date must be after {{ minDate | date: dateFormat }}.\r\n    </ng-container>\r\n    <ng-container *ngIf=\"control.hasError('maxDate')\">\r\n      Date must be before {{ maxDate | date: dateFormat }}.\r\n    </ng-container>\r\n    <ng-container *ngIf=\"control.hasError('customError')\">\r\n      {{ customError }}\r\n    </ng-container>\r\n  </div>\r\n</div>\r\n", styles: [".ic-date-picker{display:flex;flex-direction:column;position:relative;margin:8px 0;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.ic-date-picker.disabled{pointer-events:none}.ic-date-picker.disabled .input-container{background-color:var(--ic-date-picker-disabled-bg, #f3f3f3)!important;border-color:var(--ic-date-picker-disabled-border, #dcdcdc)!important;box-shadow:none!important;color:var(--ic-date-picker-disabled-color, gray)!important}.ic-date-picker label{position:absolute;left:clamp(12px,2vw,20px);font-size:clamp(12px,1vw,14px);transition:font-size .3s ease,transform .3s ease,color .3s ease,padding .3s ease;color:var(--ic-date-picker-label-color, #666);font-family:var(--ic-primary-font-family),sans-serif;transform:translateY(9px)!important;z-index:2}.ic-date-picker label.floated{left:clamp(10px,1.5vw,16px);transform:translateY(-8px)!important;font-size:clamp(11px,1vw,13px);color:var(--ic-date-picker-label-active-color, #0033a1);background:var(--ic-date-picker-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0), #fff 57%, rgba(0, 128, 0, 0)));padding:0 clamp(2px,.5vw,6px);z-index:1}.ic-date-picker label.floated .required-star{color:var(--ic-date-picker-required-star, red)}.ic-date-picker .input-container{position:relative;display:flex;justify-content:space-between;flex-direction:row;align-items:center;padding:clamp(6px,1vw,10px) clamp(4px,1vw,12px) clamp(6px,1vw,10px) clamp(12px,2vw,16px);height:40px;font-size:clamp(13px,1vw,15px)!important;border:2px solid var(--ic-date-picker-border, #dcdcdc);border-radius:8px;background:var(--ic-date-picker-bg, #fff);outline:none;transition:padding .3s ease,border-color .3s ease,box-shadow .3s ease,background-color .3s ease}.ic-date-picker .input-container:has(input:focus){border-color:var(--ic-date-picker-border-focus, #0033a1)}.ic-date-picker .input-container.has-error{border-color:var(--ic-date-picker-border-error, red)}.ic-date-picker .input-container:has(input:disabled){background-color:var(--ic-date-picker-disabled-bg, #f3f3f3);border-color:var(--ic-date-picker-disabled-border, #dcdcdc);box-shadow:none;cursor:not-allowed}.ic-date-picker .input-container input{flex:1;border:none;outline:none;font-size:clamp(13px,1vw,15px);background:transparent;width:70%;transition:font-size .3s ease;color:var(--ic-date-picker-input-color, inherit)}.ic-date-picker .input-container .calendar-toggle{background:none;border:none;cursor:pointer;font-size:clamp(16px,1.5vw,20px);transition:font-size .3s ease;color:var(--ic-date-picker-calendar-toggle-color, inherit)}.ic-date-picker .calendar-container{position:absolute;top:calc(100% + 4px);left:0;min-width:100%;max-width:100%;width:max-content;max-height:400px;overflow:auto;z-index:999;background:var(--ic-date-picker-calendar-bg, #fff);border-radius:8px;box-shadow:var(--ic-date-picker-calendar-shadow, 0 3px 15px rgba(0, 0, 0, .15));padding:clamp(8px,2vw,16px);transition:opacity .3s ease,transform .3s ease,padding .3s ease;opacity:0;transform:scaleY(.95);pointer-events:none}.ic-date-picker .calendar-container.show{opacity:1;transform:scaleY(1);pointer-events:auto;min-width:355px}.ic-date-picker .calendar-container .calendar-header{display:flex;justify-content:space-between;align-items:center;gap:clamp(4px,1vw,8px)}.ic-date-picker .calendar-container .calendar-header button,.ic-date-picker .calendar-container .calendar-header span{background:none;border:none;cursor:pointer;font-size:clamp(14px,1vw,16px);font-weight:700;padding:clamp(4px,.8vw,10px) clamp(6px,1.2vw,12px);transition:background .2s ease,padding .3s ease}.ic-date-picker .calendar-container .calendar-header button:hover,.ic-date-picker .calendar-container .calendar-header span:hover{background:var(--ic-date-picker-calendar-header-hover-bg, #ededed)}.ic-date-picker .calendar-container .calendar-header .navigation_btn_div{display:flex;color:var(--ic-date-picker-calendar-nav-color, #0033a1)!important;gap:5px;transition:all .23s linear}.ic-date-picker .calendar-container .calendar-header .navigation_btn_div ic-icon{height:auto;border-radius:6px;padding:3px}.ic-date-picker .calendar-container .calendar-header .navigation_btn_div ic-icon:hover{background:var(--ic-date-picker-calendar-nav-hover-bg, #f0f0f0);cursor:pointer}.ic-date-picker .calendar-container .calendar-header span.dp_nav_header_text{padding:clamp(4px,1vw,8px) clamp(8px,2vw,12px);border-radius:8px;background:var(--ic-date-picker-calendar-header-bg, #e6efff);color:var(--ic-date-picker-calendar-header-color, #0033a1)!important}.ic-date-picker .calendar-container .calendar-header button.dp_nav_btn{height:40px;width:40px;background:transparent;border-radius:50%}.ic-date-picker .calendar-container .calendar-weekdays,.ic-date-picker .calendar-container .calendar-dates{display:grid;grid-template-columns:repeat(7,1fr);text-align:center;gap:clamp(2px,.5vw,6px)}.ic-date-picker .calendar-container .calendar-weekdays span,.ic-date-picker .calendar-container .calendar-dates span{padding:clamp(6px,1vw,10px);border-radius:50%;cursor:pointer;aspect-ratio:1;display:inline-flex;justify-content:center;align-items:center;transition:background .2s ease;color:var(--ic-date-picker-calendar-date-color, inherit)}.ic-date-picker .calendar-container .calendar-weekdays span.disabledCell,.ic-date-picker .calendar-container .calendar-dates span.disabledCell{color:var(--ic-date-picker-calendar-date-disabled-color, #aaa);pointer-events:none}.ic-date-picker .calendar-container .calendar-weekdays span.selectedCell,.ic-date-picker .calendar-container .calendar-dates span.selectedCell{background-color:var(--ic-date-picker-calendar-date-selected-bg, #007bff);color:var(--ic-date-picker-calendar-date-selected-color, #fff)}.ic-date-picker .calendar-container .calendar-weekdays span:hover:not(.disabledCell),.ic-date-picker .calendar-container .calendar-dates span:hover:not(.disabledCell){background-color:var(--ic-date-picker-calendar-date-hover-bg, #f0f0f0)}.ic-date-picker .calendar-container .month-selector,.ic-date-picker .calendar-container .year-selector{height:250px;overflow:auto;display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(6px,1vw,10px);text-align:center;padding:clamp(4px,1vw,8px)}.ic-date-picker .calendar-container .month-selector span,.ic-date-picker .calendar-container .year-selector span{padding:clamp(6px,1vw,10px);border:1px solid var(--ic-date-picker-calendar-selector-border, #ccc);border-radius:40px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;transition:background .2s ease,border-color .3s ease}.ic-date-picker .calendar-container .month-selector span:hover,.ic-date-picker .calendar-container .year-selector span:hover{background-color:var(--ic-date-picker-calendar-selector-hover-bg, #f0f0f0)}.ic-date-picker .error-message{color:var(--ic-date-picker-error-color, red);font-size:12px;margin:0 16px;display:flex;align-items:center;gap:5px;z-index:4;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}\n"], dependencies: [{ kind: "directive", type: i1$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: NoInitialSpaceDirective, selector: "input, textarea" }, { kind: "component", type: IconComponent, selector: "ic-icon", inputs: ["name", "color", "size"] }, { kind: "pipe", type: i1$1.DatePipe, name: "date" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-date-picker', providers: [DatePipe], template: "<div class=\"ic-date-picker\" [class.disabled]=\"disabled || readonly\">\r\n  <label *ngIf=\"label\" class=\"floated\">\r\n    {{ label }}\r\n    <span *ngIf=\"isRequired()\" class=\"required-star\" style=\"color: red\">*</span>\r\n  </label>\r\n\r\n  <div\r\n    class=\"input-container\"\r\n    [class.has-error]=\"control.invalid && (control.dirty || control.touched)\"\r\n    #calendarHeader>\r\n    <input\r\n      #dateInput\r\n      id=\"dateInput\"\r\n      type=\"text\"\r\n      [formControl]=\"control\"\r\n      [placeholder]=\"placeholder || dateFormat\"\r\n      [readonly]=\"readonly\"\r\n      (input)=\"onInput($event)\"\r\n      (blur)=\"onBlur()\"\r\n      (change)=\"dateDispatchEvent($event)\" />\r\n    <ic-icon\r\n      name=\"calendar\"\r\n      style=\"--ic-icon-color: var(--ic-text-black, #000000)\"\r\n      tabindex=\"0\"\r\n      role=\"button\"\r\n      (keydown.enter)=\"onToggleCalendar()\"\r\n      (click)=\"onToggleCalendar()\"></ic-icon>\r\n  </div>\r\n\r\n  <div class=\"calendar-container\" [class.show]=\"isCalendarVisible\" #calendar>\r\n    <div class=\"custom-calendar\">\r\n      <div class=\"calendar-header\">\r\n        <div>\r\n          <span class=\"dp_nav_header_text\" (click)=\"toggleMonthSelector()\">\r\n            {{ displayMonth }}\r\n          </span>\r\n          &nbsp;\r\n          <span class=\"dp_nav_header_text\" (click)=\"toggleYearSelector()\">\r\n            {{ displayYear }}\r\n          </span>\r\n        </div>\r\n        <div class=\"navigation_btn_div\">\r\n          <ic-icon\r\n            name=\"keyboard-arrow-left\"\r\n            class=\"dp_nav_btn\"\r\n            (click)=\"navigateMonth(-1)\"></ic-icon>\r\n          <ic-icon\r\n            name=\"keyboard-arrow-right\"\r\n            class=\"dp_nav_btn\"\r\n            (click)=\"navigateMonth(1)\"></ic-icon>\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"calendar-body\">\r\n        <div\r\n          class=\"calendar-weekdays\"\r\n          *ngIf=\"!isMonthSelectorVisible && !isYearSelectorVisible\">\r\n          <span *ngFor=\"let day of weekdays\">{{ day }}</span>\r\n        </div>\r\n        <hr class=\"my-2\" />\r\n        <div\r\n          class=\"calendar-dates\"\r\n          *ngIf=\"!isMonthSelectorVisible && !isYearSelectorVisible\">\r\n          <span\r\n            *ngFor=\"let date of dates\"\r\n            [class.disabledCell]=\"date.disabled\"\r\n            [class.selectedCell]=\"isSelectedDate(date.value)\"\r\n            (click)=\"selectDate(date.value)\">\r\n            {{ date.display }}\r\n          </span>\r\n        </div>\r\n\r\n        <div class=\"month-selector\" *ngIf=\"isMonthSelectorVisible\">\r\n          <span\r\n            *ngFor=\"let month of months; let i = index\"\r\n            (click)=\"selectMonth(i)\">\r\n            {{ month }}\r\n          </span>\r\n        </div>\r\n\r\n        <div class=\"year-selector\" *ngIf=\"isYearSelectorVisible\">\r\n          <span *ngFor=\"let year of years\" (click)=\"selectYear(year)\">\r\n            {{ year }}\r\n          </span>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"error-message\">\r\n    <ng-container *ngIf=\"control.hasError('required') && control.touched\">\r\n      {{ label }} is required!\r\n    </ng-container>\r\n    <ng-container\r\n      *ngIf=\"\r\n        control.hasError('invalidDate') && (control.dirty || control.touched)\r\n      \">\r\n      Invalid date format!\r\n    </ng-container>\r\n    <ng-container *ngIf=\"control.hasError('minDate')\">\r\n      Date must be after {{ minDate | date: dateFormat }}.\r\n    </ng-container>\r\n    <ng-container *ngIf=\"control.hasError('maxDate')\">\r\n      Date must be before {{ maxDate | date: dateFormat }}.\r\n    </ng-container>\r\n    <ng-container *ngIf=\"control.hasError('customError')\">\r\n      {{ customError }}\r\n    </ng-container>\r\n  </div>\r\n</div>\r\n", styles: [".ic-date-picker{display:flex;flex-direction:column;position:relative;margin:8px 0;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.ic-date-picker.disabled{pointer-events:none}.ic-date-picker.disabled .input-container{background-color:var(--ic-date-picker-disabled-bg, #f3f3f3)!important;border-color:var(--ic-date-picker-disabled-border, #dcdcdc)!important;box-shadow:none!important;color:var(--ic-date-picker-disabled-color, gray)!important}.ic-date-picker label{position:absolute;left:clamp(12px,2vw,20px);font-size:clamp(12px,1vw,14px);transition:font-size .3s ease,transform .3s ease,color .3s ease,padding .3s ease;color:var(--ic-date-picker-label-color, #666);font-family:var(--ic-primary-font-family),sans-serif;transform:translateY(9px)!important;z-index:2}.ic-date-picker label.floated{left:clamp(10px,1.5vw,16px);transform:translateY(-8px)!important;font-size:clamp(11px,1vw,13px);color:var(--ic-date-picker-label-active-color, #0033a1);background:var(--ic-date-picker-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0), #fff 57%, rgba(0, 128, 0, 0)));padding:0 clamp(2px,.5vw,6px);z-index:1}.ic-date-picker label.floated .required-star{color:var(--ic-date-picker-required-star, red)}.ic-date-picker .input-container{position:relative;display:flex;justify-content:space-between;flex-direction:row;align-items:center;padding:clamp(6px,1vw,10px) clamp(4px,1vw,12px) clamp(6px,1vw,10px) clamp(12px,2vw,16px);height:40px;font-size:clamp(13px,1vw,15px)!important;border:2px solid var(--ic-date-picker-border, #dcdcdc);border-radius:8px;background:var(--ic-date-picker-bg, #fff);outline:none;transition:padding .3s ease,border-color .3s ease,box-shadow .3s ease,background-color .3s ease}.ic-date-picker .input-container:has(input:focus){border-color:var(--ic-date-picker-border-focus, #0033a1)}.ic-date-picker .input-container.has-error{border-color:var(--ic-date-picker-border-error, red)}.ic-date-picker .input-container:has(input:disabled){background-color:var(--ic-date-picker-disabled-bg, #f3f3f3);border-color:var(--ic-date-picker-disabled-border, #dcdcdc);box-shadow:none;cursor:not-allowed}.ic-date-picker .input-container input{flex:1;border:none;outline:none;font-size:clamp(13px,1vw,15px);background:transparent;width:70%;transition:font-size .3s ease;color:var(--ic-date-picker-input-color, inherit)}.ic-date-picker .input-container .calendar-toggle{background:none;border:none;cursor:pointer;font-size:clamp(16px,1.5vw,20px);transition:font-size .3s ease;color:var(--ic-date-picker-calendar-toggle-color, inherit)}.ic-date-picker .calendar-container{position:absolute;top:calc(100% + 4px);left:0;min-width:100%;max-width:100%;width:max-content;max-height:400px;overflow:auto;z-index:999;background:var(--ic-date-picker-calendar-bg, #fff);border-radius:8px;box-shadow:var(--ic-date-picker-calendar-shadow, 0 3px 15px rgba(0, 0, 0, .15));padding:clamp(8px,2vw,16px);transition:opacity .3s ease,transform .3s ease,padding .3s ease;opacity:0;transform:scaleY(.95);pointer-events:none}.ic-date-picker .calendar-container.show{opacity:1;transform:scaleY(1);pointer-events:auto;min-width:355px}.ic-date-picker .calendar-container .calendar-header{display:flex;justify-content:space-between;align-items:center;gap:clamp(4px,1vw,8px)}.ic-date-picker .calendar-container .calendar-header button,.ic-date-picker .calendar-container .calendar-header span{background:none;border:none;cursor:pointer;font-size:clamp(14px,1vw,16px);font-weight:700;padding:clamp(4px,.8vw,10px) clamp(6px,1.2vw,12px);transition:background .2s ease,padding .3s ease}.ic-date-picker .calendar-container .calendar-header button:hover,.ic-date-picker .calendar-container .calendar-header span:hover{background:var(--ic-date-picker-calendar-header-hover-bg, #ededed)}.ic-date-picker .calendar-container .calendar-header .navigation_btn_div{display:flex;color:var(--ic-date-picker-calendar-nav-color, #0033a1)!important;gap:5px;transition:all .23s linear}.ic-date-picker .calendar-container .calendar-header .navigation_btn_div ic-icon{height:auto;border-radius:6px;padding:3px}.ic-date-picker .calendar-container .calendar-header .navigation_btn_div ic-icon:hover{background:var(--ic-date-picker-calendar-nav-hover-bg, #f0f0f0);cursor:pointer}.ic-date-picker .calendar-container .calendar-header span.dp_nav_header_text{padding:clamp(4px,1vw,8px) clamp(8px,2vw,12px);border-radius:8px;background:var(--ic-date-picker-calendar-header-bg, #e6efff);color:var(--ic-date-picker-calendar-header-color, #0033a1)!important}.ic-date-picker .calendar-container .calendar-header button.dp_nav_btn{height:40px;width:40px;background:transparent;border-radius:50%}.ic-date-picker .calendar-container .calendar-weekdays,.ic-date-picker .calendar-container .calendar-dates{display:grid;grid-template-columns:repeat(7,1fr);text-align:center;gap:clamp(2px,.5vw,6px)}.ic-date-picker .calendar-container .calendar-weekdays span,.ic-date-picker .calendar-container .calendar-dates span{padding:clamp(6px,1vw,10px);border-radius:50%;cursor:pointer;aspect-ratio:1;display:inline-flex;justify-content:center;align-items:center;transition:background .2s ease;color:var(--ic-date-picker-calendar-date-color, inherit)}.ic-date-picker .calendar-container .calendar-weekdays span.disabledCell,.ic-date-picker .calendar-container .calendar-dates span.disabledCell{color:var(--ic-date-picker-calendar-date-disabled-color, #aaa);pointer-events:none}.ic-date-picker .calendar-container .calendar-weekdays span.selectedCell,.ic-date-picker .calendar-container .calendar-dates span.selectedCell{background-color:var(--ic-date-picker-calendar-date-selected-bg, #007bff);color:var(--ic-date-picker-calendar-date-selected-color, #fff)}.ic-date-picker .calendar-container .calendar-weekdays span:hover:not(.disabledCell),.ic-date-picker .calendar-container .calendar-dates span:hover:not(.disabledCell){background-color:var(--ic-date-picker-calendar-date-hover-bg, #f0f0f0)}.ic-date-picker .calendar-container .month-selector,.ic-date-picker .calendar-container .year-selector{height:250px;overflow:auto;display:grid;grid-template-columns:repeat(3,1fr);gap:clamp(6px,1vw,10px);text-align:center;padding:clamp(4px,1vw,8px)}.ic-date-picker .calendar-container .month-selector span,.ic-date-picker .calendar-container .year-selector span{padding:clamp(6px,1vw,10px);border:1px solid var(--ic-date-picker-calendar-selector-border, #ccc);border-radius:40px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;transition:background .2s ease,border-color .3s ease}.ic-date-picker .calendar-container .month-selector span:hover,.ic-date-picker .calendar-container .year-selector span:hover{background-color:var(--ic-date-picker-calendar-selector-hover-bg, #f0f0f0)}.ic-date-picker .error-message{color:var(--ic-date-picker-error-color, red);font-size:12px;margin:0 16px;display:flex;align-items:center;gap:5px;z-index:4;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$1.DatePipe }]; }, propDecorators: { control: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], minDate: [{
                type: Input
            }], maxDate: [{
                type: Input
            }], mandatory: [{
                type: Input
            }], disabled: [{
                type: Input
            }], readonly: [{
                type: Input
            }], dateFormat: [{
                type: Input
            }], customError: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], dateInput: [{
                type: ViewChild,
                args: ['dateInput', { static: false }]
            }], closeDropdownOnClickOutside: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

const PERFECT_SCROLLBAR_CONFIG = new InjectionToken('PERFECT_SCROLLBAR_CONFIG');
class Geometry {
    constructor(x, y, w, h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
}
class Position {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
}
const PerfectScrollbarEvents = [
    'psScrollY',
    'psScrollX',
    'psScrollUp',
    'psScrollDown',
    'psScrollLeft',
    'psScrollRight',
    'psYReachEnd',
    'psYReachStart',
    'psXReachEnd',
    'psXReachStart',
];
class PerfectScrollbarConfig {
    constructor(config = {}) {
        this.assign(config);
    }
    assign(config = {}) {
        for (const key in config) {
            this[key] = config[key];
        }
    }
}

class PerfectScrollbarDirective {
    constructor(zone, differs, elementRef, platformId, defaults) {
        this.zone = zone;
        this.differs = differs;
        this.elementRef = elementRef;
        this.platformId = platformId;
        this.defaults = defaults;
        this.instance = null;
        this.ro = null;
        this.timeout = null;
        this.animation = null;
        this.configDiff = null;
        this.ngDestroy = new Subject();
        this.disabled = false;
        this.psScrollY = new EventEmitter();
        this.psScrollX = new EventEmitter();
        this.psScrollUp = new EventEmitter();
        this.psScrollDown = new EventEmitter();
        this.psScrollLeft = new EventEmitter();
        this.psScrollRight = new EventEmitter();
        this.psYReachEnd = new EventEmitter();
        this.psYReachStart = new EventEmitter();
        this.psXReachEnd = new EventEmitter();
        this.psXReachStart = new EventEmitter();
    }
    ngOnInit() {
        if (this.platformId) {
            if (!this.disabled && isPlatformBrowser(this.platformId)) {
                const config = new PerfectScrollbarConfig(this.defaults);
                config.assign(this.config); // Custom configuration
                this.zone.runOutsideAngular(() => {
                    this.instance = new PerfectScrollbar(this.elementRef.nativeElement, config);
                });
                if (!this.configDiff) {
                    this.configDiff = this.differs.find(this.config || {}).create();
                    this.configDiff.diff(this.config || {});
                }
                this.zone.runOutsideAngular(() => {
                    this.ro = new ResizeObserver(() => {
                        this.update();
                    });
                    if (this.elementRef.nativeElement.children[0]) {
                        this.ro.observe(this.elementRef.nativeElement.children[0]);
                    }
                    this.ro.observe(this.elementRef.nativeElement);
                });
                this.zone.runOutsideAngular(() => {
                    PerfectScrollbarEvents.forEach((eventName) => {
                        const eventType = eventName.replace(/([A-Z])/g, (c) => `-${c.toLowerCase()}`);
                        fromEvent(this.elementRef.nativeElement, eventType)
                            .pipe(auditTime(20), takeUntil(this.ngDestroy))
                            .subscribe((event) => {
                            this[eventName].emit(event);
                        });
                    });
                });
            }
        }
    }
    ngOnDestroy() {
        if (this.platformId) {
            if (isPlatformBrowser(this.platformId)) {
                this.ngDestroy.next();
                this.ngDestroy.complete();
                if (this.ro) {
                    this.ro.disconnect();
                }
                if (this.timeout && typeof window !== 'undefined') {
                    window.clearTimeout(this.timeout);
                }
                this.zone.runOutsideAngular(() => {
                    if (this.instance) {
                        this.instance.destroy();
                    }
                });
                this.instance = null;
            }
        }
    }
    ngDoCheck() {
        if (this.platformId) {
            if (!this.disabled &&
                this.configDiff &&
                isPlatformBrowser(this.platformId)) {
                const changes = this.configDiff.diff(this.config || {});
                if (changes) {
                    this.ngOnDestroy();
                    this.ngOnInit();
                }
            }
        }
    }
    ngOnChanges(changes) {
        if (this.platformId) {
            if (changes['disabled'] &&
                !changes['disabled'].isFirstChange() &&
                isPlatformBrowser(this.platformId)) {
                if (changes['disabled'].currentValue !== changes['disabled'].previousValue) {
                    if (changes['disabled'].currentValue === true) {
                        this.ngOnDestroy();
                    }
                    else if (changes['disabled'].currentValue === false) {
                        this.ngOnInit();
                    }
                }
            }
        }
    }
    ps() {
        return this.instance;
    }
    update() {
        if (typeof window !== 'undefined') {
            if (this.timeout) {
                window.clearTimeout(this.timeout);
            }
            this.timeout = window.setTimeout(() => {
                if (!this.disabled && this.configDiff) {
                    try {
                        this.zone.runOutsideAngular(() => {
                            if (this.instance) {
                                this.instance.update();
                            }
                        });
                    }
                    catch (error) {
                        // Update can be finished after destroy so catch errors
                    }
                }
            }, 0);
        }
    }
    geometry(prefix = 'scroll') {
        return new Geometry(this.elementRef.nativeElement[prefix + 'Left'], this.elementRef.nativeElement[prefix + 'Top'], this.elementRef.nativeElement[prefix + 'Width'], this.elementRef.nativeElement[prefix + 'Height']);
    }
    position(absolute = false) {
        if (!absolute && this.instance) {
            return new Position(this.instance.reach.x || 0, this.instance.reach.y || 0);
        }
        else {
            return new Position(this.elementRef.nativeElement.scrollLeft, this.elementRef.nativeElement.scrollTop);
        }
    }
    scrollable(direction = 'any') {
        const element = this.elementRef.nativeElement;
        if (direction === 'any') {
            return (element.classList.contains('ps--active-x') ||
                element.classList.contains('ps--active-y'));
        }
        else if (direction === 'both') {
            return (element.classList.contains('ps--active-x') &&
                element.classList.contains('ps--active-y'));
        }
        else {
            return element.classList.contains('ps--active-' + direction);
        }
    }
    scrollTo(x, y, speed) {
        if (!this.disabled) {
            if (y == null && speed == null) {
                this.animateScrolling('scrollTop', x, speed);
            }
            else {
                if (x != null) {
                    this.animateScrolling('scrollLeft', x, speed);
                }
                if (y != null) {
                    this.animateScrolling('scrollTop', y, speed);
                }
            }
        }
    }
    scrollToX(x, speed) {
        this.animateScrolling('scrollLeft', x, speed);
    }
    scrollToY(y, speed) {
        this.animateScrolling('scrollTop', y, speed);
    }
    scrollToTop(offset, speed) {
        this.animateScrolling('scrollTop', offset || 0, speed);
    }
    scrollToLeft(offset, speed) {
        this.animateScrolling('scrollLeft', offset || 0, speed);
    }
    scrollToRight(offset, speed) {
        const left = this.elementRef.nativeElement.scrollWidth -
            this.elementRef.nativeElement.clientWidth;
        this.animateScrolling('scrollLeft', left - (offset || 0), speed);
    }
    scrollToBottom(offset, speed) {
        const top = this.elementRef.nativeElement.scrollHeight -
            this.elementRef.nativeElement.clientHeight;
        this.animateScrolling('scrollTop', top - (offset || 0), speed);
    }
    scrollToElement(element, offset, speed) {
        if (typeof element === 'string') {
            element = this.elementRef.nativeElement.querySelector(element);
        }
        if (element) {
            const elementPos = element.getBoundingClientRect();
            const scrollerPos = this.elementRef.nativeElement.getBoundingClientRect();
            if (this.elementRef.nativeElement.classList.contains('ps--active-x')) {
                const currentPos = this.elementRef.nativeElement['scrollLeft'];
                const position = elementPos.left - scrollerPos.left + currentPos;
                this.animateScrolling('scrollLeft', position + (offset || 0), speed);
            }
            if (this.elementRef.nativeElement.classList.contains('ps--active-y')) {
                const currentPos = this.elementRef.nativeElement['scrollTop'];
                const position = elementPos.top - scrollerPos.top + currentPos;
                this.animateScrolling('scrollTop', position + (offset || 0), speed);
            }
        }
    }
    animateScrolling(target, value, speed) {
        if (this.animation) {
            window.cancelAnimationFrame(this.animation);
            this.animation = null;
        }
        if (!speed || typeof window === 'undefined') {
            this.elementRef.nativeElement[target] = value;
        }
        else if (value !== this.elementRef.nativeElement[target]) {
            let newValue = 0;
            let scrollCount = 0;
            let oldTimestamp = performance.now();
            let oldValue = this.elementRef.nativeElement[target];
            const cosParameter = (oldValue - value) / 2;
            const step = (newTimestamp) => {
                scrollCount += Math.PI / (speed / (newTimestamp - oldTimestamp));
                newValue = Math.round(value + cosParameter + cosParameter * Math.cos(scrollCount));
                // Only continue animation if scroll position has not changed
                if (this.elementRef.nativeElement[target] === oldValue) {
                    if (scrollCount >= Math.PI) {
                        this.animateScrolling(target, value, 0);
                    }
                    else {
                        this.elementRef.nativeElement[target] = newValue;
                        // On a zoomed out page the resulting offset may differ
                        oldValue = this.elementRef.nativeElement[target];
                        oldTimestamp = newTimestamp;
                        this.animation = window.requestAnimationFrame(step);
                    }
                }
            };
            window.requestAnimationFrame(step);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PerfectScrollbarDirective, deps: [{ token: i0.NgZone }, { token: i0.KeyValueDiffers }, { token: i0.ElementRef }, { token: PLATFORM_ID }, { token: PERFECT_SCROLLBAR_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: PerfectScrollbarDirective, selector: "[perfectScrollbar]", inputs: { disabled: "disabled", config: ["perfectScrollbar", "config"] }, outputs: { psScrollY: "psScrollY", psScrollX: "psScrollX", psScrollUp: "psScrollUp", psScrollDown: "psScrollDown", psScrollLeft: "psScrollLeft", psScrollRight: "psScrollRight", psYReachEnd: "psYReachEnd", psYReachStart: "psYReachStart", psXReachEnd: "psXReachEnd", psXReachStart: "psXReachStart" }, exportAs: ["ngxPerfectScrollbar"], usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PerfectScrollbarDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[perfectScrollbar]',
                    exportAs: 'ngxPerfectScrollbar',
                }]
        }], ctorParameters: function () { return [{ type: i0.NgZone }, { type: i0.KeyValueDiffers }, { type: i0.ElementRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [PERFECT_SCROLLBAR_CONFIG]
                }] }]; }, propDecorators: { disabled: [{
                type: Input
            }], config: [{
                type: Input,
                args: ['perfectScrollbar']
            }], psScrollY: [{
                type: Output
            }], psScrollX: [{
                type: Output
            }], psScrollUp: [{
                type: Output
            }], psScrollDown: [{
                type: Output
            }], psScrollLeft: [{
                type: Output
            }], psScrollRight: [{
                type: Output
            }], psYReachEnd: [{
                type: Output
            }], psYReachStart: [{
                type: Output
            }], psXReachEnd: [{
                type: Output
            }], psXReachStart: [{
                type: Output
            }] } });

class PerfectScrollbarComponent {
    constructor(zone, cdRef, platformId) {
        this.zone = zone;
        this.cdRef = cdRef;
        this.platformId = platformId;
        this.states = {};
        this.indicatorX = false;
        this.indicatorY = false;
        this.interaction = false;
        this.scrollPositionX = 0;
        this.scrollPositionY = 0;
        this.scrollDirectionX = 0;
        this.scrollDirectionY = 0;
        this.usePropagationX = false;
        this.usePropagationY = false;
        this.allowPropagationX = false;
        this.allowPropagationY = false;
        this.stateTimeout = null;
        this.ngDestroy = new Subject();
        this.stateUpdate = new Subject();
        this.disabled = false;
        this.usePSClass = true;
        this.autoPropagation = false;
        this.scrollIndicators = false;
        this.psScrollY = new EventEmitter();
        this.psScrollX = new EventEmitter();
        this.psScrollUp = new EventEmitter();
        this.psScrollDown = new EventEmitter();
        this.psScrollLeft = new EventEmitter();
        this.psScrollRight = new EventEmitter();
        this.psYReachEnd = new EventEmitter();
        this.psYReachStart = new EventEmitter();
        this.psXReachEnd = new EventEmitter();
        this.psXReachStart = new EventEmitter();
    }
    ngOnInit() {
        if (this.platformId) {
            if (isPlatformBrowser(this.platformId)) {
                this.stateUpdate
                    .pipe(takeUntil(this.ngDestroy), distinctUntilChanged((a, b) => a === b && !this.stateTimeout))
                    .subscribe((state) => {
                    if (this.stateTimeout && typeof window !== 'undefined') {
                        window.clearTimeout(this.stateTimeout);
                        this.stateTimeout = null;
                    }
                    if (state === 'x' || state === 'y') {
                        this.interaction = false;
                        if (state === 'x') {
                            this.indicatorX = false;
                            this.states.left = false;
                            this.states.right = false;
                            if (this.autoPropagation && this.usePropagationX) {
                                this.allowPropagationX = false;
                            }
                        }
                        else if (state === 'y') {
                            this.indicatorY = false;
                            this.states.top = false;
                            this.states.bottom = false;
                            if (this.autoPropagation && this.usePropagationY) {
                                this.allowPropagationY = false;
                            }
                        }
                    }
                    else {
                        if (state === 'left' || state === 'right') {
                            this.states.left = false;
                            this.states.right = false;
                            this.states[state] = true;
                            if (this.autoPropagation && this.usePropagationX) {
                                this.indicatorX = true;
                            }
                        }
                        else if (state === 'top' || state === 'bottom') {
                            this.states.top = false;
                            this.states.bottom = false;
                            this.states[state] = true;
                            if (this.autoPropagation && this.usePropagationY) {
                                this.indicatorY = true;
                            }
                        }
                        if (this.autoPropagation && typeof window !== 'undefined') {
                            this.stateTimeout = window.setTimeout(() => {
                                this.indicatorX = false;
                                this.indicatorY = false;
                                this.stateTimeout = null;
                                if (this.interaction &&
                                    (this.states.left || this.states.right)) {
                                    this.allowPropagationX = true;
                                }
                                if (this.interaction &&
                                    (this.states.top || this.states.bottom)) {
                                    this.allowPropagationY = true;
                                }
                                this.cdRef.markForCheck();
                            }, 500);
                        }
                    }
                    this.cdRef.markForCheck();
                    this.cdRef.detectChanges();
                });
                this.zone.runOutsideAngular(() => {
                    if (this.directiveRef) {
                        const element = this.directiveRef.elementRef.nativeElement;
                        fromEvent(element, 'wheel')
                            .pipe(takeUntil(this.ngDestroy))
                            .subscribe((event) => {
                            if (!this.disabled && this.autoPropagation) {
                                const scrollDeltaX = event.deltaX;
                                const scrollDeltaY = event.deltaY;
                                this.checkPropagation(event, scrollDeltaX, scrollDeltaY);
                            }
                        });
                        fromEvent(element, 'touchmove')
                            .pipe(takeUntil(this.ngDestroy))
                            .subscribe((event) => {
                            if (!this.disabled && this.autoPropagation) {
                                const scrollPositionX = event.touches[0]?.clientX ?? 0;
                                const scrollPositionY = event.touches[0]?.clientY ?? 0;
                                const scrollDeltaX = (scrollPositionX ?? 0) - (this.scrollPositionX ?? 0);
                                const scrollDeltaY = (scrollPositionY ?? 0) - (this.scrollPositionY ?? 0);
                                this.checkPropagation(event, scrollDeltaX, scrollDeltaY);
                                this.scrollPositionX = scrollPositionX;
                                this.scrollPositionY = scrollPositionY;
                            }
                        });
                        merge(fromEvent(element, 'ps-scroll-x').pipe(map(() => 'x')), fromEvent(element, 'ps-scroll-y').pipe(map(() => 'y')), fromEvent(element, 'ps-x-reach-end').pipe(map(() => 'right')), fromEvent(element, 'ps-y-reach-end').pipe(map(() => 'bottom')), fromEvent(element, 'ps-x-reach-start').pipe(map(() => 'left')), fromEvent(element, 'ps-y-reach-start').pipe(map(() => 'top')))
                            .pipe(takeUntil(this.ngDestroy))
                            .subscribe((state) => {
                            if (!this.disabled &&
                                (this.autoPropagation || this.scrollIndicators)) {
                                this.stateUpdate.next(state);
                            }
                        });
                    }
                });
                window.setTimeout(() => {
                    PerfectScrollbarEvents.forEach((eventName) => {
                        if (this.directiveRef) {
                            this.directiveRef[eventName] = this[eventName];
                        }
                    });
                }, 0);
            }
        }
    }
    ngOnDestroy() {
        if (this.platformId) {
            if (isPlatformBrowser(this.platformId)) {
                this.ngDestroy.next();
                this.ngDestroy.unsubscribe();
                if (this.stateTimeout && typeof window !== 'undefined') {
                    window.clearTimeout(this.stateTimeout);
                }
            }
        }
    }
    ngDoCheck() {
        if (this.platformId) {
            if (isPlatformBrowser(this.platformId)) {
                if (!this.disabled && this.autoPropagation && this.directiveRef) {
                    const element = this.directiveRef.elementRef.nativeElement;
                    this.usePropagationX = element.classList.contains('ps--active-x');
                    this.usePropagationY = element.classList.contains('ps--active-y');
                }
            }
        }
    }
    checkPropagation(event, deltaX, deltaY) {
        this.interaction = true;
        const scrollDirectionX = deltaX < 0 ? -1 : 1;
        const scrollDirectionY = deltaY < 0 ? -1 : 1;
        if ((this.usePropagationX && this.usePropagationY) ||
            (this.usePropagationX &&
                (!this.allowPropagationX ||
                    this.scrollDirectionX !== scrollDirectionX)) ||
            (this.usePropagationY &&
                (!this.allowPropagationY || this.scrollDirectionY !== scrollDirectionY))) {
            event.preventDefault();
            event.stopPropagation();
        }
        if (deltaX) {
            this.scrollDirectionX = scrollDirectionX;
        }
        if (deltaY) {
            this.scrollDirectionY = scrollDirectionY;
        }
        this.stateUpdate.next('interaction');
        this.cdRef.detectChanges();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PerfectScrollbarComponent, deps: [{ token: i0.NgZone }, { token: i0.ChangeDetectorRef }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: PerfectScrollbarComponent, selector: "perfect-scrollbar", inputs: { disabled: "disabled", usePSClass: "usePSClass", autoPropagation: "autoPropagation", scrollIndicators: "scrollIndicators", config: "config" }, outputs: { psScrollY: "psScrollY", psScrollX: "psScrollX", psScrollUp: "psScrollUp", psScrollDown: "psScrollDown", psScrollLeft: "psScrollLeft", psScrollRight: "psScrollRight", psYReachEnd: "psYReachEnd", psYReachStart: "psYReachStart", psXReachEnd: "psXReachEnd", psXReachStart: "psXReachStart" }, host: { properties: { "class.ps-show-limits": "this.autoPropagation", "class.ps-show-active": "this.scrollIndicators" } }, viewQueries: [{ propertyName: "directiveRef", first: true, predicate: PerfectScrollbarDirective, descendants: true, static: true }], exportAs: ["ngxPerfectScrollbar"], ngImport: i0, template: "<div\r\n  style=\"position: static\"\r\n  [class.ps]=\"usePSClass\"\r\n  [perfectScrollbar]=\"config\"\r\n  [disabled]=\"disabled\"\r\n>\r\n  <div class=\"ps-content\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n\r\n  <div\r\n    *ngIf=\"scrollIndicators\"\r\n    class=\"ps-overlay\"\r\n    [class.ps-at-top]=\"states.top\"\r\n    [class.ps-at-left]=\"states.left\"\r\n    [class.ps-at-right]=\"states.right\"\r\n    [class.ps-at-bottom]=\"states.bottom\"\r\n  >\r\n    <div\r\n      class=\"ps-indicator-top\"\r\n      [class.ps-indicator-show]=\"indicatorY && interaction\"\r\n    ></div>\r\n    <div\r\n      class=\"ps-indicator-left\"\r\n      [class.ps-indicator-show]=\"indicatorX && interaction\"\r\n    ></div>\r\n    <div\r\n      class=\"ps-indicator-right\"\r\n      [class.ps-indicator-show]=\"indicatorX && interaction\"\r\n    ></div>\r\n    <div\r\n      class=\"ps-indicator-bottom\"\r\n      [class.ps-indicator-show]=\"indicatorY && interaction\"\r\n    ></div>\r\n  </div>\r\n</div>\r\n", styles: ["perfect-scrollbar{position:relative;display:block;overflow:hidden;width:100%;height:100%;max-width:100%;max-height:100%}perfect-scrollbar[hidden]{display:none}perfect-scrollbar[fxflex]{display:flex;flex-direction:column;height:auto;min-width:0;min-height:0}perfect-scrollbar[fxflex]>.ps{flex:1 1 auto;width:auto;height:auto;min-width:0;min-height:0;-webkit-box-flex:1}perfect-scrollbar[fxlayout]>.ps,perfect-scrollbar[fxlayout]>.ps>.ps-content{display:flex;flex:1 1 auto;flex-direction:inherit;align-items:inherit;align-content:inherit;justify-content:inherit;width:100%;height:100%;-webkit-box-align:inherit;-webkit-box-flex:1;-webkit-box-pack:inherit}perfect-scrollbar[fxlayout=row]>.ps,perfect-scrollbar[fxlayout=row]>.ps>.ps-content{flex-direction:row!important}perfect-scrollbar[fxlayout=column]>.ps,perfect-scrollbar[fxlayout=column]>.ps>.ps-content{flex-direction:column!important}perfect-scrollbar>.ps{position:static;display:block;width:100%;height:100%;max-width:100%;max-height:100%}perfect-scrollbar>.ps textarea{-ms-overflow-style:scrollbar}perfect-scrollbar>.ps>.ps-overlay{position:absolute;inset:0;display:block;overflow:hidden;pointer-events:none}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-top,perfect-scrollbar>.ps>.ps-overlay .ps-indicator-left,perfect-scrollbar>.ps>.ps-overlay .ps-indicator-right,perfect-scrollbar>.ps>.ps-overlay .ps-indicator-bottom{position:absolute;opacity:0;transition:opacity .3s ease-in-out}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-top,perfect-scrollbar>.ps>.ps-overlay .ps-indicator-bottom{left:0;min-width:100%;min-height:24px}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-left,perfect-scrollbar>.ps>.ps-overlay .ps-indicator-right{top:0;min-width:24px;min-height:100%}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-top{top:0}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-left{left:0}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-right{right:0}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-bottom{bottom:0}perfect-scrollbar>.ps.ps--active-y>.ps__rail-y{top:0!important;right:0!important;left:auto!important;width:10px;cursor:default;transition:width .2s linear,opacity .2s linear,background-color .2s linear}perfect-scrollbar>.ps.ps--active-y>.ps__rail-y:hover,perfect-scrollbar>.ps.ps--active-y>.ps__rail-y.ps--clicking{width:15px}perfect-scrollbar>.ps.ps--active-x>.ps__rail-x{top:auto!important;bottom:0!important;left:0!important;height:10px;cursor:default;transition:height .2s linear,opacity .2s linear,background-color .2s linear}perfect-scrollbar>.ps.ps--active-x>.ps__rail-x:hover,perfect-scrollbar>.ps.ps--active-x>.ps__rail-x.ps--clicking{height:15px}perfect-scrollbar>.ps.ps--active-x.ps--active-y>.ps__rail-y{margin:0 0 10px}perfect-scrollbar>.ps.ps--active-x.ps--active-y>.ps__rail-x{margin:0 10px 0 0}perfect-scrollbar>.ps.ps--scrolling-y>.ps__rail-y,perfect-scrollbar>.ps.ps--scrolling-x>.ps__rail-x{opacity:.9;background-color:#eee}perfect-scrollbar.ps-show-always>.ps.ps--active-y>.ps__rail-y,perfect-scrollbar.ps-show-always>.ps.ps--active-x>.ps__rail-x{opacity:.6}perfect-scrollbar.ps-show-active>.ps.ps--active-y>.ps-overlay:not(.ps-at-top) .ps-indicator-top{opacity:1;background:linear-gradient(to bottom,#ffffff80,#fff0)}perfect-scrollbar.ps-show-active>.ps.ps--active-y>.ps-overlay:not(.ps-at-bottom) .ps-indicator-bottom{opacity:1;background:linear-gradient(to top,#ffffff80,#fff0)}perfect-scrollbar.ps-show-active>.ps.ps--active-x>.ps-overlay:not(.ps-at-left) .ps-indicator-left{opacity:1;background:linear-gradient(to right,#ffffff80,#fff0)}perfect-scrollbar.ps-show-active>.ps.ps--active-x>.ps-overlay:not(.ps-at-right) .ps-indicator-right{opacity:1;background:linear-gradient(to left,#ffffff80,#fff0)}perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-y>.ps-overlay.ps-at-top .ps-indicator-top{background:linear-gradient(to bottom,#aaaaaa80,#aaa0)}perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-y>.ps-overlay.ps-at-bottom .ps-indicator-bottom{background:linear-gradient(to top,#aaaaaa80,#aaa0)}perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-x>.ps-overlay.ps-at-left .ps-indicator-left{background:linear-gradient(to right,#aaaaaa80,#aaa0)}perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-x>.ps-overlay.ps-at-right .ps-indicator-right{background:linear-gradient(to left,#aaaaaa80,#aaa0)}perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-y>.ps-overlay.ps-at-top .ps-indicator-top.ps-indicator-show,perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-y>.ps-overlay.ps-at-bottom .ps-indicator-bottom.ps-indicator-show,perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-x>.ps-overlay.ps-at-left .ps-indicator-left.ps-indicator-show,perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-x>.ps-overlay.ps-at-right .ps-indicator-right.ps-indicator-show{opacity:1}\n"], dependencies: [{ kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: PerfectScrollbarDirective, selector: "[perfectScrollbar]", inputs: ["disabled", "perfectScrollbar"], outputs: ["psScrollY", "psScrollX", "psScrollUp", "psScrollDown", "psScrollLeft", "psScrollRight", "psYReachEnd", "psYReachStart", "psXReachEnd", "psXReachStart"], exportAs: ["ngxPerfectScrollbar"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PerfectScrollbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'perfect-scrollbar', exportAs: 'ngxPerfectScrollbar', encapsulation: ViewEncapsulation.None, template: "<div\r\n  style=\"position: static\"\r\n  [class.ps]=\"usePSClass\"\r\n  [perfectScrollbar]=\"config\"\r\n  [disabled]=\"disabled\"\r\n>\r\n  <div class=\"ps-content\">\r\n    <ng-content></ng-content>\r\n  </div>\r\n\r\n  <div\r\n    *ngIf=\"scrollIndicators\"\r\n    class=\"ps-overlay\"\r\n    [class.ps-at-top]=\"states.top\"\r\n    [class.ps-at-left]=\"states.left\"\r\n    [class.ps-at-right]=\"states.right\"\r\n    [class.ps-at-bottom]=\"states.bottom\"\r\n  >\r\n    <div\r\n      class=\"ps-indicator-top\"\r\n      [class.ps-indicator-show]=\"indicatorY && interaction\"\r\n    ></div>\r\n    <div\r\n      class=\"ps-indicator-left\"\r\n      [class.ps-indicator-show]=\"indicatorX && interaction\"\r\n    ></div>\r\n    <div\r\n      class=\"ps-indicator-right\"\r\n      [class.ps-indicator-show]=\"indicatorX && interaction\"\r\n    ></div>\r\n    <div\r\n      class=\"ps-indicator-bottom\"\r\n      [class.ps-indicator-show]=\"indicatorY && interaction\"\r\n    ></div>\r\n  </div>\r\n</div>\r\n", styles: ["perfect-scrollbar{position:relative;display:block;overflow:hidden;width:100%;height:100%;max-width:100%;max-height:100%}perfect-scrollbar[hidden]{display:none}perfect-scrollbar[fxflex]{display:flex;flex-direction:column;height:auto;min-width:0;min-height:0}perfect-scrollbar[fxflex]>.ps{flex:1 1 auto;width:auto;height:auto;min-width:0;min-height:0;-webkit-box-flex:1}perfect-scrollbar[fxlayout]>.ps,perfect-scrollbar[fxlayout]>.ps>.ps-content{display:flex;flex:1 1 auto;flex-direction:inherit;align-items:inherit;align-content:inherit;justify-content:inherit;width:100%;height:100%;-webkit-box-align:inherit;-webkit-box-flex:1;-webkit-box-pack:inherit}perfect-scrollbar[fxlayout=row]>.ps,perfect-scrollbar[fxlayout=row]>.ps>.ps-content{flex-direction:row!important}perfect-scrollbar[fxlayout=column]>.ps,perfect-scrollbar[fxlayout=column]>.ps>.ps-content{flex-direction:column!important}perfect-scrollbar>.ps{position:static;display:block;width:100%;height:100%;max-width:100%;max-height:100%}perfect-scrollbar>.ps textarea{-ms-overflow-style:scrollbar}perfect-scrollbar>.ps>.ps-overlay{position:absolute;inset:0;display:block;overflow:hidden;pointer-events:none}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-top,perfect-scrollbar>.ps>.ps-overlay .ps-indicator-left,perfect-scrollbar>.ps>.ps-overlay .ps-indicator-right,perfect-scrollbar>.ps>.ps-overlay .ps-indicator-bottom{position:absolute;opacity:0;transition:opacity .3s ease-in-out}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-top,perfect-scrollbar>.ps>.ps-overlay .ps-indicator-bottom{left:0;min-width:100%;min-height:24px}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-left,perfect-scrollbar>.ps>.ps-overlay .ps-indicator-right{top:0;min-width:24px;min-height:100%}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-top{top:0}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-left{left:0}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-right{right:0}perfect-scrollbar>.ps>.ps-overlay .ps-indicator-bottom{bottom:0}perfect-scrollbar>.ps.ps--active-y>.ps__rail-y{top:0!important;right:0!important;left:auto!important;width:10px;cursor:default;transition:width .2s linear,opacity .2s linear,background-color .2s linear}perfect-scrollbar>.ps.ps--active-y>.ps__rail-y:hover,perfect-scrollbar>.ps.ps--active-y>.ps__rail-y.ps--clicking{width:15px}perfect-scrollbar>.ps.ps--active-x>.ps__rail-x{top:auto!important;bottom:0!important;left:0!important;height:10px;cursor:default;transition:height .2s linear,opacity .2s linear,background-color .2s linear}perfect-scrollbar>.ps.ps--active-x>.ps__rail-x:hover,perfect-scrollbar>.ps.ps--active-x>.ps__rail-x.ps--clicking{height:15px}perfect-scrollbar>.ps.ps--active-x.ps--active-y>.ps__rail-y{margin:0 0 10px}perfect-scrollbar>.ps.ps--active-x.ps--active-y>.ps__rail-x{margin:0 10px 0 0}perfect-scrollbar>.ps.ps--scrolling-y>.ps__rail-y,perfect-scrollbar>.ps.ps--scrolling-x>.ps__rail-x{opacity:.9;background-color:#eee}perfect-scrollbar.ps-show-always>.ps.ps--active-y>.ps__rail-y,perfect-scrollbar.ps-show-always>.ps.ps--active-x>.ps__rail-x{opacity:.6}perfect-scrollbar.ps-show-active>.ps.ps--active-y>.ps-overlay:not(.ps-at-top) .ps-indicator-top{opacity:1;background:linear-gradient(to bottom,#ffffff80,#fff0)}perfect-scrollbar.ps-show-active>.ps.ps--active-y>.ps-overlay:not(.ps-at-bottom) .ps-indicator-bottom{opacity:1;background:linear-gradient(to top,#ffffff80,#fff0)}perfect-scrollbar.ps-show-active>.ps.ps--active-x>.ps-overlay:not(.ps-at-left) .ps-indicator-left{opacity:1;background:linear-gradient(to right,#ffffff80,#fff0)}perfect-scrollbar.ps-show-active>.ps.ps--active-x>.ps-overlay:not(.ps-at-right) .ps-indicator-right{opacity:1;background:linear-gradient(to left,#ffffff80,#fff0)}perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-y>.ps-overlay.ps-at-top .ps-indicator-top{background:linear-gradient(to bottom,#aaaaaa80,#aaa0)}perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-y>.ps-overlay.ps-at-bottom .ps-indicator-bottom{background:linear-gradient(to top,#aaaaaa80,#aaa0)}perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-x>.ps-overlay.ps-at-left .ps-indicator-left{background:linear-gradient(to right,#aaaaaa80,#aaa0)}perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-x>.ps-overlay.ps-at-right .ps-indicator-right{background:linear-gradient(to left,#aaaaaa80,#aaa0)}perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-y>.ps-overlay.ps-at-top .ps-indicator-top.ps-indicator-show,perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-y>.ps-overlay.ps-at-bottom .ps-indicator-bottom.ps-indicator-show,perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-x>.ps-overlay.ps-at-left .ps-indicator-left.ps-indicator-show,perfect-scrollbar.ps-show-active.ps-show-limits>.ps.ps--active-x>.ps-overlay.ps-at-right .ps-indicator-right.ps-indicator-show{opacity:1}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.NgZone }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }]; }, propDecorators: { disabled: [{
                type: Input
            }], usePSClass: [{
                type: Input
            }], autoPropagation: [{
                type: HostBinding,
                args: ['class.ps-show-limits']
            }, {
                type: Input
            }], scrollIndicators: [{
                type: HostBinding,
                args: ['class.ps-show-active']
            }, {
                type: Input
            }], config: [{
                type: Input
            }], psScrollY: [{
                type: Output
            }], psScrollX: [{
                type: Output
            }], psScrollUp: [{
                type: Output
            }], psScrollDown: [{
                type: Output
            }], psScrollLeft: [{
                type: Output
            }], psScrollRight: [{
                type: Output
            }], psYReachEnd: [{
                type: Output
            }], psYReachStart: [{
                type: Output
            }], psXReachEnd: [{
                type: Output
            }], psXReachStart: [{
                type: Output
            }], directiveRef: [{
                type: ViewChild,
                args: [PerfectScrollbarDirective, { static: true }]
            }] } });

class ForceNativeScrollDirective {
    constructor(renderer, el) {
        this.renderer = renderer;
        ['ps__child', 'ps__child--consume'].forEach((className) => {
            this.renderer.addClass(el?.nativeElement, className);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ForceNativeScrollDirective, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: ForceNativeScrollDirective, selector: "[forceNativeScrolling]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ForceNativeScrollDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[forceNativeScrolling]',
                }]
        }], ctorParameters: function () { return [{ type: i0.Renderer2 }, { type: i0.ElementRef }]; } });

class PerfectScrollbarModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PerfectScrollbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: PerfectScrollbarModule, declarations: [PerfectScrollbarComponent,
            PerfectScrollbarDirective,
            ForceNativeScrollDirective], imports: [CommonModule], exports: [CommonModule,
            PerfectScrollbarComponent,
            PerfectScrollbarDirective,
            ForceNativeScrollDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PerfectScrollbarModule, imports: [CommonModule, CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PerfectScrollbarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    declarations: [
                        PerfectScrollbarComponent,
                        PerfectScrollbarDirective,
                        ForceNativeScrollDirective,
                    ],
                    exports: [
                        CommonModule,
                        PerfectScrollbarComponent,
                        PerfectScrollbarDirective,
                        ForceNativeScrollDirective,
                    ],
                }]
        }] });

class RadioButtonComponent {
    constructor() {
        this.disabled = false;
        this.uniqueName = '';
        this.valueChange = new EventEmitter();
    }
    // Getter for disabled state
    get isDisabled() {
        return this.disabled || this.control?.disabled || false;
    }
    ngOnInit() {
        // If no groupName is provided, generate a unique name based on FormControl
        if (!this.groupName) {
            this.uniqueName = `radio-group-${this.control?.value}-${Math.random().toString(36).substring(2, 9)}`;
        }
        if (this.control) {
            // Subscribe to valueChanges to listen for updates
            this.valueChangeSub = this.control.valueChanges.subscribe(_newValue => {
                this.valueChange.emit(this.value);
            });
        }
    }
    onSelectionChange() {
        // Update formControl value when a selection is made
        if (this.control) {
            this.control.setValue(this.value);
            this.valueChange.emit(this.value);
        }
    }
    ngOnDestroy() {
        // Clean up the subscription
        this.valueChangeSub?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RadioButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: RadioButtonComponent, selector: "ic-radio-button", inputs: { value: "value", label: "label", disabled: "disabled", control: "control", groupName: "groupName" }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: "<label class=\"ic-radio-button\" [class.disabled]=\"isDisabled\">\r\n  <input\r\n    type=\"radio\"\r\n    [value]=\"value\"\r\n    [formControl]=\"control\"\r\n    [name]=\"groupName || uniqueName\"\r\n    [disabled]=\"isDisabled\"\r\n    (change)=\"onSelectionChange()\" />\r\n  <span class=\"radio-label\">{{ label }}</span>\r\n</label>\r\n", styles: ["label{display:flex;align-items:center;cursor:pointer;-webkit-user-select:none;user-select:none;font-weight:500;color:var(--ic-radio-label-color, #707070);font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);transition:color .3s ease}label:has(input[type=radio]:checked){color:var(--ic-radio-label-checked-color, #0033a1)}label.disabled{cursor:not-allowed;opacity:.6;pointer-events:none;color:var(--ic-radio-label-disabled-color, #b1b1b1)}input[type=radio]:checked+label{color:var(--ic-radio-label-checked-color, #0033a1)}input[type=radio]{appearance:none;width:20px!important;height:20px!important;border-radius:50%;outline:none;margin-right:8px;transition:all .3s ease;box-shadow:0 3px 6px #00000029;border:2px solid var(--ic-radio-border, #fff);background:var(--ic-radio-bg, #fff)}input[type=radio]:checked{border:4px solid var(--ic-radio-border-checked, #fff);background:var(--ic-radio-bg-checked, #0033a1);outline:2px solid var(--ic-radio-outline-checked, #0033a1)}input[type=radio]:hover{opacity:.9;border-color:var(--ic-radio-border-hover, #0033a1)}input[type=radio]:disabled{opacity:.5;cursor:not-allowed;background:var(--ic-radio-bg-disabled, #f3f3f3);border-color:var(--ic-radio-border-disabled, #dcdcdc)}\n"], dependencies: [{ kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.RadioControlValueAccessor, selector: "input[type=radio][formControlName],input[type=radio][formControl],input[type=radio][ngModel]", inputs: ["name", "formControlName", "value"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: NoInitialSpaceDirective, selector: "input, textarea" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RadioButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-radio-button', template: "<label class=\"ic-radio-button\" [class.disabled]=\"isDisabled\">\r\n  <input\r\n    type=\"radio\"\r\n    [value]=\"value\"\r\n    [formControl]=\"control\"\r\n    [name]=\"groupName || uniqueName\"\r\n    [disabled]=\"isDisabled\"\r\n    (change)=\"onSelectionChange()\" />\r\n  <span class=\"radio-label\">{{ label }}</span>\r\n</label>\r\n", styles: ["label{display:flex;align-items:center;cursor:pointer;-webkit-user-select:none;user-select:none;font-weight:500;color:var(--ic-radio-label-color, #707070);font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);transition:color .3s ease}label:has(input[type=radio]:checked){color:var(--ic-radio-label-checked-color, #0033a1)}label.disabled{cursor:not-allowed;opacity:.6;pointer-events:none;color:var(--ic-radio-label-disabled-color, #b1b1b1)}input[type=radio]:checked+label{color:var(--ic-radio-label-checked-color, #0033a1)}input[type=radio]{appearance:none;width:20px!important;height:20px!important;border-radius:50%;outline:none;margin-right:8px;transition:all .3s ease;box-shadow:0 3px 6px #00000029;border:2px solid var(--ic-radio-border, #fff);background:var(--ic-radio-bg, #fff)}input[type=radio]:checked{border:4px solid var(--ic-radio-border-checked, #fff);background:var(--ic-radio-bg-checked, #0033a1);outline:2px solid var(--ic-radio-outline-checked, #0033a1)}input[type=radio]:hover{opacity:.9;border-color:var(--ic-radio-border-hover, #0033a1)}input[type=radio]:disabled{opacity:.5;cursor:not-allowed;background:var(--ic-radio-bg-disabled, #f3f3f3);border-color:var(--ic-radio-border-disabled, #dcdcdc)}\n"] }]
        }], propDecorators: { value: [{
                type: Input
            }], label: [{
                type: Input
            }], disabled: [{
                type: Input
            }], control: [{
                type: Input
            }], groupName: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });

class TextareaComponent {
    constructor() {
        this.required = false;
        this.rows = 1;
        this.disabled = false;
        // Attribute Directives Input
        this.icNumbersOnly = false;
        this.icAlphaNumericWithSpace = false;
        this.icSpecialAlphaNumeric = false;
        this.icAlphanumeric = false;
        this.icNoInitialSpace = false;
        this.icNoSpace = false;
        this.icSpecialText = false;
        this.icIsUpperCase = false;
        this.icNoSpecialCharFirst = false;
        this.icAlphabetOnly = false;
        this.icRestrictPercentage = false;
        this.icRestrictDecimal = false;
        this.icTwoDigitDecimalNumber = false;
        this.alphabetspace = false;
        this.appNoInitialDot = false;
        this.specialIsAlphaNumeric = false;
        this.someSpecialIsAlphaNumeric = false;
        this.valueChange = new EventEmitter();
        this.onKeyUp = new EventEmitter();
        this.onKeyDown = new EventEmitter();
        this.isFocused = false;
    }
    ngOnInit() {
        if (!this.control) {
            console.error('FormControl is required for ic-textarea');
        }
    }
    ngOnChanges(changes) {
        if (changes['control'] && this.control) {
            this.valueChange.emit(this.control.value);
        }
    }
    onFocus() {
        this.isFocused = true;
    }
    handleKeyUp(event) {
        this.onKeyUp.emit(event);
    }
    handleKeyDown(event) {
        this.onKeyDown.emit(event);
    }
    onBlur() {
        this.isFocused = false;
        this.valueChange.emit(this.control.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TextareaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: TextareaComponent, selector: "ic-textarea", inputs: { label: "label", id: "id", control: "control", required: "required", rows: "rows", maxlength: "maxlength", disabled: "disabled", customError: "customError", customClass: "customClass", icNumbersOnly: "icNumbersOnly", icAlphaNumericWithSpace: "icAlphaNumericWithSpace", icSpecialAlphaNumeric: "icSpecialAlphaNumeric", icAlphanumeric: "icAlphanumeric", icNoInitialSpace: "icNoInitialSpace", icNoSpace: "icNoSpace", icSpecialText: "icSpecialText", icIsUpperCase: "icIsUpperCase", icNoSpecialCharFirst: "icNoSpecialCharFirst", icAlphabetOnly: "icAlphabetOnly", icRestrictPercentage: "icRestrictPercentage", icRestrictDecimal: "icRestrictDecimal", icTwoDigitDecimalNumber: "icTwoDigitDecimalNumber", alphabetspace: "alphabetspace", appNoInitialDot: "appNoInitialDot", specialIsAlphaNumeric: "specialIsAlphaNumeric", someSpecialIsAlphaNumeric: "someSpecialIsAlphaNumeric" }, outputs: { valueChange: "valueChange", onKeyUp: "onKeyUp", onKeyDown: "onKeyDown" }, usesOnChanges: true, ngImport: i0, template: "<div\r\n  class=\"ic-textarea-container {{ customClass }}\"\r\n  [class.focused]=\"isFocused\">\r\n  <label\r\n    *ngIf=\"label\"\r\n    [for]=\"id\"\r\n    class=\"textarea-label\"\r\n    [class.floated]=\"isFocused || !!control.value\">\r\n    {{ label }} <span *ngIf=\"required\" class=\"required\">*</span>\r\n  </label>\r\n  <textarea\r\n    [id]=\"id\"\r\n    [formControl]=\"control\"\r\n    [rows]=\"rows\"\r\n    [maxlength]=\"maxlength ? maxlength : null\"\r\n    [disabled]=\"disabled\"\r\n    [class.disabled]=\"this.disabled\"\r\n    [attr.icAlphaNumericWithSpace]=\"icAlphaNumericWithSpace ? '' : null\"\r\n    [attr.icAlphanumeric]=\"icAlphanumeric ? '' : null\"\r\n    [icIsUpperCase]=\"icIsUpperCase\"\r\n    [attr.icNoInitialSpace]=\"icNoInitialSpace ? '' : null\"\r\n    [attr.icNoSpace]=\"icNoSpace ? '' : null\"\r\n    [attr.icNumbersOnly]=\"icNumbersOnly ? '' : null\"\r\n    [attr.icSpecialAlphaNumeric]=\"icSpecialAlphaNumeric ? '' : null\"\r\n    [attr.icSpecialText]=\"icSpecialText ? '' : null\"\r\n    [attr.icAlphabetOnly]=\"icAlphabetOnly ? '' : null\"\r\n    [attr.icNoSpecialCharFirst]=\"icNoSpecialCharFirst ? '' : null\"\r\n    [attr.icRestrictPercentage]=\"icRestrictPercentage ? '' : null\"\r\n    [attr.icRestrictDecimal]=\"icRestrictDecimal ? '' : null\"\r\n    [attr.icTwoDigitDecimalNumber]=\"icTwoDigitDecimalNumber ? '' : null\"\r\n    [attr.alphabetspace]=\"alphabetspace ? '' : null\"\r\n    [attr.appNoInitialDot]=\"appNoInitialDot ? '' : null\"\r\n    [attr.specialIsAlphaNumeric]=\"specialIsAlphaNumeric ? '' : null\"\r\n    [attr.someSpecialIsAlphaNumeric]=\"someSpecialIsAlphaNumeric ? '' : null\"\r\n    (focus)=\"onFocus()\"\r\n    (keyup)=\"handleKeyUp($event)\"\r\n    (keydown)=\"handleKeyDown($event)\"\r\n    (blur)=\"onBlur()\"></textarea>\r\n  <div\r\n    *ngIf=\"control?.invalid && (control?.dirty || control?.touched)\"\r\n    class=\"error-message\"\r\n    id=\"error-message\">\r\n    <div *ngIf=\"control?.errors?.['required']\">{{ label }} is Required!</div>\r\n    <div *ngIf=\"customError\">\r\n      {{ customError }}\r\n    </div>\r\n  </div>\r\n</div>\r\n", styles: [".ic-textarea-container{position:relative;display:flex;flex-direction:column;width:100%;margin:8px 0}.ic-textarea-container .textarea-label{position:absolute;left:16px;font-size:14px;transition:.3s;color:var(--ic-textarea-label-color, #666);font-family:var(--ic-primary-font-family),sans-serif;transform:translateY(9px)!important;z-index:2}.ic-textarea-container .textarea-label.floated{left:12px;transform:translateY(-8px)!important;font-size:12px;color:var(--ic-textarea-label-active-color, #0033a1);background:var(--ic-textarea-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0), #fff 57%, rgba(0, 128, 0, 0)));padding:0 4px;z-index:1}.ic-textarea-container .required{color:var(--ic-textarea-required-star, red)}.ic-textarea-container textarea{width:100%;padding:8px;border:2px solid var(--ic-textarea-border, #dcdcdc);border-radius:8px;font-size:14px;resize:vertical;outline:none;background:var(--ic-textarea-bg, #fff);box-shadow:var(--ic-textarea-box-shadow, none);transition:border-color .3s;min-height:40px;color:var(--ic-textarea-input-color, inherit)}.ic-textarea-container textarea:focus{border-color:var(--ic-textarea-border-focus, #0033a1)}.ic-textarea-container textarea.ng-invalid.ng-touched{border-color:var(--ic-textarea-border-error, red)}.ic-textarea-container textarea.disabled{background-color:var(--ic-textarea-disabled-bg, #f3f3f3)!important;border-color:var(--ic-textarea-disabled-border, #dcdcdc)!important;box-shadow:none!important;color:var(--ic-textarea-disabled-color, gray)!important;pointer-events:none;cursor:not-allowed!important}.ic-textarea-container .error-message{color:var(--ic-textarea-error-color, red);font-size:12px;margin:0 16px}.ic-textarea-container.focused textarea{border-color:var(--ic-textarea-border-focus, #0033a1)}\n"], dependencies: [{ kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: IsUpperCaseDirective, selector: "[icIsUpperCase]", inputs: ["icIsUpperCase"] }, { kind: "directive", type: NoInitialSpaceDirective, selector: "input, textarea" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TextareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-textarea', template: "<div\r\n  class=\"ic-textarea-container {{ customClass }}\"\r\n  [class.focused]=\"isFocused\">\r\n  <label\r\n    *ngIf=\"label\"\r\n    [for]=\"id\"\r\n    class=\"textarea-label\"\r\n    [class.floated]=\"isFocused || !!control.value\">\r\n    {{ label }} <span *ngIf=\"required\" class=\"required\">*</span>\r\n  </label>\r\n  <textarea\r\n    [id]=\"id\"\r\n    [formControl]=\"control\"\r\n    [rows]=\"rows\"\r\n    [maxlength]=\"maxlength ? maxlength : null\"\r\n    [disabled]=\"disabled\"\r\n    [class.disabled]=\"this.disabled\"\r\n    [attr.icAlphaNumericWithSpace]=\"icAlphaNumericWithSpace ? '' : null\"\r\n    [attr.icAlphanumeric]=\"icAlphanumeric ? '' : null\"\r\n    [icIsUpperCase]=\"icIsUpperCase\"\r\n    [attr.icNoInitialSpace]=\"icNoInitialSpace ? '' : null\"\r\n    [attr.icNoSpace]=\"icNoSpace ? '' : null\"\r\n    [attr.icNumbersOnly]=\"icNumbersOnly ? '' : null\"\r\n    [attr.icSpecialAlphaNumeric]=\"icSpecialAlphaNumeric ? '' : null\"\r\n    [attr.icSpecialText]=\"icSpecialText ? '' : null\"\r\n    [attr.icAlphabetOnly]=\"icAlphabetOnly ? '' : null\"\r\n    [attr.icNoSpecialCharFirst]=\"icNoSpecialCharFirst ? '' : null\"\r\n    [attr.icRestrictPercentage]=\"icRestrictPercentage ? '' : null\"\r\n    [attr.icRestrictDecimal]=\"icRestrictDecimal ? '' : null\"\r\n    [attr.icTwoDigitDecimalNumber]=\"icTwoDigitDecimalNumber ? '' : null\"\r\n    [attr.alphabetspace]=\"alphabetspace ? '' : null\"\r\n    [attr.appNoInitialDot]=\"appNoInitialDot ? '' : null\"\r\n    [attr.specialIsAlphaNumeric]=\"specialIsAlphaNumeric ? '' : null\"\r\n    [attr.someSpecialIsAlphaNumeric]=\"someSpecialIsAlphaNumeric ? '' : null\"\r\n    (focus)=\"onFocus()\"\r\n    (keyup)=\"handleKeyUp($event)\"\r\n    (keydown)=\"handleKeyDown($event)\"\r\n    (blur)=\"onBlur()\"></textarea>\r\n  <div\r\n    *ngIf=\"control?.invalid && (control?.dirty || control?.touched)\"\r\n    class=\"error-message\"\r\n    id=\"error-message\">\r\n    <div *ngIf=\"control?.errors?.['required']\">{{ label }} is Required!</div>\r\n    <div *ngIf=\"customError\">\r\n      {{ customError }}\r\n    </div>\r\n  </div>\r\n</div>\r\n", styles: [".ic-textarea-container{position:relative;display:flex;flex-direction:column;width:100%;margin:8px 0}.ic-textarea-container .textarea-label{position:absolute;left:16px;font-size:14px;transition:.3s;color:var(--ic-textarea-label-color, #666);font-family:var(--ic-primary-font-family),sans-serif;transform:translateY(9px)!important;z-index:2}.ic-textarea-container .textarea-label.floated{left:12px;transform:translateY(-8px)!important;font-size:12px;color:var(--ic-textarea-label-active-color, #0033a1);background:var(--ic-textarea-label-bg, linear-gradient(180deg, rgba(0, 0, 255, 0), #fff 57%, rgba(0, 128, 0, 0)));padding:0 4px;z-index:1}.ic-textarea-container .required{color:var(--ic-textarea-required-star, red)}.ic-textarea-container textarea{width:100%;padding:8px;border:2px solid var(--ic-textarea-border, #dcdcdc);border-radius:8px;font-size:14px;resize:vertical;outline:none;background:var(--ic-textarea-bg, #fff);box-shadow:var(--ic-textarea-box-shadow, none);transition:border-color .3s;min-height:40px;color:var(--ic-textarea-input-color, inherit)}.ic-textarea-container textarea:focus{border-color:var(--ic-textarea-border-focus, #0033a1)}.ic-textarea-container textarea.ng-invalid.ng-touched{border-color:var(--ic-textarea-border-error, red)}.ic-textarea-container textarea.disabled{background-color:var(--ic-textarea-disabled-bg, #f3f3f3)!important;border-color:var(--ic-textarea-disabled-border, #dcdcdc)!important;box-shadow:none!important;color:var(--ic-textarea-disabled-color, gray)!important;pointer-events:none;cursor:not-allowed!important}.ic-textarea-container .error-message{color:var(--ic-textarea-error-color, red);font-size:12px;margin:0 16px}.ic-textarea-container.focused textarea{border-color:var(--ic-textarea-border-focus, #0033a1)}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], id: [{
                type: Input
            }], control: [{
                type: Input
            }], required: [{
                type: Input
            }], rows: [{
                type: Input
            }], maxlength: [{
                type: Input
            }], disabled: [{
                type: Input
            }], customError: [{
                type: Input
            }], customClass: [{
                type: Input
            }], icNumbersOnly: [{
                type: Input,
                args: ['icNumbersOnly']
            }], icAlphaNumericWithSpace: [{
                type: Input,
                args: ['icAlphaNumericWithSpace']
            }], icSpecialAlphaNumeric: [{
                type: Input,
                args: ['icSpecialAlphaNumeric']
            }], icAlphanumeric: [{
                type: Input,
                args: ['icAlphanumeric']
            }], icNoInitialSpace: [{
                type: Input,
                args: ['icNoInitialSpace']
            }], icNoSpace: [{
                type: Input,
                args: ['icNoSpace']
            }], icSpecialText: [{
                type: Input,
                args: ['icSpecialText']
            }], icIsUpperCase: [{
                type: Input,
                args: ['icIsUpperCase']
            }], icNoSpecialCharFirst: [{
                type: Input,
                args: ['icNoSpecialCharFirst']
            }], icAlphabetOnly: [{
                type: Input,
                args: ['icAlphabetOnly']
            }], icRestrictPercentage: [{
                type: Input,
                args: ['icRestrictPercentage']
            }], icRestrictDecimal: [{
                type: Input,
                args: ['icRestrictDecimal']
            }], icTwoDigitDecimalNumber: [{
                type: Input,
                args: ['icTwoDigitDecimalNumber']
            }], alphabetspace: [{
                type: Input,
                args: ['alphabetspace']
            }], appNoInitialDot: [{
                type: Input,
                args: ['appNoInitialDot']
            }], specialIsAlphaNumeric: [{
                type: Input,
                args: ['specialIsAlphaNumeric']
            }], someSpecialIsAlphaNumeric: [{
                type: Input,
                args: ['someSpecialIsAlphaNumeric']
            }], valueChange: [{
                type: Output
            }], onKeyUp: [{
                type: Output
            }], onKeyDown: [{
                type: Output
            }] } });

class ButtonToggleGroupComponent {
    constructor(cdr) {
        this.cdr = cdr;
        this.buttonList = [];
        this.disabled = false;
        this.outlined = false;
        this.customClass = '';
        this.valueChange = new EventEmitter();
    }
    ngOnInit() {
        if (this.formControl) {
            this.formControl.valueChanges.subscribe(() => {
                this.cdr.detectChanges(); // Ensure UI updates properly
            });
        }
    }
    ngOnChanges(changes) {
        if (changes['disabled']) {
            this.cdr.detectChanges(); // Ensure disabled state updates
        }
    }
    onButtonClick(value) {
        if (!this.disabled) {
            this.formControl.setValue(value);
            this.valueChange.emit(value);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonToggleGroupComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ButtonToggleGroupComponent, selector: "ic-button-toggle-group", inputs: { formControl: "formControl", buttonList: "buttonList", disabled: "disabled", outlined: "outlined", customClass: "customClass" }, outputs: { valueChange: "valueChange" }, usesOnChanges: true, ngImport: i0, template: "<div\r\n  class=\"ic-button-toggle-group {{ customClass }}\"\r\n  [class.outlined]=\"outlined\"\r\n  [class.disabled]=\"disabled\">\r\n  <ng-container *ngFor=\"let button of buttonList\">\r\n    <ic-button\r\n      [label]=\"button.label\"\r\n      [type]=\"'button'\"\r\n      size=\"medium\"\r\n      [icButtonType]=\"\r\n        formControl.value === button.value\r\n          ? outlined\r\n            ? 'outlined-neutral'\r\n            : 'filled'\r\n          : 'ghost-basic'\r\n      \"\r\n      [prefixIcon]=\"button.prefixIcon ? button.prefixIcon : ''\"\r\n      [suffixIcon]=\"button.suffixIcon ? button.suffixIcon : ''\"\r\n      class=\"w-100\"\r\n      customButtonClass=\"box-shadow-none w-100 px-0\"\r\n      (OnClick)=\"onButtonClick(button?.value)\">\r\n    </ic-button>\r\n  </ng-container>\r\n</div>\r\n", styles: [".ic-button-toggle-group{position:relative;margin:8px 0;box-shadow:var(--ic-btn-toggle-group-shadow, 0 3px 10px rgba(0, 0, 0, .0901960784));border-radius:8px;display:flex;justify-content:space-between;align-items:center;width:100%;background:var(--ic-btn-toggle-group-bg, #fff);padding:5px;gap:5px}.ic-button-toggle-group.outlined{box-shadow:none!important;border:1px solid var(--ic-btn-toggle-group-border, #e0e0e0)!important;padding:0!important}.ic-button-toggle-group.disabled{cursor:not-allowed;opacity:.6;pointer-events:none}\n"], dependencies: [{ kind: "directive", type: i1$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: ButtonComponent, selector: "ic-button", inputs: ["label", "type", "size", "disabled", "isLoading", "isSkeleton", "icButtonType", "icIcon", "prefixIcon", "suffixIcon", "customButtonClass"], outputs: ["OnClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonToggleGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-button-toggle-group', template: "<div\r\n  class=\"ic-button-toggle-group {{ customClass }}\"\r\n  [class.outlined]=\"outlined\"\r\n  [class.disabled]=\"disabled\">\r\n  <ng-container *ngFor=\"let button of buttonList\">\r\n    <ic-button\r\n      [label]=\"button.label\"\r\n      [type]=\"'button'\"\r\n      size=\"medium\"\r\n      [icButtonType]=\"\r\n        formControl.value === button.value\r\n          ? outlined\r\n            ? 'outlined-neutral'\r\n            : 'filled'\r\n          : 'ghost-basic'\r\n      \"\r\n      [prefixIcon]=\"button.prefixIcon ? button.prefixIcon : ''\"\r\n      [suffixIcon]=\"button.suffixIcon ? button.suffixIcon : ''\"\r\n      class=\"w-100\"\r\n      customButtonClass=\"box-shadow-none w-100 px-0\"\r\n      (OnClick)=\"onButtonClick(button?.value)\">\r\n    </ic-button>\r\n  </ng-container>\r\n</div>\r\n", styles: [".ic-button-toggle-group{position:relative;margin:8px 0;box-shadow:var(--ic-btn-toggle-group-shadow, 0 3px 10px rgba(0, 0, 0, .0901960784));border-radius:8px;display:flex;justify-content:space-between;align-items:center;width:100%;background:var(--ic-btn-toggle-group-bg, #fff);padding:5px;gap:5px}.ic-button-toggle-group.outlined{box-shadow:none!important;border:1px solid var(--ic-btn-toggle-group-border, #e0e0e0)!important;padding:0!important}.ic-button-toggle-group.disabled{cursor:not-allowed;opacity:.6;pointer-events:none}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.ChangeDetectorRef }]; }, propDecorators: { formControl: [{
                type: Input
            }], buttonList: [{
                type: Input
            }], disabled: [{
                type: Input
            }], outlined: [{
                type: Input
            }], customClass: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });

class SliderComponent {
    constructor() {
        this.min = 0;
        this.max = 100;
        this.step = 1;
        this.value = 50;
        this.disabled = false;
        this.showLabel = true;
        this.activeTrackColor = '';
        this.inactiveTrackColor = '';
        this.thumbColor = '';
        this.tooltipBgColor = '';
        this.tooltipTextColor = '';
        this.valueChange = new EventEmitter();
        this.onSliderValueChange = new EventEmitter();
        this.currentValue = 50;
        this.showTooltip = false;
        this.tooltipPosition = 0;
    }
    ngOnInit() {
        this.initializeValue();
        this.updateTooltipPosition();
    }
    ngOnChanges(changes) {
        if (changes['value'] || changes['min'] || changes['max']) {
            this.initializeValue();
            this.updateTooltipPosition();
        }
    }
    initializeValue() {
        if (this.control) {
            this.currentValue = this.control.value ?? this.clampValue(this.value);
        }
        else {
            this.currentValue = this.clampValue(this.value);
        }
    }
    clampValue(value) {
        return Math.min(Math.max(value, this.min), this.max);
    }
    onSliderChange(event) {
        const input = event.target;
        this.currentValue = Number(input.value);
        this.updateTooltipPosition();
        if (this.control) {
            this.control.setValue(this.currentValue, { emitEvent: false });
        }
        this.valueChange.emit(this.currentValue);
        this.onSliderValueChange.emit(this.currentValue);
    }
    updateTooltipPosition() {
        const percentage = ((this.currentValue - this.min) / (this.max - this.min)) * 100;
        this.tooltipPosition = Math.min(Math.max(percentage, 0), 100);
        const sliderElement = document.querySelector('.slider-container input[type="range"]');
        if (sliderElement) {
            sliderElement.style.setProperty('--progress', `${percentage}%`);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SliderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SliderComponent, selector: "ic-slider", inputs: { control: "control", min: "min", max: "max", step: "step", value: "value", disabled: "disabled", showLabel: "showLabel", activeTrackColor: "activeTrackColor", inactiveTrackColor: "inactiveTrackColor", thumbColor: "thumbColor", tooltipBgColor: "tooltipBgColor", tooltipTextColor: "tooltipTextColor" }, outputs: { valueChange: "valueChange", onSliderValueChange: "onSliderValueChange" }, usesOnChanges: true, ngImport: i0, template: "<!-- slider.component.html -->\r\n<div class=\"slider-container\" [class.disabled]=\"disabled\">\r\n  <input\r\n    type=\"range\"\r\n    [min]=\"min\"\r\n    [max]=\"max\"\r\n    [step]=\"step\"\r\n    [value]=\"currentValue\"\r\n    (input)=\"onSliderChange($event)\"\r\n    (mouseenter)=\"showTooltip = true\"\r\n    (mouseleave)=\"showTooltip = false\"\r\n    [disabled]=\"disabled\"\r\n    [style.--active-color]=\"activeTrackColor\"\r\n    [style.--inactive-color]=\"inactiveTrackColor\"\r\n    [style.--thumb-color]=\"thumbColor\" />\r\n\r\n  <div class=\"slider-labels\" *ngIf=\"showLabel\">\r\n    <span>{{ min }}</span>\r\n    <span>{{ max }}</span>\r\n  </div>\r\n\r\n  <div\r\n    class=\"tooltip\"\r\n    [class.visible]=\"showTooltip\"\r\n    [style.left]=\"tooltipPosition + '%'\"\r\n    [style.background]=\"tooltipBgColor\"\r\n    [style.color]=\"tooltipTextColor\">\r\n    {{ currentValue }}\r\n  </div>\r\n</div>\r\n", styles: [".slider-container{position:relative;width:100%;padding:15px 0;--active-color: #0033a1;--inactive-color: #b4b4b430;--thumb-color: #0033a1;--tooltip-bg: #333;--tooltip-text: #fff;--disabled-track: #e0e0e0;--disabled-thumb: #9e9e9e}.slider-container input[type=range]{width:100%;height:6px;margin:0;appearance:none;background:linear-gradient(to right,var(--active-color) 0%,var(--active-color) var(--progress, 50%),var(--inactive-color) var(--progress, 50%),var(--inactive-color) 100%);border-radius:3px;outline:none;cursor:pointer}.slider-container input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:var(--thumb-color);cursor:pointer;-webkit-transition:transform .1s;transition:transform .1s;box-shadow:0 2px 4px #0003}.slider-container input[type=range]::-moz-range-thumb{width:18px;height:18px;border-radius:50%;background:var(--thumb-color);cursor:pointer;-moz-transition:transform .1s;transition:transform .1s;box-shadow:0 2px 4px #0003}.slider-container input[type=range]:hover::-webkit-slider-thumb{transform:scale(1.1)}.slider-container input[type=range]:hover::-moz-range-thumb{transform:scale(1.1)}.slider-container.disabled input[type=range]{cursor:not-allowed}.slider-container.disabled input[type=range]::-webkit-slider-thumb{transform:none!important;cursor:not-allowed}.slider-container.disabled input[type=range]::-moz-range-thumb{transform:none!important;cursor:not-allowed}.slider-container .slider-labels{display:flex;justify-content:space-between;margin-top:8px;font-size:12px;color:#666}.slider-container .tooltip{position:absolute;top:-30px;transform:translate(-50%);padding:4px 8px;border-radius:4px;background:var(--tooltip-bg);color:var(--tooltip-text);font-size:12px;opacity:0;transition:opacity .2s;pointer-events:none;white-space:nowrap;box-shadow:0 2px 4px #0000001a}.slider-container .tooltip.visible{opacity:1}\n"], dependencies: [{ kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NoInitialSpaceDirective, selector: "input, textarea" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SliderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-slider', encapsulation: ViewEncapsulation.None, template: "<!-- slider.component.html -->\r\n<div class=\"slider-container\" [class.disabled]=\"disabled\">\r\n  <input\r\n    type=\"range\"\r\n    [min]=\"min\"\r\n    [max]=\"max\"\r\n    [step]=\"step\"\r\n    [value]=\"currentValue\"\r\n    (input)=\"onSliderChange($event)\"\r\n    (mouseenter)=\"showTooltip = true\"\r\n    (mouseleave)=\"showTooltip = false\"\r\n    [disabled]=\"disabled\"\r\n    [style.--active-color]=\"activeTrackColor\"\r\n    [style.--inactive-color]=\"inactiveTrackColor\"\r\n    [style.--thumb-color]=\"thumbColor\" />\r\n\r\n  <div class=\"slider-labels\" *ngIf=\"showLabel\">\r\n    <span>{{ min }}</span>\r\n    <span>{{ max }}</span>\r\n  </div>\r\n\r\n  <div\r\n    class=\"tooltip\"\r\n    [class.visible]=\"showTooltip\"\r\n    [style.left]=\"tooltipPosition + '%'\"\r\n    [style.background]=\"tooltipBgColor\"\r\n    [style.color]=\"tooltipTextColor\">\r\n    {{ currentValue }}\r\n  </div>\r\n</div>\r\n", styles: [".slider-container{position:relative;width:100%;padding:15px 0;--active-color: #0033a1;--inactive-color: #b4b4b430;--thumb-color: #0033a1;--tooltip-bg: #333;--tooltip-text: #fff;--disabled-track: #e0e0e0;--disabled-thumb: #9e9e9e}.slider-container input[type=range]{width:100%;height:6px;margin:0;appearance:none;background:linear-gradient(to right,var(--active-color) 0%,var(--active-color) var(--progress, 50%),var(--inactive-color) var(--progress, 50%),var(--inactive-color) 100%);border-radius:3px;outline:none;cursor:pointer}.slider-container input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:var(--thumb-color);cursor:pointer;-webkit-transition:transform .1s;transition:transform .1s;box-shadow:0 2px 4px #0003}.slider-container input[type=range]::-moz-range-thumb{width:18px;height:18px;border-radius:50%;background:var(--thumb-color);cursor:pointer;-moz-transition:transform .1s;transition:transform .1s;box-shadow:0 2px 4px #0003}.slider-container input[type=range]:hover::-webkit-slider-thumb{transform:scale(1.1)}.slider-container input[type=range]:hover::-moz-range-thumb{transform:scale(1.1)}.slider-container.disabled input[type=range]{cursor:not-allowed}.slider-container.disabled input[type=range]::-webkit-slider-thumb{transform:none!important;cursor:not-allowed}.slider-container.disabled input[type=range]::-moz-range-thumb{transform:none!important;cursor:not-allowed}.slider-container .slider-labels{display:flex;justify-content:space-between;margin-top:8px;font-size:12px;color:#666}.slider-container .tooltip{position:absolute;top:-30px;transform:translate(-50%);padding:4px 8px;border-radius:4px;background:var(--tooltip-bg);color:var(--tooltip-text);font-size:12px;opacity:0;transition:opacity .2s;pointer-events:none;white-space:nowrap;box-shadow:0 2px 4px #0000001a}.slider-container .tooltip.visible{opacity:1}\n"] }]
        }], propDecorators: { control: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], step: [{
                type: Input
            }], value: [{
                type: Input
            }], disabled: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], activeTrackColor: [{
                type: Input
            }], inactiveTrackColor: [{
                type: Input
            }], thumbColor: [{
                type: Input
            }], tooltipBgColor: [{
                type: Input
            }], tooltipTextColor: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], onSliderValueChange: [{
                type: Output
            }] } });

const classes = [
    /** Components */
    CardComponent,
    ButtonComponent,
    FormFieldComponent,
    SelectComponent,
    MobileFieldComponent,
    TenureFieldComponent,
    HeaderComponent,
    FooterComponent,
    SlideToggleComponent,
    CheckboxComponent,
    ImageComponent,
    SpinnerComponent,
    DatePickerComponent,
    RadioButtonComponent,
    TextareaComponent,
    ButtonToggleGroupComponent,
    IconComponent,
    SliderComponent,
];
class IcustLibraryModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IcustLibraryModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: IcustLibraryModule, declarations: [
            /** Components */
            CardComponent,
            ButtonComponent,
            FormFieldComponent,
            SelectComponent,
            MobileFieldComponent,
            TenureFieldComponent,
            HeaderComponent,
            FooterComponent,
            SlideToggleComponent,
            CheckboxComponent,
            ImageComponent,
            SpinnerComponent,
            DatePickerComponent,
            RadioButtonComponent,
            TextareaComponent,
            ButtonToggleGroupComponent,
            IconComponent,
            SliderComponent], imports: [CommonModule,
            ReactiveFormsModule,
            FormsModule,
            PerfectScrollbarModule,
            InputMaskModule,
            LibDirectiveModule,
            NgOptimizedImage], exports: [
            /** Components */
            CardComponent,
            ButtonComponent,
            FormFieldComponent,
            SelectComponent,
            MobileFieldComponent,
            TenureFieldComponent,
            HeaderComponent,
            FooterComponent,
            SlideToggleComponent,
            CheckboxComponent,
            ImageComponent,
            SpinnerComponent,
            DatePickerComponent,
            RadioButtonComponent,
            TextareaComponent,
            ButtonToggleGroupComponent,
            IconComponent,
            SliderComponent, PerfectScrollbarModule,
            InputMaskModule,
            LibDirectiveModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IcustLibraryModule, imports: [CommonModule,
            ReactiveFormsModule,
            FormsModule,
            PerfectScrollbarModule,
            InputMaskModule,
            LibDirectiveModule, PerfectScrollbarModule,
            InputMaskModule,
            LibDirectiveModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IcustLibraryModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: classes,
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        FormsModule,
                        PerfectScrollbarModule,
                        InputMaskModule,
                        LibDirectiveModule,
                        NgOptimizedImage,
                    ],
                    exports: [
                        ...classes,
                        PerfectScrollbarModule,
                        InputMaskModule,
                        LibDirectiveModule,
                    ],
                }]
        }] });

/*
 * Public API Surface of icust-library
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AlphaNumericWithSpaceDirective, AlphabetOnlyDirective, AlphanumericDirective, ButtonComponent, ButtonToggleGroupComponent, CardComponent, CheckboxComponent, CleaveCurrencyDirective, CurrencyFormatterDirective, DateFormatEnforcerDirective, DatePickerComponent, FlexLayoutDirective, FooterComponent, ForceNativeScrollDirective, FormFieldComponent, Geometry, HeaderComponent, INPUT_MASK_CONFIG, IcIconRegistryService, IconComponent, IcustLibraryModule, ImageComponent, ImageLazyLoadDirective, InputMaskConfig, InputMaskDirective, InputMaskModule, IsUpperCaseDirective, LibDirectiveModule, MobileFieldComponent, NoInitialSpaceDirective, NoSpaceDirective, NoSpecialCharFirstDirective, NumbersOnlyDirective, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarComponent, PerfectScrollbarConfig, PerfectScrollbarDirective, PerfectScrollbarModule, Position, PreventInitialZeroDirective, RadioButtonComponent, RestrictDecimalDirective, RestrictPercentageDirective, SelectComponent, SlideToggleComponent, SliderComponent, SpecialAlphaNumericDirective, SpecialAlphaNumericExtendedDirective, SpecialTextDirective, SpinnerComponent, TenureFieldComponent, TextareaComponent, ThemeConfigService, TwoDigitDecimalNumberDirective, createMask, currencyList };
//# sourceMappingURL=onerumango-icust-element-library.mjs.map
