import { EventEmitter, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class CheckboxComponent implements OnInit, OnChanges {
    formControl: FormControl;
    checked: boolean;
    disabled: boolean;
    required: boolean;
    indeterminate: boolean;
    labelPosition: 'before' | 'after';
    color?: 'primary' | 'accent' | 'warn';
    icCheckBoxType: 'filled' | 'outlined';
    name: string;
    id: string;
    ariaLabel: string;
    ariaLabelledBy: string;
    /** Outputs */
    checkboxChange: EventEmitter<boolean>;
    indeterminateChange: EventEmitter<boolean>;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onCheckboxChange(event: Event): void;
    /** Handle indeterminate state change */
    onIndeterminateChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent, "ic-checkbox", never, { "formControl": { "alias": "formControl"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "required": { "alias": "required"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "color": { "alias": "color"; "required": false; }; "icCheckBoxType": { "alias": "icCheckBoxType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "id": { "alias": "id"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; }; }, { "checkboxChange": "checkboxChange"; "indeterminateChange": "indeterminateChange"; }, never, ["*"], false, never>;
}
