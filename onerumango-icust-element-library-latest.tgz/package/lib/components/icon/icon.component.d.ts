import { ElementRef, OnChanges, Renderer2, SimpleChanges } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import { IcIconRegistryService } from '../../services';
import * as i0 from "@angular/core";
export declare class IconComponent implements OnChanges {
    private iconRegistry;
    private renderer;
    private el;
    name?: string | null;
    color?: string;
    size: string;
    svgIcon: SafeHtml;
    constructor(iconRegistry: IcIconRegistryService, renderer: Renderer2, el: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    private loadIcon;
    private applyStyles;
    private clearIcon;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconComponent, "ic-icon", never, { "name": { "alias": "name"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, false, never>;
}
