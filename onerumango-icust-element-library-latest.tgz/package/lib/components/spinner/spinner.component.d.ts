import * as i0 from "@angular/core";
export declare class SpinnerComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SpinnerComponent, "ic-spinner", never, {}, {}, never, never, false, never>;
}
