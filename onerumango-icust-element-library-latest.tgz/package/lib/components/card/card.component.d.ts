import { AfterContentInit } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import * as i0 from "@angular/core";
export declare class CardComponent implements AfterContentInit {
    header: HeaderComponent | null;
    footer: FooterComponent | null;
    hasHeader: boolean;
    hasFooter: boolean;
    ngAfterContentInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardComponent, "ic-card", never, {}, {}, ["header", "footer"], ["ic-header", "*", "ic-footer"], false, never>;
}
