import { OnInit, OnDestroy, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class RadioButtonComponent implements OnInit, OnDestroy {
    value: any;
    label: string;
    disabled: boolean;
    control: FormControl;
    groupName?: string;
    uniqueName: string;
    private valueChangeSub;
    valueChange: EventEmitter<any>;
    get isDisabled(): boolean;
    ngOnInit(): void;
    onSelectionChange(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioButtonComponent, "ic-radio-button", never, { "value": { "alias": "value"; "required": false; }; "label": { "alias": "label"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "control": { "alias": "control"; "required": false; }; "groupName": { "alias": "groupName"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}
