import { EventEmitter, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class SlideToggleComponent implements OnInit, OnChanges {
    formControl: FormControl;
    checked: boolean;
    disabled: boolean;
    required: boolean;
    color: 'primary' | 'accent' | 'warn';
    labelPosition: 'before' | 'after';
    id: string;
    ariaLabel: string;
    ariaLabelledBy: string;
    sliderChange: EventEmitter<boolean>;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onToggleChange(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SlideToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SlideToggleComponent, "ic-slide-toggle", never, { "formControl": { "alias": "formControl"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "required": { "alias": "required"; "required": false; }; "color": { "alias": "color"; "required": false; }; "labelPosition": { "alias": "labelPosition"; "required": false; }; "id": { "alias": "id"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; }; }, { "sliderChange": "sliderChange"; }, never, ["*"], false, never>;
}
