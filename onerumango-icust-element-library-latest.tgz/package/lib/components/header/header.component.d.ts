import * as i0 from "@angular/core";
export declare class HeaderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeaderComponent, "ic-header", never, {}, {}, never, ["*"], false, never>;
}
