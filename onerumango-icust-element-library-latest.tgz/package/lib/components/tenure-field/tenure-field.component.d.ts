import { EventEmitter, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class TenureFieldComponent implements OnInit {
    private fb;
    label: string;
    fields: string[];
    fieldLabels: {
        [key: string]: string;
    };
    customError: string;
    parentForm: FormGroup;
    isRequired: boolean;
    disabled: boolean;
    skipLabel: boolean;
    readonly: boolean;
    inputValuesChange: EventEmitter<{
        [key: string]: number;
    }>;
    showError: boolean;
    errorMessage: string;
    constructor(fb: FormBuilder);
    ngOnInit(): void;
    ngDoCheck(): void;
    normalizeValues(values: {
        [key: string]: any;
    }): {
        [key: string]: number;
    };
    getFieldLabel(field: string): string;
    isNumeric(value: any): boolean;
    onBlur(field: string): void;
    onPaste(event: ClipboardEvent, field: string): void;
    validateForm(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TenureFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TenureFieldComponent, "ic-tenure-field", never, { "label": { "alias": "label"; "required": false; }; "fields": { "alias": "fields"; "required": false; }; "fieldLabels": { "alias": "fieldLabels"; "required": false; }; "customError": { "alias": "customError"; "required": false; }; "parentForm": { "alias": "parentForm"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "skipLabel": { "alias": "skipLabel"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; }, { "inputValuesChange": "inputValuesChange"; }, never, never, false, never>;
}
