import { OnInit, OnChanges, EventEmitter, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ButtonToggleGroupComponent implements OnInit, OnChanges {
    private cdr;
    formControl: FormControl;
    buttonList: {
        label: string;
        value: any;
        prefixIcon?: string;
        suffixIcon?: string;
    }[];
    disabled: boolean;
    outlined: boolean;
    customClass: string;
    valueChange: EventEmitter<any>;
    constructor(cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onButtonClick(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonToggleGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonToggleGroupComponent, "ic-button-toggle-group", never, { "formControl": { "alias": "formControl"; "required": false; }; "buttonList": { "alias": "buttonList"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "outlined": { "alias": "outlined"; "required": false; }; "customClass": { "alias": "customClass"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}
