import { OnInit } from '@angular/core';
import { SafeUrl } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class ImageComponent implements OnInit {
    /** Main image source */
    src: string | SafeUrl;
    /** Fallback image source when `src` fails */
    srcFallback: string;
    /** Placeholder image shown while loading */
    placeholder: string;
    /** Custom CSS classes for styling */
    customClass: string;
    /** Alt text for the image */
    alt: string;
    /** Tracks the current source being displayed */
    imageSrc: string | SafeUrl;
    /** Tracks loading state */
    isLoading: boolean;
    width: number | undefined;
    height: number | undefined;
    ngOnInit(): void;
    /**
     * Handle successful image loading
     */
    onLoad(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImageComponent, "ic-image", never, { "src": { "alias": "src"; "required": false; }; "srcFallback": { "alias": "srcFallback"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "customClass": { "alias": "customClass"; "required": false; }; "alt": { "alias": "alt"; "required": false; }; "width": { "alias": "width"; "required": false; }; "height": { "alias": "height"; "required": false; }; }, {}, never, never, false, never>;
}
