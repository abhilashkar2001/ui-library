import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ButtonComponent implements OnChanges {
    label: string;
    type: 'button' | 'submit' | 'reset' | 'icon';
    size: 'small' | 'medium' | 'large';
    disabled: boolean;
    isLoading: boolean;
    isSkeleton: boolean;
    icButtonType: string;
    icIcon: string;
    prefixIcon: string;
    suffixIcon: string;
    customButtonClass: string;
    OnClick: EventEmitter<any>;
    ngOnChanges(changes: SimpleChanges): void;
    onButtonClick(event: MouseEvent): void;
    handleClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "ic-button", never, { "label": { "alias": "label"; "required": false; }; "type": { "alias": "type"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "isLoading": { "alias": "isLoading"; "required": false; }; "isSkeleton": { "alias": "isSkeleton"; "required": false; }; "icButtonType": { "alias": "icButtonType"; "required": false; }; "icIcon": { "alias": "icIcon"; "required": false; }; "prefixIcon": { "alias": "prefixIcon"; "required": false; }; "suffixIcon": { "alias": "suffixIcon"; "required": false; }; "customButtonClass": { "alias": "customButtonClass"; "required": false; }; }, { "OnClick": "OnClick"; }, never, never, false, never>;
}
