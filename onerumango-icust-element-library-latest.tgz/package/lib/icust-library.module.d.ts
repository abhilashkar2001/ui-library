import * as i0 from "@angular/core";
import * as i1 from "./components/card/card.component";
import * as i2 from "./components/button/button.component";
import * as i3 from "./components/form-field/form-field.component";
import * as i4 from "./components/select/select.component";
import * as i5 from "./components/mobile-field/mobile-field.component";
import * as i6 from "./components/tenure-field/tenure-field.component";
import * as i7 from "./components/header/header.component";
import * as i8 from "./components/footer/footer.component";
import * as i9 from "./components/slide-toggle/slide-toggle.component";
import * as i10 from "./components/checkbox/checkbox.component";
import * as i11 from "./components/image/image.component";
import * as i12 from "./components/spinner/spinner.component";
import * as i13 from "./components/date-picker/date-picker.component";
import * as i14 from "./components/radio-button/radio-button.component";
import * as i15 from "./components/textarea/textarea.component";
import * as i16 from "./components/button-toggle-group/button-toggle-group.component";
import * as i17 from "./components/icon/icon.component";
import * as i18 from "./components/slider/slider.component";
import * as i19 from "@angular/common";
import * as i20 from "@angular/forms";
import * as i21 from "./components/perfect-scrollbar/perfect-scrollbar.module";
import * as i22 from "./directives/input-mask/input-mask.module";
import * as i23 from "./directives/lib-directive.module";
export declare class IcustLibraryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<IcustLibraryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IcustLibraryModule, [typeof i1.CardComponent, typeof i2.ButtonComponent, typeof i3.FormFieldComponent, typeof i4.SelectComponent, typeof i5.MobileFieldComponent, typeof i6.TenureFieldComponent, typeof i7.HeaderComponent, typeof i8.FooterComponent, typeof i9.SlideToggleComponent, typeof i10.CheckboxComponent, typeof i11.ImageComponent, typeof i12.SpinnerComponent, typeof i13.DatePickerComponent, typeof i14.RadioButtonComponent, typeof i15.TextareaComponent, typeof i16.ButtonToggleGroupComponent, typeof i17.IconComponent, typeof i18.SliderComponent], [typeof i19.CommonModule, typeof i20.ReactiveFormsModule, typeof i20.FormsModule, typeof i21.PerfectScrollbarModule, typeof i22.InputMaskModule, typeof i23.LibDirectiveModule, typeof i19.NgOptimizedImage], [typeof i1.CardComponent, typeof i2.ButtonComponent, typeof i3.FormFieldComponent, typeof i4.SelectComponent, typeof i5.MobileFieldComponent, typeof i6.TenureFieldComponent, typeof i7.HeaderComponent, typeof i8.FooterComponent, typeof i9.SlideToggleComponent, typeof i10.CheckboxComponent, typeof i11.ImageComponent, typeof i12.SpinnerComponent, typeof i13.DatePickerComponent, typeof i14.RadioButtonComponent, typeof i15.TextareaComponent, typeof i16.ButtonToggleGroupComponent, typeof i17.IconComponent, typeof i18.SliderComponent, typeof i21.PerfectScrollbarModule, typeof i22.InputMaskModule, typeof i23.LibDirectiveModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IcustLibraryModule>;
}
