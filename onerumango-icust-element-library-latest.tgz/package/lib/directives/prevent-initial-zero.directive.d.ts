import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PreventInitialZeroDirective {
    private el;
    icPreventInitialZero: boolean;
    constructor(el: ElementRef);
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PreventInitialZeroDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PreventInitialZeroDirective, "[icPreventInitialZero]", never, { "icPreventInitialZero": { "alias": "icPreventInitialZero"; "required": false; }; }, {}, never, never, false, never>;
}
