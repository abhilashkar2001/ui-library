import * as i0 from "@angular/core";
export declare class SpecialTextDirective {
    private regex;
    specialText: boolean;
    constructor();
    onKeyPress(event: KeyboardEvent): void;
    blockPaste(event: ClipboardEvent): void;
    private validateFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<SpecialTextDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SpecialTextDirective, "[icSpecialText]", never, { "specialText": { "alias": "icSpecialText"; "required": false; }; }, {}, never, never, false, never>;
}
