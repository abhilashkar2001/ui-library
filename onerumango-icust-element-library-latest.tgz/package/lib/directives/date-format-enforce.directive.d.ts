import { ElementRef, OnInit } from '@angular/core';
import { NgControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class DateFormatEnforcerDirective implements OnInit {
    private el;
    private control;
    constructor(el: ElementRef<HTMLInputElement>, control: NgControl);
    ngOnInit(): void;
    onKeyDown(event: KeyboardEvent): void;
    onInput(): void;
    onBlur(): void;
    onPaste(event: ClipboardEvent): void;
    private formatToDate;
    private isValidDate;
    private setValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateFormatEnforcerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DateFormatEnforcerDirective, "[icDateFormatEnforcer]", never, {}, {}, never, never, false, never>;
}
