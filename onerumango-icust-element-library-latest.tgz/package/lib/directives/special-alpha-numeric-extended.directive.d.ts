import { Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SpecialAlphaNumericExtendedDirective {
    private renderer;
    private regex;
    specialIsAlphaNumeric: boolean;
    constructor(renderer: Renderer2);
    onInputChange(event: Event): void;
    blockPaste(event: ClipboardEvent): void;
    private validateFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<SpecialAlphaNumericExtendedDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SpecialAlphaNumericExtendedDirective, "[icSpecialAlphaNumericExtended]", never, { "specialIsAlphaNumeric": { "alias": "icSpecialAlphaNumericExtended"; "required": false; }; }, {}, never, never, false, never>;
}
