import { ElementRef, OnInit } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class CurrencyFormatterDirective implements ControlValueAccessor, OnInit {
    private el;
    currencyCode: string | undefined;
    private config;
    private onChange;
    private onTouched;
    constructor(el: ElementRef<HTMLInputElement>);
    ngOnInit(): void;
    onInput(event: Event): void;
    onBlur(): void;
    writeValue(value: number): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    private formatValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyFormatterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CurrencyFormatterDirective, "[icCurrencyFormatter]", never, { "currencyCode": { "alias": "icCurrencyFormatter"; "required": false; }; }, {}, never, never, false, never>;
}
