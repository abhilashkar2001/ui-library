import { ElementRef, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class IsUpperCaseDirective {
    private el;
    private renderer;
    isUpperCase: boolean;
    constructor(el: ElementRef, renderer: Renderer2);
    onInputChange(event: Event): void;
    onPaste(event: ClipboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsUpperCaseDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IsUpperCaseDirective, "[icIsUpperCase]", never, { "isUpperCase": { "alias": "icIsUpperCase"; "required": false; }; }, {}, never, never, false, never>;
}
