import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class RestrictPercentageDirective {
    private el;
    enableRestrict: boolean;
    maxNumber: number;
    maxDecimal: number;
    constructor(el: ElementRef);
    onInput(event: Event): void;
    /**
     * Validates if the input value is a valid percentage (0-100 with up to 2 decimal places).
     */
    private isValidNumber;
    /**
     * Sanitizes the input value by removing invalid characters.
     */
    private sanitizeValue;
    /**
     * Updates the input value programmatically and triggers the 'input' event.
     */
    private updateInputValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<RestrictPercentageDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RestrictPercentageDirective, "[icRestrictPercentage]", never, { "enableRestrict": { "alias": "icRestrictPercentage"; "required": false; }; }, {}, never, never, false, never>;
}
