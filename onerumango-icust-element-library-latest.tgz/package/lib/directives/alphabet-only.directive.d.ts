import * as i0 from "@angular/core";
export declare class AlphabetOnlyDirective {
    appAlphabetOnly: boolean;
    onKeydown(event: KeyboardEvent): void;
    onPaste(event: ClipboardEvent): void;
    private isAlpha;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlphabetOnlyDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AlphabetOnlyDirective, "[icAlphabetOnly]", never, { "appAlphabetOnly": { "alias": "icAlphabetOnly"; "required": false; }; }, {}, never, never, false, never>;
}
