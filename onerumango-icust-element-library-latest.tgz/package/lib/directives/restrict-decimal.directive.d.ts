import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class RestrictDecimalDirective {
    private _el;
    regexStructure: string;
    constructor(_el: ElementRef);
    onInputChange(event: any): void;
    onKeyPress(event: any): boolean;
    blockPaste(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RestrictDecimalDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RestrictDecimalDirective, "ion-input[icRestrictDecimal],[icRestrictDecimal]", never, {}, {}, never, never, false, never>;
}
