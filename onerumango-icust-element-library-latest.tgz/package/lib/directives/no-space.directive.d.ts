import { Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class NoSpaceDirective {
    private renderer;
    noSpace: boolean;
    constructor(renderer: Renderer2);
    onKeyDown(event: KeyboardEvent): void;
    onInputChange(event: Event): void;
    onPaste(event: ClipboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NoSpaceDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NoSpaceDirective, "[icNoSpace]", never, { "noSpace": { "alias": "icNoSpace"; "required": false; }; }, {}, never, never, false, never>;
}
