import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class TwoDigitDecimalNumberDirective {
    private el;
    icTwoDigitDecimalNumber: boolean;
    decimalPlaces: number;
    numLength: number;
    constructor(el: ElementRef);
    onInput(): void;
    onPaste(event: ClipboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TwoDigitDecimalNumberDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TwoDigitDecimalNumberDirective, "[icTwoDigitDecimalNumber]", never, { "icTwoDigitDecimalNumber": { "alias": "icTwoDigitDecimalNumber"; "required": false; }; "decimalPlaces": { "alias": "decimalPlaces"; "required": false; }; "numLength": { "alias": "numLength"; "required": false; }; }, {}, never, never, false, never>;
}
