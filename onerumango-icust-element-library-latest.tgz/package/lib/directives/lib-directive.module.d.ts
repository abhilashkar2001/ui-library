import * as i0 from "@angular/core";
import * as i1 from "./flex-layout.directive";
import * as i2 from "./is-upper-case.directive";
import * as i3 from "./alpha-numeric-with-space.directive";
import * as i4 from "./no-initial-space.directive";
import * as i5 from "./numbers-only.directive";
import * as i6 from "./special-alpha-numeric.directive";
import * as i7 from "./special-text.directive";
import * as i8 from "./no-space.directive";
import * as i9 from "./alphanumeric.directive";
import * as i10 from "./no-special-char-first.directive";
import * as i11 from "./alphabet-only.directive";
import * as i12 from "./restrict-percentage.directive";
import * as i13 from "./restrict-decimal.directive";
import * as i14 from "./two-digit-decimal-number.directive";
import * as i15 from "./image-lazy-load.directive";
import * as i16 from "./prevent-initial-zero.directive";
import * as i17 from "./special-alpha-numeric-extended.directive";
import * as i18 from "./date-format-enforce.directive";
import * as i19 from "./currency-formatter.directive";
import * as i20 from "./cleave-currency.directive";
import * as i21 from "@angular/common";
export declare class LibDirectiveModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LibDirectiveModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LibDirectiveModule, [typeof i1.FlexLayoutDirective, typeof i2.IsUpperCaseDirective, typeof i3.AlphaNumericWithSpaceDirective, typeof i4.NoInitialSpaceDirective, typeof i5.NumbersOnlyDirective, typeof i6.SpecialAlphaNumericDirective, typeof i7.SpecialTextDirective, typeof i8.NoSpaceDirective, typeof i9.AlphanumericDirective, typeof i10.NoSpecialCharFirstDirective, typeof i11.AlphabetOnlyDirective, typeof i12.RestrictPercentageDirective, typeof i13.RestrictDecimalDirective, typeof i14.TwoDigitDecimalNumberDirective, typeof i15.ImageLazyLoadDirective, typeof i16.PreventInitialZeroDirective, typeof i17.SpecialAlphaNumericExtendedDirective, typeof i8.NoSpaceDirective, typeof i9.AlphanumericDirective, typeof i13.RestrictDecimalDirective, typeof i18.DateFormatEnforcerDirective, typeof i19.CurrencyFormatterDirective, typeof i20.CleaveCurrencyDirective], [typeof i21.CommonModule], [typeof i1.FlexLayoutDirective, typeof i2.IsUpperCaseDirective, typeof i3.AlphaNumericWithSpaceDirective, typeof i4.NoInitialSpaceDirective, typeof i5.NumbersOnlyDirective, typeof i6.SpecialAlphaNumericDirective, typeof i7.SpecialTextDirective, typeof i8.NoSpaceDirective, typeof i9.AlphanumericDirective, typeof i10.NoSpecialCharFirstDirective, typeof i11.AlphabetOnlyDirective, typeof i12.RestrictPercentageDirective, typeof i13.RestrictDecimalDirective, typeof i14.TwoDigitDecimalNumberDirective, typeof i15.ImageLazyLoadDirective, typeof i16.PreventInitialZeroDirective, typeof i17.SpecialAlphaNumericExtendedDirective, typeof i8.NoSpaceDirective, typeof i9.AlphanumericDirective, typeof i13.RestrictDecimalDirective, typeof i18.DateFormatEnforcerDirective, typeof i19.CurrencyFormatterDirective, typeof i20.CleaveCurrencyDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LibDirectiveModule>;
}
