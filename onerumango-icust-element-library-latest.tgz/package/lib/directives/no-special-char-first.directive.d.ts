import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class NoSpecialCharFirstDirective {
    private el;
    constructor(el: ElementRef);
    NoSpecialCharFirst: boolean;
    onInputChange(): void;
    private isValidFirstChar;
    static ɵfac: i0.ɵɵFactoryDeclaration<NoSpecialCharFirstDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NoSpecialCharFirstDirective, "[icNoSpecialCharFirst]", never, { "NoSpecialCharFirst": { "alias": "icNoSpecialCharFirst"; "required": false; }; }, {}, never, never, false, never>;
}
