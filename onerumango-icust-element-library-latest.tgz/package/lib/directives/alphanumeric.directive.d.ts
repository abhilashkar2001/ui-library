import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class AlphanumericDirective {
    private el;
    isAlphanumeric: boolean;
    regexStr: string;
    constructor(el: ElementRef);
    onKeyPress(event: {
        key: string;
    }): string | boolean;
    blockPaste(event: KeyboardEvent): void;
    validateFields(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlphanumericDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AlphanumericDirective, "[icAlphanumeric]", never, { "isAlphanumeric": { "alias": "icAlphanumeric"; "required": false; }; }, {}, never, never, false, never>;
}
