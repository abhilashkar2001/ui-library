import { ElementRef, OnInit, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class CleaveCurrencyDirective implements OnInit, OnDestroy, OnChanges {
    private el;
    cleaveCurrency?: boolean;
    private cleaveInstance;
    constructor(el: ElementRef<HTMLInputElement>);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private initCleave;
    private destroyCleave;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CleaveCurrencyDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CleaveCurrencyDirective, "[icCleaveCurrency]", never, { "cleaveCurrency": { "alias": "icCleaveCurrency"; "required": false; }; }, {}, never, never, false, never>;
}
