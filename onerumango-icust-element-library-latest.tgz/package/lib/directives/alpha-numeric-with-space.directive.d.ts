import * as i0 from "@angular/core";
export declare class AlphaNumericWithSpaceDirective {
    regexStr: string;
    isAlphanumericspace: boolean | any;
    isAlphaNumeric: boolean | any;
    upperCaseOnly: boolean | any;
    onKeyPress(event: KeyboardEvent): void;
    blockPaste(event: ClipboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlphaNumericWithSpaceDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AlphaNumericWithSpaceDirective, "[icAlphaNumericWithSpace]", never, { "isAlphanumericspace": { "alias": "icAlphaNumericWithSpace"; "required": false; }; "isAlphaNumeric": { "alias": "isAlphaNumeric"; "required": false; }; "upperCaseOnly": { "alias": "upperCaseOnly"; "required": false; }; }, {}, never, never, false, never>;
}
