import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class NumbersOnlyDirective {
    private _el;
    regexStructure: string;
    isNumbersOnly: boolean | undefined;
    constructor(_el: ElementRef);
    onInputChange(event: Event): void;
    onKeyPress(event: KeyboardEvent): boolean | undefined;
    blockPaste(event: ClipboardEvent): void;
    validationFields(event: ClipboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumbersOnlyDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NumbersOnlyDirective, "[icNumbersOnly]", never, { "isNumbersOnly": { "alias": "icNumbersOnly"; "required": false; }; }, {}, never, never, false, never>;
}
