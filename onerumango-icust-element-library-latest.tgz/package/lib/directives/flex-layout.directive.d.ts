import * as i0 from "@angular/core";
export declare class FlexLayoutDirective {
    /** Flexbox container direction */
    fxLayout: 'row' | 'row-reverse' | 'column' | 'column-reverse';
    /** Alignment of children along the main axis */
    fxLayoutAlign: 'start start' | 'start center' | 'start end' | 'start stretch' | 'center start' | 'center center' | 'center end' | 'center stretch' | 'end start' | 'end center' | 'end end' | 'end stretch' | 'space-between stretch' | 'space-around stretch' | 'space-evenly stretch';
    /** Flex property for the element */
    fxFlex: string;
    /** Gap between child elements */
    fxLayoutGap?: string;
    /** Host bindings for styles */
    display: string;
    get flexDirection(): "row" | "row-reverse" | "column" | "column-reverse";
    get justifyContent(): string;
    get alignItems(): string;
    get flex(): string;
    get gap(): string | undefined;
    /**
     * Helper function to extract justify-content and align-items
     * from the fxLayoutAlign input.
     */
    private extractAlignment;
    /** Maps fxLayoutAlign's justify-content values */
    private mapJustifyContent;
    /** Maps fxLayoutAlign's align-items values */
    private mapAlignItems;
    static ɵfac: i0.ɵɵFactoryDeclaration<FlexLayoutDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FlexLayoutDirective, "[icFlexLayout]", never, { "fxLayout": { "alias": "fxLayout"; "required": false; }; "fxLayoutAlign": { "alias": "fxLayoutAlign"; "required": false; }; "fxFlex": { "alias": "fxFlex"; "required": false; }; "fxLayoutGap": { "alias": "fxLayoutGap"; "required": false; }; }, {}, never, never, false, never>;
}
