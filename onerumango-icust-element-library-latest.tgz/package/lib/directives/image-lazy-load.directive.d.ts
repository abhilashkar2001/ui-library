import { ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import { SafeResourceUrl } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class ImageLazyLoadDirective implements OnChanges {
    private el;
    icLazyLoad: SafeResourceUrl | string | undefined;
    fallbackImage: SafeResourceUrl | string | undefined;
    srcAttr: SafeResourceUrl | string | null | undefined;
    constructor(el: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    onError(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageLazyLoadDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ImageLazyLoadDirective, "[icLazyLoad]", never, { "icLazyLoad": { "alias": "icLazyLoad"; "required": false; }; "fallbackImage": { "alias": "fallbackImage"; "required": false; }; }, {}, never, never, false, never>;
}
