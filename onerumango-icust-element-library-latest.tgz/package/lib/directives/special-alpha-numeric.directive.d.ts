import { Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SpecialAlphaNumericDirective {
    private renderer;
    private regex;
    specialIsAlphaNumeric: boolean;
    constructor(renderer: Renderer2);
    onInputChange(event: InputEvent): void;
    onPaste(event: ClipboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SpecialAlphaNumericDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SpecialAlphaNumericDirective, "[icSpecialAlphaNumeric]", never, { "specialIsAlphaNumeric": { "alias": "icSpecialAlphaNumeric"; "required": false; }; }, {}, never, never, false, never>;
}
