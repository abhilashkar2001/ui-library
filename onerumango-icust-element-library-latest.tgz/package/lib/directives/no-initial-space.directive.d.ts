import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class NoInitialSpaceDirective {
    private el;
    constructor(el: ElementRef);
    onInput(_event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NoInitialSpaceDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NoInitialSpaceDirective, "input, textarea", never, {}, {}, never, never, false, never>;
}
