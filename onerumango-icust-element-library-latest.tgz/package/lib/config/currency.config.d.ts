export interface CurrencyFormat {
    code: string;
    symbol: string;
    thousandsSeparator: string;
    decimalSeparator: string;
    symbolOnLeft: boolean;
    spaceBetweenAmountAndSymbol: boolean;
    decimalDigits: number;
}
export declare const currencyList: {
    [x: string]: CurrencyFormat;
};
