export * from './ic-icon-registry.service';
export * from './theme-config.service';
