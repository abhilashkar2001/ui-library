import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class IcIconRegistryService {
    private sanitizer;
    private http;
    private iconCache;
    private iconBasePath;
    constructor(sanitizer: DomSanitizer, http: HttpClient);
    getIcon(name: string): Observable<SafeHtml>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IcIconRegistryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IcIconRegistryService>;
}
