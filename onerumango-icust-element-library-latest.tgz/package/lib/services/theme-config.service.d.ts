import * as i0 from "@angular/core";
export declare class ThemeConfigService {
    private _theme;
    setTheme(theme: string): void;
    get theme(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ThemeConfigService>;
}
