import * as i1 from '@angular/common/http';
import { HttpParams, HttpResponse, HttpErrorResponse, HTTP_INTERCEPTORS } from '@angular/common/http';
import * as i4 from '@ngrx/store';
import { createActionGroup, emptyProps, props, createReducer, on, createFeatureSelector, createSelector, StoreModule } from '@ngrx/store';
import * as i0 from '@angular/core';
import { InjectionToken, Injectable, Inject, Component, Input, Directive, HostListener, NgModule, ElementRef, ViewChild, ViewEncapsulation, Pipe, EventEmitter, Output } from '@angular/core';
import * as i1$1 from '@ngrx/effects';
import { createEffect, ofType, EffectsModule } from '@ngrx/effects';
import { mergeMap, map, catchError, takeUntil, filter as filter$1, finalize, startWith, tap, retryWhen, take as take$1 } from 'rxjs/operators';
import { of, filter, exhaustMap, BehaviorSubject, take, Subject, throwError, Observable } from 'rxjs';
import * as i1$2 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as CryptoJS from 'crypto-js';
import * as i9 from '@onerumango/icust-element-library';
import { currencyList, IcustLibraryModule } from '@onerumango/icust-element-library';
import * as i1$3 from '@angular/router';
import { NavigationEnd, RouterModule, NavigationStart } from '@angular/router';
import * as i4$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i6 from '@ngbracket/ngx-layout/flex';
import * as i2 from '@angular/platform-browser';
import * as i3 from '@angular/common';
import { CommonModule, DOCUMENT } from '@angular/common';
import * as i6$1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i8 from 'ngx-image-cropper';
import { ImageCropperModule } from 'ngx-image-cropper';
import * as i1$5 from '@ngx-translate/core';
import { TemplatePortal } from '@angular/cdk/portal';
import * as i1$4 from '@angular/cdk/overlay';
import { OverlayModule, Overlay } from '@angular/cdk/overlay';
import * as i11 from '@angular/material/toolbar';
import { MatToolbarModule } from '@angular/material/toolbar';
import * as i13 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i14 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i15 from '@angular/material/form-field';
import * as i16 from '@angular/forms';
import { FormControl, FormsModule } from '@angular/forms';
import * as i18 from '@ngbracket/ngx-layout/extended';
import * as i8$1 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i5 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i3$1 from '@angular/material/progress-bar';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { FlexLayoutModule } from '@ngbracket/ngx-layout';
import * as i1$6 from 'ngx-toastr';
import { MomentDateAdapter } from '@angular/material-moment-adapter';

/**
 * set the cokkie in cookie storeage in browser
 * @param name of the cookie
 * @param value of the cookie to set
 * @param expiresIn expiry time of the cookie
 */
const setCookie = (name, value, expiresIn) => {
    let expires = '';
    if (expiresIn) {
        const date = new Date();
        date.setTime(date.getTime() + expiresIn * 1000);
        expires = '; expires=' + date.toUTCString();
    }
    document.cookie = name + '=' + (value || '') + expires + '; path=/';
};
/**
 * get the value of a cookie from it's name
 * @param name of the cookie which value is required
 * @returns value of the cookie
 */
const getCookie = (name) => {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2)
        return parts?.pop()?.split(';').shift();
    return null;
};
/**
 * Set the expiry date of cookie to it's past date it will remove automatically
 * @param name cookie name to be deleted
 */
const deleteCookie = (name) => {
    // Set the cookie's expiration date to a past date to delete it
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
};

const LocaleList = [
    { country: 'United States', locale: 'en-US' },
    { country: 'United Kingdom', locale: 'en-GB' },
    { country: 'France', locale: 'fr-FR' },
    { country: 'Germany', locale: 'de-DE' },
    { country: 'Spain', locale: 'es-ES' },
    { country: 'Italy', locale: 'it-IT' },
    { country: 'Japan', locale: 'ja-JP' },
    { country: 'South Korea', locale: 'ko-KR' },
    { country: 'China', locale: 'zh-CN' },
    { country: 'Brazil', locale: 'pt-BR' },
    { country: 'Russia', locale: 'ru-RU' },
    { country: 'Saudi Arabia', locale: 'ar-SA' },
    { country: 'India', locale: 'en-US' },
];
const DEFAULT_LOCALE = {
    country: 'United States',
    dateFormat: 'MM/DD/YYYY',
    locale: 'en-US',
    currency: 'USD',
};

function formatLocaleData(data) {
    console.log('formatLocaleData', data);
    const dateFormat = data?.dateFormat ?? DEFAULT_LOCALE.dateFormat;
    const globalData = {
        ...DEFAULT_LOCALE,
        dateFormat: dateFormat.toUpperCase(),
        country: data.country,
        currency: data.currency,
    };
    const locale = getCurrencyLocale(globalData?.country);
    const addLocalKey = { locale: locale };
    Object.assign(globalData, addLocalKey);
    return globalData;
}
function getCurrencyLocale(country) {
    const countryLocale = LocaleList.filter(item => {
        return item.country.toLowerCase() === country.toLowerCase();
    });
    return countryLocale?.length > 0
        ? countryLocale[0]?.locale
        : DEFAULT_LOCALE.locale;
}

/**
 * find the value of the param passed in route while change one location to another location in window
 * @param name name of the parameter
 * @param url url of the location of href
 * @returns the value of the particular parameter
 */
function getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'), results = regex.exec(url);
    if (!results)
        return null;
    if (!results[2])
        return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
function getQueryParam(prop) {
    const params = {};
    const search = decodeURIComponent(window.location.href.slice(window.location.href.indexOf('?') + 1));
    const definitions = search.split('&');
    definitions.forEach(function (val) {
        const parts = val.split('=', 2);
        if (parts[0] && parts[1]) {
            params[parts[0]] = parts[1];
        }
    });
    return prop && prop in params ? params[prop] : params;
}
function isValidUrl(url) {
    try {
        new URL(url);
        return true;
    }
    catch (error) {
        return false;
    }
}

function base64ToFile(dataurl, filename) {
    const arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1], bstr = atob(arr[arr.length - 1]), n = bstr.length, // `n` should be declared with `let` for reassignment
    u8arr = new Uint8Array(n);
    // Change `const` to `let` for `n`
    let i = n;
    while (i--) {
        u8arr[i] = bstr.charCodeAt(i);
    }
    return new File([u8arr], filename, { type: mime });
}

function appendFilterParam(paramsObj) {
    let params = new HttpParams();
    function addParam(key, value) {
        if (value === null || value === undefined)
            return;
        if (Array.isArray(value)) {
            params = params.set(key, value.map(v => String(v)).join(','));
        }
        else if (typeof value === 'object') {
            Object.keys(value).forEach(innerKey => {
                addParam(innerKey, value[innerKey]);
            });
        }
        else {
            params = params.set(key, String(value));
        }
    }
    Object.keys(paramsObj).forEach(key => {
        addParam(key, paramsObj[key]);
    });
    return params;
}

var SessionStorageEnum;
(function (SessionStorageEnum) {
    SessionStorageEnum["LANGUAGE"] = "LANGUAGE";
    SessionStorageEnum["TOKEN_KEY"] = "auth-token";
    SessionStorageEnum["IS_REMEMBER"] = "isRemember";
    SessionStorageEnum["VALIDITY_IN_SECS"] = "validityInSecs";
    SessionStorageEnum["LAST_LOGIN"] = "LAST_LOGIN";
})(SessionStorageEnum || (SessionStorageEnum = {}));

var UploadImage;
(function (UploadImage) {
    UploadImage["BROWSE"] = "Browse";
    UploadImage["AVATAR"] = "Avatar";
})(UploadImage || (UploadImage = {}));

var TransactionTypeEnum;
(function (TransactionTypeEnum) {
    TransactionTypeEnum["CORPORATE_LOAN"] = "CORP_LOAN";
})(TransactionTypeEnum || (TransactionTypeEnum = {}));

var WorkflowAction;
(function (WorkflowAction) {
    WorkflowAction["SUBMIT"] = "Submit";
    WorkflowAction["APPROVE"] = "Approve";
    WorkflowAction["COMPLETE"] = "Complete";
    WorkflowAction["REJECT"] = "Reject";
    WorkflowAction["CONFIRM"] = "Confirm";
    WorkflowAction["SENDLINK"] = "Send Link";
})(WorkflowAction || (WorkflowAction = {}));

const UserProfileAction = createActionGroup({
    source: 'Sign In',
    events: {
        'Load User Profile': emptyProps(),
        'Load User Profile Success': props(),
        'Load User Profile Failure': props(),
        'Remove User Profile': emptyProps(),
    },
});

const UserLocaleDataAction = createActionGroup({
    source: 'Sign In',
    events: {
        'Load Locale Data Success': props(),
        'Load Locale Data Failure': props(),
        'Remove Locale Data': emptyProps(),
    },
});

const ENVIRONMENT = new InjectionToken('environment');

const ROUTING_STATE = new InjectionToken('routing-state');

class UserProfileService {
    constructor(http, env) {
        this.http = http;
        this.env = env;
    }
    /**
     * Post-sign in call this api to fetch the logged-in user profile info
     * @returns {Observable<User>} profile info observable of the logged-in user
     */
    loadUserProfile() {
        return this.http.get(`${this.env.microServiceURL}/ic-user/fetchUser?isProfile=true`);
    }
    /**
     * This method is used to refresh the authentication token.
     * */
    refreshToken() {
        return this.http.post(`${this.env.microServiceURL}/auth/refresh-token`, {}, {
            headers: { Anonymous: 'NOTKN' },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserProfileService, deps: [{ token: i1.HttpClient }, { token: ENVIRONMENT }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserProfileService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserProfileService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [ENVIRONMENT]
                }] }]; } });

class UserProfileEffects {
    constructor(actions$, userProfileService) {
        this.actions$ = actions$;
        this.userProfileService = userProfileService;
        this.loadUserProfile$ = createEffect(() => this.actions$.pipe(ofType(UserProfileAction.loadUserProfile), mergeMap(() => this.userProfileService.loadUserProfile().pipe(map((user) => {
            return UserProfileAction.loadUserProfileSuccess({ user });
        }), catchError((error) => {
            return of(UserProfileAction.loadUserProfileFailure({ error }));
        })))));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserProfileEffects, deps: [{ token: i1$1.Actions }, { token: UserProfileService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserProfileEffects }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserProfileEffects, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1$1.Actions }, { type: UserProfileService }]; } });

class LocaleDataService {
    constructor(http, env) {
        this.http = http;
        this.env = env;
    }
    loadLocaleData(branchCode) {
        return this.http.get(`${this.env.microServiceURL}/branch/currencyByBranch?branchCode=${branchCode}`);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LocaleDataService, deps: [{ token: i1.HttpClient }, { token: ENVIRONMENT }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LocaleDataService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LocaleDataService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [ENVIRONMENT]
                }] }]; } });

class LocaleDataEffect {
    constructor(actions$, localeDataService) {
        this.actions$ = actions$;
        this.localeDataService = localeDataService;
        this.loadLocaleData$ = createEffect(() => this.actions$.pipe(ofType(UserProfileAction.loadUserProfileSuccess), filter(response => {
            return !!response?.user?.branch;
        }), exhaustMap(action => this.localeDataService.loadLocaleData(action?.user?.branch).pipe(map((localeData) => {
            return UserLocaleDataAction.loadLocaleDataSuccess({
                localeData: formatLocaleData(localeData.data),
            });
        }), catchError((error) => {
            return of(UserLocaleDataAction.loadLocaleDataFailure({ error }));
        })))));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LocaleDataEffect, deps: [{ token: i1$1.Actions }, { token: LocaleDataService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LocaleDataEffect }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LocaleDataEffect, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1$1.Actions }, { type: LocaleDataService }]; } });

const initialUserProfileState = {
    user: null,
    loading: false,
    error: null,
};

const initialLocalDataState = {
    loading: false,
    localeData: null,
    error: null,
};

// Define the reducer using createReducer and explicitly type the state parameter
const UserProfileReducer = createReducer(initialUserProfileState, // Initial state
// Load User Profile: Set loading to true and reset error
on(UserProfileAction.loadUserProfile, (state) => ({
    ...state,
    loading: true,
    error: null,
})), 
// Load User Profile Success: Set user and loading to false
on(UserProfileAction.loadUserProfileSuccess, (state, { user }) => ({
    ...state,
    user,
    loading: false,
    error: null,
})), 
// Load User Profile Failure: Set error and loading to false
on(UserProfileAction.loadUserProfileFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error,
})), on(UserProfileAction.removeUserProfile, state => ({
    ...state,
    user: null,
    loading: false,
    error: null,
})));

const LocaleDataReducer = createReducer(initialLocalDataState, on(UserLocaleDataAction.loadLocaleDataSuccess, (state, { localeData }) => ({
    ...state,
    localeData,
    loading: false,
})), on(UserLocaleDataAction.loadLocaleDataFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error,
})), on(UserLocaleDataAction.removeLocaleData, state => ({
    ...state,
    localeData: null,
})));

// user-profile.selectors.ts
// Feature selector for UserProfileState
const selectUserProfileState = createFeatureSelector('userProfile');
// Selector to get the user from the state
const selectUser = createSelector(selectUserProfileState, (state) => state.user);
// Selector to get the loading state
const selectLoading = createSelector(selectUserProfileState, (state) => state.loading);
// Selector to get the error state
const selectError = createSelector(selectUserProfileState, (state) => state.error);

const selectLocaleDataState = createFeatureSelector('localeData');
const selectLocaleData = createSelector(selectLocaleDataState, (state) => state.localeData);

class EncryptionService {
    constructor(env) {
        this.env = env;
        this.encrypt = (value) => {
            return CryptoJS.AES.encrypt(value, this.env.SECRET_KEY).toString();
        };
        this.decrypt = (value) => {
            const bytes = CryptoJS.AES.decrypt(value, this.env.SECRET_KEY);
            return bytes.toString(CryptoJS.enc.Utf8);
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: EncryptionService, deps: [{ token: ENVIRONMENT }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: EncryptionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: EncryptionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [ENVIRONMENT]
                }] }]; } });

class SessionStorageService {
    constructor(encryptionService) {
        this.encryptionService = encryptionService;
        /**
         * stringify the item and stored
         * @param key
         * @param value
         */
        this.setItemInSession = (key, value) => {
            if (!value)
                return;
            sessionStorage.removeItem(key);
            const encryptedValue = this.encryptionService.encrypt(JSON.stringify(value));
            sessionStorage.setItem(key, encryptedValue);
        };
        /**
         * It will parsed the item and give you, that is stored in session storage
         * @param key of the item to be stored in session storage
         * @returns retun parsed object
         */
        this.getItemFromSession = (key) => {
            const value = sessionStorage.getItem(key);
            if (!value)
                return '';
            return JSON.parse(this.encryptionService.decrypt(value));
        };
    }
    removeItem(key) {
        sessionStorage.removeItem(key);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SessionStorageService, deps: [{ token: EncryptionService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SessionStorageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SessionStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: EncryptionService }]; } });

class TokenStorageService {
    constructor(dialog, store, sessionStorageService) {
        this.dialog = dialog;
        this.store = store;
        this.sessionStorageService = sessionStorageService;
        this.operatingBranch = new BehaviorSubject('');
        //@ts-ignore
        this.tokenSubject = new BehaviorSubject(null);
        this.profileInfo$ = this.store.select(selectUser);
    }
    signOut() {
        this.store.dispatch(UserProfileAction.removeUserProfile());
        this.dialog.closeAll();
        sessionStorage.clear();
    }
    saveToken(token) {
        /** Save Token in inmemory storage */
        this.tokenSubject.next(token);
        this.sessionStorageService.setItemInSession(SessionStorageEnum.TOKEN_KEY, token);
    }
    getToken() {
        /* Use the below value when token stores in in memory database */
        return (this.tokenSubject.value ??
            this.sessionStorageService.getItemFromSession(SessionStorageEnum.TOKEN_KEY));
    }
    saveLanguage(language) {
        this.sessionStorageService.setItemInSession('LANGUAGE', language);
    }
    getLanguage() {
        return this.sessionStorageService.getItemFromSession('LANGUAGE');
    }
    isLoggedIn() {
        return this.getAuthStatus();
    }
    setValidityInSecs(validityInSecs) {
        this.sessionStorageService.setItemInSession(SessionStorageEnum.VALIDITY_IN_SECS, validityInSecs);
    }
    getValidityInSecs() {
        return this.sessionStorageService.getItemFromSession(SessionStorageEnum.VALIDITY_IN_SECS);
    }
    removeValidityInSecs() {
        return this.sessionStorageService.removeItem(SessionStorageEnum.VALIDITY_IN_SECS);
    }
    setRememberMe(rememberMe) {
        this.sessionStorageService.setItemInSession(SessionStorageEnum.IS_REMEMBER, rememberMe);
    }
    getRememberMe() {
        return this.sessionStorageService.getItemFromSession(SessionStorageEnum.IS_REMEMBER);
    }
    setOperatingBranch(operatingBranch) {
        this.operatingBranch.next(operatingBranch);
    }
    getOperatingBranch() {
        return this.operatingBranch.asObservable();
    }
    getAuthStatus() {
        const token = this.getToken();
        if (!token)
            return of(false);
        return this.profileInfo$?.pipe(filter(user => user != undefined), take(1), map(user => {
            return !!(token && user);
        }), catchError(() => {
            return of(false); // Return false on error
        }));
    }
    saveLastLoginSession(time) {
        this.sessionStorageService.setItemInSession(SessionStorageEnum.LAST_LOGIN, time);
    }
    getLastLoginSession() {
        return this.sessionStorageService.getItemFromSession(SessionStorageEnum.LAST_LOGIN);
    }
    clearSessionExceptLoginInfo() {
        const token = this.getToken(); // Replace 'authToken' with your actual token key
        const validityInSecs = this.getValidityInSecs();
        // Clear all session storage items
        sessionStorage.clear();
        if (token)
            this.saveToken(token);
        this.setValidityInSecs(validityInSecs);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TokenStorageService, deps: [{ token: i1$2.MatDialog }, { token: i4.Store }, { token: SessionStorageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TokenStorageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TokenStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1$2.MatDialog }, { type: i4.Store }, { type: SessionStorageService }]; } });

class IdleTimeoutComponent {
    constructor(data) {
        this.data = data;
        this.time = this.data.warningCountdown || 60;
    }
    ngOnInit() {
        this.warningCountdown = window.setInterval(() => {
            this.time--;
        }, 1000);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IdleTimeoutComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: IdleTimeoutComponent, selector: "ic-idle-timeout", ngImport: i0, template: "<div class=\"w-100 text-center timer-container\">\r\n  <h3 class=\"title-text\">You screen is idle for long time</h3>\r\n  <span class=\"desc-text\">Session is going to expire in</span>\r\n\r\n  <div class=\"w-100 timer\">00 <span>:</span> {{ time }}</div>\r\n  <ic-button\r\n    class=\"mt-24\"\r\n    label=\"Stay Logged In\"\r\n    icButtonType=\"ghost-rounded-success\"\r\n    mat-dialog-close>\r\n  </ic-button>\r\n</div>\r\n", styles: [".timer-container{display:flex;flex-direction:column;align-items:center;padding:12px}.timer-container .title-text{text-align:center;text-transform:math-auto;font:normal normal 600 16px/25px var(--ic-primary-font-family);letter-spacing:0px;color:var(--ic-text-theme)}.timer-container .desc-text{text-align:center;font:normal normal 500 13px/20px var(--ic-primary-font-family);letter-spacing:-.26px;color:#102245;opacity:.5}.timer-container .timer{font: 600 24px/32px Manrope;letter-spacing:0px;opacity:.9;color:#102245;margin-top:20px}.timer-container .flat-button{text-align:left;font:normal normal 600 13px/20px var(--ic-primary-font-family);letter-spacing:-.26px;color:#b20000;opacity:.7;padding:6px 12px;font-weight:600}\n"], dependencies: [{ kind: "directive", type: i1$2.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "component", type: i9.ButtonComponent, selector: "ic-button", inputs: ["label", "type", "size", "disabled", "isLoading", "isSkeleton", "icButtonType", "icIcon", "prefixIcon", "suffixIcon", "customButtonClass"], outputs: ["OnClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IdleTimeoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-idle-timeout', template: "<div class=\"w-100 text-center timer-container\">\r\n  <h3 class=\"title-text\">You screen is idle for long time</h3>\r\n  <span class=\"desc-text\">Session is going to expire in</span>\r\n\r\n  <div class=\"w-100 timer\">00 <span>:</span> {{ time }}</div>\r\n  <ic-button\r\n    class=\"mt-24\"\r\n    label=\"Stay Logged In\"\r\n    icButtonType=\"ghost-rounded-success\"\r\n    mat-dialog-close>\r\n  </ic-button>\r\n</div>\r\n", styles: [".timer-container{display:flex;flex-direction:column;align-items:center;padding:12px}.timer-container .title-text{text-align:center;text-transform:math-auto;font:normal normal 600 16px/25px var(--ic-primary-font-family);letter-spacing:0px;color:var(--ic-text-theme)}.timer-container .desc-text{text-align:center;font:normal normal 500 13px/20px var(--ic-primary-font-family);letter-spacing:-.26px;color:#102245;opacity:.5}.timer-container .timer{font: 600 24px/32px Manrope;letter-spacing:0px;opacity:.9;color:#102245;margin-top:20px}.timer-container .flat-button{text-align:left;font:normal normal 600 13px/20px var(--ic-primary-font-family);letter-spacing:-.26px;color:#b20000;opacity:.7;padding:6px 12px;font-weight:600}\n"] }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }]; } });

class PasswordSuccessComponent {
    constructor(dialogRef, router, tokenStorageService, data) {
        this.dialogRef = dialogRef;
        this.router = router;
        this.tokenStorageService = tokenStorageService;
        this.data = data;
    }
    close() {
        if (this.data?.message == 'Password') {
            this.tokenStorageService.signOut();
            this.router
                .navigate(['/sessions/signin'], {
                queryParams: { type: 'auth' },
            })
                .then(_ => {
                this.dialogRef.close();
            });
        }
        else
            this.dialogRef.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PasswordSuccessComponent, deps: [{ token: i1$2.MatDialogRef }, { token: i1$3.Router }, { token: TokenStorageService }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: PasswordSuccessComponent, selector: "ic-password-success", inputs: { value: "value" }, ngImport: i0, template: "<div fxLayout=\"column\">\r\n  <div fxLayoutAlign=\"end center\">\r\n    <div\r\n      class=\"cross\"\r\n      (click)=\"close()\"\r\n      tabindex=\"0\"\r\n      (keydown.enter)=\"close()\"\r\n    ></div>\r\n  </div>\r\n  <!-- <div class=\"popup-content\"> -->\r\n  <div class=\"popup-content\" fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n    <p class=\"txt\">{{ data?.message }} has been updated successfully</p>\r\n\r\n    <!-- <img src=\"assets/images/signout.png\" class=\"signout\"/> -->\r\n    <img src=\"assets/images/newtick.png\" alt=\"tick...\" style=\"max-width: 53%\" />\r\n    <!-- </div> -->\r\n  </div>\r\n\r\n  <div class=\"button-container\">\r\n    <button class=\"save-button\" mat-raised-button (click)=\"close()\">\r\n      Done\r\n    </button>\r\n  </div>\r\n</div>\r\n", styles: ["@charset \"UTF-8\";.popup-overlay{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:450px;height:243px;border-radius:8px;background-color:#fff;box-shadow:0 0 10px #00000080;z-index:100;display:flex;justify-content:center;align-items:center;flex-direction:column}.txt{font-weight:700;font-size:20px}.cross{opacity:.7;cursor:pointer;font-size:2em;font-weight:600;font-family:serif;line-height:1;display:flex;justify-content:flex-end}.cross:before{content:\"\\d7\"}.button-container{display:flex;justify-content:center;align-items:center}.save-button{width:150px;height:34px;font-family:semibold 15px var(--ic-primary-font-family)}.save-button{color:#fff!important;background:transparent linear-gradient(91deg,#051a2d,#0033a1) 0% 0% no-repeat padding-box;border-radius:23px;margin-right:10px;cursor:pointer}.popup-content{display:flex;flex-direction:column;align-items:center}\n"], dependencies: [{ kind: "component", type: i4$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "directive", type: i6.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { kind: "directive", type: i6.DefaultLayoutAlignDirective, selector: "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", inputs: ["fxLayoutAlign", "fxLayoutAlign.xs", "fxLayoutAlign.sm", "fxLayoutAlign.md", "fxLayoutAlign.lg", "fxLayoutAlign.xl", "fxLayoutAlign.lt-sm", "fxLayoutAlign.lt-md", "fxLayoutAlign.lt-lg", "fxLayoutAlign.lt-xl", "fxLayoutAlign.gt-xs", "fxLayoutAlign.gt-sm", "fxLayoutAlign.gt-md", "fxLayoutAlign.gt-lg"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PasswordSuccessComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-password-success', template: "<div fxLayout=\"column\">\r\n  <div fxLayoutAlign=\"end center\">\r\n    <div\r\n      class=\"cross\"\r\n      (click)=\"close()\"\r\n      tabindex=\"0\"\r\n      (keydown.enter)=\"close()\"\r\n    ></div>\r\n  </div>\r\n  <!-- <div class=\"popup-content\"> -->\r\n  <div class=\"popup-content\" fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n    <p class=\"txt\">{{ data?.message }} has been updated successfully</p>\r\n\r\n    <!-- <img src=\"assets/images/signout.png\" class=\"signout\"/> -->\r\n    <img src=\"assets/images/newtick.png\" alt=\"tick...\" style=\"max-width: 53%\" />\r\n    <!-- </div> -->\r\n  </div>\r\n\r\n  <div class=\"button-container\">\r\n    <button class=\"save-button\" mat-raised-button (click)=\"close()\">\r\n      Done\r\n    </button>\r\n  </div>\r\n</div>\r\n", styles: ["@charset \"UTF-8\";.popup-overlay{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:450px;height:243px;border-radius:8px;background-color:#fff;box-shadow:0 0 10px #00000080;z-index:100;display:flex;justify-content:center;align-items:center;flex-direction:column}.txt{font-weight:700;font-size:20px}.cross{opacity:.7;cursor:pointer;font-size:2em;font-weight:600;font-family:serif;line-height:1;display:flex;justify-content:flex-end}.cross:before{content:\"\\d7\"}.button-container{display:flex;justify-content:center;align-items:center}.save-button{width:150px;height:34px;font-family:semibold 15px var(--ic-primary-font-family)}.save-button{color:#fff!important;background:transparent linear-gradient(91deg,#051a2d,#0033a1) 0% 0% no-repeat padding-box;border-radius:23px;margin-right:10px;cursor:pointer}.popup-content{display:flex;flex-direction:column;align-items:center}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.MatDialogRef }, { type: i1$3.Router }, { type: TokenStorageService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }]; }, propDecorators: { value: [{
                type: Input
            }] } });

class ProfileComponent {
    constructor(dialogRef, sanitizer, shareDataService, apiService, dialog, store, env) {
        this.dialogRef = dialogRef;
        this.sanitizer = sanitizer;
        this.shareDataService = shareDataService;
        this.apiService = apiService;
        this.dialog = dialog;
        this.store = store;
        this.env = env;
        this.img = '';
        this.imageChangedEvent = '';
        this.userImage = 'assets/images/user.png';
        this.basePath = this.env.microServiceURL;
        this.profileInfo$ = this.store.select(selectUser);
    }
    ngOnInit() {
        this.profileInfo$?.subscribe(data => {
            this.currentUser = data;
        });
        this.img = this.currentUser?.profile?.fileUrl;
        this.shareDataService.getProfileImage().subscribe((res) => {
            if (res) {
                this.img = res;
            }
        });
        this.getFileUrl(this.img);
    }
    getFileUrl(filePath) {
        const file = this.basePath + filePath;
        let parseFileUrl;
        if (this.isUrlValid(file)) {
            parseFileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(file);
        }
        else {
            parseFileUrl = this.userImage;
        }
        this.fileUrl = parseFileUrl;
    }
    isUrlValid(userInput) {
        const res = userInput.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_+.~#?&//=]*)/g);
        if (res == null)
            return false;
        else
            return true;
    }
    close() {
        this.dialogRef.close();
    }
    onFileSelect(e) {
        this.imageChangedEvent = e;
    }
    imageCropped(event) {
        console.log(event);
        this.img = event.base64;
        this.img = this.sanitizer.bypassSecurityTrustUrl(event.base64);
        this.file = base64ToFile(event.base64, 'profile.png');
    }
    handleProfileUpdate(file) {
        const maxSizeInBytes = 25 * 1024 * 1024; // 25 MB in bytes
        if (file?.size > maxSizeInBytes) {
            console.error('FileModel size exceeds the limit (25 MB). Please upload a smaller file.');
            return;
        }
        else {
            if (file) {
                const formData = new FormData();
                const payload = {
                    documentType: 'Profile',
                    fileType: file?.type,
                    fileName: file?.name,
                };
                formData.append('file', file);
                formData.append('data', JSON.stringify(payload));
                formData.append('module', 'document');
                const documentId = this.currentUser?.profile?.documentId ?? null;
                formData.append('documentId', documentId);
                this.apiService.uploadDocument(formData).subscribe(resp => {
                    this.img = resp?.data.fileUrl;
                    this.shareDataService.sendProfileImage(this.img);
                    const documentId = resp?.data.documentId; // Replace 'documentId' with the actual key for profileId in the response
                    const payloadInfo = {
                        userId: this.currentUser?.userId,
                        documentId: documentId,
                    };
                    this.apiService
                        .updateProfileImage(payloadInfo)
                        .subscribe((res) => {
                        this.getProfile();
                        this.shareDataService.sendProfileImage(resp?.data?.fileUrl);
                        if (res?.statusCode == 200) {
                            this.dialog.open(PasswordSuccessComponent, {
                                width: '45%',
                                data: { message: `Profile Picture` },
                                panelClass: 'ic-dialog__panelclass',
                            });
                        }
                        this.dialogRef.close();
                    });
                });
            }
            else {
                const payloadInfo = {
                    userId: this.currentUser?.userId,
                    documentId: null,
                };
                this.apiService
                    .updateProfileImage(payloadInfo)
                    .subscribe((res) => {
                    this.getProfile();
                    this.shareDataService.sendProfileImage('assets/images/user.png');
                    if (res?.statusCode == 200) {
                        this.dialog.open(PasswordSuccessComponent, {
                            width: '45%',
                            data: { message: `Profile Picture` },
                            panelClass: 'ic-dialog__panelclass',
                        });
                    }
                    this.dialogRef.close();
                });
            }
        }
    }
    deleteImage() {
        this.img = null;
        this.imageChangedEvent = null;
        this.fileUrl = null;
        this.getFileUrl(this.fileUrl);
    }
    getProfile() {
        this.store.dispatch(UserProfileAction.loadUserProfile());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProfileComponent, deps: [{ token: i1$2.MatDialogRef }, { token: i2.DomSanitizer }, { token: CoreDataService }, { token: ApiService }, { token: i1$2.MatDialog }, { token: i4.Store }, { token: ENVIRONMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ProfileComponent, selector: "ic-profile", ngImport: i0, template: "<div class=\"profile_popup_container\">\r\n  <div fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\r\n    <div class=\"theme_lg\">Edit profile picture</div>\r\n    <ic-button\r\n      type=\"icon\"\r\n      icButtonType=\"ghost-neutral\"\r\n      icIcon=\"close\"\r\n      (OnClick)=\"close()\"></ic-button>\r\n  </div>\r\n  <div class=\"popup-background\">\r\n    <div class=\"image-container\">\r\n      <mat-icon class=\"delete-icon\" *ngIf=\"img\" (click)=\"deleteImage()\"\r\n        >delete</mat-icon\r\n      >\r\n      <image-cropper\r\n        class=\"img-crop\"\r\n        [imageChangedEvent]=\"imageChangedEvent\"\r\n        [maintainAspectRatio]=\"true\"\r\n        [aspectRatio]=\"1 / 1\"\r\n        [resizeToWidth]=\"256\"\r\n        format=\"jpeg\"\r\n        (imageCropped)=\"imageCropped($event)\"\r\n        *ngIf=\"imageChangedEvent\"></image-cropper>\r\n      <ng-container *ngIf=\"!imageChangedEvent\">\r\n        <img #img [src]=\"fileUrl\" class=\"croppedImageStyle\" alt=\"fileUrl\" />\r\n      </ng-container>\r\n    </div>\r\n  </div>\r\n  <div fxLayout=\"row\" fxLayoutAlign=\"center center\" fxLayoutGap=\"4px\">\r\n    <div class=\"drag-drop-text\">Drag and drop file here or</div>\r\n    <input\r\n      type=\"file\"\r\n      id=\"fileInput\"\r\n      accept=\".jpg, .jpeg, .png\"\r\n      style=\"display: none\"\r\n      (change)=\"onFileSelect($event)\" />\r\n    <label class=\"choose-file\" for=\"fileInput\">Choose file</label>\r\n  </div>\r\n\r\n  <p class=\"file-size-info theme_md\">Maximum size: 25 MB</p>\r\n\r\n  <div fxLayout=\"row\" fxLayoutAlign=\"center center\" fxLayoutGap=\"10px\">\r\n    <ic-button\r\n      label=\"Save\"\r\n      icButtonType=\"filled-rounded\"\r\n      (OnClick)=\"handleProfileUpdate(file)\">\r\n    </ic-button>\r\n\r\n    <ic-button\r\n      label=\"Cancle\"\r\n      icButtonType=\"ghost-rounded-danger\"\r\n      (OnClick)=\"close()\">\r\n    </ic-button>\r\n  </div>\r\n</div>\r\n", styles: [".profile_popup_container .popup-background{background-color:#d2d2d2d0;display:flex;align-items:center;justify-content:center;margin:5px 0;padding:5px;border-radius:12px}.profile_popup_container .popup-background .image-container{position:relative;max-width:50%;max-height:100%;text-align:center}.profile_popup_container .popup-background .image-container .delete-icon{color:#b20000!important;position:absolute!important;right:-50%!important;top:0!important;z-index:5;cursor:pointer}.profile_popup_container .popup-background .image-container image-cropper.img-crop{max-width:100%;max-height:100%}.profile_popup_container .popup-background .image-container image-cropper.img-crop .ngx-ic-overlay{min-width:100%!important;height:190px!important;margin-left:calc(50% - 95px)!important;width:190px!important}.profile_popup_container .popup-background .image-container img{height:100%;width:100%}.profile_popup_container .popup-background .image-container .croppedImageStyle{border-radius:50%}.profile_popup_container .drag-drop-text{font-size:14px}.profile_popup_container .choose-file{font-size:14px;font-weight:700;text-decoration:underline;cursor:pointer;color:#0033a1}.profile_popup_container .choose-file:hover{color:#0051ff}.profile_popup_container .file-size-info{text-align:center}.profile_popup_container .button-container{display:flex;justify-content:center}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i6$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i6.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { kind: "directive", type: i6.DefaultLayoutGapDirective, selector: "  [fxLayoutGap], [fxLayoutGap.xs], [fxLayoutGap.sm], [fxLayoutGap.md],  [fxLayoutGap.lg], [fxLayoutGap.xl], [fxLayoutGap.lt-sm], [fxLayoutGap.lt-md],  [fxLayoutGap.lt-lg], [fxLayoutGap.lt-xl], [fxLayoutGap.gt-xs], [fxLayoutGap.gt-sm],  [fxLayoutGap.gt-md], [fxLayoutGap.gt-lg]", inputs: ["fxLayoutGap", "fxLayoutGap.xs", "fxLayoutGap.sm", "fxLayoutGap.md", "fxLayoutGap.lg", "fxLayoutGap.xl", "fxLayoutGap.lt-sm", "fxLayoutGap.lt-md", "fxLayoutGap.lt-lg", "fxLayoutGap.lt-xl", "fxLayoutGap.gt-xs", "fxLayoutGap.gt-sm", "fxLayoutGap.gt-md", "fxLayoutGap.gt-lg"] }, { kind: "directive", type: i6.DefaultLayoutAlignDirective, selector: "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", inputs: ["fxLayoutAlign", "fxLayoutAlign.xs", "fxLayoutAlign.sm", "fxLayoutAlign.md", "fxLayoutAlign.lg", "fxLayoutAlign.xl", "fxLayoutAlign.lt-sm", "fxLayoutAlign.lt-md", "fxLayoutAlign.lt-lg", "fxLayoutAlign.lt-xl", "fxLayoutAlign.gt-xs", "fxLayoutAlign.gt-sm", "fxLayoutAlign.gt-md", "fxLayoutAlign.gt-lg"] }, { kind: "component", type: i8.ImageCropperComponent, selector: "image-cropper", inputs: ["imageChangedEvent", "imageURL", "imageBase64", "imageFile", "imageAltText", "format", "transform", "maintainAspectRatio", "aspectRatio", "resetCropOnAspectRatioChange", "resizeToWidth", "resizeToHeight", "cropperMinWidth", "cropperMinHeight", "cropperMaxHeight", "cropperMaxWidth", "cropperStaticWidth", "cropperStaticHeight", "canvasRotation", "initialStepSize", "roundCropper", "onlyScaleDown", "imageQuality", "autoCrop", "backgroundColor", "containWithinAspectRatio", "hideResizeSquares", "allowMoveImage", "cropper", "alignImage", "disabled", "hidden"], outputs: ["imageCropped", "startCropImage", "imageLoaded", "cropperReady", "loadImageFailed", "transformChange"] }, { kind: "component", type: i9.ButtonComponent, selector: "ic-button", inputs: ["label", "type", "size", "disabled", "isLoading", "isSkeleton", "icButtonType", "icIcon", "prefixIcon", "suffixIcon", "customButtonClass"], outputs: ["OnClick"] }, { kind: "directive", type: i9.NoInitialSpaceDirective, selector: "input, textarea" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProfileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-profile', template: "<div class=\"profile_popup_container\">\r\n  <div fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\r\n    <div class=\"theme_lg\">Edit profile picture</div>\r\n    <ic-button\r\n      type=\"icon\"\r\n      icButtonType=\"ghost-neutral\"\r\n      icIcon=\"close\"\r\n      (OnClick)=\"close()\"></ic-button>\r\n  </div>\r\n  <div class=\"popup-background\">\r\n    <div class=\"image-container\">\r\n      <mat-icon class=\"delete-icon\" *ngIf=\"img\" (click)=\"deleteImage()\"\r\n        >delete</mat-icon\r\n      >\r\n      <image-cropper\r\n        class=\"img-crop\"\r\n        [imageChangedEvent]=\"imageChangedEvent\"\r\n        [maintainAspectRatio]=\"true\"\r\n        [aspectRatio]=\"1 / 1\"\r\n        [resizeToWidth]=\"256\"\r\n        format=\"jpeg\"\r\n        (imageCropped)=\"imageCropped($event)\"\r\n        *ngIf=\"imageChangedEvent\"></image-cropper>\r\n      <ng-container *ngIf=\"!imageChangedEvent\">\r\n        <img #img [src]=\"fileUrl\" class=\"croppedImageStyle\" alt=\"fileUrl\" />\r\n      </ng-container>\r\n    </div>\r\n  </div>\r\n  <div fxLayout=\"row\" fxLayoutAlign=\"center center\" fxLayoutGap=\"4px\">\r\n    <div class=\"drag-drop-text\">Drag and drop file here or</div>\r\n    <input\r\n      type=\"file\"\r\n      id=\"fileInput\"\r\n      accept=\".jpg, .jpeg, .png\"\r\n      style=\"display: none\"\r\n      (change)=\"onFileSelect($event)\" />\r\n    <label class=\"choose-file\" for=\"fileInput\">Choose file</label>\r\n  </div>\r\n\r\n  <p class=\"file-size-info theme_md\">Maximum size: 25 MB</p>\r\n\r\n  <div fxLayout=\"row\" fxLayoutAlign=\"center center\" fxLayoutGap=\"10px\">\r\n    <ic-button\r\n      label=\"Save\"\r\n      icButtonType=\"filled-rounded\"\r\n      (OnClick)=\"handleProfileUpdate(file)\">\r\n    </ic-button>\r\n\r\n    <ic-button\r\n      label=\"Cancle\"\r\n      icButtonType=\"ghost-rounded-danger\"\r\n      (OnClick)=\"close()\">\r\n    </ic-button>\r\n  </div>\r\n</div>\r\n", styles: [".profile_popup_container .popup-background{background-color:#d2d2d2d0;display:flex;align-items:center;justify-content:center;margin:5px 0;padding:5px;border-radius:12px}.profile_popup_container .popup-background .image-container{position:relative;max-width:50%;max-height:100%;text-align:center}.profile_popup_container .popup-background .image-container .delete-icon{color:#b20000!important;position:absolute!important;right:-50%!important;top:0!important;z-index:5;cursor:pointer}.profile_popup_container .popup-background .image-container image-cropper.img-crop{max-width:100%;max-height:100%}.profile_popup_container .popup-background .image-container image-cropper.img-crop .ngx-ic-overlay{min-width:100%!important;height:190px!important;margin-left:calc(50% - 95px)!important;width:190px!important}.profile_popup_container .popup-background .image-container img{height:100%;width:100%}.profile_popup_container .popup-background .image-container .croppedImageStyle{border-radius:50%}.profile_popup_container .drag-drop-text{font-size:14px}.profile_popup_container .choose-file{font-size:14px;font-weight:700;text-decoration:underline;cursor:pointer;color:#0033a1}.profile_popup_container .choose-file:hover{color:#0051ff}.profile_popup_container .file-size-info{text-align:center}.profile_popup_container .button-container{display:flex;justify-content:center}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.MatDialogRef }, { type: i2.DomSanitizer }, { type: CoreDataService }, { type: ApiService }, { type: i1$2.MatDialog }, { type: i4.Store }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [ENVIRONMENT]
                }] }]; } });

class RequestCache {
    constructor() {
        this.cache$ = new Map();
    }
    get(req) {
        const cachedResponse = this.cache$.get(req.urlWithParams);
        return cachedResponse ? cachedResponse : undefined;
    }
    put(req, response) {
        if (response.body?.statusCode === 200) {
            this.cache$.set(req.urlWithParams, response);
        }
    }
    clear() {
        this.cache$.clear();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RequestCache, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RequestCache, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RequestCache, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class SignoutComponent {
    constructor(dialogRef, router, tokenStorageService, store, data, cache, env) {
        this.dialogRef = dialogRef;
        this.router = router;
        this.tokenStorageService = tokenStorageService;
        this.store = store;
        this.data = data;
        this.cache = cache;
        this.env = env;
        this.openedTill = false;
        this.tillDiv = false;
        this.profileInfo$ = this.store.select(selectUser);
    }
    ngOnInit() {
        this.profileInfo$?.subscribe(data => {
            this.currentUser = data;
        });
        if (this.data.tillAvail) {
            this.tillAvail = true;
        }
        if (this.data.msg) {
            this.tillDiv = true;
        }
        if (this.currentUser.counterNumber) {
            if (this.currentUser.counterNumber != '')
                this.openedTill = true;
        }
        else
            return;
    }
    noClick() {
        if (this.tillDiv) {
            if (this.data.noChangeOpBranch) {
                this.dialogRef.close();
                return;
            }
            else if (this.data.tillClose) {
                this.goToOpenCloseTill();
                return;
            }
            else if (this.data.notSameBranch) {
                this.dialogRef.close();
                return;
            }
        }
        if (this.openedTill) {
            this.signOut();
            return;
        }
        else {
            this.dialogRef.close();
            return;
        }
    }
    yesClick() {
        if (this.tillDiv) {
            if (this.data.noChangeOpBranch) {
                this.goToOpenCloseTill();
                return;
            }
            else if (this.data.tillClose) {
                this.goToTransferCash();
                return;
            }
            else if (this.data.notSameBranch) {
                this.dialogRef.close();
                return;
            }
        }
        if (this.openedTill) {
            this.goToOpenCloseTill();
            return;
        }
        else {
            this.signOut();
            return;
        }
    }
    doneClick() {
        this.dialogRef.close('Done');
    }
    goToTransferCash() {
        this.router
            .navigate(['teller/operation/transferCashSummary/addEditTransfer/addNew'])
            .then(_ => {
            this.dialogRef.close();
        });
    }
    goToOpenCloseTill() {
        this.router.navigate(['teller/operation/openCloseTillVault']).then(_ => {
            this.dialogRef.close();
        });
    }
    gotoDashboard() {
        this.dialogRef.afterClosed().subscribe(() => {
            this.router.navigate(['teller/dashboard']);
        });
        this.dialogRef.close();
    }
    signOut() {
        this.cache.clear();
        this.store.dispatch(UserLocaleDataAction.removeLocaleData());
        this.store.dispatch(UserProfileAction.removeUserProfile());
        const currentOrigin = window.location.origin;
        const parentOrigin = new URL(this.env.parentAppUrl).origin;
        if (currentOrigin === parentOrigin) {
            this.router
                .navigate(['/sessions/signin'], {
                queryParams: { type: 'auth' },
            })
                .then(_ => {
                this.tokenStorageService.signOut();
                this.dialogRef.close();
            });
        }
        else {
            window.location.href = `${parentOrigin}`;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SignoutComponent, deps: [{ token: i1$2.MatDialogRef }, { token: i1$3.Router }, { token: TokenStorageService }, { token: i4.Store }, { token: MAT_DIALOG_DATA }, { token: RequestCache }, { token: ENVIRONMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SignoutComponent, selector: "ic-signout", ngImport: i0, template: "<div class=\"popup-overlay\">\r\n  <div class=\"popup-content\">\r\n    <img src=\"assets/images/signout.png\" alt=\"signout\" />\r\n  </div>\r\n\r\n  <div *ngIf=\"!tillDiv\">\r\n    <ng-container *ngIf=\"!openedTill; else till\">\r\n      <p class=\"txt\">You are Trying to Sign out. Do you want to proceed?</p>\r\n    </ng-container>\r\n    <ng-template #till>\r\n      <p class=\"redTxt\">Your Till is open do you want to close this?</p>\r\n    </ng-template>\r\n  </div>\r\n\r\n  <div *ngIf=\"tillDiv\">\r\n    <p class=\"orngTxt\">{{ data.msg }}</p>\r\n  </div>\r\n\r\n  <div class=\"button-container\">\r\n    <ng-container *ngIf=\"!tillAvail; else done\">\r\n      <button class=\"save-button\" mat-raised-button (click)=\"yesClick()\">\r\n        Yes\r\n      </button>\r\n      <button class=\"exit-button\" mat-raised-button (click)=\"noClick()\">\r\n        No\r\n      </button>\r\n    </ng-container>\r\n    <ng-template #done>\r\n      <button class=\"save-button\" mat-raised-button (click)=\"doneClick()\">\r\n        Done\r\n      </button>\r\n    </ng-template>\r\n  </div>\r\n</div>\r\n", styles: [".popup-overlay{width:569px;height:282px;border-radius:8px;background-color:#fff;box-shadow:none;z-index:100;display:flex;justify-content:center;align-items:center;flex-direction:column}.button-container{display:flex;justify-content:center;align-items:center;margin-bottom:62px}.txt{font-weight:500;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.redTxt{font-weight:500;color:#b20000;font-size:20px;text-align:center;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.orngTxt{font-weight:500;color:#ffaa0a;font-size:20px;text-align:center;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.save-button,.exit-button{width:150px;height:34px;font-family:semibold 15px var(--ic-primary-font-family)}.save-button{color:#fff!important;background:transparent linear-gradient(91deg,#051a2d,#0033a1) 0% 0% no-repeat padding-box;border-radius:23px;margin-right:10px}.exit-button{color:#b20000!important;border-radius:23px}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SignoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-signout', template: "<div class=\"popup-overlay\">\r\n  <div class=\"popup-content\">\r\n    <img src=\"assets/images/signout.png\" alt=\"signout\" />\r\n  </div>\r\n\r\n  <div *ngIf=\"!tillDiv\">\r\n    <ng-container *ngIf=\"!openedTill; else till\">\r\n      <p class=\"txt\">You are Trying to Sign out. Do you want to proceed?</p>\r\n    </ng-container>\r\n    <ng-template #till>\r\n      <p class=\"redTxt\">Your Till is open do you want to close this?</p>\r\n    </ng-template>\r\n  </div>\r\n\r\n  <div *ngIf=\"tillDiv\">\r\n    <p class=\"orngTxt\">{{ data.msg }}</p>\r\n  </div>\r\n\r\n  <div class=\"button-container\">\r\n    <ng-container *ngIf=\"!tillAvail; else done\">\r\n      <button class=\"save-button\" mat-raised-button (click)=\"yesClick()\">\r\n        Yes\r\n      </button>\r\n      <button class=\"exit-button\" mat-raised-button (click)=\"noClick()\">\r\n        No\r\n      </button>\r\n    </ng-container>\r\n    <ng-template #done>\r\n      <button class=\"save-button\" mat-raised-button (click)=\"doneClick()\">\r\n        Done\r\n      </button>\r\n    </ng-template>\r\n  </div>\r\n</div>\r\n", styles: [".popup-overlay{width:569px;height:282px;border-radius:8px;background-color:#fff;box-shadow:none;z-index:100;display:flex;justify-content:center;align-items:center;flex-direction:column}.button-container{display:flex;justify-content:center;align-items:center;margin-bottom:62px}.txt{font-weight:500;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.redTxt{font-weight:500;color:#b20000;font-size:20px;text-align:center;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.orngTxt{font-weight:500;color:#ffaa0a;font-size:20px;text-align:center;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif)}.save-button,.exit-button{width:150px;height:34px;font-family:semibold 15px var(--ic-primary-font-family)}.save-button{color:#fff!important;background:transparent linear-gradient(91deg,#051a2d,#0033a1) 0% 0% no-repeat padding-box;border-radius:23px;margin-right:10px}.exit-button{color:#b20000!important;border-radius:23px}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.MatDialogRef }, { type: i1$3.Router }, { type: TokenStorageService }, { type: i4.Store }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: RequestCache }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [ENVIRONMENT]
                }] }]; } });

class PopovercontainerComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PopovercontainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: PopovercontainerComponent, selector: "ic-popover-container", ngImport: i0, template: "<div class=\"popover-container\">\r\n  <ng-content></ng-content>\r\n</div>\r\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PopovercontainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-popover-container', template: "<div class=\"popover-container\">\r\n  <ng-content></ng-content>\r\n</div>\r\n" }]
        }] });

class PopoverService {
    constructor() {
        this.state = new BehaviorSubject(false);
    }
    getState() {
        return this.state.asObservable();
    }
    setState(value) {
        return this.state.next(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PopoverService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PopoverService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PopoverService, decorators: [{
            type: Injectable
        }] });

class PopoverDirective {
    constructor(elementRef, overlay, vcr, popoverService) {
        this.elementRef = elementRef;
        this.overlay = overlay;
        this.vcr = vcr;
        this.popoverService = popoverService;
        this.closeOnClickOutside = false;
        this.unsubscribe = new Subject();
    }
    ngOnInit() {
        this.createOverlay();
        this.popoverService.getState().subscribe((resp) => {
            if (resp) {
                this.detachOverlay();
            }
        });
    }
    ngOnDestroy() {
        this.detachOverlay();
        this.unsubscribe.next(null);
        this.unsubscribe.complete();
    }
    clickou() {
        this.attachOverlay();
    }
    createOverlay() {
        const scrollStrategy = this.overlay.scrollStrategies.block();
        const positionStrategy = this.overlay
            .position()
            .flexibleConnectedTo(this.elementRef)
            .withPositions([
            {
                originX: 'center',
                originY: 'bottom',
                overlayX: 'center',
                overlayY: 'top',
            },
        ]);
        this.overlayRef = this.overlay.create({
            positionStrategy,
            scrollStrategy,
            hasBackdrop: true,
            // backdropClass: "",
            backdropClass: 'cdk-overlay-transparent-backdrop',
            panelClass: 'mat-elevation-z8',
        });
        this.overlayRef.addPanelClass('profile-maintenance-overlay');
        this.overlayRef
            .backdropClick()
            .pipe(takeUntil(this.unsubscribe))
            .subscribe(() => {
            if (this.closeOnClickOutside) {
                this.detachOverlay();
            }
        });
    }
    attachOverlay() {
        if (!this.overlayRef.hasAttached()) {
            const periodSelectorPortal = new TemplatePortal(this.popoverTrigger, this.vcr);
            this.overlayRef.attach(periodSelectorPortal);
        }
    }
    detachOverlay() {
        if (this.overlayRef.hasAttached()) {
            this.overlayRef.detach();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PopoverDirective, deps: [{ token: i0.ElementRef }, { token: i1$4.Overlay }, { token: i0.ViewContainerRef }, { token: PopoverService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: PopoverDirective, selector: "[popoverTrigger]", inputs: { popoverTrigger: "popoverTrigger", closeOnClickOutside: "closeOnClickOutside" }, host: { listeners: { "click": "clickou()" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PopoverDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[popoverTrigger]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i1$4.Overlay }, { type: i0.ViewContainerRef }, { type: PopoverService }]; }, propDecorators: { popoverTrigger: [{
                type: Input
            }], closeOnClickOutside: [{
                type: Input
            }], clickou: [{
                type: HostListener,
                args: ['click']
            }] } });

class PopoverModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PopoverModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: PopoverModule, declarations: [PopoverDirective, PopovercontainerComponent], imports: [OverlayModule], exports: [PopoverDirective, PopovercontainerComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PopoverModule, providers: [Overlay, PopoverService], imports: [OverlayModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PopoverModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OverlayModule],
                    declarations: [PopoverDirective, PopovercontainerComponent],
                    exports: [PopoverDirective, PopovercontainerComponent],
                    providers: [Overlay, PopoverService],
                }]
        }] });

class HeaderTopComponent {
    constructor(translate, tokenStorageService, router, dialog, popoverService, cdr, shareDataService, matIconRegistry, sanitizer, apiService, store, sessionStorageService, env) {
        this.translate = translate;
        this.tokenStorageService = tokenStorageService;
        this.router = router;
        this.dialog = dialog;
        this.popoverService = popoverService;
        this.cdr = cdr;
        this.shareDataService = shareDataService;
        this.matIconRegistry = matIconRegistry;
        this.sanitizer = sanitizer;
        this.apiService = apiService;
        this.store = store;
        this.sessionStorageService = sessionStorageService;
        this.env = env;
        this.selectedLanguage = null;
        this.selectedBranch = '';
        this.selectedTheme = '';
        this.languageOptions = [];
        this.languages = [];
        this.branches = [];
        this.themes = ['Dark', 'Light'];
        this.languageSearchText = '';
        this.branchSearchText = '';
        this.userImage = '/assets/images/profile-user.png';
        this.hideNavItem = false;
        this.operatingBranch = [];
        this.subscription = [];
        this.matIconRegistry.addSvgIcon(`custom-menu-icon`, this.sanitizer.bypassSecurityTrustResourceUrl('assets/images/custom-menu.svg'));
        this.basePath = this.env.microServiceURL;
        this.profileInfo$ = this.store.select(selectUser);
    }
    ngOnInit() {
        const profileInfoSub = this.profileInfo$?.subscribe(data => {
            if (data)
                this.currentUser = data;
            this.selectedBranch = this.currentUser?.branchName;
            this.selectedBranchName = this.currentUser?.bankName;
            this.isTeller = this.router.url.split('/').slice(1)[0];
            this.roleName = this.currentUser?.roles?.[0]?.roleName;
            const parent_screen = this.currentUser?.roles[0]?.screens[0];
            this.lastLoginTime = new Date();
            this.languageName = this.tokenStorageService.getLanguage() || 'English';
            this.selectedLanguage = this.languageName;
            this.languageOptions = ['English'];
            this.selectedTheme = 'Light';
            this.shareDataService.getProfileImage().subscribe(res => {
                if (res) {
                    this.profileImage = res;
                }
            });
            this.getFileUrl(this.profileImage);
            this.genericValueLanguage(parent_screen?.screenName);
        });
        this.router.events.subscribe(val => {
            if (val instanceof NavigationEnd) {
                this.clickHoverMenuTrigger?.closeMenu();
            }
        });
        this.shareDataService.getIsHideItem().subscribe(resp => {
            this.hideNavItem = resp;
        });
        this.tokenStorageService.getOperatingBranch().subscribe(res => {
            if (res)
                this.selectedBranch = res;
            else
                return;
        });
        this.subscription.push(profileInfoSub);
    }
    searchBranch() {
        const query = this.branchSearchText.trim().toLowerCase();
        this.branches = this.operatingBranch.filter((item) => item?.branchName?.toLowerCase().includes(query));
    }
    searchLanguage() {
        const query = this.languageSearchText.trim().toLowerCase();
        this.languageOptions = this.languages.filter((item) => item?.toLowerCase().includes(query));
    }
    getFileUrl(filePath) {
        const file = this.basePath + filePath;
        let parseFileUrl;
        if (this.isUrlValid(file)) {
            parseFileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(file);
        }
        else {
            parseFileUrl = this.userImage;
        }
        this.fileUrl = parseFileUrl;
        this.cdr.markForCheck();
    }
    isUrlValid(userInput) {
        const res = userInput.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_+.~#?&//=]*)/g);
        if (res == null)
            return false;
        else
            return true;
    }
    toggleMenu() {
        this.mainMenuPanel.toggle();
        this.shareDataService.sendMenRef(this.isTeller);
    }
    goToHome() {
        const module_permission = this.currentUser?.roles;
        if (!module_permission)
            return;
        const currentOrigin = window.location.origin;
        const parentOrigin = new URL(this.env.parentAppUrl).origin;
        if (currentOrigin == parentOrigin) {
            const routeTo = module_permission[0]?.screens[0]?.screenName?.toLowerCase() ==
                'maintenance'
                ? '/maintenance'
                : '/teller';
            this.shareDataService.sendActiveTabMenuChildren(module_permission[0]?.screens[0]?.children);
            this.router.navigate([routeTo]);
        }
        else {
            window.location.href = `${this.env.parentAppUrl}?code=${this.sessionStorageService.getItemFromSession(SessionStorageEnum.TOKEN_KEY)}&validityInSecs=${this.sessionStorageService.getItemFromSession(SessionStorageEnum.VALIDITY_IN_SECS)}`;
        }
    }
    openPopup() {
        this.dialog.open(ProfileComponent, {
            panelClass: 'ic-dialog__panelclass',
        });
    }
    closePopover(lngName) {
        this.selectedLanguage = lngName;
        let languageCode;
        this.popoverService.setState(true);
        if (lngName === 'Spanish') {
            languageCode = 'es';
        }
        else if (lngName === 'English') {
            languageCode = 'en';
        }
        else {
            languageCode = 'en';
        }
        this.translate.use(languageCode);
        this.shareDataService.setlanguageVal(lngName);
        this.tokenStorageService.saveLanguage(lngName);
    }
    closePopoverTheme(thm) {
        this.selectedTheme = thm;
        this.popoverService.setState(true);
    }
    getOperatingBranch() {
        if (!this.currentUser)
            return;
        this.apiService
            .getOpearatingBranch(this.currentUser?.username)
            .subscribe((resp) => {
            if (resp.statusCode == 200) {
                this.branches = resp.data;
                this.operatingBranch = this.branches;
            }
        });
    }
    genericValueLanguage(screenNameVal) {
        this.apiService
            .getGenericValueLanguage(screenNameVal)
            .subscribe((resp) => {
            if (resp?.statusCode == 200) {
                this.languageOptions = resp?.data?.LANGUAGE;
                const existedValue = this.languageOptions.indexOf(this.languageName);
                if (existedValue === -1 ||
                    this.languageName === null ||
                    !this.languageOptions) {
                    this.languageName = 'English';
                }
                this.switchLanguage(this.languageName);
            }
            else {
                this.languageOptions = ['English'];
            }
            this.languages = this.languageOptions;
        });
    }
    goToSecurity() {
        this.router.navigate(['/profile/securityQuestion', 'read']);
        this.shareDataService.setIsHideItem(true);
    }
    onPasswordChange() {
        this.router.navigate(['/teller/change-password']);
    }
    switchLanguage(langName) {
        let languageCode;
        if (langName === 'English') {
            languageCode = 'en';
        }
        else if (langName === 'Spanish') {
            languageCode = 'es';
        }
        else {
            languageCode = 'en';
        }
        this.translate.use(languageCode);
        this.cdr.markForCheck();
    }
    openSignOutPopUp() {
        this.dialog.open(SignoutComponent, {
            panelClass: 'ic-dialog__panelclass',
        });
    }
    closePopoverBranch(name, operatingBranchCode) {
        this.selectedBranch = name;
        this.popoverService.setState(true);
        this.tokenStorageService.setOperatingBranch(operatingBranchCode);
        this.selectedBranchName = name;
    }
    ngOnDestroy() {
        this.subscription.forEach(subscription => subscription.unsubscribe());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: HeaderTopComponent, deps: [{ token: i1$5.TranslateService }, { token: TokenStorageService }, { token: i1$3.Router }, { token: i1$2.MatDialog }, { token: PopoverService }, { token: i0.ChangeDetectorRef }, { token: CoreDataService }, { token: i6$1.MatIconRegistry }, { token: i2.DomSanitizer }, { token: ApiService }, { token: i4.Store }, { token: SessionStorageService }, { token: ENVIRONMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: HeaderTopComponent, selector: "ic-header-top", inputs: { notificPanel: "notificPanel", mainMenuPanel: "mainMenuPanel", data: "data" }, viewQueries: [{ propertyName: "accountMenu", first: true, predicate: ["accountMenu"], descendants: true }, { propertyName: "clickHoverMenuTrigger", first: true, predicate: ["clickHoverMenuTrigger"], descendants: true }, { propertyName: "fieldSelectInput", first: true, predicate: ["fieldSelectInput"], descendants: true, read: ElementRef }], ngImport: i0, template: "<mat-toolbar class=\"topbar mat-bg-card\">\r\n  <div class=\"avatar align-self-center\">\r\n    <div class=\"avatar-title rounded bg-soft-primary\">\r\n      <button mat-icon-button title=\"Menu\" (click)=\"toggleMenu()\">\r\n        <ic-icon name=\"menu\" style=\"--ic-icon-color: #ffffff\"></ic-icon>\r\n      </button>\r\n    </div>\r\n  </div>\r\n\r\n  <div>\r\n    <a (click)=\"goToHome()\" tabindex=\"0\" (keydown.enter)=\"goToHome()\"\r\n      >&nbsp; {{ selectedBranchName }}</a\r\n    >\r\n  </div>\r\n\r\n  <span fxFlex></span>\r\n  <div\r\n    *ngIf=\"hideNavItem\"\r\n    style=\"color: #ffffff; font-size: 18px; font-weight: 600; cursor: pointer\"\r\n    (click)=\"goToHome()\"\r\n    tabindex=\"0\"\r\n    (keydown.enter)=\"goToHome()\">\r\n    <span>Skip</span>\r\n  </div>\r\n\r\n  <!-- Top left user menu -->\r\n  <div\r\n    fxLayout=\"row\"\r\n    *ngIf=\"!hideNavItem\"\r\n    class=\"user-account\"\r\n    [matMenuTriggerFor]=\"accountMenu\"\r\n    #clickHoverMenuTrigger=\"matMenuTrigger\">\r\n    <div fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n      <ic-image\r\n        fxFlex=\"100\"\r\n        [src]=\"fileUrl\"\r\n        [srcFallback]=\"userImage\"\r\n        [placeholder]=\"userImage\"\r\n        alt=\"Descriptive text for the image\"\r\n        customClass=\"rounded-circle\"\r\n        class=\"profile-img-div\">\r\n      </ic-image>\r\n    </div>\r\n    <div fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n      <span class=\"user-headline text-white\">{{ currentUser?.username }}</span>\r\n    </div>\r\n    <div fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n      <mat-icon>keyboard_arrow_down</mat-icon>\r\n    </div>\r\n  </div>\r\n\r\n  <mat-menu #accountMenu=\"matMenu\" class=\"profile-menu\">\r\n    <div class=\"profile-box\">\r\n      <div class=\"profile-header\">\r\n        <div class=\"profile-image-container\">\r\n          <ic-image\r\n            fxFlex=\"100\"\r\n            [src]=\"fileUrl\"\r\n            [srcFallback]=\"userImage\"\r\n            [placeholder]=\"userImage\"\r\n            alt=\"Descriptive text for the image\"\r\n            customClass=\"rounded-circle\"\r\n            class=\"user-img-div\"></ic-image>\r\n          <img\r\n            src=\"assets/images/edit.png\"\r\n            class=\"edit-icon\"\r\n            (click)=\"openPopup()\"\r\n            tabindex=\"0\"\r\n            (keydown.enter)=\"openPopup()\"\r\n            alt=\"image\" />\r\n        </div>\r\n\r\n        <div class=\"profile-info\">\r\n          <div class=\"profile-name user-headline\">\r\n            {{ currentUser?.username }}\r\n          </div>\r\n\r\n          <span class=\"profile-label last-session\">\r\n            Last-Login - {{ lastLoginTime }}\r\n          </span>\r\n        </div>\r\n      </div>\r\n      <hr class=\"profile-line\" />\r\n\r\n      <button mat-menu-item (click)=\"onPasswordChange()\" class=\"lang-title\">\r\n        <mat-icon>password</mat-icon> Change Password\r\n      </button>\r\n      <button\r\n        mat-menu-item\r\n        [popoverTrigger]=\"langPopover\"\r\n        [closeOnClickOutside]=\"true\"\r\n        class=\"lang-title\">\r\n        <mat-icon>language</mat-icon>\r\n        Language - {{ selectedLanguage }}\r\n        <mat-icon class=\"icon-end\">keyboard_arrow_down</mat-icon>\r\n      </button>\r\n      <button\r\n        mat-menu-item\r\n        [popoverTrigger]=\"branchPopover\"\r\n        class=\"lang-title\"\r\n        [closeOnClickOutside]=\"true\"\r\n        (click)=\"getOperatingBranch()\">\r\n        <mat-icon>location_on</mat-icon> Operating Branch - {{ selectedBranch }}\r\n        <mat-icon class=\"icon-end\">keyboard_arrow_down</mat-icon>\r\n      </button>\r\n\r\n      <button mat-menu-item (click)=\"goToSecurity()\" class=\"lang-title\">\r\n        <mat-icon\r\n          ><img\r\n            height=\"100%\"\r\n            alt=\".\"\r\n            src=\"assets/images/question_mark.svg\" /></mat-icon\r\n        >Security Question\r\n      </button>\r\n\r\n      <button mat-menu-item class=\"lang-title\" (click)=\"openSignOutPopUp()\">\r\n        <mat-icon>exit_to_app</mat-icon> Sign Out\r\n      </button>\r\n    </div>\r\n  </mat-menu>\r\n\r\n  <!-- Language template start make it reusable -->\r\n  <ng-template #langPopover>\r\n    <ic-popover-container>\r\n      <div class=\"popup-panel\">\r\n        <mat-form-field class=\"full-width\">\r\n          <input\r\n            matInput\r\n            placeholder=\"Search Language\"\r\n            (input)=\"searchLanguage()\"\r\n            [(ngModel)]=\"languageSearchText\" />\r\n\r\n          <!-- <button mat-icon-button matPrefix>\r\n            <mat-icon>search</mat-icon>\r\n          </button> -->\r\n          <ic-icon name=\"search\" matPrefix></ic-icon>\r\n        </mat-form-field>\r\n        <div class=\"language\" *ngFor=\"let language of languageOptions\">\r\n          <button\r\n            mat-menu-item\r\n            (click)=\"closePopover(language.values)\"\r\n            [ngClass]=\"{ 'active-item': language.values === selectedLanguage }\"\r\n            class=\"sub-mat-menu\">\r\n            <span class=\"lang-text\">{{ language?.values }}</span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </ic-popover-container>\r\n  </ng-template>\r\n  <!-- Language template end make it reusable -->\r\n  <!-- theme pop-over template starts -->\r\n  <ng-template #themePopover>\r\n    <ic-popover-container>\r\n      <div class=\"popup-panel\">\r\n        <div class=\"language\" *ngFor=\"let theme of themes\">\r\n          <button\r\n            mat-menu-item\r\n            (click)=\"closePopoverTheme(theme)\"\r\n            class=\"sub-mat-menu\">\r\n            <span class=\"lang-text\">{{ theme }}</span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </ic-popover-container>\r\n  </ng-template>\r\n\r\n  <!-- theme popover template ends -->\r\n\r\n  <!-- Branch template start make it reusable -->\r\n  <ng-template #branchPopover>\r\n    <ic-popover-container>\r\n      <div class=\"popup-panel\">\r\n        <mat-form-field class=\"full-width\">\r\n          <input\r\n            matInput\r\n            placeholder=\"Search\"\r\n            (input)=\"searchBranch()\"\r\n            [(ngModel)]=\"branchSearchText\" />\r\n\r\n          <ic-icon name=\"search\" matPrefix></ic-icon>\r\n        </mat-form-field>\r\n        <div class=\"language\" *ngFor=\"let branch of branches\">\r\n          <button\r\n            mat-menu-item\r\n            [ngClass]=\"{ 'active-item': branch?.branchName === selectedBranch }\"\r\n            class=\"sub-mat-menu\"\r\n            (click)=\"\r\n              closePopoverBranch(branch?.branchName, branch?.branchCode)\r\n            \">\r\n            <span class=\"lang-text\">\r\n              {{ branch?.branchCode }}({{ branch?.branchName }})\r\n            </span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </ic-popover-container>\r\n  </ng-template>\r\n  <!-- Branch template end make it reusable -->\r\n</mat-toolbar>\r\n", styles: ["::ng-deep .profile-menu.mat-mdc-menu-panel{max-width:480px;overflow-y:auto;top:12px;box-shadow:0 2px 4px #0000001a;opacity:1;border-radius:16px;padding:2px;background:#fff}::ng-deep .profile-menu.mat-mdc-menu-panel .mat-mdc-menu-content{padding:0}.profile-box{background:#fafafa 0% 0% no-repeat padding-box;padding:0 3px;border-radius:18px}.profile-img-div{height:40px;aspect-ratio:1}.user-headline{text-align:left;font-family:var(--ic-primary-font-family);font-size:18px;letter-spacing:0px;color:#000;opacity:1}.text-white{color:#fff!important}.last-session{text-align:left;font-family:var(--ic-primary-font-family);font-size:13px;letter-spacing:0px;color:#838383;opacity:1}.lang-title{text-align:left;font-family:var(--ic-primary-font-family);font-size:16px!important;letter-spacing:0px;opacity:1}.lang-title:hover{background:var(--ic-surface-tonal-a0) 0% 0% no-repeat padding-box!important;color:var(--ic-clr-primary-a0);border-radius:8px}.lang-text{text-align:left;font-family:var(--ic-primary-font-family);font-size:13px;letter-spacing:-.26px;opacity:1;font-weight:700}::ng-deep .mat-menu-content{padding-top:2px!important;padding-bottom:2px!important}::ng-deep .mat-menu-panel{min-width:150px!important;max-width:400px!important;max-height:350px;overflow-y:auto;left:0;background:#fff!important;border-radius:12px;box-shadow:0 0 15px #0000004d}::ng-deep .mat-menu-item{display:flex;align-items:center;font-size:small}.profile-image{height:60px;width:60px;margin-right:12px;border-radius:50%}.profile-header{display:flex;align-items:center;padding:10px}.profileImg{width:72px;height:72px;border-radius:50%;padding:10px}.profile-info{display:flex;flex-direction:column}.profile-name{font-weight:500;font-size:20px}.profile-line{margin:4px auto 10px;width:90%;height:1px;background-color:#ccc;border:none}.profile-image-container{display:flex;align-items:center;width:92px;height:92px;padding:10px}.img-icon{border-radius:50px}.user-img-div{height:60px;aspect-ratio:1}.edit-icon{height:60px;width:60px;margin-left:-40px;margin-bottom:-50px;z-index:2;cursor:pointer}.popup-panel{width:350px;padding:8px 10px;align-items:center;text-align:center;background:#fff 0% 0% no-repeat padding-box;box-shadow:none!important;border-radius:9px;opacity:1}.mat-menu-item.sub-mat-menu{padding:0 6px!important}.mat-menu-item:hover{color:#0033a1;opacity:100}.mat-menu-item:hover .mat-icon-no-color{color:#0033a1!important;opacity:100}.mat-menu-item.sub-mat-menu{line-height:16px!important;height:36px!important}.active-item{color:#0033a1!important;opacity:100;border-bottom:1px solid rgba(0,0,0,.1)}.input{height:50px;background:#fffefe 0% 0% no-repeat padding-box;box-shadow:0 3px 15px #00000017;border-radius:8px}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i11.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "component", type: i4$1.MatIconButton, selector: "button[mat-icon-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i13.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { kind: "component", type: i13.MatMenuItem, selector: "[mat-menu-item]", inputs: ["disabled", "disableRipple", "role"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i13.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { kind: "directive", type: i14.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i15.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i15.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "component", type: i6$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i16.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i16.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i16.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i6.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { kind: "directive", type: i6.DefaultLayoutAlignDirective, selector: "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", inputs: ["fxLayoutAlign", "fxLayoutAlign.xs", "fxLayoutAlign.sm", "fxLayoutAlign.md", "fxLayoutAlign.lg", "fxLayoutAlign.xl", "fxLayoutAlign.lt-sm", "fxLayoutAlign.lt-md", "fxLayoutAlign.lt-lg", "fxLayoutAlign.lt-xl", "fxLayoutAlign.gt-xs", "fxLayoutAlign.gt-sm", "fxLayoutAlign.gt-md", "fxLayoutAlign.gt-lg"] }, { kind: "directive", type: i6.DefaultFlexDirective, selector: "  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],  [fxFlex.gt-md], [fxFlex.gt-lg]", inputs: ["fxFlex", "fxFlex.xs", "fxFlex.sm", "fxFlex.md", "fxFlex.lg", "fxFlex.xl", "fxFlex.lt-sm", "fxFlex.lt-md", "fxFlex.lt-lg", "fxFlex.lt-xl", "fxFlex.gt-xs", "fxFlex.gt-sm", "fxFlex.gt-md", "fxFlex.gt-lg"] }, { kind: "directive", type: i18.DefaultClassDirective, selector: "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", inputs: ["ngClass", "ngClass.xs", "ngClass.sm", "ngClass.md", "ngClass.lg", "ngClass.xl", "ngClass.lt-sm", "ngClass.lt-md", "ngClass.lt-lg", "ngClass.lt-xl", "ngClass.gt-xs", "ngClass.gt-sm", "ngClass.gt-md", "ngClass.gt-lg"] }, { kind: "directive", type: PopoverDirective, selector: "[popoverTrigger]", inputs: ["popoverTrigger", "closeOnClickOutside"] }, { kind: "component", type: PopovercontainerComponent, selector: "ic-popover-container" }, { kind: "component", type: i9.ImageComponent, selector: "ic-image", inputs: ["src", "srcFallback", "placeholder", "customClass", "alt", "width", "height"] }, { kind: "component", type: i9.IconComponent, selector: "ic-icon", inputs: ["name", "color", "size"] }, { kind: "directive", type: i9.NoInitialSpaceDirective, selector: "input, textarea" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: HeaderTopComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-header-top', template: "<mat-toolbar class=\"topbar mat-bg-card\">\r\n  <div class=\"avatar align-self-center\">\r\n    <div class=\"avatar-title rounded bg-soft-primary\">\r\n      <button mat-icon-button title=\"Menu\" (click)=\"toggleMenu()\">\r\n        <ic-icon name=\"menu\" style=\"--ic-icon-color: #ffffff\"></ic-icon>\r\n      </button>\r\n    </div>\r\n  </div>\r\n\r\n  <div>\r\n    <a (click)=\"goToHome()\" tabindex=\"0\" (keydown.enter)=\"goToHome()\"\r\n      >&nbsp; {{ selectedBranchName }}</a\r\n    >\r\n  </div>\r\n\r\n  <span fxFlex></span>\r\n  <div\r\n    *ngIf=\"hideNavItem\"\r\n    style=\"color: #ffffff; font-size: 18px; font-weight: 600; cursor: pointer\"\r\n    (click)=\"goToHome()\"\r\n    tabindex=\"0\"\r\n    (keydown.enter)=\"goToHome()\">\r\n    <span>Skip</span>\r\n  </div>\r\n\r\n  <!-- Top left user menu -->\r\n  <div\r\n    fxLayout=\"row\"\r\n    *ngIf=\"!hideNavItem\"\r\n    class=\"user-account\"\r\n    [matMenuTriggerFor]=\"accountMenu\"\r\n    #clickHoverMenuTrigger=\"matMenuTrigger\">\r\n    <div fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n      <ic-image\r\n        fxFlex=\"100\"\r\n        [src]=\"fileUrl\"\r\n        [srcFallback]=\"userImage\"\r\n        [placeholder]=\"userImage\"\r\n        alt=\"Descriptive text for the image\"\r\n        customClass=\"rounded-circle\"\r\n        class=\"profile-img-div\">\r\n      </ic-image>\r\n    </div>\r\n    <div fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n      <span class=\"user-headline text-white\">{{ currentUser?.username }}</span>\r\n    </div>\r\n    <div fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n      <mat-icon>keyboard_arrow_down</mat-icon>\r\n    </div>\r\n  </div>\r\n\r\n  <mat-menu #accountMenu=\"matMenu\" class=\"profile-menu\">\r\n    <div class=\"profile-box\">\r\n      <div class=\"profile-header\">\r\n        <div class=\"profile-image-container\">\r\n          <ic-image\r\n            fxFlex=\"100\"\r\n            [src]=\"fileUrl\"\r\n            [srcFallback]=\"userImage\"\r\n            [placeholder]=\"userImage\"\r\n            alt=\"Descriptive text for the image\"\r\n            customClass=\"rounded-circle\"\r\n            class=\"user-img-div\"></ic-image>\r\n          <img\r\n            src=\"assets/images/edit.png\"\r\n            class=\"edit-icon\"\r\n            (click)=\"openPopup()\"\r\n            tabindex=\"0\"\r\n            (keydown.enter)=\"openPopup()\"\r\n            alt=\"image\" />\r\n        </div>\r\n\r\n        <div class=\"profile-info\">\r\n          <div class=\"profile-name user-headline\">\r\n            {{ currentUser?.username }}\r\n          </div>\r\n\r\n          <span class=\"profile-label last-session\">\r\n            Last-Login - {{ lastLoginTime }}\r\n          </span>\r\n        </div>\r\n      </div>\r\n      <hr class=\"profile-line\" />\r\n\r\n      <button mat-menu-item (click)=\"onPasswordChange()\" class=\"lang-title\">\r\n        <mat-icon>password</mat-icon> Change Password\r\n      </button>\r\n      <button\r\n        mat-menu-item\r\n        [popoverTrigger]=\"langPopover\"\r\n        [closeOnClickOutside]=\"true\"\r\n        class=\"lang-title\">\r\n        <mat-icon>language</mat-icon>\r\n        Language - {{ selectedLanguage }}\r\n        <mat-icon class=\"icon-end\">keyboard_arrow_down</mat-icon>\r\n      </button>\r\n      <button\r\n        mat-menu-item\r\n        [popoverTrigger]=\"branchPopover\"\r\n        class=\"lang-title\"\r\n        [closeOnClickOutside]=\"true\"\r\n        (click)=\"getOperatingBranch()\">\r\n        <mat-icon>location_on</mat-icon> Operating Branch - {{ selectedBranch }}\r\n        <mat-icon class=\"icon-end\">keyboard_arrow_down</mat-icon>\r\n      </button>\r\n\r\n      <button mat-menu-item (click)=\"goToSecurity()\" class=\"lang-title\">\r\n        <mat-icon\r\n          ><img\r\n            height=\"100%\"\r\n            alt=\".\"\r\n            src=\"assets/images/question_mark.svg\" /></mat-icon\r\n        >Security Question\r\n      </button>\r\n\r\n      <button mat-menu-item class=\"lang-title\" (click)=\"openSignOutPopUp()\">\r\n        <mat-icon>exit_to_app</mat-icon> Sign Out\r\n      </button>\r\n    </div>\r\n  </mat-menu>\r\n\r\n  <!-- Language template start make it reusable -->\r\n  <ng-template #langPopover>\r\n    <ic-popover-container>\r\n      <div class=\"popup-panel\">\r\n        <mat-form-field class=\"full-width\">\r\n          <input\r\n            matInput\r\n            placeholder=\"Search Language\"\r\n            (input)=\"searchLanguage()\"\r\n            [(ngModel)]=\"languageSearchText\" />\r\n\r\n          <!-- <button mat-icon-button matPrefix>\r\n            <mat-icon>search</mat-icon>\r\n          </button> -->\r\n          <ic-icon name=\"search\" matPrefix></ic-icon>\r\n        </mat-form-field>\r\n        <div class=\"language\" *ngFor=\"let language of languageOptions\">\r\n          <button\r\n            mat-menu-item\r\n            (click)=\"closePopover(language.values)\"\r\n            [ngClass]=\"{ 'active-item': language.values === selectedLanguage }\"\r\n            class=\"sub-mat-menu\">\r\n            <span class=\"lang-text\">{{ language?.values }}</span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </ic-popover-container>\r\n  </ng-template>\r\n  <!-- Language template end make it reusable -->\r\n  <!-- theme pop-over template starts -->\r\n  <ng-template #themePopover>\r\n    <ic-popover-container>\r\n      <div class=\"popup-panel\">\r\n        <div class=\"language\" *ngFor=\"let theme of themes\">\r\n          <button\r\n            mat-menu-item\r\n            (click)=\"closePopoverTheme(theme)\"\r\n            class=\"sub-mat-menu\">\r\n            <span class=\"lang-text\">{{ theme }}</span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </ic-popover-container>\r\n  </ng-template>\r\n\r\n  <!-- theme popover template ends -->\r\n\r\n  <!-- Branch template start make it reusable -->\r\n  <ng-template #branchPopover>\r\n    <ic-popover-container>\r\n      <div class=\"popup-panel\">\r\n        <mat-form-field class=\"full-width\">\r\n          <input\r\n            matInput\r\n            placeholder=\"Search\"\r\n            (input)=\"searchBranch()\"\r\n            [(ngModel)]=\"branchSearchText\" />\r\n\r\n          <ic-icon name=\"search\" matPrefix></ic-icon>\r\n        </mat-form-field>\r\n        <div class=\"language\" *ngFor=\"let branch of branches\">\r\n          <button\r\n            mat-menu-item\r\n            [ngClass]=\"{ 'active-item': branch?.branchName === selectedBranch }\"\r\n            class=\"sub-mat-menu\"\r\n            (click)=\"\r\n              closePopoverBranch(branch?.branchName, branch?.branchCode)\r\n            \">\r\n            <span class=\"lang-text\">\r\n              {{ branch?.branchCode }}({{ branch?.branchName }})\r\n            </span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </ic-popover-container>\r\n  </ng-template>\r\n  <!-- Branch template end make it reusable -->\r\n</mat-toolbar>\r\n", styles: ["::ng-deep .profile-menu.mat-mdc-menu-panel{max-width:480px;overflow-y:auto;top:12px;box-shadow:0 2px 4px #0000001a;opacity:1;border-radius:16px;padding:2px;background:#fff}::ng-deep .profile-menu.mat-mdc-menu-panel .mat-mdc-menu-content{padding:0}.profile-box{background:#fafafa 0% 0% no-repeat padding-box;padding:0 3px;border-radius:18px}.profile-img-div{height:40px;aspect-ratio:1}.user-headline{text-align:left;font-family:var(--ic-primary-font-family);font-size:18px;letter-spacing:0px;color:#000;opacity:1}.text-white{color:#fff!important}.last-session{text-align:left;font-family:var(--ic-primary-font-family);font-size:13px;letter-spacing:0px;color:#838383;opacity:1}.lang-title{text-align:left;font-family:var(--ic-primary-font-family);font-size:16px!important;letter-spacing:0px;opacity:1}.lang-title:hover{background:var(--ic-surface-tonal-a0) 0% 0% no-repeat padding-box!important;color:var(--ic-clr-primary-a0);border-radius:8px}.lang-text{text-align:left;font-family:var(--ic-primary-font-family);font-size:13px;letter-spacing:-.26px;opacity:1;font-weight:700}::ng-deep .mat-menu-content{padding-top:2px!important;padding-bottom:2px!important}::ng-deep .mat-menu-panel{min-width:150px!important;max-width:400px!important;max-height:350px;overflow-y:auto;left:0;background:#fff!important;border-radius:12px;box-shadow:0 0 15px #0000004d}::ng-deep .mat-menu-item{display:flex;align-items:center;font-size:small}.profile-image{height:60px;width:60px;margin-right:12px;border-radius:50%}.profile-header{display:flex;align-items:center;padding:10px}.profileImg{width:72px;height:72px;border-radius:50%;padding:10px}.profile-info{display:flex;flex-direction:column}.profile-name{font-weight:500;font-size:20px}.profile-line{margin:4px auto 10px;width:90%;height:1px;background-color:#ccc;border:none}.profile-image-container{display:flex;align-items:center;width:92px;height:92px;padding:10px}.img-icon{border-radius:50px}.user-img-div{height:60px;aspect-ratio:1}.edit-icon{height:60px;width:60px;margin-left:-40px;margin-bottom:-50px;z-index:2;cursor:pointer}.popup-panel{width:350px;padding:8px 10px;align-items:center;text-align:center;background:#fff 0% 0% no-repeat padding-box;box-shadow:none!important;border-radius:9px;opacity:1}.mat-menu-item.sub-mat-menu{padding:0 6px!important}.mat-menu-item:hover{color:#0033a1;opacity:100}.mat-menu-item:hover .mat-icon-no-color{color:#0033a1!important;opacity:100}.mat-menu-item.sub-mat-menu{line-height:16px!important;height:36px!important}.active-item{color:#0033a1!important;opacity:100;border-bottom:1px solid rgba(0,0,0,.1)}.input{height:50px;background:#fffefe 0% 0% no-repeat padding-box;box-shadow:0 3px 15px #00000017;border-radius:8px}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$5.TranslateService }, { type: TokenStorageService }, { type: i1$3.Router }, { type: i1$2.MatDialog }, { type: PopoverService }, { type: i0.ChangeDetectorRef }, { type: CoreDataService }, { type: i6$1.MatIconRegistry }, { type: i2.DomSanitizer }, { type: ApiService }, { type: i4.Store }, { type: SessionStorageService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [ENVIRONMENT]
                }] }]; }, propDecorators: { notificPanel: [{
                type: Input
            }], mainMenuPanel: [{
                type: Input
            }], data: [{
                type: Input
            }], accountMenu: [{
                type: ViewChild,
                args: ['accountMenu']
            }], clickHoverMenuTrigger: [{
                type: ViewChild,
                args: ['clickHoverMenuTrigger']
            }], fieldSelectInput: [{
                type: ViewChild,
                args: ['fieldSelectInput', { read: ElementRef }]
            }] } });

class SecurityWarningPopupComponent {
    constructor(dialogRef) {
        this.dialogRef = dialogRef;
    }
    close() {
        this.dialogRef.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SecurityWarningPopupComponent, deps: [{ token: i1$2.MatDialogRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SecurityWarningPopupComponent, selector: "ic-security-warning-popup", ngImport: i0, template: "<div class=\"container\">\r\n  <img class=\"summaryIcon\" src=\"assets/images/success_icon.svg\" alt=\"...\" />\r\n  <!-- <p *ngIf=\"\">User Id disabled contact your administrator!</p> -->\r\n  <p>\r\n    You reached minimum limit, answer few Security questions to create new\r\n    password or use forgot password to reset password\r\n  </p>\r\n  <div fxLayout=\"row\" class=\"mb-12\">\r\n    <div fxLayoutGap=\"30px\">\r\n      <button type=\"button\" mat-raised-button class=\"nextBtn\">Next</button>\r\n\r\n      <button type=\"button\" mat-raised-button class=\"back\" (click)=\"close()\">\r\n        Back\r\n      </button>\r\n    </div>\r\n  </div>\r\n</div>\r\n", styles: [".container{display:flex;justify-content:center;align-items:center;flex-direction:column}p{font-size:16px;text-align:center;font-weight:600}.nextBtn{background:transparent linear-gradient(90deg,#051a2d,#0033a1) 0% 0% no-repeat padding-box;border-radius:24px!important;padding:5px!important;width:200px;height:46px;color:#fff!important}.back{background:#fff;border-radius:24px!important;opacity:1!important;padding:5px!important;width:200px;color:#000!important}\n"], dependencies: [{ kind: "component", type: i4$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "directive", type: i6.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { kind: "directive", type: i6.DefaultLayoutGapDirective, selector: "  [fxLayoutGap], [fxLayoutGap.xs], [fxLayoutGap.sm], [fxLayoutGap.md],  [fxLayoutGap.lg], [fxLayoutGap.xl], [fxLayoutGap.lt-sm], [fxLayoutGap.lt-md],  [fxLayoutGap.lt-lg], [fxLayoutGap.lt-xl], [fxLayoutGap.gt-xs], [fxLayoutGap.gt-sm],  [fxLayoutGap.gt-md], [fxLayoutGap.gt-lg]", inputs: ["fxLayoutGap", "fxLayoutGap.xs", "fxLayoutGap.sm", "fxLayoutGap.md", "fxLayoutGap.lg", "fxLayoutGap.xl", "fxLayoutGap.lt-sm", "fxLayoutGap.lt-md", "fxLayoutGap.lt-lg", "fxLayoutGap.lt-xl", "fxLayoutGap.gt-xs", "fxLayoutGap.gt-sm", "fxLayoutGap.gt-md", "fxLayoutGap.gt-lg"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SecurityWarningPopupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-security-warning-popup', template: "<div class=\"container\">\r\n  <img class=\"summaryIcon\" src=\"assets/images/success_icon.svg\" alt=\"...\" />\r\n  <!-- <p *ngIf=\"\">User Id disabled contact your administrator!</p> -->\r\n  <p>\r\n    You reached minimum limit, answer few Security questions to create new\r\n    password or use forgot password to reset password\r\n  </p>\r\n  <div fxLayout=\"row\" class=\"mb-12\">\r\n    <div fxLayoutGap=\"30px\">\r\n      <button type=\"button\" mat-raised-button class=\"nextBtn\">Next</button>\r\n\r\n      <button type=\"button\" mat-raised-button class=\"back\" (click)=\"close()\">\r\n        Back\r\n      </button>\r\n    </div>\r\n  </div>\r\n</div>\r\n", styles: [".container{display:flex;justify-content:center;align-items:center;flex-direction:column}p{font-size:16px;text-align:center;font-weight:600}.nextBtn{background:transparent linear-gradient(90deg,#051a2d,#0033a1) 0% 0% no-repeat padding-box;border-radius:24px!important;padding:5px!important;width:200px;height:46px;color:#fff!important}.back{background:#fff;border-radius:24px!important;opacity:1!important;padding:5px!important;width:200px;color:#000!important}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.MatDialogRef }]; } });

class NewErrorPopupComponent {
    constructor(data, dialogRef) {
        this.data = data;
        this.dialogRef = dialogRef;
    }
    ngOnInit() {
        this.errorDetails = this.data?.errPayload;
        this.errorImage(this.errorDetails.statusCode);
    }
    errorImage(code) {
        if (code == 400) {
            return (this.imageUrl = '400-error');
        }
        else if (code == 401) {
            return (this.imageUrl = '401-error');
        }
        else if (code == 403) {
            return (this.imageUrl = '403-error');
        }
        else if (code == 404) {
            return (this.imageUrl = '404-not-found');
        }
        else if (code == 500) {
            return (this.imageUrl = '500-error');
        }
        else if (code == 501) {
            return (this.imageUrl = '501-error');
        }
        else if (code == 503) {
            return (this.imageUrl = '503-error');
        }
        else if (code == 504) {
            return (this.imageUrl = '504-error');
        }
        else if (code == 505) {
            return (this.imageUrl = '505-error');
        }
        else {
            return (this.imageUrl = '500-error');
        }
    }
    back() {
        this.dialogRef.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NewErrorPopupComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1$2.MatDialogRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: NewErrorPopupComponent, selector: "ic-new-error-popup", ngImport: i0, template: "<div class=\"error_popup_container\">\r\n  <div class=\"error_popup_body\">\r\n    <h3 class=\"bold-error-message\">{{ errorDetails?.error || 'Oops!' }}</h3>\r\n    <p class=\"error-description\">\r\n      {{ errorDetails?.message || 'Something went wrong' }}\r\n    </p>\r\n    <ic-button\r\n      label=\"Back\"\r\n      icButtonType=\"filled-rounded\"\r\n      size=\"medium\"\r\n      type=\"submit\"\r\n      (OnClick)=\"back()\"></ic-button>\r\n  </div>\r\n  <div class=\"error_popup_img\">\r\n    <ic-icon [name]=\"imageUrl\"> </ic-icon>\r\n  </div>\r\n</div>\r\n", styles: [".error_popup_container{height:100%;display:flex;justify-content:space-between;align-items:center}.error_popup_container .error_popup_body{width:50%;height:100%;display:flex;flex-direction:column;justify-content:center}.error_popup_container .error_popup_body .bold-error-code{color:#184680;font-size:7rem;font-family:Arial,Helvetica,sans-serif;font-weight:900;letter-spacing:-6px}.error_popup_container .error_popup_body .bold-error-code:first-letter{color:#1e90ff}.error_popup_container .error_popup_body .bold-error-message{color:#184680;font-size:18px;font-weight:700;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);text-transform:uppercase}.error_popup_container .error_popup_body .bold-error-message:first-letter{color:#1e90ff}.error_popup_container .error_popup_body .error-description{font-size:16px;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);font-weight:500;color:var(--ic-text-black)}.error_popup_container .error_popup_body .back-button{width:130px;background:#051a2d;background:linear-gradient(91deg,#051a2d,#004c97);padding:3px 50px;border-radius:20px;color:#e7e7e7}.error_popup_container .error_popup_img{width:50%;height:100%;overflow:hidden}.error_popup_container .error_popup_img ic-icon{height:100%;width:100%}\n"], dependencies: [{ kind: "component", type: i9.ButtonComponent, selector: "ic-button", inputs: ["label", "type", "size", "disabled", "isLoading", "isSkeleton", "icButtonType", "icIcon", "prefixIcon", "suffixIcon", "customButtonClass"], outputs: ["OnClick"] }, { kind: "component", type: i9.IconComponent, selector: "ic-icon", inputs: ["name", "color", "size"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NewErrorPopupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-new-error-popup', template: "<div class=\"error_popup_container\">\r\n  <div class=\"error_popup_body\">\r\n    <h3 class=\"bold-error-message\">{{ errorDetails?.error || 'Oops!' }}</h3>\r\n    <p class=\"error-description\">\r\n      {{ errorDetails?.message || 'Something went wrong' }}\r\n    </p>\r\n    <ic-button\r\n      label=\"Back\"\r\n      icButtonType=\"filled-rounded\"\r\n      size=\"medium\"\r\n      type=\"submit\"\r\n      (OnClick)=\"back()\"></ic-button>\r\n  </div>\r\n  <div class=\"error_popup_img\">\r\n    <ic-icon [name]=\"imageUrl\"> </ic-icon>\r\n  </div>\r\n</div>\r\n", styles: [".error_popup_container{height:100%;display:flex;justify-content:space-between;align-items:center}.error_popup_container .error_popup_body{width:50%;height:100%;display:flex;flex-direction:column;justify-content:center}.error_popup_container .error_popup_body .bold-error-code{color:#184680;font-size:7rem;font-family:Arial,Helvetica,sans-serif;font-weight:900;letter-spacing:-6px}.error_popup_container .error_popup_body .bold-error-code:first-letter{color:#1e90ff}.error_popup_container .error_popup_body .bold-error-message{color:#184680;font-size:18px;font-weight:700;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);text-transform:uppercase}.error_popup_container .error_popup_body .bold-error-message:first-letter{color:#1e90ff}.error_popup_container .error_popup_body .error-description{font-size:16px;font-family:var(--ic-primary-font-family, \"Poppins\", sans-serif);font-weight:500;color:var(--ic-text-black)}.error_popup_container .error_popup_body .back-button{width:130px;background:#051a2d;background:linear-gradient(91deg,#051a2d,#004c97);padding:3px 50px;border-radius:20px;color:#e7e7e7}.error_popup_container .error_popup_img{width:50%;height:100%;overflow:hidden}.error_popup_container .error_popup_img ic-icon{height:100%;width:100%}\n"] }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1$2.MatDialogRef }]; } });

class BreadcrumbComponent {
    constructor(router, routePartsService, activeRoute, layout) {
        this.router = router;
        this.routePartsService = routePartsService;
        this.activeRoute = activeRoute;
        this.layout = layout;
        this.staticNavs = [];
        this.routeParts = this.routePartsService.generateRouteParts(this.activeRoute.snapshot);
        this.routerEventSub = this.router.events
            .pipe(filter$1(event => event instanceof NavigationEnd))
            .subscribe(() => {
            this.routeParts = this.routePartsService.generateRouteParts(this.activeRoute.snapshot);
            this.routeParts.reverse().map((item, i) => {
                item.breadcrumb = this.parseText(item);
                item.url = '';
                item.urlSegments.forEach((urlSegment, j) => {
                    if (j === 0) {
                        item.url = `${urlSegment.path}`;
                    }
                    else {
                        item.url += `/${urlSegment.path}`;
                    }
                });
                if (i === 0) {
                    return item;
                }
                // prepend previous part to current part
                item.url = `${this.routeParts[i - 1].url}/${item.url}`;
                return item;
            });
        });
    }
    ngOnDestroy() {
        if (this.routerEventSub) {
            this.routerEventSub.unsubscribe();
        }
    }
    parseText(part) {
        if (!part.breadcrumb) {
            return '';
        }
        part.breadcrumb = part.breadcrumb.replace(/{{([^{}]*)}}/g, (a, b) => {
            const r = part.params[b];
            return typeof r === 'string' ? r : a;
        });
        return part.breadcrumb;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: BreadcrumbComponent, deps: [{ token: i1$3.Router }, { token: RoutePartsService }, { token: i1$3.ActivatedRoute }, { token: LayoutService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: BreadcrumbComponent, selector: "ic-breadcrumb", inputs: { isStatic: "isStatic", staticNavs: "staticNavs" }, ngImport: i0, template: "<div class=\"container-dynamic\">\r\n  <div class=\"breadcrumb-title\" *ngIf=\"!isStatic\">\r\n    <ul\r\n      class=\"breadcrumb\"\r\n      *ngIf=\"\r\n        routeParts.length > 1 &&\r\n        routeParts[routeParts.length - 1].title !== 'Maintenance Summary'\r\n      \"\r\n    >\r\n      <li *ngFor=\"let part of routeParts\">\r\n        <ng-container\r\n          *ngIf=\"\r\n            routeParts[routeParts.length - 1]?.breadcrumb === part.breadcrumb;\r\n            else showLink\r\n          \"\r\n        >\r\n          <a class=\"text-muted\">\r\n            {{ part.breadcrumb }}\r\n          </a>\r\n        </ng-container>\r\n        <ng-template #showLink>\r\n          <a routerLink=\"/{{ part.url }}\" class=\"text-muted\">\r\n            {{ part.breadcrumb }}</a\r\n          >\r\n        </ng-template>\r\n      </li>\r\n    </ul>\r\n  </div>\r\n\r\n  <ng-container *ngIf=\"isStatic\">\r\n    <div class=\"breadcrumb-title\">\r\n      <ul class=\"breadcrumb\">\r\n        <li *ngFor=\"let part of staticNavs\">\r\n          <a routerLink=\"/{{ part.path }}\" class=\"text-muted\">\r\n            {{ part.breadcrumb }}</a\r\n          >\r\n        </li>\r\n      </ul>\r\n    </div>\r\n  </ng-container>\r\n</div>\r\n", styles: [""], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$3.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: BreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-breadcrumb', template: "<div class=\"container-dynamic\">\r\n  <div class=\"breadcrumb-title\" *ngIf=\"!isStatic\">\r\n    <ul\r\n      class=\"breadcrumb\"\r\n      *ngIf=\"\r\n        routeParts.length > 1 &&\r\n        routeParts[routeParts.length - 1].title !== 'Maintenance Summary'\r\n      \"\r\n    >\r\n      <li *ngFor=\"let part of routeParts\">\r\n        <ng-container\r\n          *ngIf=\"\r\n            routeParts[routeParts.length - 1]?.breadcrumb === part.breadcrumb;\r\n            else showLink\r\n          \"\r\n        >\r\n          <a class=\"text-muted\">\r\n            {{ part.breadcrumb }}\r\n          </a>\r\n        </ng-container>\r\n        <ng-template #showLink>\r\n          <a routerLink=\"/{{ part.url }}\" class=\"text-muted\">\r\n            {{ part.breadcrumb }}</a\r\n          >\r\n        </ng-template>\r\n      </li>\r\n    </ul>\r\n  </div>\r\n\r\n  <ng-container *ngIf=\"isStatic\">\r\n    <div class=\"breadcrumb-title\">\r\n      <ul class=\"breadcrumb\">\r\n        <li *ngFor=\"let part of staticNavs\">\r\n          <a routerLink=\"/{{ part.path }}\" class=\"text-muted\">\r\n            {{ part.breadcrumb }}</a\r\n          >\r\n        </li>\r\n      </ul>\r\n    </div>\r\n  </ng-container>\r\n</div>\r\n" }]
        }], ctorParameters: function () { return [{ type: i1$3.Router }, { type: RoutePartsService }, { type: i1$3.ActivatedRoute }, { type: LayoutService }]; }, propDecorators: { isStatic: [{
                type: Input
            }], staticNavs: [{
                type: Input
            }] } });

class NotificationConstant {
    static { this.SIDENAV_MAINTENANCE_ITEMS = [
        {
            name: 'HOME',
            type: 'link',
            tooltip: 'Home',
            icon: 'home',
            state: 'maintenance/dashboard',
        },
        {
            type: 'separator',
            name: 'Maintenance Modules',
        },
        {
            name: 'Maintenance',
            type: 'dropDown',
            tooltip: 'maintenance',
            icon: 'dashboard',
            state: '/maintenance/',
            sub: [
                {
                    name: 'Security Policy',
                    url: 'assets/images/bank-maint.svg',
                    type: 'link',
                    state: 'security-policy/summary',
                },
                {
                    name: 'General Maintenance',
                    url: 'assets/images/bank-maint.svg',
                    type: 'link',
                    state: 'material',
                },
                {
                    name: 'Menus Maintenance',
                    url: 'assets/images/menu-maint.svg',
                    type: 'link',
                    state: 'menu-maintenance/summary',
                },
                {
                    name: 'Role Maintenance',
                    url: 'assets/images/role-maint.svg',
                    type: 'link',
                    state: 'role-maintenance/summary',
                },
                {
                    name: 'Country, State and City Maintenance',
                    url: 'assets/images/country-city-state.svg',
                    type: 'link',
                    state: 'country-state-and-city-maintenance/summary',
                },
                {
                    name: 'User Maintenance',
                    url: 'assets/images/user-maint.svg',
                    type: 'link',
                    state: 'user-maintenance/summary',
                },
                {
                    name: 'Entity Maintenance',
                    url: 'assets/images/basis-subclass.svg',
                    type: 'link',
                    state: 'entity-maintenance/summary',
                },
                {
                    name: 'Bank Maintenance',
                    url: 'assets/images/bank-maint.svg',
                    type: 'link',
                    state: 'bank-maintenance/summary',
                },
                {
                    name: 'Branch Maintenance',
                    url: 'assets/images/branch-maint.svg',
                    type: 'link',
                    state: 'branch-maintenance/summary',
                },
                {
                    name: 'Currency Maintenance',
                    url: 'assets/images/currency-pair-maint.svg',
                    type: 'link',
                    state: 'currency-maintenance/summary',
                },
                {
                    name: 'Accounting Maintenance',
                    url: 'assets/images/till-vault-config.svg',
                    type: 'link',
                    state: 'accounting-maintenance/summary',
                },
                {
                    name: 'Customer Category Maintenance',
                    url: 'assets/images/user-maint.svg',
                    type: 'link',
                    state: 'customer-category-maintenance/summary',
                },
                {
                    name: 'Charge Group Maintenance',
                    url: 'assets/images/Int-charg-maint.svg',
                    type: 'link',
                    state: 'charge-group-maintenance/summary',
                },
                {
                    name: 'Currency Pair Maintenance',
                    url: 'assets/images/currency-pair-maint.svg',
                    type: 'link',
                    state: 'currency-pair-maintenance/summary',
                },
                {
                    name: 'Holiday Maintenance',
                    url: 'assets/images/holiday-maint.svg',
                    type: 'link',
                    state: 'holiday-maintenance/summary',
                },
                {
                    name: 'Kiosk Login',
                    url: 'assets/images/kiosk-maint.svg',
                    type: 'link',
                    state: 'kiosk-maintenance/summary',
                },
                {
                    name: 'Teller Product Maintenance',
                    url: 'assets/images/checklist-maint.svg',
                    type: 'link',
                    state: 'teller-product-maintenance/summary',
                },
                {
                    name: 'Generic Value Maintenance',
                    url: 'assets/images/generic-value-maint.svg',
                    type: 'link',
                    state: 'generic-value-maintenance/summary',
                },
                {
                    name: 'Till/Vault Manager',
                    type: 'dropDown',
                    sub: [
                        {
                            name: 'Till/Vault Maintenance',
                            url: 'assets/images/till-vault-position-maint.svg',
                            type: 'link',
                            state: 'till-vault-maintenance/summary',
                        },
                        {
                            name: 'Till/Vault Configuration Maintenance',
                            url: 'assets/images/till-vault-maint.svg',
                            type: 'link',
                            state: 'till-vault-configuration-maintenance/summary',
                        },
                        // {
                        //   name: "Till/Vault Status",
                        //   url: "assets/images/till-vault-config.svg",
                        //   type: "link",
                        //   state: "till-vault-status-maintenance",
                        // },
                        // {
                        //   name: "Open Or Close Till / Vault",
                        //   url: "assets/images/till-vault-position-maint.svg",
                        //   type: "link",
                        //   state: "till-vault-status-maintenance",
                        // },
                        // {
                        //   name: "Till / Vault Position",
                        //   url: "assets/images/basis-class-maint.svg",
                        //   type: "link",
                        //   state: "till-vault-position-maintenance",
                        // },
                    ],
                },
                {
                    name: 'Denomination Maintenance',
                    url: 'assets/images/depart-maint.svg',
                    type: 'link',
                    state: 'denomination-maintenance/summary',
                },
                {
                    name: 'Employee Levels Maintenance',
                    url: 'assets/images/emp-maint.svg',
                    type: 'link',
                    state: 'employee-levels-maintenance/summary',
                },
                {
                    name: 'Approval Configuration',
                    url: 'assets/images/emp-maint.svg',
                    type: 'link',
                    state: 'approval-configuration-maintenance/summary',
                },
                {
                    name: 'Department Maintenance',
                    url: 'assets/images/depart-maint.svg',
                    type: 'link',
                    state: 'department-maintenance/summary',
                },
                {
                    name: 'Process Stage Configuration',
                    url: 'assets/images/kiosk-maint.svg',
                    type: 'link',
                    state: 'process-stage-configuration/summary',
                },
                {
                    name: 'Process Cycle',
                    url: 'assets/images/book-short-maint.svg',
                    type: 'link',
                    state: 'process-cycle-maintenance/summary',
                },
                {
                    name: 'Check List Maintenance',
                    url: 'assets/images/checklist-maint.svg',
                    type: 'link',
                    state: 'check-list-maintenance/summary',
                },
                // {
                //   name: "Buy/ Sell Cash from Central Bank/ Currency Chest",
                //   url: "assets/images/buy-sell.svg",
                //   type: "link",
                //   state: "buySellCash",
                // },
                // {
                //   name: "Branch Breaching Limits",
                //   url: "assets/images/book-short-maint.svg",
                //   type: "link",
                //   state: "branch-breaching-limits-maintenance",
                // },
                {
                    name: 'Agent Maintenance',
                    url: 'assets/images/agent-maint.svg',
                    type: 'link',
                    state: 'agent-maintenance/summary',
                },
                {
                    name: 'Business Suite Maintenance',
                    url: 'assets/images/business-suite.svg',
                    type: 'link',
                    state: 'business-suite-maintenance/summary',
                },
                {
                    name: 'Communication Protocol',
                    url: 'assets/images/emp-maint.svg',
                    type: 'link',
                    state: 'communication-protocol-maintenance/summary',
                },
                {
                    name: 'Feature Title Maintenance',
                    url: 'assets/images/features-title.svg',
                    type: 'link',
                    state: 'feature-title-maintenance/summary',
                },
                {
                    name: 'User Maintenance',
                    url: 'assets/images/user-maint.svg',
                    type: 'link',
                    state: 'user-maintenance/summary',
                },
                {
                    name: 'Affinity Program Maintenance',
                    url: 'assets/images/aff-prg.svg',
                    type: 'link',
                    state: 'affinity-program-maintenance/summary',
                },
                {
                    name: 'Exchange Rate Maintenance',
                    url: 'assets/images/exchange-rate-maint.svg',
                    type: 'link',
                    state: 'exchange-rate-maintenance/summary',
                },
                {
                    name: 'Instrument Maintenance',
                    url: 'assets/images/kiosk-maint.svg',
                    type: 'link',
                    state: 'instrument-maintenance/summary',
                },
                {
                    name: 'Instrument Status Maintenance',
                    url: 'assets/images/collat-maint.svg',
                    type: 'link',
                    state: 'instrument-status-maintenance/summary',
                },
                {
                    name: 'Interest / Charge Mapping Maintenance',
                    url: 'assets/images/Int-charg-maint.svg',
                    type: 'link',
                    state: 'interest-charge-mapping-maintenance/summary',
                },
                {
                    name: 'Origination Basis Maintenance',
                    url: 'assets/images/orig-maint.svg',
                    type: 'link',
                    state: 'origination-basis-maintenance/summary',
                },
                {
                    name: 'Basis Class Maintenance',
                    url: 'assets/images/basis-class-maint.svg',
                    type: 'link',
                    state: 'basis-class-maintenance/summary',
                },
                {
                    name: 'Basis Subclass Maintenance',
                    url: 'assets/images/basis-subclass.svg',
                    type: 'link',
                    state: 'basis-subclass-maintenance/summary',
                },
                {
                    name: 'Qualitative Scorecard',
                    url: 'assets/images/kiosk-maint.svg',
                    type: 'link',
                    state: 'qualitative-scorecard/summary',
                },
                {
                    name: 'Quantitative Scorecard',
                    url: 'assets/images/quant-maint.svg',
                    type: 'link',
                    state: 'quantitative-scorecard/summary',
                },
                // {
                //   name: "Book Shortage Maintenance",
                //   url: "assets/images/book-short-maint.svg",
                //   type: "link",
                //   state: "bookShortage",
                // },
                // {
                //   name: "Branch Cash Transfer Maintenance",
                //   url: "assets/images/branch-maint.svg",
                //   type: "link",
                //   state: "branchCashTransfer",
                // },
                // {
                //   name: "Transfer Cash from/ to Vault/ Till",
                //   url: "assets/images/transfer-cash-maint.svg",
                //   type: "link",
                //   state: "transferCashSummary",
                // },
                {
                    name: 'Limit Maintenance',
                    url: 'assets/images/limit-maint.svg',
                    type: 'link',
                    state: 'limit-maintenance/summary',
                },
                {
                    name: 'Asset Maintenance',
                    url: 'assets/images/book-short-maint.svg',
                    type: 'link',
                    state: 'asset-maintenance/summary',
                },
                {
                    name: 'Collateral Maintenance',
                    url: 'assets/images/collat-maint.svg',
                    type: 'link',
                    state: 'collateral-maintenance/summary',
                },
            ],
        },
    ]; }
    static { this.SIDENAV_REPORT_ITEMS = [
        {
            name: 'Dashboard',
            type: 'link',
            tooltip: 'Dashboard',
            icon: 'pending_actions',
            state: '/teller/dashboard',
        },
        {
            name: 'Reports',
            type: 'link',
            tooltip: 'Reports',
            icon: 'pending_actions',
            state: 'teller/reports/landing/',
            sub: [
                {
                    name: 'Token Service',
                    type: 'link',
                    state: 'tokenService',
                    avatar: '/assets/images/landing/seo-search.svg',
                    content: 'A token is a device that helps authenticate digital banking users.',
                },
                {
                    name: 'Teller Service',
                    type: 'link',
                    state: 'teller-service',
                    avatar: '/assets/images/landing/table-rows.svg',
                    content: 'A bank tellers provide basic banking services and complete routine financial transactions for account holders and the public.',
                },
                {
                    name: 'Walkin Service',
                    type: 'link',
                    state: 'walking-service',
                    avatar: '/assets/images/landing/bolt.svg',
                    content: 'A walk-in or guest customer is a patron who does not have an appointment, reservation, or an account with a business.',
                },
                {
                    name: 'Agent Service',
                    type: 'link',
                    state: 'agent-service',
                    avatar: '/assets/images/landing/figma.svg',
                    content: 'Agent banking, allows banks to provide services directly to customers.',
                },
            ],
        },
        {
            name: 'Trades',
            type: 'link',
            tooltip: 'Dashboard',
            icon: 'pending_actions',
            state: '/user/dashboard/trade/dashboard',
        },
    ]; }
}

class NotificationsComponent {
    constructor(router, shareDataService, cdr) {
        this.router = router;
        this.shareDataService = shareDataService;
        this.cdr = cdr;
        this.searchValue = new FormControl();
        this.expandDropdown = false;
        this.flag = false;
        this.notifications = [];
        this.menuItems = [];
        this.expandOnClick = () => (this.expandDropdown = !this.expandDropdown);
    }
    ngOnInit() {
        this.shareDataService.getMenuRef.subscribe(() => {
            this.isTeller = window.location.hash.startsWith('#/tel');
            if (this.isTeller) {
                this.menuItems = this.getReportMenuItem();
            }
            else {
                this.menuItems = this.getMaintenanceMenuItem();
            }
            this.cdr.markForCheck();
        });
        this.shareDataService.getMainMenuStatus.subscribe((data) => {
            this.hasMainMenu = data;
            this.cdr.markForCheck();
        });
        this.router.events.subscribe(routeChange => {
            if (routeChange instanceof NavigationEnd) {
                this.notificPanel?.close();
                this.mainMenuPanel?.close();
            }
        });
        this.searchValue.valueChanges.subscribe(value => {
            if (!value)
                this.expandDropdown = false;
        });
    }
    getMaintenanceMenuItem() {
        return NotificationConstant.SIDENAV_MAINTENANCE_ITEMS || [];
    }
    getReportMenuItem() {
        return NotificationConstant.SIDENAV_REPORT_ITEMS || [];
    }
    routeChange(item) {
        if (item?.name === 'Trades') {
            console.log('Trades');
        }
        else {
            this.router.navigate([item.state]);
        }
    }
    onSearch(event) {
        let value = event.target.value;
        value = value.toLowerCase();
        this.flag = false;
        if (this.isTeller) {
            this.menuItems = this.getReportMenuItem();
        }
        else {
            this.menuItems = this.getMaintenanceMenuItem();
        }
        if (value.length > 0) {
            this.menuItems = this.menuItems.filter((item) => item.name.slice(0, value.length).toLowerCase() == value ||
                item.type == 'dropDown');
            this.menuItems.map((item) => {
                if (item.type == 'dropDown') {
                    item.sub = item.sub.filter((sub) => sub.name.slice(0, value.length).toLowerCase() == value ||
                        sub.type == 'dropDown');
                    item.sub.map((sub) => {
                        if (sub.type == 'dropDown') {
                            sub.sub = sub.sub.filter((underSub) => underSub.name.slice(0, value.length).toLowerCase() == value);
                            if (sub.name.slice(0, value.length).toLowerCase() == value &&
                                sub?.sub.length == 0) {
                                let subMenu = [];
                                if (this.isTeller) {
                                    subMenu = this.getReportMenuItem();
                                }
                                else {
                                    subMenu = this.getMaintenanceMenuItem();
                                }
                                if (sub.name == 'Teller') {
                                    sub.sub = subMenu[1]?.sub[29]?.sub;
                                }
                                else if (sub.name == 'Holiday Maintenance') {
                                    sub.sub = subMenu[1]?.sub[11]?.sub;
                                }
                            }
                            item.sub = item.sub.filter((i) => !i.sub ||
                                i?.sub.length != 0 ||
                                i.name.slice(0, value.length).toLowerCase() == value);
                        }
                    });
                    if (item.name.slice(0, value.length).toLowerCase() == value &&
                        item?.sub.length == 0) {
                        let maintenance = [];
                        if (this.isTeller) {
                            maintenance = this.getReportMenuItem();
                        }
                        else {
                            maintenance = this.getMaintenanceMenuItem();
                        }
                        item.sub = maintenance[1]?.sub;
                    }
                    this.menuItems = this.menuItems.filter((item) => !item.sub ||
                        item?.sub.length != 0 ||
                        item.name.slice(0, value.length).toLowerCase() == value);
                }
            });
            if (this.menuItems.length == 0) {
                this.flag = true;
            }
            else {
                this.flag = false;
            }
        }
        else {
            this.flag = false;
        }
    }
    close() {
        this.flag = false;
        if (this.isTeller) {
            this.menuItems = this.getReportMenuItem();
        }
        else {
            this.menuItems = this.getMaintenanceMenuItem();
        }
        this.mainMenuPanel.close();
    }
    ngOnDestroy() {
        //Called once, before the instance is destroyed.
        //Add 'implements OnDestroy' to the class.
        console.log('exited');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NotificationsComponent, deps: [{ token: i1$3.Router }, { token: CoreDataService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: NotificationsComponent, selector: "ic-notifications", inputs: { notificPanel: "notificPanel", mainMenuPanel: "mainMenuPanel" }, ngImport: i0, template: "<div class=\"sidebar-panel\">\r\n  <div\r\n    id=\"scroll-area\"\r\n    [perfectScrollbar]\r\n    class=\"navigation-hold\"\r\n    fxLayout=\"column\">\r\n    <div class=\"sidebar-hold\">\r\n      <div class=\"sidenav-hold\" fxLayout=\"column\">\r\n        <div\r\n          fxLayout=\"row\"\r\n          fxFlex=\"100\"\r\n          fxFlexAlign=\"center\"\r\n          class=\"w-100 px-2\">\r\n          <ic-form-field\r\n            fxFlex=\"100\"\r\n            label=\"Search\"\r\n            placeholder=\"Search\"\r\n            (input)=\"onSearch($event)\"\r\n            suffixIcon=\"search\"></ic-form-field>\r\n        </div>\r\n        <div>\r\n          <ng-container *ngIf=\"isTeller; else showMain\">\r\n            <ul\r\n              appDropdown\r\n              class=\"sidenav\"\r\n              (click)=\"expandOnClick()\"\r\n              tabindex=\"0\"\r\n              (keydown.enter)=\"expandOnClick()\">\r\n              <li\r\n                *ngFor=\"let item of menuItems\"\r\n                appDropdownLink\r\n                [class.open]=\"!!searchValue.value || expandDropdown\">\r\n                <div class=\"nav-item-sep\" *ngIf=\"item.type === 'separator'\">\r\n                  <mat-divider></mat-divider>\r\n                  <span class=\"text-muted\">{{ item.name }}</span>\r\n                </div>\r\n                <div\r\n                  *ngIf=\"\r\n                    !item.disabled &&\r\n                    item.type !== 'separator' &&\r\n                    item.type !== 'icon'\r\n                  \"\r\n                  class=\"lvl1\">\r\n                  <a\r\n                    appDropdownToggle\r\n                    matRipple\r\n                    (click)=\"mainMenuPanel.close(); routeChange(item)\"\r\n                    *ngIf=\"item.type === 'link'\"\r\n                    tabindex=\"0\"\r\n                    (keydown.enter)=\"mainMenuPanel.close()\">\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <mat-icon\r\n                      *ngIf=\"item.svgIcon\"\r\n                      [svgIcon]=\"item.svgIcon\"\r\n                      class=\"svgIcon\"></mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                  </a>\r\n                  <a\r\n                    [href]=\"item.state\"\r\n                    appDropdownToggle\r\n                    matRipple\r\n                    (click)=\"mainMenuPanel.close()\"\r\n                    *ngIf=\"item.type === 'extLink'\"\r\n                    target=\"_blank\">\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                  </a>\r\n\r\n                  <!-- DropDown -->\r\n                  <a\r\n                    *ngIf=\"item.type === 'dropDown'\"\r\n                    appDropdownToggle\r\n                    matRipple>\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <mat-icon\r\n                      *ngIf=\"item.svgIcon\"\r\n                      [svgIcon]=\"item.svgIcon\"\r\n                      class=\"svgIcon\"></mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                    <mat-icon class=\"menu-caret\">keyboard_arrow_right</mat-icon>\r\n                  </a>\r\n                  <!-- LEVEL 2 -->\r\n                  <ul\r\n                    class=\"submenu lvl2\"\r\n                    appDropdown\r\n                    *ngIf=\"item.type === 'dropDown'\">\r\n                    <li\r\n                      *ngFor=\"let itemLvL2 of item.sub\"\r\n                      appDropdownLink\r\n                      routerLinkActive=\"open\">\r\n                      <a\r\n                        routerLink=\"{{ item.state ? '/' + item.state : '' }}/{{\r\n                          itemLvL2.state\r\n                        }}\"\r\n                        appDropdownToggle\r\n                        *ngIf=\"itemLvL2.type !== 'dropDown'\"\r\n                        (click)=\"mainMenuPanel.close()\"\r\n                        matRipple>\r\n                        <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                          <div>\r\n                            <img\r\n                              width=\"20\"\r\n                              height=\"20\"\r\n                              [src]=\"itemLvL2.url\"\r\n                              alt=\"photo\" />\r\n                          </div>\r\n                          <div>\r\n                            <span class=\"item-name lvl2\">{{\r\n                              itemLvL2.name\r\n                            }}</span>\r\n                          </div>\r\n                        </div>\r\n                        <span fxFlex></span>\r\n                      </a>\r\n\r\n                      <a\r\n                        *ngIf=\"itemLvL2.type === 'dropDown'\"\r\n                        appDropdownToggle\r\n                        matRipple>\r\n                        <span class=\"item-name lvl2\">{{ itemLvL2.name }}</span>\r\n                        <span fxFlex></span>\r\n                        <mat-icon class=\"menu-caret\"\r\n                          >keyboard_arrow_right</mat-icon\r\n                        >\r\n                      </a>\r\n\r\n                      <!-- LEVEL 3 -->\r\n                      <ul\r\n                        class=\"submenu lvl3\"\r\n                        appDropdown\r\n                        *ngIf=\"itemLvL2.type === 'dropDown'\">\r\n                        <li\r\n                          *ngFor=\"let itemLvL3 of itemLvL2.sub\"\r\n                          appDropdownLink\r\n                          routerLinkActive=\"open\">\r\n                          <a\r\n                            routerLink=\"{{\r\n                              item.state ? '/' + item.state : ''\r\n                            }}{{\r\n                              itemLvL2.state ? '/' + itemLvL2.state : ''\r\n                            }}/{{ itemLvL3.state }}\"\r\n                            appDropdownToggle\r\n                            (click)=\"mainMenuPanel.close()\"\r\n                            matRipple>\r\n                            <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                              <div>\r\n                                <img\r\n                                  width=\"20\"\r\n                                  height=\"20\"\r\n                                  [src]=\"itemLvL3.url\"\r\n                                  alt=\"photo\" />\r\n                              </div>\r\n                              <div>\r\n                                <span class=\"item-name lvl3\">{{\r\n                                  itemLvL3.name\r\n                                }}</span>\r\n                              </div>\r\n                            </div>\r\n                          </a>\r\n                        </li>\r\n                      </ul>\r\n                    </li>\r\n                  </ul>\r\n                </div>\r\n              </li>\r\n              <div\r\n                class=\"container-v2\"\r\n                fxLayoutAlign=\"center center\"\r\n                *ngIf=\"menuItems.length === 0\">\r\n                <div class=\"item-name lvl1 px-8\">\r\n                  You do not have a sufficient privileges to do this menu\r\n                  operation\r\n                </div>\r\n              </div>\r\n            </ul>\r\n            <div\r\n              class=\"container-v2\"\r\n              fxLayoutAlign=\"center center\"\r\n              *ngIf=\"menuItems.length === 0\">\r\n              <div class=\"text\">\r\n                You do not have a sufficient privileges to do this reports\r\n                operation\r\n              </div>\r\n            </div>\r\n          </ng-container>\r\n          <ng-template #showMain>\r\n            <ul\r\n              appDropdown\r\n              class=\"sidenav\"\r\n              (click)=\"expandOnClick()\"\r\n              tabindex=\"0\"\r\n              (keydown.enter)=\"expandOnClick()\"\r\n              *ngIf=\"hasMainMenu.length > 0\">\r\n              <li\r\n                *ngFor=\"let item of menuItems\"\r\n                appDropdownLink\r\n                [class.open]=\"!!searchValue.value || expandDropdown\">\r\n                <div class=\"nav-item-sep\" *ngIf=\"item.type === 'separator'\">\r\n                  <mat-divider></mat-divider>\r\n                  <span class=\"text-muted\">{{ item.name }}</span>\r\n                </div>\r\n                <div\r\n                  *ngIf=\"\r\n                    !item.disabled &&\r\n                    item.type !== 'separator' &&\r\n                    item.type !== 'icon'\r\n                  \"\r\n                  class=\"lvl1\">\r\n                  <a\r\n                    routerLink=\"/{{ item.state }}\"\r\n                    appDropdownToggle\r\n                    matRipple\r\n                    (click)=\"mainMenuPanel.close()\"\r\n                    *ngIf=\"item.type === 'link'\">\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <mat-icon\r\n                      *ngIf=\"item.svgIcon\"\r\n                      [svgIcon]=\"item.svgIcon\"\r\n                      class=\"svgIcon\"></mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                  </a>\r\n                  <a\r\n                    [href]=\"item.state\"\r\n                    appDropdownToggle\r\n                    matRipple\r\n                    (click)=\"mainMenuPanel.close()\"\r\n                    *ngIf=\"item.type === 'extLink'\"\r\n                    target=\"_blank\">\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                  </a>\r\n\r\n                  <!-- DropDown -->\r\n                  <a\r\n                    *ngIf=\"item.type === 'dropDown'\"\r\n                    appDropdownToggle\r\n                    matRipple>\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <mat-icon\r\n                      *ngIf=\"item.svgIcon\"\r\n                      [svgIcon]=\"item.svgIcon\"\r\n                      class=\"svgIcon\"></mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                    <mat-icon class=\"menu-caret\">keyboard_arrow_right</mat-icon>\r\n                  </a>\r\n                  <!-- LEVEL 2 -->\r\n                  <ul\r\n                    class=\"submenu lvl2\"\r\n                    appDropdown\r\n                    *ngIf=\"item.type === 'dropDown'\">\r\n                    <li\r\n                      *ngFor=\"let itemLvL2 of item.sub\"\r\n                      appDropdownLink\r\n                      routerLinkActive=\"open\">\r\n                      <a\r\n                        routerLink=\"{{ item.state ? '/' + item.state : '' }}/{{\r\n                          itemLvL2.state\r\n                        }}\"\r\n                        appDropdownToggle\r\n                        *ngIf=\"itemLvL2.type !== 'dropDown'\"\r\n                        (click)=\"mainMenuPanel.close()\"\r\n                        matRipple>\r\n                        <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                          <div>\r\n                            <img\r\n                              width=\"20\"\r\n                              height=\"20\"\r\n                              [src]=\"itemLvL2.url\"\r\n                              alt=\"photo\" />\r\n                          </div>\r\n                          <div>\r\n                            <span class=\"item-name lvl2\">{{\r\n                              itemLvL2.name\r\n                            }}</span>\r\n                          </div>\r\n                        </div>\r\n                        <span fxFlex></span>\r\n                      </a>\r\n\r\n                      <a\r\n                        *ngIf=\"itemLvL2.type === 'dropDown'\"\r\n                        appDropdownToggle\r\n                        matRipple>\r\n                        <span class=\"item-name lvl2\">{{ itemLvL2.name }}</span>\r\n                        <span fxFlex></span>\r\n                        <mat-icon class=\"menu-caret\"\r\n                          >keyboard_arrow_right</mat-icon\r\n                        >\r\n                      </a>\r\n\r\n                      <!-- LEVEL 3 -->\r\n                      <ul\r\n                        class=\"submenu lvl3\"\r\n                        appDropdown\r\n                        *ngIf=\"itemLvL2.type === 'dropDown'\">\r\n                        <li\r\n                          *ngFor=\"let itemLvL3 of itemLvL2.sub\"\r\n                          appDropdownLink\r\n                          routerLinkActive=\"open\">\r\n                          <a\r\n                            routerLink=\"{{\r\n                              item.state ? '/' + item.state : ''\r\n                            }}{{\r\n                              itemLvL2.state ? '/' + itemLvL2.state : ''\r\n                            }}/{{ itemLvL3.state }}\"\r\n                            appDropdownToggle\r\n                            (click)=\"mainMenuPanel.close()\"\r\n                            matRipple>\r\n                            <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                              <div>\r\n                                <img\r\n                                  width=\"20\"\r\n                                  height=\"20\"\r\n                                  [src]=\"itemLvL3.url\"\r\n                                  alt=\"photo\" />\r\n                              </div>\r\n                              <div>\r\n                                <span class=\"item-name lvl3\">{{\r\n                                  itemLvL3.name\r\n                                }}</span>\r\n                              </div>\r\n                            </div>\r\n                          </a>\r\n                        </li>\r\n                      </ul>\r\n                    </li>\r\n                  </ul>\r\n                </div>\r\n              </li>\r\n              <div\r\n                class=\"container-v2\"\r\n                fxLayoutAlign=\"center center\"\r\n                *ngIf=\"menuItems.length === 0\">\r\n                <div class=\"item-name lvl1 px-8\">\r\n                  You do not have a sufficient privileges to do this menu\r\n                  operation\r\n                </div>\r\n              </div>\r\n            </ul>\r\n\r\n            <div fxLayoutAlign=\"center center\" *ngIf=\"hasMainMenu.length === 0\">\r\n              <div class=\"item-name lvl1 px-8\">\r\n                You do not have a sufficient privileges to do this maintenance\r\n                operation\r\n              </div>\r\n            </div>\r\n          </ng-template>\r\n        </div>\r\n        <div *ngIf=\"flag\" class=\"errmsg\">\r\n          <mat-hint>{{ 'No Matching Record' }}</mat-hint>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n", dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i15.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "component", type: i6$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i6.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { kind: "directive", type: i6.DefaultLayoutGapDirective, selector: "  [fxLayoutGap], [fxLayoutGap.xs], [fxLayoutGap.sm], [fxLayoutGap.md],  [fxLayoutGap.lg], [fxLayoutGap.xl], [fxLayoutGap.lt-sm], [fxLayoutGap.lt-md],  [fxLayoutGap.lt-lg], [fxLayoutGap.lt-xl], [fxLayoutGap.gt-xs], [fxLayoutGap.gt-sm],  [fxLayoutGap.gt-md], [fxLayoutGap.gt-lg]", inputs: ["fxLayoutGap", "fxLayoutGap.xs", "fxLayoutGap.sm", "fxLayoutGap.md", "fxLayoutGap.lg", "fxLayoutGap.xl", "fxLayoutGap.lt-sm", "fxLayoutGap.lt-md", "fxLayoutGap.lt-lg", "fxLayoutGap.lt-xl", "fxLayoutGap.gt-xs", "fxLayoutGap.gt-sm", "fxLayoutGap.gt-md", "fxLayoutGap.gt-lg"] }, { kind: "directive", type: i6.DefaultLayoutAlignDirective, selector: "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", inputs: ["fxLayoutAlign", "fxLayoutAlign.xs", "fxLayoutAlign.sm", "fxLayoutAlign.md", "fxLayoutAlign.lg", "fxLayoutAlign.xl", "fxLayoutAlign.lt-sm", "fxLayoutAlign.lt-md", "fxLayoutAlign.lt-lg", "fxLayoutAlign.lt-xl", "fxLayoutAlign.gt-xs", "fxLayoutAlign.gt-sm", "fxLayoutAlign.gt-md", "fxLayoutAlign.gt-lg"] }, { kind: "directive", type: i6.DefaultFlexAlignDirective, selector: "  [fxFlexAlign], [fxFlexAlign.xs], [fxFlexAlign.sm], [fxFlexAlign.md],  [fxFlexAlign.lg], [fxFlexAlign.xl], [fxFlexAlign.lt-sm], [fxFlexAlign.lt-md],  [fxFlexAlign.lt-lg], [fxFlexAlign.lt-xl], [fxFlexAlign.gt-xs], [fxFlexAlign.gt-sm],  [fxFlexAlign.gt-md], [fxFlexAlign.gt-lg]", inputs: ["fxFlexAlign", "fxFlexAlign.xs", "fxFlexAlign.sm", "fxFlexAlign.md", "fxFlexAlign.lg", "fxFlexAlign.xl", "fxFlexAlign.lt-sm", "fxFlexAlign.lt-md", "fxFlexAlign.lt-lg", "fxFlexAlign.lt-xl", "fxFlexAlign.gt-xs", "fxFlexAlign.gt-sm", "fxFlexAlign.gt-md", "fxFlexAlign.gt-lg"] }, { kind: "directive", type: i6.DefaultFlexDirective, selector: "  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],  [fxFlex.gt-md], [fxFlex.gt-lg]", inputs: ["fxFlex", "fxFlex.xs", "fxFlex.sm", "fxFlex.md", "fxFlex.lg", "fxFlex.xl", "fxFlex.lt-sm", "fxFlex.lt-md", "fxFlex.lt-lg", "fxFlex.lt-xl", "fxFlex.gt-xs", "fxFlex.gt-sm", "fxFlex.gt-md", "fxFlex.gt-lg"] }, { kind: "directive", type: i18.DefaultStyleDirective, selector: "  [ngStyle],  [ngStyle.xs], [ngStyle.sm], [ngStyle.md], [ngStyle.lg], [ngStyle.xl],  [ngStyle.lt-sm], [ngStyle.lt-md], [ngStyle.lt-lg], [ngStyle.lt-xl],  [ngStyle.gt-xs], [ngStyle.gt-sm], [ngStyle.gt-md], [ngStyle.gt-lg]", inputs: ["ngStyle", "ngStyle.xs", "ngStyle.sm", "ngStyle.md", "ngStyle.lg", "ngStyle.xl", "ngStyle.lt-sm", "ngStyle.lt-md", "ngStyle.lt-lg", "ngStyle.lt-xl", "ngStyle.gt-xs", "ngStyle.gt-sm", "ngStyle.gt-md", "ngStyle.gt-lg"] }, { kind: "component", type: i8$1.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "directive", type: i1$3.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i1$3.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: i9.FormFieldComponent, selector: "ic-form-field", inputs: ["label", "type", "placeholder", "id", "control", "disabled", "customClass", "prefixIcon", "minLength", "maxLength", "numLength", "decimalPlaces", "suffixIcon", "suffixButton", "readonly", "skipLabel", "maskedInput", "customError", "addDiv", "icNumbersOnly", "icAlphaNumericWithSpace", "icSpecialAlphaNumeric", "icSpecialAlphaNumericExtended", "icAlphanumeric", "icNoSpace", "icSpecialText", "icIsUpperCase", "icNoSpecialCharFirst", "icAlphabetOnly", "icRestrictPercentage", "icRestrictDecimal", "icTwoDigitDecimalNumber", "alphabetspace", "appNoInitialDot", "specialIsAlphaNumeric", "someSpecialIsAlphaNumeric", "icPreventInitialZero", "icCurrencyFormatter", "icCleaveCurrency"], outputs: ["onSuffixClick", "onInputChange", "onKeyUp", "onKeyDown"] }, { kind: "directive", type: i9.PerfectScrollbarDirective, selector: "[perfectScrollbar]", inputs: ["disabled", "perfectScrollbar"], outputs: ["psScrollY", "psScrollX", "psScrollUp", "psScrollDown", "psScrollLeft", "psScrollRight", "psYReachEnd", "psYReachStart", "psXReachEnd", "psXReachStart"], exportAs: ["ngxPerfectScrollbar"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NotificationsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-notifications', template: "<div class=\"sidebar-panel\">\r\n  <div\r\n    id=\"scroll-area\"\r\n    [perfectScrollbar]\r\n    class=\"navigation-hold\"\r\n    fxLayout=\"column\">\r\n    <div class=\"sidebar-hold\">\r\n      <div class=\"sidenav-hold\" fxLayout=\"column\">\r\n        <div\r\n          fxLayout=\"row\"\r\n          fxFlex=\"100\"\r\n          fxFlexAlign=\"center\"\r\n          class=\"w-100 px-2\">\r\n          <ic-form-field\r\n            fxFlex=\"100\"\r\n            label=\"Search\"\r\n            placeholder=\"Search\"\r\n            (input)=\"onSearch($event)\"\r\n            suffixIcon=\"search\"></ic-form-field>\r\n        </div>\r\n        <div>\r\n          <ng-container *ngIf=\"isTeller; else showMain\">\r\n            <ul\r\n              appDropdown\r\n              class=\"sidenav\"\r\n              (click)=\"expandOnClick()\"\r\n              tabindex=\"0\"\r\n              (keydown.enter)=\"expandOnClick()\">\r\n              <li\r\n                *ngFor=\"let item of menuItems\"\r\n                appDropdownLink\r\n                [class.open]=\"!!searchValue.value || expandDropdown\">\r\n                <div class=\"nav-item-sep\" *ngIf=\"item.type === 'separator'\">\r\n                  <mat-divider></mat-divider>\r\n                  <span class=\"text-muted\">{{ item.name }}</span>\r\n                </div>\r\n                <div\r\n                  *ngIf=\"\r\n                    !item.disabled &&\r\n                    item.type !== 'separator' &&\r\n                    item.type !== 'icon'\r\n                  \"\r\n                  class=\"lvl1\">\r\n                  <a\r\n                    appDropdownToggle\r\n                    matRipple\r\n                    (click)=\"mainMenuPanel.close(); routeChange(item)\"\r\n                    *ngIf=\"item.type === 'link'\"\r\n                    tabindex=\"0\"\r\n                    (keydown.enter)=\"mainMenuPanel.close()\">\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <mat-icon\r\n                      *ngIf=\"item.svgIcon\"\r\n                      [svgIcon]=\"item.svgIcon\"\r\n                      class=\"svgIcon\"></mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                  </a>\r\n                  <a\r\n                    [href]=\"item.state\"\r\n                    appDropdownToggle\r\n                    matRipple\r\n                    (click)=\"mainMenuPanel.close()\"\r\n                    *ngIf=\"item.type === 'extLink'\"\r\n                    target=\"_blank\">\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                  </a>\r\n\r\n                  <!-- DropDown -->\r\n                  <a\r\n                    *ngIf=\"item.type === 'dropDown'\"\r\n                    appDropdownToggle\r\n                    matRipple>\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <mat-icon\r\n                      *ngIf=\"item.svgIcon\"\r\n                      [svgIcon]=\"item.svgIcon\"\r\n                      class=\"svgIcon\"></mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                    <mat-icon class=\"menu-caret\">keyboard_arrow_right</mat-icon>\r\n                  </a>\r\n                  <!-- LEVEL 2 -->\r\n                  <ul\r\n                    class=\"submenu lvl2\"\r\n                    appDropdown\r\n                    *ngIf=\"item.type === 'dropDown'\">\r\n                    <li\r\n                      *ngFor=\"let itemLvL2 of item.sub\"\r\n                      appDropdownLink\r\n                      routerLinkActive=\"open\">\r\n                      <a\r\n                        routerLink=\"{{ item.state ? '/' + item.state : '' }}/{{\r\n                          itemLvL2.state\r\n                        }}\"\r\n                        appDropdownToggle\r\n                        *ngIf=\"itemLvL2.type !== 'dropDown'\"\r\n                        (click)=\"mainMenuPanel.close()\"\r\n                        matRipple>\r\n                        <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                          <div>\r\n                            <img\r\n                              width=\"20\"\r\n                              height=\"20\"\r\n                              [src]=\"itemLvL2.url\"\r\n                              alt=\"photo\" />\r\n                          </div>\r\n                          <div>\r\n                            <span class=\"item-name lvl2\">{{\r\n                              itemLvL2.name\r\n                            }}</span>\r\n                          </div>\r\n                        </div>\r\n                        <span fxFlex></span>\r\n                      </a>\r\n\r\n                      <a\r\n                        *ngIf=\"itemLvL2.type === 'dropDown'\"\r\n                        appDropdownToggle\r\n                        matRipple>\r\n                        <span class=\"item-name lvl2\">{{ itemLvL2.name }}</span>\r\n                        <span fxFlex></span>\r\n                        <mat-icon class=\"menu-caret\"\r\n                          >keyboard_arrow_right</mat-icon\r\n                        >\r\n                      </a>\r\n\r\n                      <!-- LEVEL 3 -->\r\n                      <ul\r\n                        class=\"submenu lvl3\"\r\n                        appDropdown\r\n                        *ngIf=\"itemLvL2.type === 'dropDown'\">\r\n                        <li\r\n                          *ngFor=\"let itemLvL3 of itemLvL2.sub\"\r\n                          appDropdownLink\r\n                          routerLinkActive=\"open\">\r\n                          <a\r\n                            routerLink=\"{{\r\n                              item.state ? '/' + item.state : ''\r\n                            }}{{\r\n                              itemLvL2.state ? '/' + itemLvL2.state : ''\r\n                            }}/{{ itemLvL3.state }}\"\r\n                            appDropdownToggle\r\n                            (click)=\"mainMenuPanel.close()\"\r\n                            matRipple>\r\n                            <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                              <div>\r\n                                <img\r\n                                  width=\"20\"\r\n                                  height=\"20\"\r\n                                  [src]=\"itemLvL3.url\"\r\n                                  alt=\"photo\" />\r\n                              </div>\r\n                              <div>\r\n                                <span class=\"item-name lvl3\">{{\r\n                                  itemLvL3.name\r\n                                }}</span>\r\n                              </div>\r\n                            </div>\r\n                          </a>\r\n                        </li>\r\n                      </ul>\r\n                    </li>\r\n                  </ul>\r\n                </div>\r\n              </li>\r\n              <div\r\n                class=\"container-v2\"\r\n                fxLayoutAlign=\"center center\"\r\n                *ngIf=\"menuItems.length === 0\">\r\n                <div class=\"item-name lvl1 px-8\">\r\n                  You do not have a sufficient privileges to do this menu\r\n                  operation\r\n                </div>\r\n              </div>\r\n            </ul>\r\n            <div\r\n              class=\"container-v2\"\r\n              fxLayoutAlign=\"center center\"\r\n              *ngIf=\"menuItems.length === 0\">\r\n              <div class=\"text\">\r\n                You do not have a sufficient privileges to do this reports\r\n                operation\r\n              </div>\r\n            </div>\r\n          </ng-container>\r\n          <ng-template #showMain>\r\n            <ul\r\n              appDropdown\r\n              class=\"sidenav\"\r\n              (click)=\"expandOnClick()\"\r\n              tabindex=\"0\"\r\n              (keydown.enter)=\"expandOnClick()\"\r\n              *ngIf=\"hasMainMenu.length > 0\">\r\n              <li\r\n                *ngFor=\"let item of menuItems\"\r\n                appDropdownLink\r\n                [class.open]=\"!!searchValue.value || expandDropdown\">\r\n                <div class=\"nav-item-sep\" *ngIf=\"item.type === 'separator'\">\r\n                  <mat-divider></mat-divider>\r\n                  <span class=\"text-muted\">{{ item.name }}</span>\r\n                </div>\r\n                <div\r\n                  *ngIf=\"\r\n                    !item.disabled &&\r\n                    item.type !== 'separator' &&\r\n                    item.type !== 'icon'\r\n                  \"\r\n                  class=\"lvl1\">\r\n                  <a\r\n                    routerLink=\"/{{ item.state }}\"\r\n                    appDropdownToggle\r\n                    matRipple\r\n                    (click)=\"mainMenuPanel.close()\"\r\n                    *ngIf=\"item.type === 'link'\">\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <mat-icon\r\n                      *ngIf=\"item.svgIcon\"\r\n                      [svgIcon]=\"item.svgIcon\"\r\n                      class=\"svgIcon\"></mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                  </a>\r\n                  <a\r\n                    [href]=\"item.state\"\r\n                    appDropdownToggle\r\n                    matRipple\r\n                    (click)=\"mainMenuPanel.close()\"\r\n                    *ngIf=\"item.type === 'extLink'\"\r\n                    target=\"_blank\">\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                  </a>\r\n\r\n                  <!-- DropDown -->\r\n                  <a\r\n                    *ngIf=\"item.type === 'dropDown'\"\r\n                    appDropdownToggle\r\n                    matRipple>\r\n                    <mat-icon *ngIf=\"item.icon\" class=\"sidenav-mat-icon\">{{\r\n                      item.icon\r\n                    }}</mat-icon>\r\n                    <mat-icon\r\n                      *ngIf=\"item.svgIcon\"\r\n                      [svgIcon]=\"item.svgIcon\"\r\n                      class=\"svgIcon\"></mat-icon>\r\n                    <span class=\"item-name lvl1\">{{ item.name }}</span>\r\n                    <span fxFlex></span>\r\n                    <span\r\n                      class=\"menuitem-badge mat-bg-{{ badge.color }}\"\r\n                      [ngStyle]=\"{ background: badge.color }\"\r\n                      *ngFor=\"let badge of item.badges\"\r\n                      >{{ badge.value }}</span\r\n                    >\r\n                    <mat-icon class=\"menu-caret\">keyboard_arrow_right</mat-icon>\r\n                  </a>\r\n                  <!-- LEVEL 2 -->\r\n                  <ul\r\n                    class=\"submenu lvl2\"\r\n                    appDropdown\r\n                    *ngIf=\"item.type === 'dropDown'\">\r\n                    <li\r\n                      *ngFor=\"let itemLvL2 of item.sub\"\r\n                      appDropdownLink\r\n                      routerLinkActive=\"open\">\r\n                      <a\r\n                        routerLink=\"{{ item.state ? '/' + item.state : '' }}/{{\r\n                          itemLvL2.state\r\n                        }}\"\r\n                        appDropdownToggle\r\n                        *ngIf=\"itemLvL2.type !== 'dropDown'\"\r\n                        (click)=\"mainMenuPanel.close()\"\r\n                        matRipple>\r\n                        <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                          <div>\r\n                            <img\r\n                              width=\"20\"\r\n                              height=\"20\"\r\n                              [src]=\"itemLvL2.url\"\r\n                              alt=\"photo\" />\r\n                          </div>\r\n                          <div>\r\n                            <span class=\"item-name lvl2\">{{\r\n                              itemLvL2.name\r\n                            }}</span>\r\n                          </div>\r\n                        </div>\r\n                        <span fxFlex></span>\r\n                      </a>\r\n\r\n                      <a\r\n                        *ngIf=\"itemLvL2.type === 'dropDown'\"\r\n                        appDropdownToggle\r\n                        matRipple>\r\n                        <span class=\"item-name lvl2\">{{ itemLvL2.name }}</span>\r\n                        <span fxFlex></span>\r\n                        <mat-icon class=\"menu-caret\"\r\n                          >keyboard_arrow_right</mat-icon\r\n                        >\r\n                      </a>\r\n\r\n                      <!-- LEVEL 3 -->\r\n                      <ul\r\n                        class=\"submenu lvl3\"\r\n                        appDropdown\r\n                        *ngIf=\"itemLvL2.type === 'dropDown'\">\r\n                        <li\r\n                          *ngFor=\"let itemLvL3 of itemLvL2.sub\"\r\n                          appDropdownLink\r\n                          routerLinkActive=\"open\">\r\n                          <a\r\n                            routerLink=\"{{\r\n                              item.state ? '/' + item.state : ''\r\n                            }}{{\r\n                              itemLvL2.state ? '/' + itemLvL2.state : ''\r\n                            }}/{{ itemLvL3.state }}\"\r\n                            appDropdownToggle\r\n                            (click)=\"mainMenuPanel.close()\"\r\n                            matRipple>\r\n                            <div fxLayout=\"row\" fxLayoutGap=\"10px\">\r\n                              <div>\r\n                                <img\r\n                                  width=\"20\"\r\n                                  height=\"20\"\r\n                                  [src]=\"itemLvL3.url\"\r\n                                  alt=\"photo\" />\r\n                              </div>\r\n                              <div>\r\n                                <span class=\"item-name lvl3\">{{\r\n                                  itemLvL3.name\r\n                                }}</span>\r\n                              </div>\r\n                            </div>\r\n                          </a>\r\n                        </li>\r\n                      </ul>\r\n                    </li>\r\n                  </ul>\r\n                </div>\r\n              </li>\r\n              <div\r\n                class=\"container-v2\"\r\n                fxLayoutAlign=\"center center\"\r\n                *ngIf=\"menuItems.length === 0\">\r\n                <div class=\"item-name lvl1 px-8\">\r\n                  You do not have a sufficient privileges to do this menu\r\n                  operation\r\n                </div>\r\n              </div>\r\n            </ul>\r\n\r\n            <div fxLayoutAlign=\"center center\" *ngIf=\"hasMainMenu.length === 0\">\r\n              <div class=\"item-name lvl1 px-8\">\r\n                You do not have a sufficient privileges to do this maintenance\r\n                operation\r\n              </div>\r\n            </div>\r\n          </ng-template>\r\n        </div>\r\n        <div *ngIf=\"flag\" class=\"errmsg\">\r\n          <mat-hint>{{ 'No Matching Record' }}</mat-hint>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n" }]
        }], ctorParameters: function () { return [{ type: i1$3.Router }, { type: CoreDataService }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { notificPanel: [{
                type: Input
            }], mainMenuPanel: [{
                type: Input
            }] } });

class HeaderTabNavComponent {
    constructor(cdr, shareDataService, router, store) {
        this.cdr = cdr;
        this.shareDataService = shareDataService;
        this.router = router;
        this.store = store;
        this.sticky = false;
        this.tabs = [];
        this.hideNavItem = false;
        this.showTabs = true;
        this.profileInfo$ = this.store.select(selectUser);
    }
    ngOnInit() {
        let user;
        this.profileInfo$?.subscribe(data => {
            user = data;
        });
        // let user: any = this.tokenStore.getUser();
        this.currentUser = user;
        const roles = user.roles;
        const isRefresh = this.router.url.split('/').slice(1)[0];
        this.pluckActiveTabsFromRoles(isRefresh, roles);
        if (isRefresh == 'profile') {
            this.shareDataService.setIsHideItem(true);
        }
        this.showTabs = this.showMenu;
        this.router.events
            .pipe(filter$1(event => event instanceof NavigationEnd))
            .subscribe(event => {
            const navigationEndEvent = event;
            this.showTabs = !(navigationEndEvent.urlAfterRedirects == '/teller/dashboard' ||
                navigationEndEvent.urlAfterRedirects == '/maintenance/dashboard' ||
                navigationEndEvent.urlAfterRedirects == '/token/dashboard' ||
                navigationEndEvent.urlAfterRedirects == '/task-summary' ||
                navigationEndEvent.urlAfterRedirects.includes('/monitoring'));
        });
    }
    /**
     * Pluck latest active tab childrens from current context
     * @method pluckActiveTabsFromRoles():void
     * @param isRefresh
     * @param roles
     */
    pluckActiveTabsFromRoles(isRefresh, roles) {
        roles?.forEach((role) => {
            if (role && role?.screens?.length > 0) {
                role?.screens?.forEach((screen) => {
                    const tabItem = {
                        label: screen?.screenName,
                        route: screen.route,
                        menus: screen?.children,
                    };
                    this.tabs.push(tabItem);
                });
            }
        });
        if (isRefresh) {
            roles.forEach((role) => {
                if (role && role?.screens?.length > 0) {
                    if (role.screens[0]?.screenName === 'UFC Back Office'
                        ? 'teller'
                        : role.screens[0]?.screenName.toLowerCase() == isRefresh) {
                        this.shareDataService.sendActiveTabMenuChildren(role.screens[0]?.children);
                        return;
                    }
                }
            });
        }
        this.cdr.markForCheck();
    }
    getActiveTabMenus(data) {
        this.shareDataService.sendActiveTabMenuChildren(data?.menus);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: HeaderTabNavComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: CoreDataService }, { token: i1$3.Router }, { token: i4.Store }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: HeaderTabNavComponent, selector: "ic-header-tab-nav", inputs: { showMenu: "showMenu" }, viewQueries: [{ propertyName: "menuElement", first: true, predicate: ["stickyMenu"], descendants: true }], ngImport: i0, template: "<div class=\"container sub-tabs\" #stickyMenu [class.sticky]=\"sticky\">\r\n  <nav mat-tab-nav-bar [tabPanel]=\"tabPanel\" *ngIf=\"!showTabs\">\r\n    <ng-container *ngFor=\"let tabItem of tabs; let i = index\">\r\n      <a\r\n        *ngIf=\"tabItem.label && tabItem.label.trim().length > 0\"\r\n        mat-tab-link\r\n        [routerLink]=\"tabItem.route\"\r\n        routerLinkActive\r\n        #rla=\"routerLinkActive\"\r\n        [active]=\"rla.isActive\"\r\n        (click)=\"getActiveTabMenus(tabItem)\">\r\n        {{ tabItem.label }}\r\n      </a>\r\n    </ng-container>\r\n  </nav>\r\n  <mat-tab-nav-panel #tabPanel></mat-tab-nav-panel>\r\n</div>\r\n", styles: [".sub-tabs .mat-mdc-tab-nav-bar .mat-mdc-tab-link-container{flex-grow:unset!important}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$3.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i1$3.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: i5.MatTabNav, selector: "[mat-tab-nav-bar]", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "animationDuration"], exportAs: ["matTabNavBar", "matTabNav"] }, { kind: "component", type: i5.MatTabNavPanel, selector: "mat-tab-nav-panel", inputs: ["id"], exportAs: ["matTabNavPanel"] }, { kind: "component", type: i5.MatTabLink, selector: "[mat-tab-link], [matTabLink]", inputs: ["disabled", "disableRipple", "tabIndex", "active", "id"], exportAs: ["matTabLink"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: HeaderTabNavComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-header-tab-nav', template: "<div class=\"container sub-tabs\" #stickyMenu [class.sticky]=\"sticky\">\r\n  <nav mat-tab-nav-bar [tabPanel]=\"tabPanel\" *ngIf=\"!showTabs\">\r\n    <ng-container *ngFor=\"let tabItem of tabs; let i = index\">\r\n      <a\r\n        *ngIf=\"tabItem.label && tabItem.label.trim().length > 0\"\r\n        mat-tab-link\r\n        [routerLink]=\"tabItem.route\"\r\n        routerLinkActive\r\n        #rla=\"routerLinkActive\"\r\n        [active]=\"rla.isActive\"\r\n        (click)=\"getActiveTabMenus(tabItem)\">\r\n        {{ tabItem.label }}\r\n      </a>\r\n    </ng-container>\r\n  </nav>\r\n  <mat-tab-nav-panel #tabPanel></mat-tab-nav-panel>\r\n</div>\r\n", styles: [".sub-tabs .mat-mdc-tab-nav-bar .mat-mdc-tab-link-container{flex-grow:unset!important}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.ChangeDetectorRef }, { type: CoreDataService }, { type: i1$3.Router }, { type: i4.Store }]; }, propDecorators: { menuElement: [{
                type: ViewChild,
                args: ['stickyMenu']
            }], showMenu: [{
                type: Input
            }] } });

class LoadingBarComponent {
    /**
     * Constructor
     */
    constructor(_loadingService) {
        this._loadingService = _loadingService;
        this.autoMode = true;
        this.progress = 0;
        this.show = false;
        this._unsubscribeAll = new Subject();
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------
    /**
     * On changes
     *
     * @param changes
     */
    ngOnChanges(changes) {
        // Auto mode
        if (changes['autoMode'] && changes['autoMode'].currentValue !== undefined) {
            // Set the auto mode in the service
            this._loadingService.setAutoMode(coerceBooleanProperty(changes['autoMode'].currentValue));
        }
    }
    /**
     * On init
     */
    ngOnInit() {
        // Subscribe to the service
        this._loadingService.mode$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(value => {
            this.mode = value;
        });
        this._loadingService.progress$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(value => {
            if (value)
                this.progress = value;
        });
        this._loadingService.show$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(value => {
            if (value)
                this.show = value;
        });
    }
    /**
     * On destroy
     */
    ngOnDestroy() {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next(null);
        this._unsubscribeAll.complete();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingBarComponent, deps: [{ token: LoadingService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LoadingBarComponent, selector: "ic-loading-bar", inputs: { autoMode: "autoMode" }, usesOnChanges: true, ngImport: i0, template: "<ng-container *ngIf=\"show\">\r\n  <mat-progress-bar [mode]=\"mode\" [value]=\"progress\"></mat-progress-bar>\r\n</ng-container>\r\n", styles: [""], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i3$1.MatProgressBar, selector: "mat-progress-bar", inputs: ["color", "value", "bufferValue", "mode"], outputs: ["animationEnd"], exportAs: ["matProgressBar"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-loading-bar', encapsulation: ViewEncapsulation.None, template: "<ng-container *ngIf=\"show\">\r\n  <mat-progress-bar [mode]=\"mode\" [value]=\"progress\"></mat-progress-bar>\r\n</ng-container>\r\n" }]
        }], ctorParameters: function () { return [{ type: LoadingService }]; }, propDecorators: { autoMode: [{
                type: Input
            }] } });

class SafePipe {
    constructor(domSanitizer, http, environment) {
        this.domSanitizer = domSanitizer;
        this.http = http;
        this.environment = environment;
    }
    transform(value, type) {
        if (!value || value.includes('undefined') || value.includes('null')) {
            return of(null);
        }
        switch (type) {
            case 'html':
                return of(this.domSanitizer.bypassSecurityTrustHtml(value));
            case 'style':
                return of(this.domSanitizer.bypassSecurityTrustStyle(value));
            case 'resourceUrl':
                return of(this.domSanitizer.bypassSecurityTrustResourceUrl(value));
            case 'script':
                return of(this.domSanitizer.bypassSecurityTrustScript(value));
            case 'url':
                return this.getImageBlobUrl(value);
            default:
                throw new Error(`Unsupported type '${type}'`);
        }
    }
    getImageBlobUrl(uuid) {
        return this.http
            .get(`${this.environment.microServiceURL}/dms/download?uuid=${uuid}`, { responseType: 'blob' })
            .pipe(map(blob => {
            const objectUrl = URL.createObjectURL(blob);
            return this.domSanitizer.bypassSecurityTrustUrl(objectUrl);
        }), catchError(() => of(null)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SafePipe, deps: [{ token: i2.DomSanitizer }, { token: i1.HttpClient }, { token: ENVIRONMENT }], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: SafePipe, name: "safe" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SafePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'safe',
                    pure: true, // Ensures performance optimizations
                }]
        }], ctorParameters: function () { return [{ type: i2.DomSanitizer }, { type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [ENVIRONMENT]
                }] }]; } });

class BrowseImageComponent {
    constructor(env) {
        this.env = env;
        this.deleted = new EventEmitter();
        this.ACTION_NAME = UploadImage;
        this.basePath = this.env.microServiceURL;
    }
    ngOnChanges(changes) {
        if (changes?.['image']) {
            const currentValue = changes['image'].currentValue;
            const previousValue = changes['image'].previousValue;
            this.image = currentValue;
            if (!currentValue || currentValue === 'assets/images/download2.png') {
                this.filePreview = null;
            }
            else if (currentValue !== previousValue ||
                previousValue === undefined) {
                this.filePreview = currentValue;
            }
            else {
                const assetUrl = this.getAssetsUrl(currentValue);
                this.filePreview =
                    assetUrl !== 'assets/images/download2.png' ? assetUrl : null;
            }
        }
    }
    checkImage() {
        return this.filePreview != 'assets/images/download2.png';
    }
    deleteImage() {
        this.deleted.emit(this.fallBackImage);
    }
    getParsedUrl(path) {
        return this.getFileUrl(path);
    }
    getFileUrl(filePath) {
        const file = `${this.basePath}${filePath}`;
        if (isValidUrl(file)) {
            return file;
        }
        else {
            return this.fallBackImage;
        }
    }
    getAssetsUrl(filePath) {
        return filePath && filePath !== 'assets/images/download2.png'
            ? filePath
            : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: BrowseImageComponent, deps: [{ token: ENVIRONMENT }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: BrowseImageComponent, selector: "ic-browse-image", inputs: { action: "action", image: "image", isEdit: "isEdit", readorWrite: "readorWrite", fallBackImage: "fallBackImage", menuIcon: "menuIcon" }, outputs: { deleted: "deleted" }, usesOnChanges: true, ngImport: i0, template: "<ng-container *ngIf=\"action === ACTION_NAME.BROWSE\">\r\n  <!-- Done icon -->\r\n  <div\r\n    class=\"done_icon_btn\"\r\n    *ngIf=\"\r\n      menuIcon ||\r\n      (filePreview &&\r\n        filePreview !== fallBackImage &&\r\n        filePreview !== 'assets/images/download2.png' &&\r\n        filePreview !== null)\r\n    \">\r\n    <ic-icon name=\"green-tick\"></ic-icon>\r\n  </div>\r\n\r\n  <ng-container *ngIf=\"filePreview || menuIcon; else noImage\">\r\n    <div *ngIf=\"filePreview\">\r\n      <img\r\n        #img\r\n        *ngIf=\"filePreview | safe: 'url' | async as safeUrl\"\r\n        [src]=\"safeUrl\"\r\n        class=\"custom-image\"\r\n        [ngClass]=\"{ upload_img: checkImage() }\"\r\n        alt=\"file\" />\r\n      <span\r\n        *ngIf=\"filePreview === 'assets/images/download2.png' && !menuIcon\"\r\n        class=\"image-txt\"\r\n        >Image</span\r\n      >\r\n    </div>\r\n    <div *ngIf=\"menuIcon\">\r\n      <mat-icon class=\"menu_icon\">{{ menuIcon }}</mat-icon>\r\n    </div>\r\n  </ng-container>\r\n\r\n  <ng-template #noImage>\r\n    <img class=\"noImage\" src=\"assets/images/download2.png\" alt=\"text\" />\r\n  </ng-template>\r\n\r\n  <div\r\n    class=\"image_icon_btn\"\r\n    fxLayout=\"column\"\r\n    fxLayout=\"start start\"\r\n    *ngIf=\"\r\n      menuIcon || (filePreview && filePreview != 'assets/images/download2.png')\r\n    \">\r\n    <ic-button\r\n      type=\"icon\"\r\n      icIcon=\"delete\"\r\n      icButtonType=\"ghost\"\r\n      size=\"small\"\r\n      [disabled]=\"readorWrite\"\r\n      (OnClick)=\"deleteImage()\"\r\n      customButtonClass=\"box-shadow-none w-100 h-100\"></ic-button>\r\n  </div>\r\n</ng-container>\r\n", styles: [".done_icon_btn{position:absolute;top:5px;left:5px;height:25px;width:25px}.image_icon_btn{position:absolute;top:0;right:0;color:#b20000;background-color:#fcfcfc;box-shadow:-1px 2px 3px #00000029;border-top-right-radius:10px;border-bottom-left-radius:10px}.upload_img{height:214px!important;width:97%!important}.image-txt{color:#051a2d;opacity:.5;position:relative;top:50px;left:10px}.image-text{top:11px;opacity:.5;left:3px;position:relative;font-size:18px;color:#051a2c}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i6$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: i6.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { kind: "directive", type: i18.DefaultClassDirective, selector: "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", inputs: ["ngClass", "ngClass.xs", "ngClass.sm", "ngClass.md", "ngClass.lg", "ngClass.xl", "ngClass.lt-sm", "ngClass.lt-md", "ngClass.lt-lg", "ngClass.lt-xl", "ngClass.gt-xs", "ngClass.gt-sm", "ngClass.gt-md", "ngClass.gt-lg"] }, { kind: "component", type: i9.ButtonComponent, selector: "ic-button", inputs: ["label", "type", "size", "disabled", "isLoading", "isSkeleton", "icButtonType", "icIcon", "prefixIcon", "suffixIcon", "customButtonClass"], outputs: ["OnClick"] }, { kind: "component", type: i9.IconComponent, selector: "ic-icon", inputs: ["name", "color", "size"] }, { kind: "pipe", type: i3.AsyncPipe, name: "async" }, { kind: "pipe", type: SafePipe, name: "safe" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: BrowseImageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ic-browse-image', template: "<ng-container *ngIf=\"action === ACTION_NAME.BROWSE\">\r\n  <!-- Done icon -->\r\n  <div\r\n    class=\"done_icon_btn\"\r\n    *ngIf=\"\r\n      menuIcon ||\r\n      (filePreview &&\r\n        filePreview !== fallBackImage &&\r\n        filePreview !== 'assets/images/download2.png' &&\r\n        filePreview !== null)\r\n    \">\r\n    <ic-icon name=\"green-tick\"></ic-icon>\r\n  </div>\r\n\r\n  <ng-container *ngIf=\"filePreview || menuIcon; else noImage\">\r\n    <div *ngIf=\"filePreview\">\r\n      <img\r\n        #img\r\n        *ngIf=\"filePreview | safe: 'url' | async as safeUrl\"\r\n        [src]=\"safeUrl\"\r\n        class=\"custom-image\"\r\n        [ngClass]=\"{ upload_img: checkImage() }\"\r\n        alt=\"file\" />\r\n      <span\r\n        *ngIf=\"filePreview === 'assets/images/download2.png' && !menuIcon\"\r\n        class=\"image-txt\"\r\n        >Image</span\r\n      >\r\n    </div>\r\n    <div *ngIf=\"menuIcon\">\r\n      <mat-icon class=\"menu_icon\">{{ menuIcon }}</mat-icon>\r\n    </div>\r\n  </ng-container>\r\n\r\n  <ng-template #noImage>\r\n    <img class=\"noImage\" src=\"assets/images/download2.png\" alt=\"text\" />\r\n  </ng-template>\r\n\r\n  <div\r\n    class=\"image_icon_btn\"\r\n    fxLayout=\"column\"\r\n    fxLayout=\"start start\"\r\n    *ngIf=\"\r\n      menuIcon || (filePreview && filePreview != 'assets/images/download2.png')\r\n    \">\r\n    <ic-button\r\n      type=\"icon\"\r\n      icIcon=\"delete\"\r\n      icButtonType=\"ghost\"\r\n      size=\"small\"\r\n      [disabled]=\"readorWrite\"\r\n      (OnClick)=\"deleteImage()\"\r\n      customButtonClass=\"box-shadow-none w-100 h-100\"></ic-button>\r\n  </div>\r\n</ng-container>\r\n", styles: [".done_icon_btn{position:absolute;top:5px;left:5px;height:25px;width:25px}.image_icon_btn{position:absolute;top:0;right:0;color:#b20000;background-color:#fcfcfc;box-shadow:-1px 2px 3px #00000029;border-top-right-radius:10px;border-bottom-left-radius:10px}.upload_img{height:214px!important;width:97%!important}.image-txt{color:#051a2d;opacity:.5;position:relative;top:50px;left:10px}.image-text{top:11px;opacity:.5;left:3px;position:relative;font-size:18px;color:#051a2c}\n"] }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [ENVIRONMENT]
                }] }]; }, propDecorators: { action: [{
                type: Input
            }], image: [{
                type: Input
            }], isEdit: [{
                type: Input
            }], readorWrite: [{
                type: Input
            }], fallBackImage: [{
                type: Input
            }], menuIcon: [{
                type: Input
            }], deleted: [{
                type: Output
            }] } });

class CurrencySymbolPipe {
    constructor() {
        this.currencyList = currencyList;
    }
    transform(value) {
        const symbol = this.currencyList[value]?.symbol;
        return symbol ?? '₹';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CurrencySymbolPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: CurrencySymbolPipe, name: "currencySymbol" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CurrencySymbolPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'currencySymbol',
                    pure: true,
                }]
        }] });

class ControlAsFormControlPipe {
    transform(control) {
        return control instanceof FormControl ? control : new FormControl();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ControlAsFormControlPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: ControlAsFormControlPipe, name: "controlAsFormControl" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ControlAsFormControlPipe, decorators: [{
            type: Pipe,
            args: [{ name: 'controlAsFormControl', pure: true }]
        }] });

class FormArrayPipe {
    transform(value) {
        return value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormArrayPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: FormArrayPipe, name: "formarray" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormArrayPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: "formarray"
                }]
        }] });

class FormControlPipe {
    transform(value) {
        return value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormControlPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: FormControlPipe, name: "formgroup" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormControlPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'formgroup',
                }]
        }] });

const pipes = [
    SafePipe,
    CurrencySymbolPipe,
    ControlAsFormControlPipe,
    FormControlPipe,
    FormArrayPipe
];
class LibPipesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LibPipesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: LibPipesModule, declarations: [SafePipe,
            CurrencySymbolPipe,
            ControlAsFormControlPipe,
            FormControlPipe,
            FormArrayPipe], exports: [SafePipe,
            CurrencySymbolPipe,
            ControlAsFormControlPipe,
            FormControlPipe,
            FormArrayPipe] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LibPipesModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LibPipesModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: pipes,
                    exports: pipes,
                }]
        }] });

const components = [
    IdleTimeoutComponent,
    HeaderTopComponent,
    SignoutComponent,
    NewErrorPopupComponent,
    PasswordSuccessComponent,
    ProfileComponent,
    SecurityWarningPopupComponent,
    BreadcrumbComponent,
    HeaderTabNavComponent,
    LoadingBarComponent,
    NotificationsComponent,
    BrowseImageComponent,
];
class LibComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LibComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: LibComponentsModule, declarations: [IdleTimeoutComponent,
            HeaderTopComponent,
            SignoutComponent,
            NewErrorPopupComponent,
            PasswordSuccessComponent,
            ProfileComponent,
            SecurityWarningPopupComponent,
            BreadcrumbComponent,
            HeaderTabNavComponent,
            LoadingBarComponent,
            NotificationsComponent,
            BrowseImageComponent], imports: [CommonModule,
            MatToolbarModule,
            MatDialogModule,
            MatButtonModule,
            MatMenuModule,
            MatInputModule,
            MatIconModule,
            FormsModule,
            FlexLayoutModule,
            ImageCropperModule,
            PopoverModule,
            MatDividerModule,
            RouterModule,
            MatProgressBarModule,
            MatTabsModule,
            LibPipesModule,
            IcustLibraryModule], exports: [IdleTimeoutComponent,
            HeaderTopComponent,
            SignoutComponent,
            NewErrorPopupComponent,
            PasswordSuccessComponent,
            ProfileComponent,
            SecurityWarningPopupComponent,
            BreadcrumbComponent,
            HeaderTabNavComponent,
            LoadingBarComponent,
            NotificationsComponent,
            BrowseImageComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LibComponentsModule, imports: [CommonModule,
            MatToolbarModule,
            MatDialogModule,
            MatButtonModule,
            MatMenuModule,
            MatInputModule,
            MatIconModule,
            FormsModule,
            FlexLayoutModule,
            ImageCropperModule,
            PopoverModule,
            MatDividerModule,
            RouterModule,
            MatProgressBarModule,
            MatTabsModule,
            LibPipesModule,
            IcustLibraryModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LibComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: components,
                    imports: [
                        CommonModule,
                        MatToolbarModule,
                        MatDialogModule,
                        MatButtonModule,
                        MatMenuModule,
                        MatInputModule,
                        MatIconModule,
                        FormsModule,
                        FlexLayoutModule,
                        ImageCropperModule,
                        PopoverModule,
                        MatDividerModule,
                        RouterModule,
                        MatProgressBarModule,
                        MatTabsModule,
                        LibPipesModule,
                        IcustLibraryModule,
                    ],
                    exports: components,
                }]
        }] });

class IdleTimeoutService {
    constructor(router, matDialog, tokenStorageService) {
        this.router = router;
        this.matDialog = matDialog;
        this.tokenStorageService = tokenStorageService;
        this.idleDuration = 10 * 60 * 1000; // 10 minutes
        this.warningDuration = 60 * 1000; // 1-minute warning
        this.startSession();
        this.startWatching();
    }
    // Get the elapsed session time in milliseconds
    getElapsedSessionTime() {
        if (!this.sessionStartTime) {
            return 0; // No session started
        }
        return Date.now() - this.sessionStartTime;
    }
    clearTimeOut() {
        [this.idleTimeout, this.warningTimeout, this.sessionTimeout].forEach(timeout => {
            if (timeout) {
                clearTimeout(timeout);
            }
        });
    }
    // Start watching user activity
    startWatching() {
        this.resetTimer(); // Set initial idle timer
        // Reset timer on any user interaction
        ['mousemove', 'keypress', 'click', 'touchstart'].forEach(event => {
            window.addEventListener(event, this.resetTimer.bind(this));
        });
    }
    // Clear all timers and log out
    logout() {
        this.clearTimeOut();
        this.hideWarning();
        this.tokenStorageService.signOut();
        this.router.navigate(['/sessions/signin'], {
            queryParams: { type: 'auth' },
        });
    }
    // Start the session timeout
    startSession() {
        if (this.sessionTimeout)
            clearTimeout(this.sessionTimeout);
        const validityInSeconds = this.tokenStorageService.getValidityInSecs();
        if (!validityInSeconds || validityInSeconds <= 0) {
            this.logout(); // Log out immediately if session duration is invalid
            return;
        }
        this.sessionStartTime = Date.now(); // Record session start time
        this.sessionExpiryDuration = validityInSeconds * 1000;
        this.sessionTimeout = window.setTimeout(() => {
            if (!this.warningTimeout) {
                this.startWarningCountdown('session'); // Session-specific warning
            }
        }, this.sessionExpiryDuration - this.warningDuration);
    }
    // Reset the idle timer on user activity
    resetTimer() {
        if (this.idleTimeout) {
            clearTimeout(this.idleTimeout);
        }
        this.idleTimeout = window.setTimeout(() => {
            if (!this.warningTimeout) {
                this.startWarningCountdown('idle'); // Idle-specific warning
            }
        }, this.idleDuration - this.warningDuration);
    }
    // Show the warning dialog and start the countdown
    startWarningCountdown(type) {
        const warningMessage = type === 'idle'
            ? 'You have been idle for too long.'
            : 'Your session is about to expire.';
        this.idleDialogRef = this.matDialog.open(IdleTimeoutComponent, {
            width: '40%',
            data: {
                warningCountdown: this.warningDuration / 1000,
                message: warningMessage,
            },
        });
        this.warningTimeout = window.setTimeout(() => {
            this.logout();
        }, this.warningDuration);
    }
    // Clear warning dialog and related timers
    hideWarning() {
        this.idleDialogRef?.close();
        if (this.warningTimeout) {
            clearTimeout(this.warningTimeout);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IdleTimeoutService, deps: [{ token: i1$3.Router }, { token: i1$2.MatDialog }, { token: TokenStorageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IdleTimeoutService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IdleTimeoutService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1$3.Router }, { type: i1$2.MatDialog }, { type: TokenStorageService }]; } });

class ApiService {
    constructor(env, http) {
        this.env = env;
        this.http = http;
        console.log(this.env, 'Environment');
    }
    getOpearatingBranch(userName) {
        return this.http.get(`${this.env.microServiceURL}/ic-user/getOperatingBranch?username=${userName}`);
    }
    uploadDocument(formData) {
        return this.http.post(`${this.env.microServiceURL}/upload-document`, formData);
    }
    updateProfileImage(payload) {
        return this.http.put(`${this.env.microServiceURL}/ic-user/updateProfile`, payload);
    }
    getGenericValueLanguage(_screenNameVal) {
        return this.http.get(`${this.env.microServiceURL}/generic-value?screenCode=45&genericName=LANGUAGE`);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ApiService, deps: [{ token: ENVIRONMENT }, { token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ApiService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ApiService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [ENVIRONMENT]
                }] }, { type: i1.HttpClient }]; } });

class ThemeService {
    constructor(document, rendererFactory) {
        this.document = document;
        this.onThemeChange = new EventEmitter();
        this.egretThemes = [
            {
                name: 'egret-navy',
                // baseColor: "#10174c",
                baseColor: '#cacaca',
                isActive: false,
            },
            {
                name: 'egret-navy-dark',
                // baseColor: "#0081ff",
                baseColor: '#000000',
                isActive: false,
            },
        ];
        this.renderer = rendererFactory.createRenderer(null, null);
    }
    // Invoked in AppComponent and apply 'activatedTheme' on startup
    applyMatTheme(themeName) {
        this.activatedTheme = this.egretThemes.find((t) => t.name === themeName);
        this.flipActiveFlag(themeName);
        this.renderer.addClass(this.document.body, themeName);
    }
    changeTheme(prevTheme, themeName) {
        this.renderer.removeClass(this.document.body, prevTheme);
        this.renderer.addClass(this.document.body, themeName);
        this.flipActiveFlag(themeName);
        this.onThemeChange.emit(this.activatedTheme);
    }
    flipActiveFlag(themeName) {
        this.egretThemes.forEach((t) => {
            t.isActive = false;
            if (t.name === themeName) {
                t.isActive = true;
                this.activatedTheme = t;
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ThemeService, deps: [{ token: DOCUMENT }, { token: i0.RendererFactory2 }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ThemeService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ThemeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.RendererFactory2 }]; } });

class CoreDataService {
    constructor() {
        this.lang = new BehaviorSubject({});
        this.hideNavItem = new BehaviorSubject(false);
        this.profileImage = new BehaviorSubject('');
        this.menuChildrens = new BehaviorSubject([]);
        this.menuRef = new BehaviorSubject('');
        this.mainMenuStatus = new BehaviorSubject([]);
        this.getMenuRef = this.menuRef.asObservable();
        this.getMenuChildrens = this.menuChildrens.asObservable();
        this.getMainMenuStatus = this.mainMenuStatus.asObservable();
    }
    setlanguageVal(value) {
        this.lang.next(value);
    }
    setIsHideItem(value) {
        this.hideNavItem.next(value);
    }
    getIsHideItem() {
        return this.hideNavItem.asObservable();
    }
    sendProfileImage(profileImage) {
        this.profileImage.next(profileImage);
    }
    getProfileImage() {
        return this.profileImage.asObservable();
    }
    sendMenRef(id) {
        this.menuRef.next(id);
    }
    sendActiveTabMenuChildren(data) {
        this.menuChildrens.next(data);
    }
    sendMainMenuStatus(data) {
        this.mainMenuStatus.next(data);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CoreDataService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CoreDataService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CoreDataService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class LayoutService {
    constructor(themeService) {
        this.themeService = themeService;
        this.layoutConf = {};
        this.layoutConfSubject = new BehaviorSubject(this.layoutConf);
        this.layoutConf$ = this.layoutConfSubject.asObservable();
        this.fullWidthRoutes = [];
        this.setAppLayout(
        // ******** SET YOUR LAYOUT OPTIONS HERE *********
        {
            navigationPos: 'top',
            sidebarStyle: 'full',
            sidebarColor: 'slate',
            sidebarCompactToggle: false,
            dir: 'ltr',
            useBreadcrumb: true,
            topbarFixed: true,
            footerFixed: false,
            topbarColor: 'white',
            footerColor: 'slate',
            matTheme: 'egret-navy',
            breadcrumb: 'simple',
            perfectScrollbar: true,
        });
    }
    setAppLayout(layoutConf) {
        this.layoutConf = { ...this.layoutConf, ...layoutConf };
        this.applyMatTheme();
    }
    publishLayoutChange(lc) {
        if (this.layoutConf.matTheme !== lc.matTheme && lc.matTheme) {
            this.themeService.changeTheme(this.layoutConf.matTheme, lc.matTheme);
        }
        this.layoutConf = Object.assign(this.layoutConf, lc);
        this.layoutConfSubject.next(this.layoutConf);
    }
    applyMatTheme() {
        const theme = this.layoutConf.matTheme ?? 'default-theme'; // Provide default if undefined
        this.themeService.applyMatTheme(theme);
    }
    setLayoutFromQuery() {
        const layoutConfString = getQueryParam('layout');
        const prevTheme = this.layoutConf.matTheme;
        try {
            this.layoutConf = JSON.parse(layoutConfString);
            const theme = this.layoutConf.matTheme ?? 'default-theme'; // Provide default if undefined
            this.themeService.changeTheme(prevTheme, theme);
        }
        catch (e) {
            console.log(e);
        }
    }
    adjustLayout(options = {}) {
        let sidebarStyle;
        this.isMobile = this.isSm();
        this.currentRoute = options.route || this.currentRoute;
        sidebarStyle = this.isMobile ? 'closed' : 'full';
        if (this.currentRoute) {
            this.fullWidthRoutes.forEach(route => {
                if (this.currentRoute.indexOf(route) !== -1) {
                    sidebarStyle = 'closed';
                }
            });
        }
        this.publishLayoutChange({
            isMobile: this.isMobile,
            sidebarStyle,
        });
    }
    isSm() {
        return window.matchMedia(`(max-width: 959px)`).matches;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LayoutService, deps: [{ token: ThemeService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LayoutService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LayoutService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: ThemeService }]; } });

class LoadingService {
    constructor() {
        this._auto$ = new BehaviorSubject(true);
        this._mode$ = new BehaviorSubject('indeterminate');
        this._progress$ = new BehaviorSubject(0);
        this._show$ = new BehaviorSubject(false);
        this._urlMap = new Map();
    }
    /**
     * Constructor
     */
    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------
    /**
     * Getter for auto mode
     */
    get auto$() {
        return this._auto$.asObservable();
    }
    /**
     * Getter for mode
     */
    get mode$() {
        return this._mode$.asObservable();
    }
    /**
     * Getter for progress
     */
    get progress$() {
        return this._progress$.asObservable();
    }
    /**
     * Getter for show
     */
    get show$() {
        return this._show$.asObservable();
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------
    /**
     * Show the loading bar
     */
    show() {
        this._show$.next(true);
    }
    /**
     * Hide the loading bar
     */
    hide() {
        this._show$.next(false);
    }
    /**
     * Set the auto mode
     *
     * @param value
     */
    setAutoMode(value) {
        this._auto$.next(value);
    }
    /**
     * Set the mode
     *
     * @param value
     */
    setMode(value) {
        this._mode$.next(value);
    }
    /**
     * Set the progress of the bar manually
     *
     * @param value
     */
    setProgress(value) {
        if (value < 0 || value > 100) {
            console.error('Progress value must be between 0 and 100!');
            return;
        }
        this._progress$.next(value);
    }
    /**
     * Sets the loading status on the given url
     *
     * @param status
     * @param url
     */
    _setLoadingStatus(status, url) {
        // Return if the url was not provided
        if (!url) {
            console.error('The request URL must be provided!');
            return;
        }
        if (status) {
            this._urlMap.set(url, status);
            this._show$.next(true);
        }
        else if (!status && this._urlMap.has(url)) {
            this._urlMap.delete(url);
        }
        // Only set the status to 'false' if all outgoing requests are completed
        if (this._urlMap.size === 0) {
            this._show$.next(false);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class NotificationService {
    constructor(toastr) {
        this.toastr = toastr;
    }
    showSuccess(message, title) {
        this.toastr.success(message, title);
    }
    showError(message, title) {
        this.toastr.error(message, title);
    }
    showInfo(message, title) {
        this.toastr.info(message, title);
    }
    showWarning(message, title) {
        this.toastr.warning(message, title);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NotificationService, deps: [{ token: i1$6.ToastrService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NotificationService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NotificationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1$6.ToastrService }]; } });

class RoutePartsService {
    generateRouteParts(snapshot) {
        let routeParts = [];
        if (snapshot) {
            if (snapshot.firstChild) {
                routeParts = routeParts.concat(this.generateRouteParts(snapshot.firstChild));
            }
            if (snapshot.data['title'] && snapshot.url.length) {
                routeParts.push({
                    title: snapshot.data['title'],
                    breadcrumb: snapshot.data['breadcrumb'],
                    url: snapshot.url[0]?.path,
                    urlSegments: snapshot.url,
                    params: snapshot.queryParams,
                });
            }
        }
        return routeParts;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RoutePartsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RoutePartsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RoutePartsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

// date-time.service
class DateTimeService {
    constructor(store) {
        this.store = store;
        this.currentLocal = DEFAULT_LOCALE;
        this.store
            .select(selectLocaleData)
            .pipe(take(1), filter(localeData => !!localeData))
            .subscribe(opt => {
            if (opt)
                this.currentLocal = opt;
            this.init(opt);
        });
    }
    init(opt) {
        this._format = opt?.dateFormat ?? this.currentLocal?.dateFormat;
        this._locale = opt?.locale ?? this.currentLocal?.locale;
    }
    get format() {
        return this._format;
    }
    set format(value) {
        this._format = value;
    }
    get locale() {
        return this._locale;
    }
    set locale(value) {
        this._locale = value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DateTimeService, deps: [{ token: i4.Store }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DateTimeService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DateTimeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i4.Store }]; } });

class CustomDateAdapter extends MomentDateAdapter {
    constructor(_dateTimeService) {
        super(_dateTimeService.locale);
        this._dateTimeService = _dateTimeService;
    }
    format(date) {
        const locale = this._dateTimeService.locale;
        const format = this._dateTimeService.format;
        return date.locale(locale).format(format);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CustomDateAdapter, deps: [{ token: DateTimeService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CustomDateAdapter, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CustomDateAdapter, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: DateTimeService }]; } });

class DmsService {
    constructor(httpClient, env) {
        this.httpClient = httpClient;
        this.basePath = env.microServiceURL;
    }
    /**
     * Uploads a file to the server using the provided FormData object.
     *
     * @param {FormData} formData - An instance of FormData containing the file to be uploaded.
     * @return {Observable<any>} An Observable that emits the server response upon successful upload.
     */
    uploadDocuments(formData) {
        return this.httpClient.post(`${this.basePath}/dms/upload`, formData);
    }
    uploadSignaturewithEvent(payload) {
        return this.httpClient.post(`${this.basePath}/dms/upload`, payload, {
            reportProgress: true,
            observe: 'events',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DmsService, deps: [{ token: i1.HttpClient }, { token: ENVIRONMENT }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DmsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DmsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [ENVIRONMENT]
                }] }]; } });

const TOKEN_HEADER_KEY = 'Authorization'; // for Spring Boot back-end
class AuthInterceptor {
    constructor(token) {
        this.token = token;
    }
    intercept(req, next) {
        let authReq = req;
        const token = this.token.getToken();
        const language = this.token.getLanguage() || 'English';
        if (req.headers.get('Anonymous') == 'NOTKN') {
            const newHeaders = req.headers.delete('Anonymous');
            newHeaders.delete('Authorization');
            const newRequest = req.clone({ headers: newHeaders });
            return next.handle(newRequest);
        }
        else {
            if (token) {
                // for Spring Boot back-end
                authReq = req.clone({
                    headers: req.headers
                        .set(TOKEN_HEADER_KEY, 'Bearer ' + token)
                        .set('language', language),
                });
            }
            return next.handle(authReq);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AuthInterceptor, deps: [{ token: TokenStorageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AuthInterceptor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AuthInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: TokenStorageService }]; } });

class LoadingInterceptor {
    /**
     * Constructor
     */
    constructor(_loadingService) {
        this._loadingService = _loadingService;
        // Subscribe to the auto
        this._loadingService.auto$.subscribe(value => {
            this.handleRequestsAutomatically = value;
        });
    }
    /**
     * Intercept
     *
     * @param req
     * @param next
     */
    intercept(req, next) {
        // If the Auto mode is turned off, do nothing
        if (!this.handleRequestsAutomatically) {
            return next.handle(req);
        }
        // Set the loading status to true
        this._loadingService._setLoadingStatus(true, req.url);
        return next.handle(req).pipe(finalize(() => {
            // Set the status to false if there are any errors or the request is completed
            this._loadingService._setLoadingStatus(false, req.url);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingInterceptor, deps: [{ token: LoadingService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingInterceptor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: LoadingService }]; } });

class CachingInterceptor {
    constructor(cache) {
        this.cache = cache;
    }
    intercept(req, next) {
        // continue if not cacheable.
        if (!isCacheable(req)) {
            return next.handle(req);
        }
        const cachedResponse = this.cache.get(req);
        // cache-then-refresh
        if (req.headers.get('x-refresh')) {
            const results$ = sendRequest(req, next, this.cache);
            return cachedResponse
                ? results$.pipe(startWith(cachedResponse))
                : results$;
        }
        // cache-or-fetch
        return cachedResponse
            ? of(cachedResponse)
            : sendRequest(req, next, this.cache);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CachingInterceptor, deps: [{ token: RequestCache }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CachingInterceptor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CachingInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: RequestCache }]; } });
function isCacheable(req) {
    // Implement your own logic to determine if the request is cacheable.
    // For example, you might check if the request method is GET.
    return req.method === 'GET';
}
/**
 * Get server response observable by sending request to `next()`.
 * Will add the response to the cache on the way out.
 */
function sendRequest(req, next, cache) {
    return next.handle(req).pipe(tap(event => {
        // There may be other events besides the response.
        if (event instanceof HttpResponse) {
            if (cacheableEndpoints.some(endPoint => req.urlWithParams.includes(endPoint)))
                cache.put(req, event); // Update the cache.
        }
    }));
}
const cacheableEndpoints = [
    '/basis-detail',
    '/aspects-account',
    '/boundaries',
    '/aspects-lending',
    '/account-information-initial-funding',
    '/country?oneTimeAuth=Y&recordStatus=OPEN',
    '/branch?oneTimeAuth=Y&recordStatus=OPEN',
    '/entity?oneTimeAuth=Y&recordStatus=OPEN',
    '/icCurrency?oneTimeAuth=Y&recordStatus=OPEN',
    '/city/fetchByPinCode?oneTimeAuth=Y&recordStatus=OPEN',
    '/ic-role?oneTimeAuth=Y&recordStatus=OPEN',
    '/loginApi/profile',
    '/auth/privilege',
    '/loginApi/allParentScreen?authStatus=AUTHORIZED&recordStatus=OPEN',
    '/loginApi/allRole',
    '/process_cycle?authStatus=AUTHORIZED&recordStatus=OPEN',
    '/bank?oneTimeAuth=Y&recordStatus=OPEN',
    '/ic-user/getOperatingBranch',
    '/securityPolicy/summary',
    '/screen/summary?',
    '/teller-product?oneTimeAuth=Y&recordStatus=OPEN',
    '/ChecklistMaint?oneTimeAuth=Y&recordStatus=OPEN',
    '/affinity-program?oneTimeAuth=Y&recordStatus=OPEN',
    '/featureTitle?oneTimeAuth=Y&recordStatus=OPEN',
    '/interestChargeMapping?oneTimeAuth=Y&recordStatus=OPEN',
];

class RetryMapCache {
    constructor() {
        this.retryMap = new Map();
    }
    get(request) {
        const key = request.urlWithParams;
        return this.retryMap.get(key);
    }
    put(key, req) {
        this.retryMap.set(key, req);
    }
    getAll() {
        return Array.from(this.retryMap.values()) ?? [];
    }
    clear() {
        this.retryMap.clear();
    }
    delete(key) {
        this.retryMap.delete(key);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RetryMapCache, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RetryMapCache, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RetryMapCache, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class ErrorNotifierService {
    constructor(tokenStorageService, router, routingState, notificationService, dialog, _loaderService, sessionService, retryCache) {
        this.tokenStorageService = tokenStorageService;
        this.router = router;
        this.routingState = routingState;
        this.notificationService = notificationService;
        this.dialog = dialog;
        this._loaderService = _loaderService;
        this.sessionService = sessionService;
        this.retryCache = retryCache;
        this.hasAlreadyLoggedOut = false;
    }
    intercept(request, next) {
        return next.handle(request).pipe(catchError((error) => {
            let handled = false;
            let history = [];
            history = this.routingState.getHistory();
            const errorPayload = {
                error: error?.error?.error,
                message: error?.error?.message,
                statusCode: error?.status,
            };
            if (error.error instanceof ErrorEvent) {
                // Handle client-side errors here (if needed)
            }
            else {
                // CLose all dialog popup on error
                this.dialog.closeAll();
                if (error?.error?.message?.includes('operating time range')) {
                    this.openCustomErrorDialog(errorPayload);
                    this._loaderService.hide();
                    return of(error); // Always return an observable
                }
                else if (error.status === 401) {
                    if (errorPayload?.message &&
                        errorPayload?.message
                            ?.toLowerCase()
                            .includes('user record is not authorised')) {
                        this.notificationService.showError('Please use a valid credential', errorPayload?.message);
                        this.tokenStorageService.signOut();
                        this.router.navigate(['/sessions/signin'], {
                            queryParams: { type: 'auth' },
                        });
                        this._loaderService.hide();
                        return of(error); // Return an observable
                    }
                    else if (request.url.includes('auth/refresh-token')) {
                        // this.alert
                        //   .showCustomAlert(
                        //     '',
                        //     '',
                        //     'Your Session is Expired, Please relogin!'
                        //   )
                        //   .subscribe(() => {
                        this.openCustomErrorDialog('Your Session is Expired, Please relogin!');
                        this.tokenStorageService.signOut();
                        this.router.navigate(['/sessions/signin'], {
                            queryParams: { type: 'auth' },
                        });
                        // });
                        return;
                    }
                    return this.handleRequestMap(request, next);
                    // this.notificationService.showError(
                    //   'Please Re-Login to continue',
                    //   'Your Session Expired'
                    // );
                    // this._loaderService.hide();
                    // return of(error); // Return an observable
                }
                else if (error.status === 500) {
                    this._loaderService.hide();
                    this.openCustomErrorDialog(errorPayload);
                    return throwError(error); // Return observable with error
                }
                else if (error.status === 403) {
                    errorPayload.error = 'Contact your Administrator.';
                    errorPayload.message =
                        'You do not have sufficient privileges to do this operation';
                    this.openCustomErrorDialog(errorPayload);
                    this._loaderService.hide();
                    return of(error); // Return an observable
                }
                else if (error.status === 409 &&
                    error?.error?.message == 'Reached maximum invalid attempts') {
                    const type = 'LOCKED';
                    this.router
                        .navigate(['/sessions/signin'], {
                        queryParams: { type: 'auth' },
                    })
                        .then(_ => {
                        this.openLockedDialog(type);
                    });
                    handled = true;
                    this._loaderService.hide();
                    return of(error); // Return an observable
                }
                else if (error.status === 409 &&
                    error?.error?.message?.includes('cannot deactivate')) {
                    this.openCustomErrorDialog(errorPayload);
                    return of(error); // Return an observable
                }
                else if (error?.error?.error == 'blocked and user disabled' ||
                    error?.error?.error == 'User is disabled') {
                    const type = 'LOCKED';
                    this.openLockedDialog(type);
                    handled = true;
                }
                else if (error.status >= 300 && error.status <= 308) {
                    this.router.navigateByUrl(`/sessions/invalidsession`);
                }
                else {
                    // This works for other cases
                    if (!history.includes(`/sessions/error/${error?.status}`) ||
                        history.includes(`/sessions/error/400`)) {
                        // OPEN Custom Error Popup
                        this.openCustomErrorDialog(errorPayload);
                    }
                }
            }
            if (handled) {
                return of(error); // Return an observable
            }
            else {
                return throwError(error); // Return an observable with error
            }
        }));
    }
    openCustomErrorDialog(errPayload) {
        this.dialog.open(NewErrorPopupComponent, {
            width: '45%',
            height: '50%',
            disableClose: true,
            panelClass: 'ic-dialog__panelclass',
            data: {
                type: 'customError',
                errPayload,
            },
        });
    }
    openLockedDialog(type) {
        this.dialog.open(SecurityWarningPopupComponent, {
            width: '40%',
            disableClose: true,
            panelClass: 'ic-dialog__panelclass',
            data: {
                type: type,
            },
        });
    }
    handleRequestMap(req, next) {
        return new Observable(observer => {
            const isReload = performance.getEntriesByType('navigation')[0]?.type === 'reload';
            if (isReload) {
                if (!this.hasAlreadyLoggedOut) {
                    this.hasAlreadyLoggedOut = true;
                    this.retryCache.clear();
                    this.tokenStorageService.signOut();
                    this.notificationService.showError('Session expired', 'Please login again.');
                    this.router.navigate(['/sessions/signin'], {
                        queryParams: { type: 'reload' },
                    });
                }
                observer.error('Reload detected – forced logout');
                return;
            }
            this.retryCache.put(req.urlWithParams, (token) => {
                const clonedReq = req.clone({
                    headers: req.headers.set('Authorization', 'Bearer ' + token),
                });
                return next.handle(clonedReq);
            });
            this.sessionService.refreshToken().subscribe({
                next: (res) => {
                    this.tokenStorageService.saveToken(res?.accessToken);
                    this.retryCache?.getAll()?.forEach(callback => {
                        callback(res?.accessToken).subscribe({
                            next: (event) => observer.next(event),
                            error: (err) => observer.error(err),
                            complete: () => {
                                this.retryCache.clear();
                                observer.complete();
                            },
                        });
                    });
                },
                error: (err) => {
                    this.retryCache.clear();
                    observer.error(err);
                    this.notificationService.showError('Session refresh failed', 'Please login again.');
                    this.tokenStorageService.signOut();
                    this.router.navigate(['/sessions/signin'], {
                        queryParams: { type: 'auth' },
                    });
                },
            });
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ErrorNotifierService, deps: [{ token: TokenStorageService }, { token: i1$3.Router }, { token: ROUTING_STATE }, { token: NotificationService }, { token: i1$2.MatDialog }, { token: LoadingService }, { token: UserProfileService }, { token: RetryMapCache }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ErrorNotifierService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ErrorNotifierService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: TokenStorageService }, { type: i1$3.Router }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [ROUTING_STATE]
                }] }, { type: NotificationService }, { type: i1$2.MatDialog }, { type: LoadingService }, { type: UserProfileService }, { type: RetryMapCache }]; } });

class ApiCancellationInterceptor {
    constructor(router) {
        this.router = router;
        // It the subjects that trigges when route changes
        this.cancelRequest$ = new Subject();
        this.keepAliveUrl = ['ic-user/fetchUser', 'branch/currencyByBranch'];
        this.router.events.subscribe(event => {
            if (event instanceof NavigationStart) {
                this.cancelRequest$.next();
            }
        });
    }
    /**
     * This method is the implementation of http interceptor
     * Once the route changes the the existing api call of that particular screen cancelled
     * @param {HttpRequest<any>} req
     * @param {HttpHandler} next
     * @returns {Observable<HttpEvent<any>>}
     */
    intercept(req, next) {
        if (this.keepAliveUrl.some(url => req.url.includes(url))) {
            return next.handle(req);
        }
        return next.handle(req).pipe(takeUntil(this.cancelRequest$));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ApiCancellationInterceptor, deps: [{ token: i1$3.Router }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ApiCancellationInterceptor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ApiCancellationInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1$3.Router }]; } });

class RetryInterceptor {
    constructor() {
        this.maxRetries = 1;
        this.initialDelay = 1000;
    }
    intercept(req, next) {
        return next.handle(req).pipe(retryWhen(errors => errors.pipe(mergeMap((error, attempt) => {
            if (attempt >= this.maxRetries ||
                !(error instanceof HttpErrorResponse)) {
                return throwError(() => error); // Stop retrying after max retries or non-HTTP error
            }
            const retryDelay = this.initialDelay * Math.pow(2, attempt); // Exponential backoff formula
            console.warn(`Retrying request... Attempt ${attempt + 1}, waiting ${retryDelay}ms`);
            return new Observable(observer => {
                const timeoutId = setTimeout(() => observer.next(0), retryDelay);
                return () => clearTimeout(timeoutId);
            });
        }), take$1(this.maxRetries) // Limit the number of retries
        )));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RetryInterceptor, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RetryInterceptor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: RetryInterceptor, decorators: [{
            type: Injectable
        }] });

const InterceptorProviders = [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    {
        provide: HTTP_INTERCEPTORS,
        useClass: ApiCancellationInterceptor,
        multi: true,
    },
    { provide: HTTP_INTERCEPTORS, useClass: CachingInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoadingInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: RetryInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorNotifierService, multi: true },
];

class UtilsModule {
    static forRoot(env) {
        if (!env) {
            throw new Error('Environment must be provided');
        }
        return {
            ngModule: UtilsModule,
            providers: [
                { provide: ENVIRONMENT, useValue: env },
                ...InterceptorProviders,
            ],
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UtilsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: UtilsModule, imports: [CommonModule,
            PopoverModule,
            LibComponentsModule, i4.StoreRootModule, i1$1.EffectsRootModule], exports: [StoreModule, EffectsModule, PopoverModule, LibComponentsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UtilsModule, imports: [CommonModule,
            PopoverModule,
            LibComponentsModule,
            StoreModule.forRoot({
                userProfile: UserProfileReducer,
                localeData: LocaleDataReducer,
            }),
            EffectsModule.forRoot([UserProfileEffects, LocaleDataEffect]), StoreModule, EffectsModule, PopoverModule, LibComponentsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UtilsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PopoverModule,
                        LibComponentsModule,
                        StoreModule.forRoot({
                            userProfile: UserProfileReducer,
                            localeData: LocaleDataReducer,
                        }),
                        EffectsModule.forRoot([UserProfileEffects, LocaleDataEffect]),
                    ],
                    exports: [StoreModule, EffectsModule, PopoverModule, LibComponentsModule],
                }]
        }] });

/*
 * Public API Surface of utils
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApiCancellationInterceptor, ApiService, AuthInterceptor, BreadcrumbComponent, BrowseImageComponent, CachingInterceptor, ControlAsFormControlPipe, CoreDataService, CurrencySymbolPipe, CustomDateAdapter, DEFAULT_LOCALE, DateTimeService, DmsService, ENVIRONMENT, EncryptionService, ErrorNotifierService, FormArrayPipe, FormControlPipe, HeaderTabNavComponent, HeaderTopComponent, IdleTimeoutComponent, IdleTimeoutService, InterceptorProviders, LayoutService, LibComponentsModule, LibPipesModule, LoadingBarComponent, LoadingInterceptor, LoadingService, LocaleDataEffect, LocaleDataReducer, LocaleList, NewErrorPopupComponent, NotificationConstant, NotificationService, NotificationsComponent, PasswordSuccessComponent, PopoverDirective, PopoverModule, PopoverService, PopovercontainerComponent, ProfileComponent, ROUTING_STATE, RequestCache, RetryInterceptor, RoutePartsService, SafePipe, SecurityWarningPopupComponent, SessionStorageEnum, SignoutComponent, ThemeService, TokenStorageService, TransactionTypeEnum, UploadImage, UserLocaleDataAction, UserProfileAction, UserProfileEffects, UserProfileReducer, UserProfileService, UtilsModule, WorkflowAction, appendFilterParam, base64ToFile, cacheableEndpoints, deleteCookie, formatLocaleData, getCookie, getCurrencyLocale, getParameterByName, getQueryParam, initialLocalDataState, initialUserProfileState, isValidUrl, selectError, selectLoading, selectLocaleData, selectLocaleDataState, selectUser, selectUserProfileState, setCookie };
//# sourceMappingURL=onerumango-utils.mjs.map
