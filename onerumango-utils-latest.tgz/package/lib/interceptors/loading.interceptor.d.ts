import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoadingService } from '../services';
import * as i0 from "@angular/core";
export declare class LoadingInterceptor implements HttpInterceptor {
    private _loadingService;
    handleRequestsAutomatically: boolean;
    /**
     * Constructor
     */
    constructor(_loadingService: LoadingService);
    /**
     * Intercept
     *
     * @param req
     * @param next
     */
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoadingInterceptor>;
}
