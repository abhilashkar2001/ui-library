import { HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { LoadingService, NotificationService, TokenStorageService } from '../services';
import { IRoutingState } from '../types';
import { RetryMapCache } from '../services/retry-map';
import { UserProfileService } from '../store';
import * as i0 from "@angular/core";
export declare class ErrorNotifierService implements HttpInterceptor {
    private tokenStorageService;
    private router;
    private routingState;
    private notificationService;
    private dialog;
    private _loaderService;
    private sessionService;
    private retryCache;
    private hasAlreadyLoggedOut;
    constructor(tokenStorageService: TokenStorageService, router: Router, routingState: IRoutingState, notificationService: NotificationService, dialog: MatDialog, _loaderService: LoadingService, sessionService: UserProfileService, retryCache: RetryMapCache);
    intercept(request: HttpRequest<any>, next: HttpHandler): any;
    openCustomErrorDialog(errPayload?: any): void;
    openLockedDialog(type: any): void;
    private handleRequestMap;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorNotifierService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorNotifierService>;
}
