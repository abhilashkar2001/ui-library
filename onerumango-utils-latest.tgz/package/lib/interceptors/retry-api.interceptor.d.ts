import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class RetryInterceptor implements HttpInterceptor {
    private readonly maxRetries;
    private readonly initialDelay;
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RetryInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RetryInterceptor>;
}
