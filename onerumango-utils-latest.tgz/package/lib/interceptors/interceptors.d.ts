import { AuthInterceptor } from './auth.interceptor';
import { ApiCancellationInterceptor } from './api-cancellation.interceptor';
import { CachingInterceptor } from './browser-caching.interceptor';
import { LoadingInterceptor } from './loading.interceptor';
import { RetryInterceptor } from './retry-api.interceptor';
import { ErrorNotifierService } from './error-notifier.interceptor';
export declare const InterceptorProviders: ({
    provide: import("@angular/core").InjectionToken<import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof AuthInterceptor;
    multi: boolean;
} | {
    provide: import("@angular/core").InjectionToken<import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof ApiCancellationInterceptor;
    multi: boolean;
} | {
    provide: import("@angular/core").InjectionToken<import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof CachingInterceptor;
    multi: boolean;
} | {
    provide: import("@angular/core").InjectionToken<import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof LoadingInterceptor;
    multi: boolean;
} | {
    provide: import("@angular/core").InjectionToken<import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof RetryInterceptor;
    multi: boolean;
} | {
    provide: import("@angular/core").InjectionToken<import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof ErrorNotifierService;
    multi: boolean;
})[];
