import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RequestCache } from '../services';
import * as i0 from "@angular/core";
export declare class CachingInterceptor implements HttpInterceptor {
    private cache;
    constructor(cache: RequestCache);
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CachingInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CachingInterceptor>;
}
export declare const cacheableEndpoints: string[];
