import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class ApiCancellationInterceptor implements HttpInterceptor {
    private router;
    private cancelRequest$;
    private keepAliveUrl;
    constructor(router: Router);
    /**
     * This method is the implementation of http interceptor
     * Once the route changes the the existing api call of that particular screen cancelled
     * @param {HttpRequest<any>} req
     * @param {HttpHandler} next
     * @returns {Observable<HttpEvent<any>>}
     */
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApiCancellationInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApiCancellationInterceptor>;
}
