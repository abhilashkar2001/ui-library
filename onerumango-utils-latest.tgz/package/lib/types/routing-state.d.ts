export type IRoutingState = {
    getHistory: () => string[];
};
