export type CountryLocale = {
    country: string;
    locale: string;
};
export type CountryLocales = CountryLocale[];
