export type SafePipeType = 'html' | 'style' | 'script' | 'url' | 'resourceUrl';
