export type IEnvironment = {
    microServiceURL: string;
    SECRET_KEY: string;
    parentAppUrl: string;
    [key: string]: string | number | boolean | undefined;
};
