import { InjectionToken } from '@angular/core';
import { IEnvironment } from '../types';
export declare const ENVIRONMENT: InjectionToken<IEnvironment>;
