import { InjectionToken } from '@angular/core';
import { IRoutingState } from '../types';
export declare const ROUTING_STATE: InjectionToken<IRoutingState>;
