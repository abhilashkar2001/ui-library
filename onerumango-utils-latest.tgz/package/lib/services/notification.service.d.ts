import { ToastrService } from 'ngx-toastr';
import * as i0 from "@angular/core";
export declare class NotificationService {
    private toastr;
    constructor(toastr: ToastrService);
    showSuccess(message: any, title: any): void;
    showError(message: any, title: any): void;
    showInfo(message: any, title: any): void;
    showWarning(message: any, title: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotificationService>;
}
