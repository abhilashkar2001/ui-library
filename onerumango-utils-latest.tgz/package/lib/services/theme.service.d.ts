import { RendererFactory2, EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export interface ITheme {
    name: string;
    baseColor?: string;
    isActive?: boolean;
}
export declare class ThemeService {
    private document;
    onThemeChange: EventEmitter<ITheme>;
    egretThemes: ITheme[];
    activatedTheme: ITheme | undefined;
    private renderer;
    constructor(document: Document, rendererFactory: RendererFactory2);
    applyMatTheme(themeName: string): void;
    changeTheme(prevTheme: any, themeName: string): void;
    flipActiveFlag(themeName: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ThemeService>;
}
