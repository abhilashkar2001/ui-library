import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class LoadingService {
    private _auto$;
    private _mode$;
    private _progress$;
    private _show$;
    private _urlMap;
    /**
     * Constructor
     */
    /**
     * Getter for auto mode
     */
    get auto$(): Observable<boolean>;
    /**
     * Getter for mode
     */
    get mode$(): Observable<'determinate' | 'indeterminate'>;
    /**
     * Getter for progress
     */
    get progress$(): Observable<any>;
    /**
     * Getter for show
     */
    get show$(): Observable<boolean>;
    /**
     * Show the loading bar
     */
    show(): void;
    /**
     * Hide the loading bar
     */
    hide(): void;
    /**
     * Set the auto mode
     *
     * @param value
     */
    setAutoMode(value: boolean): void;
    /**
     * Set the mode
     *
     * @param value
     */
    setMode(value: 'determinate' | 'indeterminate'): void;
    /**
     * Set the progress of the bar manually
     *
     * @param value
     */
    setProgress(value: number): void;
    /**
     * Sets the loading status on the given url
     *
     * @param status
     * @param url
     */
    _setLoadingStatus(status: boolean, url: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoadingService>;
}
