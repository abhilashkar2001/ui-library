import { IEnvironment } from '../types';
import * as i0 from "@angular/core";
export declare class EncryptionService {
    private env;
    constructor(env: IEnvironment);
    encrypt: (value: string) => string;
    decrypt: (value: string) => string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EncryptionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EncryptionService>;
}
