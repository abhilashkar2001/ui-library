import { IEnvironment } from '../types';
import { HttpClient } from '@angular/common/http';
import * as i0 from "@angular/core";
export declare class ApiService {
    private env;
    private http;
    constructor(env: IEnvironment, http: HttpClient);
    getOpearatingBranch(userName: string): import("rxjs").Observable<any>;
    uploadDocument(formData: FormData): import("rxjs").Observable<any>;
    updateProfileImage(payload: {
        userId: any;
        documentId: any;
    }): import("rxjs").Observable<any>;
    getGenericValueLanguage(_screenNameVal: any): import("rxjs").Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApiService>;
}
