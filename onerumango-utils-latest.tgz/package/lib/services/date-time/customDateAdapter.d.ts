import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateTimeService } from './date-time.service';
import * as moment from 'moment';
import * as i0 from "@angular/core";
export declare class CustomDateAdapter extends MomentDateAdapter {
    private _dateTimeService;
    constructor(_dateTimeService: DateTimeService);
    format(date: moment.Moment): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomDateAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomDateAdapter>;
}
