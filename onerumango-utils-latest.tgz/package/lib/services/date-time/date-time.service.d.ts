import { Store } from '@ngrx/store';
import { AppState } from '../../store';
import * as i0 from "@angular/core";
export declare class DateTimeService {
    private store;
    currentLocal: import("../../store").LocaleData;
    _format: string;
    _locale: string;
    constructor(store: Store<AppState>);
    init(opt: any): void;
    get format(): string;
    set format(value: string);
    get locale(): string;
    set locale(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<DateTimeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DateTimeService>;
}
