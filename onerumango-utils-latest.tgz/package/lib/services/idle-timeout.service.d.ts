import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { IdleTimeoutComponent } from '../components';
import { Router } from '@angular/router';
import { TokenStorageService } from './token-storage.service';
import * as i0 from "@angular/core";
export declare class IdleTimeoutService {
    private router;
    private matDialog;
    private tokenStorageService;
    idleDialogRef: MatDialogRef<IdleTimeoutComponent> | undefined;
    private idleTimeout;
    private idleDuration;
    private warningTimeout;
    private warningDuration;
    private sessionTimeout;
    private sessionExpiryDuration;
    private sessionStartTime;
    constructor(router: Router, matDialog: MatDialog, tokenStorageService: TokenStorageService);
    getElapsedSessionTime(): number;
    clearTimeOut(): void;
    private startWatching;
    private logout;
    private startSession;
    private resetTimer;
    private startWarningCountdown;
    private hideWarning;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdleTimeoutService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IdleTimeoutService>;
}
