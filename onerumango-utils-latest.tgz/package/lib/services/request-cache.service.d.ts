import { HttpRequest, HttpResponse } from '@angular/common/http';
import * as i0 from "@angular/core";
export declare class RequestCache {
    cache$: Map<string, HttpResponse<any>>;
    get(req: HttpRequest<any>): HttpResponse<any> | undefined;
    put(req: HttpRequest<any>, response: HttpResponse<any>): void;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestCache, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RequestCache>;
}
