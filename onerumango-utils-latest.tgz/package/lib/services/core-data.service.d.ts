import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class CoreDataService {
    private lang;
    private hideNavItem;
    private profileImage;
    private menuChildrens;
    private menuRef;
    private mainMenuStatus;
    setlanguageVal(value: any): void;
    setIsHideItem(value: any): void;
    getIsHideItem(): Observable<any>;
    sendProfileImage(profileImage: string): void;
    getProfileImage(): Observable<string>;
    sendMenRef(id: any): void;
    getMenuRef: Observable<any>;
    sendActiveTabMenuChildren(data: any): void;
    getMenuChildrens: Observable<any>;
    getMainMenuStatus: Observable<any>;
    sendMainMenuStatus(data: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreDataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreDataService>;
}
