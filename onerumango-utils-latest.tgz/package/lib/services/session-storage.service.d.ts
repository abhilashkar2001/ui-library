import { EncryptionService } from './encryption.service';
import * as i0 from "@angular/core";
export declare class SessionStorageService {
    private readonly encryptionService;
    constructor(encryptionService: EncryptionService);
    /**
     * stringify the item and stored
     * @param key
     * @param value
     */
    setItemInSession: (key: string, value: any) => void;
    /**
     * It will parsed the item and give you, that is stored in session storage
     * @param key of the item to be stored in session storage
     * @returns retun parsed object
     */
    getItemFromSession: (key: string) => any;
    removeItem(key: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SessionStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SessionStorageService>;
}
