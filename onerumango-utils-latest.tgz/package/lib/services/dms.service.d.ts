import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IEnvironment } from '../types';
import { FileModel } from '../models';
import * as i0 from "@angular/core";
export declare class DmsService {
    private httpClient;
    private basePath;
    constructor(httpClient: HttpClient, env: IEnvironment);
    /**
     * Uploads a file to the server using the provided FormData object.
     *
     * @param {FormData} formData - An instance of FormData containing the file to be uploaded.
     * @return {Observable<any>} An Observable that emits the server response upon successful upload.
     */
    uploadDocuments(formData: FormData): Observable<FileModel>;
    uploadSignaturewithEvent(payload: FormData): Observable<import("@angular/common/http").HttpEvent<Object>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DmsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DmsService>;
}
