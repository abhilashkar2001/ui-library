import { ActivatedRouteSnapshot, Params } from '@angular/router';
import * as i0 from "@angular/core";
interface IRoutePart {
    title: string;
    breadcrumb: string;
    params?: Params;
    url: string;
    urlSegments: any[];
}
export declare class RoutePartsService {
    routeParts: IRoutePart[];
    generateRouteParts(snapshot: ActivatedRouteSnapshot): IRoutePart[];
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutePartsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoutePartsService>;
}
export {};
