import { HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class RetryMapCache {
    private retryMap;
    get(request: HttpRequest<any>): ((token: string) => Observable<HttpEvent<any>>) | undefined;
    put(key: string, req: (token: string) => Observable<HttpEvent<any>>): void;
    getAll(): ((token: string) => Observable<HttpEvent<any>>)[];
    clear(): void;
    delete(key: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RetryMapCache, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RetryMapCache>;
}
