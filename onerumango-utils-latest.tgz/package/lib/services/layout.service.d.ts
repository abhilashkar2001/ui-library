import { BehaviorSubject } from 'rxjs';
import { ThemeService } from './theme.service';
import * as i0 from "@angular/core";
export interface ILayoutConf {
    navigationPos?: string;
    sidebarStyle?: string;
    sidebarCompactToggle?: boolean;
    sidebarColor?: string;
    dir?: string;
    isMobile?: boolean;
    useBreadcrumb?: boolean;
    breadcrumb?: string;
    topbarFixed?: boolean;
    footerFixed?: boolean;
    topbarColor?: string;
    footerColor?: string;
    matTheme?: string;
    perfectScrollbar?: boolean;
}
export interface ILayoutChangeOptions {
    duration?: number;
    transitionClass?: boolean;
}
interface IAdjustScreenOptions {
    browserEvent?: any;
    route?: string;
}
export declare class LayoutService {
    private themeService;
    layoutConf: ILayoutConf;
    layoutConfSubject: BehaviorSubject<ILayoutConf>;
    layoutConf$: import("rxjs").Observable<ILayoutConf>;
    isMobile: boolean;
    currentRoute: string;
    fullWidthRoutes: never[];
    constructor(themeService: ThemeService);
    setAppLayout(layoutConf: ILayoutConf): void;
    publishLayoutChange(lc: ILayoutConf): void;
    applyMatTheme(): void;
    setLayoutFromQuery(): void;
    adjustLayout(options?: IAdjustScreenOptions): void;
    isSm(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LayoutService>;
}
export {};
