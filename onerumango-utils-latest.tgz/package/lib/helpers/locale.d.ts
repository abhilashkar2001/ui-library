import { LocaleData } from '../store';
export declare function formatLocaleData(data: LocaleData): LocaleData;
export declare function getCurrencyLocale(country: string): string | undefined;
