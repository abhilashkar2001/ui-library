/**
 * set the cokkie in cookie storeage in browser
 * @param name of the cookie
 * @param value of the cookie to set
 * @param expiresIn expiry time of the cookie
 */
export declare const setCookie: (name: string, value: any, expiresIn: number) => void;
/**
 * get the value of a cookie from it's name
 * @param name of the cookie which value is required
 * @returns value of the cookie
 */
export declare const getCookie: (name: string) => string | null | undefined;
/**
 * Set the expiry date of cookie to it's past date it will remove automatically
 * @param name cookie name to be deleted
 */
export declare const deleteCookie: (name: string) => void;
