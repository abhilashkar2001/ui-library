/**
 * find the value of the param passed in route while change one location to another location in window
 * @param name name of the parameter
 * @param url url of the location of href
 * @returns the value of the particular parameter
 */
export declare function getParameterByName(name: string, url?: string): string | null;
export declare function getQueryParam(prop: any): string | {
    [key: string]: string;
} | undefined;
export declare function isValidUrl(url: string): boolean;
