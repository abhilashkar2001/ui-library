export declare function base64ToFile(dataurl: any, filename: any): File;
