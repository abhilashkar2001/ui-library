import { HttpParams } from '@angular/common/http';
type ParamValue = string | number | boolean | null | undefined | ParamValue[] | {
    [key: string]: any;
};
export declare function appendFilterParam(paramsObj: {
    [key: string]: ParamValue;
}): HttpParams;
export {};
