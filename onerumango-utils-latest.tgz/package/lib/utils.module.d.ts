import { ModuleWithProviders } from '@angular/core';
import { IEnvironment } from './types';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "./popover/popover.module";
import * as i3 from "./components/lib-component.module";
import * as i4 from "@ngrx/store";
import * as i5 from "@ngrx/effects";
export declare class UtilsModule {
    static forRoot(env: IEnvironment): ModuleWithProviders<UtilsModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UtilsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UtilsModule, never, [typeof i1.CommonModule, typeof i2.PopoverModule, typeof i3.LibComponentsModule, typeof i4.StoreRootModule, typeof i5.EffectsRootModule], [typeof i4.StoreModule, typeof i5.EffectsModule, typeof i2.PopoverModule, typeof i3.LibComponentsModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UtilsModule>;
}
