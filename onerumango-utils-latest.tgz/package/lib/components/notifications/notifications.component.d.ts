import { ChangeDetectorRef, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { CoreDataService } from '../../services';
import * as i0 from "@angular/core";
export declare class NotificationsComponent implements OnInit {
    private router;
    private shareDataService;
    private cdr;
    notificPanel: any;
    mainMenuPanel: any;
    searchValue: FormControl<any>;
    expandDropdown: boolean;
    flag: boolean;
    notifications: never[];
    menuItems: any;
    url: any;
    isTeller: boolean;
    hasMainMenu: any;
    constructor(router: Router, shareDataService: CoreDataService, cdr: ChangeDetectorRef);
    ngOnInit(): void;
    getMaintenanceMenuItem(): ({
        name: string;
        type: string;
        tooltip: string;
        icon: string;
        state: string;
        sub?: undefined;
    } | {
        type: string;
        name: string;
        tooltip?: undefined;
        icon?: undefined;
        state?: undefined;
        sub?: undefined;
    } | {
        name: string;
        type: string;
        tooltip: string;
        icon: string;
        state: string;
        sub: ({
            name: string;
            url: string;
            type: string;
            state: string;
            sub?: undefined;
        } | {
            name: string;
            type: string;
            sub: {
                name: string;
                url: string;
                type: string;
                state: string;
            }[];
            url?: undefined;
            state?: undefined;
        })[];
    })[];
    getReportMenuItem(): ({
        name: string;
        type: string;
        tooltip: string;
        icon: string;
        state: string;
        sub?: undefined;
    } | {
        name: string;
        type: string;
        tooltip: string;
        icon: string;
        state: string;
        sub: {
            name: string;
            type: string;
            state: string;
            avatar: string;
            content: string;
        }[];
    })[];
    routeChange(item: any): void;
    expandOnClick: () => boolean;
    onSearch(event: any): void;
    close(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationsComponent, "ic-notifications", never, { "notificPanel": { "alias": "notificPanel"; "required": false; }; "mainMenuPanel": { "alias": "mainMenuPanel"; "required": false; }; }, {}, never, never, false, never>;
}
