export declare class NotificationConstant {
    static readonly SIDENAV_MAINTENANCE_ITEMS: ({
        name: string;
        type: string;
        tooltip: string;
        icon: string;
        state: string;
        sub?: undefined;
    } | {
        type: string;
        name: string;
        tooltip?: undefined;
        icon?: undefined;
        state?: undefined;
        sub?: undefined;
    } | {
        name: string;
        type: string;
        tooltip: string;
        icon: string;
        state: string;
        sub: ({
            name: string;
            url: string;
            type: string;
            state: string;
            sub?: undefined;
        } | {
            name: string;
            type: string;
            sub: {
                name: string;
                url: string;
                type: string;
                state: string;
            }[];
            url?: undefined;
            state?: undefined;
        })[];
    })[];
    static readonly SIDENAV_REPORT_ITEMS: ({
        name: string;
        type: string;
        tooltip: string;
        icon: string;
        state: string;
        sub?: undefined;
    } | {
        name: string;
        type: string;
        tooltip: string;
        icon: string;
        state: string;
        sub: {
            name: string;
            type: string;
            state: string;
            avatar: string;
            content: string;
        }[];
    })[];
}
