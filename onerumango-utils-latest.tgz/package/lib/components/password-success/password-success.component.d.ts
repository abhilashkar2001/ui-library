import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { TokenStorageService } from '../../services';
import * as i0 from "@angular/core";
export declare class PasswordSuccessComponent {
    dialogRef: MatDialogRef<PasswordSuccessComponent>;
    private router;
    tokenStorageService: TokenStorageService;
    data: any;
    value: any;
    constructor(dialogRef: MatDialogRef<PasswordSuccessComponent>, router: Router, tokenStorageService: TokenStorageService, data: any);
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordSuccessComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PasswordSuccessComponent, "ic-password-success", never, { "value": { "alias": "value"; "required": false; }; }, {}, never, never, false, never>;
}
