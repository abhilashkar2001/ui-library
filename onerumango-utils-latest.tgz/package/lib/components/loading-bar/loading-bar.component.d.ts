import { OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { LoadingService } from '../../services';
import * as i0 from "@angular/core";
export declare class LoadingBarComponent implements OnChanges, OnInit, OnDestroy {
    private _loadingService;
    autoMode: boolean;
    mode: 'determinate' | 'indeterminate';
    progress: number;
    show: boolean;
    private _unsubscribeAll;
    /**
     * Constructor
     */
    constructor(_loadingService: LoadingService);
    /**
     * On changes
     *
     * @param changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * On init
     */
    ngOnInit(): void;
    /**
     * On destroy
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoadingBarComponent, "ic-loading-bar", never, { "autoMode": { "alias": "autoMode"; "required": false; }; }, {}, never, never, false, never>;
}
