import { ChangeDetectorRef, ElementRef, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { User } from '../../store';
import { CoreDataService } from '../../services';
import * as i0 from "@angular/core";
export interface TabItem {
    label: string;
    route: string;
    menus: any[];
}
export declare class HeaderTabNavComponent implements OnInit {
    private cdr;
    private shareDataService;
    private router;
    private store;
    menuElement: ElementRef;
    sticky: boolean;
    elementPosition: any;
    showMenu: boolean;
    tabs: TabItem[];
    event$: any;
    hideNavItem: boolean;
    showTabs: boolean;
    currentUser: any;
    profileInfo$: Observable<User> | undefined;
    constructor(cdr: ChangeDetectorRef, shareDataService: CoreDataService, router: Router, store: Store);
    ngOnInit(): void;
    /**
     * Pluck latest active tab childrens from current context
     * @method pluckActiveTabsFromRoles():void
     * @param isRefresh
     * @param roles
     */
    pluckActiveTabsFromRoles(isRefresh: any, roles: any): void;
    getActiveTabMenus(data: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderTabNavComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeaderTabNavComponent, "ic-header-tab-nav", never, { "showMenu": { "alias": "showMenu"; "required": false; }; }, {}, never, never, false, never>;
}
