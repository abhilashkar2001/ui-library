import { OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
export declare class NewErrorPopupComponent implements OnInit {
    data: any;
    private dialogRef;
    errorDetails: any;
    imageUrl: any;
    constructor(data: any, dialogRef: MatDialogRef<NewErrorPopupComponent>);
    ngOnInit(): void;
    errorImage(code: number): "400-error" | "401-error" | "403-error" | "404-not-found" | "500-error" | "501-error" | "503-error" | "504-error" | "505-error";
    back(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NewErrorPopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NewErrorPopupComponent, "ic-new-error-popup", never, {}, {}, never, never, false, never>;
}
