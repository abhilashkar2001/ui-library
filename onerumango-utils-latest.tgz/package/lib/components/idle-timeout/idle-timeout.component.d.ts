import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class IdleTimeoutComponent implements OnInit {
    private data;
    warningCountdown: number | null | undefined;
    time: number;
    constructor(data: {
        warningCountdown: number;
    });
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdleTimeoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IdleTimeoutComponent, "ic-idle-timeout", never, {}, {}, never, never, false, never>;
}
