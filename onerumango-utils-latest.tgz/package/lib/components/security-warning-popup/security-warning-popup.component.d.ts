import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
export declare class SecurityWarningPopupComponent {
    private dialogRef;
    constructor(dialogRef: MatDialogRef<SecurityWarningPopupComponent>);
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SecurityWarningPopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SecurityWarningPopupComponent, "ic-security-warning-popup", never, {}, {}, never, never, false, never>;
}
