import { OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LayoutService, RoutePartsService } from '../../services';
import * as i0 from "@angular/core";
export declare class BreadcrumbComponent implements OnDestroy {
    private router;
    private routePartsService;
    private activeRoute;
    layout: LayoutService;
    isStatic: boolean;
    staticNavs: any;
    routeParts: any[];
    routerEventSub: Subscription;
    constructor(router: Router, routePartsService: RoutePartsService, activeRoute: ActivatedRoute, layout: LayoutService);
    ngOnDestroy(): void;
    parseText(part: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbComponent, "ic-breadcrumb", never, { "isStatic": { "alias": "isStatic"; "required": false; }; "staticNavs": { "alias": "staticNavs"; "required": false; }; }, {}, never, never, false, never>;
}
