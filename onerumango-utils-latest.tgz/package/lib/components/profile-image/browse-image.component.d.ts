import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { SafeResourceUrl } from '@angular/platform-browser';
import { UploadImage } from '../../enums';
import { IEnvironment } from '../../types';
import * as i0 from "@angular/core";
export declare class BrowseImageComponent implements OnChanges {
    private env;
    action: string;
    image: string | any;
    isEdit: boolean;
    readorWrite: boolean;
    fallBackImage: any;
    menuIcon: string;
    deleted: EventEmitter<any>;
    filePreview: any;
    ACTION_NAME: typeof UploadImage;
    private readonly basePath;
    constructor(env: IEnvironment);
    ngOnChanges(changes: SimpleChanges): void;
    checkImage(): boolean;
    deleteImage(): void;
    getParsedUrl(path: any): SafeResourceUrl;
    getFileUrl(filePath: string): SafeResourceUrl;
    getAssetsUrl(filePath: string): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrowseImageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BrowseImageComponent, "ic-browse-image", never, { "action": { "alias": "action"; "required": false; }; "image": { "alias": "image"; "required": false; }; "isEdit": { "alias": "isEdit"; "required": false; }; "readorWrite": { "alias": "readorWrite"; "required": false; }; "fallBackImage": { "alias": "fallBackImage"; "required": false; }; "menuIcon": { "alias": "menuIcon"; "required": false; }; }, { "deleted": "deleted"; }, never, never, false, never>;
}
