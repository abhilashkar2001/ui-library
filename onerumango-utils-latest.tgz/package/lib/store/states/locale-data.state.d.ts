import { LocaleData } from '../models';
export interface LocaleDataState {
    localeData: LocaleData | null;
    loading: boolean;
    error: Error | null;
}
export declare const initialLocalDataState: LocaleDataState;
