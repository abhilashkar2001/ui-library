import { User } from '../models';
export interface UserProfileState {
    user: User | null;
    loading: boolean;
    error: Error | null;
}
export declare const initialUserProfileState: UserProfileState;
