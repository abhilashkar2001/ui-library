import { UserProfileState } from './user-profile.state';
import { LocaleDataState } from './locale-data.state';
export interface AppState {
    userProfile: UserProfileState;
    localeData: LocaleDataState;
}
