import { HttpClient } from '@angular/common/http';
import { IEnvironment } from '../../types';
import { IcHttpResponseModel } from '../../models';
import { LocaleData } from '../models';
import * as i0 from "@angular/core";
export declare class LocaleDataService {
    private http;
    private env;
    constructor(http: HttpClient, env: IEnvironment);
    loadLocaleData(branchCode: string | undefined): import("rxjs").Observable<IcHttpResponseModel<LocaleData>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocaleDataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LocaleDataService>;
}
