import { HttpClient } from '@angular/common/http';
import { User } from '../models';
import { IEnvironment } from '../../types';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class UserProfileService {
    private http;
    private env;
    constructor(http: HttpClient, env: IEnvironment);
    /**
     * Post-sign in call this api to fetch the logged-in user profile info
     * @returns {Observable<User>} profile info observable of the logged-in user
     */
    loadUserProfile(): Observable<User>;
    /**
     * This method is used to refresh the authentication token.
     * */
    refreshToken(): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserProfileService>;
}
