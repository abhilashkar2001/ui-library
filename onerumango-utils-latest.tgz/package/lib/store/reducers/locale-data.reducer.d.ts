export declare const LocaleDataReducer: import("@ngrx/store").ActionReducer<import("../states").LocaleDataState, import("@ngrx/store").Action>;
