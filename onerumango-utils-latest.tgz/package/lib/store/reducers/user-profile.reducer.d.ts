import { UserProfileState } from '../states';
export declare const UserProfileReducer: import("@ngrx/store").ActionReducer<UserProfileState, import("@ngrx/store").Action>;
