import { Actions } from '@ngrx/effects';
import { LocaleDataService } from '../services/locale-data.service';
import { LocaleData } from '../models';
import * as i0 from "@angular/core";
export declare class LocaleDataEffect {
    private actions$;
    private localeDataService;
    constructor(actions$: Actions, localeDataService: LocaleDataService);
    loadLocaleData$: import("rxjs").Observable<({
        localeData: LocaleData | null;
    } & import("@ngrx/store/src/models").TypedAction<"[Sign In] Load Locale Data Success">) | ({
        error: Error | null;
    } & import("@ngrx/store/src/models").TypedAction<"[Sign In] Load Locale Data Failure">)> & import("@ngrx/effects").CreateEffectMetadata;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocaleDataEffect, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LocaleDataEffect>;
}
