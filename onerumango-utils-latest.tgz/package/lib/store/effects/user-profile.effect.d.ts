import { Actions } from '@ngrx/effects';
import { UserProfileService } from '../services';
import { User } from '../models';
import * as i0 from "@angular/core";
export declare class UserProfileEffects {
    private actions$;
    private userProfileService;
    constructor(actions$: Actions, userProfileService: UserProfileService);
    loadUserProfile$: import("rxjs").Observable<({
        user: User | null;
    } & import("@ngrx/store/src/models").TypedAction<"[Sign In] Load User Profile Success">) | ({
        error: Error | null;
    } & import("@ngrx/store/src/models").TypedAction<"[Sign In] Load User Profile Failure">)> & import("@ngrx/effects").CreateEffectMetadata;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileEffects, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserProfileEffects>;
}
