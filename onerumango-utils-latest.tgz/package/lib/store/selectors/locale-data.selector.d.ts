import { LocaleDataState } from '../states';
export declare const selectLocaleDataState: import("@ngrx/store").MemoizedSelector<object, LocaleDataState, import("@ngrx/store").DefaultProjectorFn<LocaleDataState>>;
export declare const selectLocaleData: import("@ngrx/store").MemoizedSelector<object, import("@onerumango/utils").LocaleData | null, (s1: LocaleDataState) => import("@onerumango/utils").LocaleData | null>;
