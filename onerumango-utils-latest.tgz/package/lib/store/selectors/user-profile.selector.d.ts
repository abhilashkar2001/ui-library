import { UserProfileState } from '../states';
export declare const selectUserProfileState: import("@ngrx/store").MemoizedSelector<object, UserProfileState, import("@ngrx/store").DefaultProjectorFn<UserProfileState>>;
export declare const selectUser: import("@ngrx/store").MemoizedSelector<object, import("@onerumango/utils").User | null, (s1: UserProfileState) => import("@onerumango/utils").User | null>;
export declare const selectLoading: import("@ngrx/store").MemoizedSelector<object, boolean, (s1: UserProfileState) => boolean>;
export declare const selectError: import("@ngrx/store").MemoizedSelector<object, Error | null, (s1: UserProfileState) => Error | null>;
