export interface User {
    using2FA: boolean;
    userId: number;
    username: string;
    firstName: string;
    lastName: string;
    email: string;
    enabled: boolean;
    notifyPasswordExpiryInDays: number;
    intime: string;
    outtime: string;
    firstTimeLogin: boolean;
    currencyCode: string;
    currencyName: string;
    currencyId: number;
    passwordGenerationType: string;
    otp: boolean;
    googleAuth: boolean;
    mobile: string;
    entityId: number;
    entityCode: string;
    entityName: string;
    bankId: number;
    bankCode: string;
    bankName: string;
    branchId: number;
    branch: string;
    branchName: string;
    language: string;
    roles: Role[];
    biometricIdList: any[];
    isdCode: string;
    lastUpdatedBy: string;
    recordStatus: string;
    authStatus: string;
    oneTimeAuth: string;
    empId: string;
    operatingBranchCode: boolean;
    department: string;
}
export interface Role {
    roleDescription: string;
    processCycleList: ProcessCycleList[];
    refRoleId: number;
    screens: Screen[];
    action: string;
    authBy: string;
    authStatus: string;
    authorizedDate: string;
    corpDescription: string | null;
    created: string;
    createdBy: string;
    dealerAdmin: boolean;
    description: string;
    empId: string;
    id: number;
    lastUpdated: string;
    lastUpdatedBy: string;
    oneTimeAuth: string;
    recordStatus: string;
    roleId: number;
    roleName: string;
    status: boolean;
    userType: string | null;
    version: number;
    ischecked?: boolean;
}
export interface ProcessCycleList {
    created: string;
    createdBy: string;
    lastUpdated: string;
    lastUpdatedBy: string;
    authBy: string;
    authorizedDate: string;
    recordStatus: string;
    authStatus: string;
    oneTimeAuth: string;
    version: number;
    revisionNumber: number;
    revisionTimestamp: string;
    id: number;
    processCycleCode: string;
    processCycleName: string;
    processCycleSequenceList: ProcessCycleSequenceList[];
}
export interface ProcessCycleSequenceList {
    created: string;
    createdBy: string;
    lastUpdated: string;
    lastUpdatedBy: string;
    authBy: string;
    authorizedDate: string;
    recordStatus: string;
    authStatus: string;
    oneTimeAuth: string;
    version: number;
    revisionNumber: number;
    revisionTimestamp: string;
    id: number;
    sequence: number;
    processStage: ProcessStage;
}
export interface ProcessStage {
    created: string;
    createdBy: string;
    lastUpdated: string;
    lastUpdatedBy: string;
    authBy: string;
    authorizedDate: string;
    recordStatus: string;
    authStatus: string;
    oneTimeAuth: string;
    version: number;
    revisionNumber: number;
    revisionTimestamp: string;
    id: number;
    processCode: string;
    processName: string;
    menuIcon: string;
    dataInputSequence: DataInputSequence[];
}
export interface DataInputSequence {
    id: number;
    sequence: number;
    qualified: boolean;
    checklist: Checklist;
    icScreen: IcScreen;
}
export interface Checklist {
    created: string;
    createdBy: string;
    lastUpdated: string;
    lastUpdatedBy: string;
    authBy: string;
    authorizedDate: string;
    recordStatus: string;
    authStatus: string;
    oneTimeAuth: string;
    version: number;
    revisionNumber: number;
    revisionTimestamp: string;
    id: number;
    checklistCode: string;
    checklistDesc: string;
    checklistSequences: ChecklistSequence[];
}
export interface ChecklistSequence {
    created: string;
    createdBy: string;
    lastUpdated: string;
    lastUpdatedBy: string;
    authBy: string;
    authorizedDate: string;
    recordStatus: string;
    authStatus: string;
    oneTimeAuth: string;
    version: number;
    revisionNumber: number;
    revisionTimestamp: string;
    id: number;
    seq: number;
    document: string;
    summary: string;
    mandatoryForNxtStg: boolean;
    mandatoryForApproval: boolean;
    docRequired: boolean;
    documentTypes: string;
}
export interface IcScreen {
    created: string;
    createdBy: string;
    lastUpdated: string;
    lastUpdatedBy: string;
    authBy: string;
    authorizedDate: string;
    recordStatus: string;
    authStatus: string;
    oneTimeAuth: string;
    version: number;
    revisionNumber: number;
    revisionTimestamp: string;
    screenCode: number;
    screenName: string;
    route: string;
    linkType: string;
    language: string;
    profile: Profile;
    description: string;
    menuIcon: string;
    menu: boolean;
}
export interface Profile {
    documentId: number;
    documentName: string;
    documentType: string;
    fileName: string;
    fileType: string;
    documentSide: number;
    verificationType: string;
    fileUrl: string;
    documentNumber: string;
    passportNumber: string;
    issueDate: string;
    expiryDate: string;
    dob: string;
    phoneNumber: string;
}
export interface Screen {
    screenCode: number;
    screenName: string;
    route: string;
    isMenu: boolean;
    linkType: string;
    privileges: Privilege[];
    children: Screen[];
    menuIcon: string;
    description: string;
}
export interface Privilege {
    id: number;
    name: string;
}
export interface Biometric {
    biometricType?: string;
    biometricId: string;
    fileUrl?: string;
    fpTemplateBase64?: string;
}
export interface BankInfo {
    action: string;
    afterTimeHour: number;
    afterTimeMin: number;
    afterTimeSec: number;
    authBy: string;
    authStatus: string;
    authorizedDate: string;
    bankCode: string;
    bankName: string;
    beforeTimeHour: number;
    beforeTimeMin: number;
    beforeTimeSec: number;
    contact: Contact;
    address: Address[];
    altCode: string;
    alternativeNumber: string;
    contactId: number;
    email: string;
    fax: string | null;
    mobile: string;
    mobtCode: string;
    officePhone: string | null;
    residencePhone: string | null;
    telephone: string | null;
    waptCode: string;
    whatsappNo: string;
    country: string;
    countryTelIsdCode: number;
    created: string;
    createdBy: string;
    dateFormat: string | null;
    dateFormatValue: string | null;
    denomRequired: boolean;
    empId: string;
    entityCode: string;
    entityId: number;
    headOfficeBranch: string;
    id: number;
    lastUpdated: string;
    lastUpdatedBy: string;
    minorAge: number;
    oneTimeAuth: string;
    recordStatus: string;
    referenceFormat: [];
    swiftCode: string;
    version: number;
}
export interface Address {
    address1: string;
    address2: string;
    addressId: number;
    addressType: string | null;
    city: string;
    cityId: number;
    country: string;
    pincode: string;
    residenceType: string | null;
    residenceTypeValue: string | null;
    state: string;
}
export interface Contact {
    address?: Address[] | undefined;
    altCode: string;
    alternativeNumber: string;
    contactId: number;
    email: string;
    fax: string | null;
    mobile: string;
    mobtCode: string;
    officePhone: string | null;
    residencePhone: string | null;
    telephone: string | null;
    waptCode: string;
    whatsappNo: string;
    country: string;
    countryTelIsdCode: number;
}
export interface UserLevelDetails {
    statusCode: number;
    status: string;
    data: UserLevel[];
    message: string;
    meta: number;
}
export interface UserLevel {
    action: string;
    authBy: string;
    authStatus: string;
    authorizedDate: string;
    bankCode: string;
    bankId: number;
    created: string;
    createdBy: string;
    empId: string;
    entityCode: string;
    id: number;
    lastUpdated: string;
    lastUpdatedBy: string;
    levelCode: string;
    levelDesc: string;
    oneTimeAuth: string;
    recordStatus: string;
    version: number;
}
export interface OperationModel {
    operation: string;
}
export interface CustomerOperationsResponse {
    statusCode: number;
    status: string;
    data: CustomerOperationModel;
    message: string;
}
export interface CustomerOperationModel {
    authBy: string;
    authStatus: string;
    authorizedDate: string;
    cbsRefNo: string | null;
    created: string;
    createdBy: string;
    lastUpdated: string;
    lastUpdatedBy: string;
    oneTimeAuth: string;
    recordStatus: string;
    referenceNo: string | null;
    version: number;
}
export interface DeleteResponseModel {
    data: number | null;
    error: string | null;
    message: string;
    status: number;
    trace: string | null;
}
export interface UserPaylod {
    username: string;
    firstName: string;
    lastName: string;
    entityCode: string;
    googleAuth: boolean;
    otp: boolean;
    documentId: number | null;
    bankCode: string;
    branch: string;
    email: string;
    mobile: string;
    department: string;
    reportingManagerId: number | null;
    roleIds: number[];
    levelForUser: string;
    tillId: number | null;
    agentId: string | null;
    passwordGenerationType: string;
    statusForUser: boolean;
    isOperatingBranchCode: boolean;
    allowedOrNotallowedBranches: BankInfo[];
    language: string;
    password: string | null;
    empId: string | number | null;
    isLDAPEnabled: boolean;
    isdCode: number | string;
    intime: string;
    outtime: string;
    userId: number;
    biometricIds: Biometric[];
    userRole?: string;
    roles?: Role;
    using2FA?: string;
    encryptedPassword?: string;
    enabled?: boolean;
    operatingBranchCode?: string;
    biometricIdList?: Biometric[];
    userType: string;
    branchId: number;
}
export interface PasswordStrengthTooltip {
    message: string;
    isValid: boolean;
}
export interface Till {
    id: number;
    name: string;
    description?: string;
    createdAt?: string;
    updatedAt?: string;
}
export interface VerificationTypeModel {
    name: string;
    checked: boolean;
    isUserChecked?: boolean;
    id?: number;
}
export interface ReportingUser {
    action: string;
    agentId: string | null;
    allowedOrNotallowedBranches: BankInfo[];
    authBy: string;
    authStatus: string;
    authorizedDate: string;
    bankCode: string;
    branchCode: string;
    contact: string | null;
    created: string;
    createdBy: string;
    department: string;
    disableUser: boolean | null;
    emailNotification: boolean | null;
    empId: string;
    encryptedPassword: string | null;
    entityCode: string;
    failLgnCounter: number;
    failedAttempts: number;
    finance: string | null;
    firstName: string;
    firstTimeLogin: string;
    id: number;
    intime: string;
    isPushNotificationRequired: boolean | null;
    language: string;
    lastName: string;
    lastUpdated: string;
    lastUpdatedBy: string;
    ldapUserId: string | null;
    levelForUser: string;
    logoutTime: string | null;
    oneTimeAuth: string;
    operatingBranchCode: boolean;
    outtime: string;
    passwordAge: number;
    passwordGenerationType: string;
    profile: string | null;
    pwdChangeDate: string | null;
    recordStatus: string;
    roleName: string;
    screenThemeSelected: string | null;
    smsNotification: boolean | null;
    statusForUser: boolean;
    tillId: string | null;
    userId: number;
    userName: string;
    userRole: string | null;
    userType: string | null;
    version: number;
    quantitativeId?: number;
    qualitativeScoreId?: number;
    screenCode?: number;
}
export interface SecurityQuestionModel {
    id: number;
    userId?: number | null;
    securityQuestion: number;
    securityQuestionValue: string;
    securityAnswer: string;
    dealerUserId?: number | null;
    masked?: boolean;
}
export interface AuditLogModel {
    allowedOrNotallowedBranches: BankInfo[];
    authBy: string;
    authStatus: string;
    bankCode: string;
    bankId: number;
    bankName: string;
    biometricIdList: Biometric[];
    branchCode: string;
    branchId: number;
    counterNumber: string;
    denomRequired: boolean;
    department: string;
    email: string;
    enabled: boolean;
    entityCode: string;
    firstName: string;
    firstTimeLogin: string;
    googleAuth: boolean;
    icSecurityQstnModelList: SecurityQuestionModel[];
    intime: string;
    isLDAPEnabled: boolean;
    isdCode: string;
    language: string;
    lastName: string;
    lastUpdatedBy: string;
    levelForUser: string;
    mobile: string;
    notifyPasswordExpiryInDays: number;
    oneTimeAuth: string;
    operatingBranchCode: boolean;
    otp: boolean;
    outtime: string;
    passwordGenerationType: string;
    recordStatus: string;
    roles: Role[];
    userId: number;
    username: string;
    using2FA: boolean;
    id?: number;
}
export interface Profile {
    fileUrl: string;
}
