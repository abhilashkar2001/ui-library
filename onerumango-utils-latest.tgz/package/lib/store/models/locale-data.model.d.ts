export interface LocaleData {
    country: string;
    currency: string;
    dateFormat: string;
    locale: string;
}
