import { LocaleData } from '../models';
export declare const UserLocaleDataAction: {
    loadLocaleDataSuccess: import("@ngrx/store").ActionCreator<"[Sign In] Load Locale Data Success", (props: {
        localeData: LocaleData | null;
    }) => {
        localeData: LocaleData | null;
    } & import("@ngrx/store/src/models").TypedAction<"[Sign In] Load Locale Data Success">>;
    loadLocaleDataFailure: import("@ngrx/store").ActionCreator<"[Sign In] Load Locale Data Failure", (props: {
        error: Error | null;
    }) => {
        error: Error | null;
    } & import("@ngrx/store/src/models").TypedAction<"[Sign In] Load Locale Data Failure">>;
    removeLocaleData: import("@ngrx/store").ActionCreator<"[Sign In] Remove Locale Data", () => import("@ngrx/store/src/models").TypedAction<"[Sign In] Remove Locale Data">>;
};
