import { User } from '../models';
export declare const UserProfileAction: {
    loadUserProfile: import("@ngrx/store").ActionCreator<"[Sign In] Load User Profile", () => import("@ngrx/store/src/models").TypedAction<"[Sign In] Load User Profile">>;
    loadUserProfileSuccess: import("@ngrx/store").ActionCreator<"[Sign In] Load User Profile Success", (props: {
        user: User | null;
    }) => {
        user: User | null;
    } & import("@ngrx/store/src/models").TypedAction<"[Sign In] Load User Profile Success">>;
    loadUserProfileFailure: import("@ngrx/store").ActionCreator<"[Sign In] Load User Profile Failure", (props: {
        error: Error | null;
    }) => {
        error: Error | null;
    } & import("@ngrx/store/src/models").TypedAction<"[Sign In] Load User Profile Failure">>;
    removeUserProfile: import("@ngrx/store").ActionCreator<"[Sign In] Remove User Profile", () => import("@ngrx/store/src/models").TypedAction<"[Sign In] Remove User Profile">>;
};
