import { LocaleData } from '../store';
export declare const LocaleList: {
    country: string;
    locale: string;
}[];
export declare const DEFAULT_LOCALE: LocaleData;
