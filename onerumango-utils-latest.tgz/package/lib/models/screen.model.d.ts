export interface IScreen {
    screenCode: number;
    screenName: string;
    route?: any;
    fileUrl?: any;
    sequence: number;
    screenValue?: any;
}
export type IScreens = Array<IScreen>;
export interface IScreenInfo {
    id: number;
    processCode?: any;
    processName: string;
    fileUrl?: any;
    sequence?: any;
    screens: IScreens;
}
export type IScreenInfos = Array<IScreenInfo>;
