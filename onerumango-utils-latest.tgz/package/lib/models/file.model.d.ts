export interface FileModel {
    uuid: string;
    fileData: string;
    fileName: string;
    fileUrl: string;
    fileType: string;
    documentId: number;
    documentType: string;
    documentName: string;
    documentSide: number;
}
export interface Document {
    documentId: number;
    documentName?: any;
    documentNameValue?: any;
    documentType?: any;
    fileName: string;
    fileType: string;
    documentSide?: any;
    verificationType?: any;
    fileUrl: string;
    documentNumber?: any;
    passportNumber?: any;
    issueDate?: any;
    expiryDate?: any;
    dob?: any;
    fileData?: any;
}
