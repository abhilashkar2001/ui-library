export interface ProcessStageList {
    id: number;
    processCode?: any;
    processName: string;
    fileUrl?: any;
    sequence: number;
    screens?: any;
}
export interface IProcessStage {
    processCycleCode: string;
    processCycleName: string;
    id: number;
    processStageList: ProcessStageList[];
}
export type IProcessStages = Array<IProcessStage>;
