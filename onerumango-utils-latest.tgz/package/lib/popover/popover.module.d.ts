import * as i0 from "@angular/core";
import * as i1 from "./popover.directive";
import * as i2 from "./popover-container/popover-container.component";
import * as i3 from "@angular/cdk/overlay";
export declare class PopoverModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PopoverModule, [typeof i1.PopoverDirective, typeof i2.PopovercontainerComponent], [typeof i3.OverlayModule], [typeof i1.PopoverDirective, typeof i2.PopovercontainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PopoverModule>;
}
