import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class PopoverService {
    private state;
    getState(): Observable<boolean>;
    setState(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PopoverService>;
}
