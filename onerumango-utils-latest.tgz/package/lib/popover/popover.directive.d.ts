import { OnDestroy, OnInit, TemplateRef, ViewContainerRef, ElementRef } from '@angular/core';
import { Overlay } from '@angular/cdk/overlay';
import { PopoverService } from './popover.service';
import * as i0 from "@angular/core";
export declare class PopoverDirective implements OnDestroy, OnInit {
    private elementRef;
    private overlay;
    private vcr;
    private popoverService;
    popoverTrigger: TemplateRef<object>;
    closeOnClickOutside: boolean;
    private unsubscribe;
    private overlayRef;
    constructor(elementRef: ElementRef, overlay: Overlay, vcr: ViewContainerRef, popoverService: PopoverService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    clickou(): void;
    private createOverlay;
    private attachOverlay;
    private detachOverlay;
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PopoverDirective, "[popoverTrigger]", never, { "popoverTrigger": { "alias": "popoverTrigger"; "required": false; }; "closeOnClickOutside": { "alias": "closeOnClickOutside"; "required": false; }; }, {}, never, never, false, never>;
}
