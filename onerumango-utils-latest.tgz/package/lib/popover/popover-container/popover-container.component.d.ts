import * as i0 from "@angular/core";
export declare class PopovercontainerComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<PopovercontainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PopovercontainerComponent, "ic-popover-container", never, {}, {}, never, ["*"], false, never>;
}
