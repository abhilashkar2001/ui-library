export declare enum SessionStorageEnum {
    LANGUAGE = "LANGUAGE",
    TOKEN_KEY = "auth-token",
    IS_REMEMBER = "isRemember",
    VALIDITY_IN_SECS = "validityInSecs",
    LAST_LOGIN = "LAST_LOGIN"
}
