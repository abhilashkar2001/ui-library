export declare enum TransactionTypeEnum {
    CORPORATE_LOAN = "CORP_LOAN"
}
