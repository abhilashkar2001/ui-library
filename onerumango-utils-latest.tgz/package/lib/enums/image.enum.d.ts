export declare enum UploadImage {
    BROWSE = "Browse",
    AVATAR = "Avatar"
}
