export declare enum WorkflowAction {
    SUBMIT = "Submit",
    APPROVE = "Approve",
    COMPLETE = "Complete",
    REJECT = "Reject",
    CONFIRM = "Confirm",
    SENDLINK = "Send Link"
}
