import * as i0 from "@angular/core";
import * as i1 from "./safe.pipe";
import * as i2 from "./currency-symbol.pipe";
import * as i3 from "./control.pipe";
import * as i4 from "./form-group.pipe";
import * as i5 from "./form-array.pipe";
export declare class LibPipesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LibPipesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LibPipesModule, [typeof i1.SafePipe, typeof i2.CurrencySymbolPipe, typeof i3.ControlAsFormControlPipe, typeof i4.FormControlPipe, typeof i5.FormArrayPipe], never, [typeof i1.SafePipe, typeof i2.CurrencySymbolPipe, typeof i3.ControlAsFormControlPipe, typeof i4.FormControlPipe, typeof i5.FormArrayPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LibPipesModule>;
}
