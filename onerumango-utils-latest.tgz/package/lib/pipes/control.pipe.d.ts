import { PipeTransform } from '@angular/core';
import { AbstractControl, FormControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ControlAsFormControlPipe implements PipeTransform {
    transform(control: AbstractControl | undefined | any): FormControl;
    static ɵfac: i0.ɵɵFactoryDeclaration<ControlAsFormControlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ControlAsFormControlPipe, "controlAsFormControl", false>;
}
