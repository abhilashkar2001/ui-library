import { PipeTransform } from '@angular/core';
import { SafePipeType } from '../types/safe';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { IEnvironment } from '../types';
import * as i0 from "@angular/core";
export declare class SafePipe implements PipeTransform {
    private domSanitizer;
    private http;
    private environment;
    constructor(domSanitizer: DomSanitizer, http: HttpClient, environment: IEnvironment);
    transform(value: string, type: SafePipeType): Observable<SafeUrl | null>;
    private getImageBlobUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<SafePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SafePipe, "safe", false>;
}
