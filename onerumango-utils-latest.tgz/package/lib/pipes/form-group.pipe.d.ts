import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FormControlPipe implements PipeTransform {
    transform(value: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormControlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FormControlPipe, "formgroup", false>;
}
