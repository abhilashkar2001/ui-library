import { PipeTransform } from '@angular/core';
import { currencyList } from '@onerumango/icust-element-library';
import * as i0 from "@angular/core";
export declare class CurrencySymbolPipe implements PipeTransform {
    currencyList: {
        [x: string]: import("@onerumango/icust-element-library").CurrencyFormat;
    };
    transform(value: keyof typeof currencyList): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencySymbolPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CurrencySymbolPipe, "currencySymbol", false>;
}
