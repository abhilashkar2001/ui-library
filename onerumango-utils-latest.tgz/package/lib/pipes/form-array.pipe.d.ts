import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FormArrayPipe implements PipeTransform {
    transform(value: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormArrayPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FormArrayPipe, "formarray", false>;
}
